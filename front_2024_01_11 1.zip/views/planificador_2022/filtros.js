function CambiaEditableController(rut, division, valor){
    

    var campos = {

        "rut" : rut,
        "division" : division,

        "valor" : valor
    };

    $.ajax({
        data : campos,
        url : '?sw=ModificaEditableController',
        type : 'post',
        beforeSend : function() {
           /* $("#back").show();
            $("#loader").show();*/
        },
        success : function(response) {
         /*   $("#back").hide();
            $("#loader").hide();
            $("#IconoEstado_"+cui+"_"+cargo+"_"+mes+"_"+ano).html(response);*/
        }
    });

    alert("Edicion modificada");

}

function Rechazar_PL(cargo, cui, mes, ano)
{

    var campos = {

        "cui" : cui,
        "cargo" : cargo,

        "mes" : mes,
        "ano" : ano
    };

    $.ajax({
        data : campos,
        url : '?sw=ActualizaEstadoParaCombinacionCuiCargoR',
        type : 'post',
        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
        },

        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#IconoEstado_"+cui+"_"+cargo+"_"+mes+"_"+ano).html(cleanResponse);
        }



    });

}



function GuardaComentarioControllerAdmin(cargo, cui, comentario){


    var campos = {

        "cui" : cui,
        "cargo" : cargo,
        "comentario" : comentario
    };

    $.ajax({
        data : campos,
        url : '?sw=GuardaComentarioPorControllerAdmin',
        type : 'post',
        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#IconoEstadoComentarioControllesAdmin_"+cui+"_"+cargo).html(cleanResponse);
        }

    });




}


function GuardaComentarioController(cargo, cui, comentario){


    var campos = {

        "cui" : cui,
        "cargo" : cargo,
        "comentario" : comentario
    };

    $.ajax({
        data : campos,
        url : '?sw=GuardaComentarioPorController',
        type : 'post',
        beforeSend : function() {
            /*$("#back").show();
            $("#loader").show();*/
        },
        success: (response) => {

            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#IconoEstadoComentarioControlles_"+cui+"_"+cargo).html(cleanResponse);
        }

    });




}





function Aprobar_PL(cargo, cui, mes, ano)
{

    var campos = {

        "cui" : cui,
        "cargo" : cargo,

        "mes" : mes,
        "ano" : ano
    };

    $.ajax({
        data : campos,
        url : '?sw=ActualizaEstadoParaCombinacionCuiCargo',
        type : 'post',
        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#IconoEstado_"+cui+"_"+cargo+"_"+mes+"_"+ano).html(cleanResponse);
        }
    });

}


function GuardaVal(valor1, valor2, valor3, cui, cargo){

    var campos = {
        "ano" : valor1,
        "mes" : valor2,
        "cui" : cui,
        "cargo" : cargo,
        "cantidad" : valor3
    };
    $.ajax({
        data : campos,
        url : '?sw=colocaDatosPlanificacion',
        type : 'post',
        beforeSend : function() {
            /*$("#back").show();
            $("#loader").show();*/
        },
        success: (response) => {
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#"+valor1+"_"+valor2+"_"+cui+"_"+cargo).html(cleanResponse);
        }
    });

}




function MueveDivision(){
    division = $("#division").val();
    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_area",
        "campo_a_buscar_id" : "area"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("area").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#area").html(cleanResponse);
            document.getElementById("area").disabled = false;
        }
    });


    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_departamento",
        "campo_a_buscar_id" : "departamento"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("departamento").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#departamento").html(cleanResponse);
            document.getElementById("departamento").disabled = false;
        }
    });


    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_zona",
        "campo_a_buscar_id" : "zona"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("zona").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#zona").html(cleanResponse);
            document.getElementById("zona").disabled = false;
        }
    });




    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_seccion",
        "campo_a_buscar_id" : "seccion"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("seccion").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#seccion").html(cleanResponse);
            document.getElementById("seccion").disabled = false;
        }
    });

    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_oficina",
        "campo_a_buscar_id" : "oficina"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("oficina").disabled = true;

        },success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#oficina").html(cleanResponse);
            document.getElementById("oficina").disabled = false;
        }

    });


    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_cui",
        "campo_a_buscar_id" : "cui"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("unidad").disabled = true;

        },


        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#unidad").html(cleanResponse);
            document.getElementById("unidad").disabled = false;
        }
    });





    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_cargo",
        "campo_a_buscar_id" : "cargo"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("cargo").disabled = true;

        },


        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#cargo").html(cleanResponse);
            document.getElementById("cargo").disabled = false;
        }
    });





}

//AREA


function MueveArea(){
    division = $("#division").val();
    area = $("#area").val();

    var campos = {
        "division" : division,
        "area" : area,
        "campo_filtrado" : "descripcion_departamento",
        "campo_a_buscar_id" : "departamento"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_area',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("departamento").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#departamento").html(cleanResponse);
            document.getElementById("departamento").disabled = false;
        }
    });



    var campos = {
        "division" : division,
        "area" : area,
        "campo_filtrado" : "descripcion_zona",
        "campo_a_buscar_id" : "zona"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_area',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("zona").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#zona").html(cleanResponse);
            document.getElementById("zona").disabled = false;
        }
    });

    var campos = {
        "division" : division,
        "area" : area,
        "campo_filtrado" : "descripcion_seccion",
        "campo_a_buscar_id" : "seccion"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_area',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("seccion").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#seccion").html(cleanResponse);
            document.getElementById("seccion").disabled = false;
        }
    });


    var campos = {
        "division" : division,
        "area" : area,
        "campo_filtrado" : "descripcion_oficina",
        "campo_a_buscar_id" : "oficina"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_area',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("oficina").disabled = true;

        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#oficina").html(cleanResponse);
            document.getElementById("oficina").disabled = false;
        }
    });



    var campos = {
        "division" : division,
        "area" : area,
        "campo_filtrado" : "descripcion_cui",
        "campo_a_buscar_id" : "cui"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_area',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("unidad").disabled = true;

        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#unidad").html(cleanResponse);
            document.getElementById("unidad").disabled = false;
        }
    });



}


//DEPARTAMENTO

function MueveDepartamento() {

    division = $("#division").val();
    area = $("#area").val();
    departamento = $("#departamento").val();

  var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "campo_filtrado" : "descripcion_zona",
        "campo_a_buscar_id" : "zona"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_departamento',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("zona").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#zona").html(cleanResponse);
            document.getElementById("zona").disabled = false;
        }
    });



    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "campo_filtrado" : "descripcion_seccion",
        "campo_a_buscar_id" : "seccion"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_departamento',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("seccion").disabled = true;
        },
        success: (response) => {
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#seccion").html(cleanResponse);
            document.getElementById("seccion").disabled = false;
        }
    });

    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "campo_filtrado" : "descripcion_oficina",
        "campo_a_buscar_id" : "oficina"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_departamento',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("oficina").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#oficina").html(cleanResponse);
            document.getElementById("oficina").disabled = false;
        }
    });


    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "campo_filtrado" : "descripcion_cui",
        "campo_a_buscar_id" : "cui"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_departamento',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("unidad").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#unidad").html(cleanResponse);
            document.getElementById("unidad").disabled = false;
        }
    });



}



//ZONA
function MueveZONA() {

    division = $("#division").val();
    area = $("#area").val();
    departamento = $("#departamento").val();
    zona = $("#zona").val();

    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "zona" : zona,
        "campo_filtrado" : "descripcion_seccion",
        "campo_a_buscar_id" : "seccion"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_zona',
        type : 'post',


        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("seccion").disabled = true;
        },

        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#seccion").html(cleanResponse);
            document.getElementById("seccion").disabled = false;
        }
    });



    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "zona" : zona,
        "campo_filtrado" : "descripcion_oficina",
        "campo_a_buscar_id" : "oficina"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_zona',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("oficina").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#oficina").html(cleanResponse);
            document.getElementById("oficina").disabled = false;
        }
    });


    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "zona" : zona,
        "campo_filtrado" : "descripcion_cui",
        "campo_a_buscar_id" : "cui"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_zona',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("unidad").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#unidad").html(cleanResponse);
            document.getElementById("unidad").disabled = false;
        }
    });


}


//Seccion
function MueveSeccion() {

    division = $("#division").val();
    area = $("#area").val();
    departamento = $("#departamento").val();
    zona = $("#zona").val();
    seccion = $("#seccion").val();

    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "zona" : zona,
        "seccion" : seccion,
        "campo_filtrado" : "descripcion_oficina",
        "campo_a_buscar_id" : "oficina"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_seccion',
        type : 'post',


        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("oficina").disabled = true;
        },

        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#oficina").html(cleanResponse);
            document.getElementById("oficina").disabled = false;
        }
    });



    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "zona" : zona,
        "seccion" : seccion,
        "campo_filtrado" : "descripcion_cui",
        "campo_a_buscar_id" : "cui"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_seccion',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("unidad").disabled = true;
        },
        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#unidad").html(cleanResponse);
            document.getElementById("unidad").disabled = false;
        }
    });




}



//Seccion
function MueveOficina() {

    division = $("#division").val();
    area = $("#area").val();
    departamento = $("#departamento").val();
    zona = $("#zona").val();
    seccion = $("#seccion").val();
    oficina = $("#oficina").val();

    var campos = {
        "division" : division,
        "area" : area,
        "departamento" : departamento,
        "zona" : zona,
        "seccion" : seccion,
        "oficina" : oficina,
        "campo_filtrado" : "descripcion_cui",
        "campo_a_buscar_id" : "cui"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_oficina',
        type : 'post',


        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("unidad").disabled = true;
        },

        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#unidad").html(cleanResponse);
            document.getElementById("unidad").disabled = false;
        }
    });







}







function MueveDivisionCuiCargo(){
    division = $("#division").val();






    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_cui",
        "campo_a_buscar_id" : "cui"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_division_con_codigo',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("unidad").disabled = true;

        },


        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#unidad").html(cleanResponse);
            document.getElementById("unidad").disabled = false;
        }
    });





    var campos = {
        "division" : division,

        "campo_filtrado" : "descripcion_cargo",
        "campo_a_buscar_id" : "cargo"
    };
    $.ajax({
        data : campos,
        url : '?sw=filtro_por_divisionSoloCargo',
        type : 'post',

        beforeSend : function() {
            $("#back").show();
            $("#loader").show();
            document.getElementById("cargo").disabled = true;

        },


        success: (response) => {
            $("#back").hide();
            $("#loader").hide();
            let cleanResponse = convertHtmlToJQueryObject(response, true, false);
            $("#cargo").html(cleanResponse);
            document.getElementById("cargo").disabled = false;
        }
    });





}


function ExportarAExcel1(){


      /*  swal({
        title : "¡Importante!",
        text : "Se consideran solo los casos aprobados en la exportacion a excel"
    });
*/
    if(confirm('Se consideran solo los casos aprobados en la exportacion a excel.\nAdemas los casos pendientes de aprobación aparecerán como ceros')){
        document.getElementById("ex").value = "1";
        document.getElementById("form01").submit();
        document.getElementById("ex").value = "";
    }else{

    }




}



function ExportarAExcel2(){


    document.getElementById("ex").value = "1";
    document.getElementById("form02").submit();
    document.getElementById("ex").value = "";

}