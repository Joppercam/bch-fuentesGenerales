export default {
	"generic": {
		'loading': "Cargando",
		'previous': "Anterior",
		'next': "Siguiente",
		'calender': "Calendario 2018",
		'today': "Hoy",
		'week': "Semana",
		'add_event': "Add Event",
		'select_language': "Select language",
	},
}