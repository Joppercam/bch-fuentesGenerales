import en from './en';
import ar from './ar';
import de from './de';

export default {
	"en": en,
	"ar": ar,
	"de": de,
};
