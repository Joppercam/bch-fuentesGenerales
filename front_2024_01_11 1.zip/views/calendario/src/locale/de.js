export default {
	"generic": {
		'loading': "Laden",
		'previous': "Vorheriger",
		'next': "Nächster",
		'calender': "Kalender",
		'today': "Heute",
		'week': "Woche",
		'add_event': "Event hinzufügen",
		'select_language': "Sprache Auswählen",
	},
}