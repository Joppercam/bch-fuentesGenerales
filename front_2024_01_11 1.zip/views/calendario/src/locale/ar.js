export default {
	"generic": {
		'loading': "جار التحميل",
		'previous': "السابق",
		'next': "التالى",
		'calender': "التقويم",
		'today': "اليوم",
		'week': "الأسبوع",
		'add_event': "أضف مناسبة",
		'select_language': "اختر اللغة",
	},
}