var Calendar = require('./Calendar.vue').default;
var messages = require('./locale').default;

module.exports =  {
    Calendar:Calendar,
    messages: messages
};