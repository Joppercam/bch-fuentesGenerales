<?php 
	if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];

    //ini_set('display_errors', 1);ini_set('display_startup_errors', 1);error_reporting(E_ALL);
    //error_reporting(E_ERROR | E_PARSE);
    require_once ("includes/include.php");
    ini_set('session.cookie_httponly',1);
    ini_set('session.use_only_cookies',1);
    session_start();
    header("Content-Security-Policy: script-src 'self';");

    $arreglo_post       = $_POST;
    $arreglo_get        = $_GET;
    $arreglo_request    = $_REQUEST;
  	$_POST      = VerificaArregloSQLInjectionV2($arreglo_post);
	$_GET       = VerificaArregloSQLInjectionV2($arreglo_get);
	$_REQUEST   = VerificaArregloSQLInjectionV2($arreglo_request);
    // echo " <br />POST despues";//print_r($_POST);//exit;//echo $_GET["sw"]." <--><br />";
    $seccion = (($_GET["sw"]));
    $seccion = str_replace("%", "", $seccion);
    $seccion = str_replace("'", "", $seccion);
    $seccion = str_replace('"', '', $seccion);
    $seccion = str_replace(' ', '', $seccion);
    $seccion = str_replace(" ", "", $seccion);
		//echo "<br />"; print_r($_SESSION);echo "<br />PHP_SELF ";echo $_SERVER['PHP_SELF'];echo "<br />SERVER_NAME ";echo $_SERVER['SERVER_NAME'];echo "<br />HTTPS ";echo $_SERVER['HTTPS'];echo "<br />HTTP_HOST ";echo $_SERVER['HTTP_HOST'];echo "<br />";
      if ($_SERVER['HTTPS'] == 'on') {
        $https = 1;
    }
    if (strpos($_SERVER['SERVER_NAME'], 'www.') !== false) {
        $wwwok = 1;
    } //echo "<br>https $https wwwok $wwwok";//sleep(5);
    if (!$seccion) {
        session_start();
        $_SESSION = array();
        if (isset($_COOKIE[session_name() ])) {
            setcookie(session_name() , '', time() - 42000, '/','secure','httpOnly');
        }
        session_destroy();
        // echo "destruye";    //echo "".$url_front."views/home/login.html";
        if ($https <> 1 and $wwwok <> 1) {
            echo "    <script>location.href='" . $url_front . "';    </script>";
        }
          //		echo "<br>	Viene con www y https	<br>";
         	// 		echo  "" . $url_front . "/front/views/home/login.html"; sleep(5);
    			//    $PRINCIPAL = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login.html"));
        $PRINCIPAL = FuncionesTransversales(file_get_contents("views/home/login.html"));
        $token_fecha_hora = Encodear3(date("Y-m-d") . " " . date("H:i:s"));
        $PRINCIPAL = str_replace("{TOKEN_FECHA_HORA}", $token_fecha_hora, $PRINCIPAL);
        session_start();
        $_SESSION["token"] = $token_fecha_hora;
        // print_r($_SESSION);
        echo $PRINCIPAL;
        exit();
    }

if (isset($_GET["ide"]) && $_GET["ide"] !== '') {
    $decodedIde = Decodear3($_GET["ide"]);
    $siesempresa = Verificasiesempresa($decodedIde);
    if ($siesempresa == 1) {
        $_SESSION["id_empresa"] = $decodedIde;
    }
}

    if ($_SESSION["id_empresa"]) {
        $id_empresa = $_SESSION["id_empresa"];
    }
    // BUSCADOR BIBLIOTECA
    if (isset($_GET['busca_archivos'])) {
        $PRINCIPAL = ListadoNoticias(FuncionesTransversales(file_get_contents("views/biblioteca/entorno.html")) , $id_empresa, "", "");
        $PRINCIPAL = BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
        $PRINCIPAL = str_replace("{ENTORNO_BIBLIOTECA}", biblioteca_archivos_busqueda(FuncionesTransversales(file_get_contents("views/biblioteca/resultados.html")) , $_GET['busca_archivos'], $id_empresa) , $PRINCIPAL);
        echo $PRINCIPAL;
        exit;
    }
    if (!empty($_SESSION["user_"]) && !empty($_SESSION["id_empresa"])) {
        $valida_usuario_logueado = UsuarioEnBasePersonaPorEmpresa($_SESSION["user_"], $_SESSION["id_empresa"]);
    }


    // echo "valida_usuario_logueado $valida_usuario_logueado";
    // print_r($valida_usuario_logueado);
    /*if(count($valida_usuario_logueado)==0){
    $PRINCIPAL=FuncionesTransversales(file_get_contents("views/home/login.html"));
    echo $PRINCIPAL;
    exit;
    }*/
    // echo "<br />$seccion, $id_empresa"; exit();
    ValidarSesion($seccion, $id_empresa, $url_front);
if (!$seccion) {
    // Unset and destroy the session to ensure a clean start
    session_start();
    session_unset();
    session_destroy();

    // Clear session cookies
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 42000, '/');
    }
    // Sanitize the token before including it in the output
    $token_fecha_hora = Encodear3(date("Y-m-d") . " " . date("H:i:s"));
    $token_fecha_hora = htmlspecialchars($token_fecha_hora, ENT_QUOTES, 'UTF-8');

    // Load the content from the file and apply necessary replacements
    $PRINCIPAL = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login.html"));
    $PRINCIPAL = str_replace("{TOKEN_FECHA_HORA}", $token_fecha_hora, $PRINCIPAL);

    // Start a new session and store the sanitized token
    session_start();
    $_SESSION["token"] = $token_fecha_hora;

    echo $PRINCIPAL;
}
else if ($seccion == "ext_Desk") {
    $redirect_url = htmlspecialchars("?sw=com_vota_canjea", ENT_QUOTES, 'UTF-8');
    echo "<script>window.location='{$redirect_url}'</script>";
    exit;
}
else if ($seccion == "prevCa") {
       // print_r($_SESSION);
        session_start();
        
        $PRINCIPAL = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login_captcha.html"));
        $token_fecha_hora = Encodear3(date("Y-m-d") . " " . date("H:i:s"));
        $PRINCIPAL = str_replace("{TOKEN_FECHA_HORA}", $token_fecha_hora, $PRINCIPAL);
        session_start();
        echo $PRINCIPAL;
}
else if ($seccion == "logexternos") {
    unset($_SESSION);
    session_start();
    $_SESSION = array();
    if (isset($_COOKIE[session_name() ])) {
        setcookie(session_name() , '', time() - 42000, '/');
    }
    session_destroy();
    $_SESSION["id_empresa"]="78";
    $PRINCIPAL = FuncionesTransversales(file_get_contents("views/home/login_externos.html"),"");
    echo $PRINCIPAL;
}
else if ($seccion == "entrada_matriz_externos") {

    if($_POST["user"]<>""){
        $excepcion=LogExcepciones($_POST["user"]);
    } else {
        exit("#err_009");
    }

    //echo "<br>Excepcion ".$excepcion; print_r($_POST);
    if($excepcion>0 and $_POST["newpass"]=="123456789a"){
            //echo "a1";
        session_start();
        $_SESSION["user_"] = $_POST["user"];
        $_SESSION["id_empresa"] = "78";
            //echo "B";
            //print_r($_SESSION);
            //echo "c";
        header("Location: ?sw=com_vota_canjea");
        exit;
            //echo "d";
        //echo "<script>location.href='?sw=home_misprogramas_2020';</script>";exit;
    } else {
    }
    exit("#err_010");
}
else if ($seccion == "ver_sesion_usuario") {
    if ($_SESSION["user_"] == "12345") {
        // Do something if the user is "12345"
    } else {
        echo "<script>location.href='https://masconectadosbch.cl';</script>";
        exit();
    }

    $rut_enviado = $_GET["rut_enviado"];

    if (filter_var($rut_enviado, FILTER_SANITIZE_NUMBER_INT) == "") {
        echo "<script>location.href='https://masconectadosbch.cl';</script>";
        exit();
    }

    $_SESSION["user_"] = $rut_enviado;
    $escaped_rut_enviado = htmlspecialchars($rut_enviado, ENT_QUOTES, 'UTF-8');

    echo "<script>
              alert('Ingresando a vista de " . $escaped_rut_enviado . "');
              location.href='https://www.bancodepuntosbch.cl/front/?sw=com_vota_canjea';
          </script>";
    exit();
}
else if($seccion=="entradaCap"){

        session_start();
       // print_r($_SESSION);
		
		
				$valor=$_POST["captcha"];

				
				//GOOGLE CAPTCHA
					class ReCaptchaResponse
					{
						public $success;
						public $errorCodes;
					}
					class ReCaptcha
					{
						private static $_signupUrl = "https://www.google.com/recaptcha/admin";
						private static $_siteVerifyUrl =
							"https://www.google.com/recaptcha/api/siteverify?";
						private $_secret;
						private static $_version = "php_1.0";
						/**
						 * Constructor.
						 *
						 * @param string $secret shared secret between site and ReCAPTCHA server.
						 */
						function ReCaptcha($secret)
						{
							if ($secret == null || $secret == "") {
								die("To use reCAPTCHA you must get an API key from <a href='"
									. self::$_signupUrl . "'>" . self::$_signupUrl . "</a>");
							}
							$this->_secret=$secret;
						}
						/**
						 * Encodes the given data into a query string format.
						 *
						 * @param array $data array of string elements to be encoded.
						 *
						 * @return string - encoded request.
						 */
						private function _encodeQS($data)
						{
							$req = "";
							foreach ($data as $key => $value) {
								$req .= $key . '=' . urlencode(stripslashes($value)) . '&';
							}
							// Cut the last '&'
							$req=substr($req, 0, strlen($req)-1);
							return $req;
						}
						/**
						 * Submits an HTTP GET to a reCAPTCHA server.
						 *
						 * @param string $path url path to recaptcha server.
						 * @param array  $data array of parameters to be sent.
						 *
						 * @return array response
						 */
						private function _submitHTTPGet($path, $data)
						{
							$req = $this->_encodeQS($data);
							$response = file_get_contents($path . $req);
							return $response;
						}
						/**
						 * Calls the reCAPTCHA siteverify API to verify whether the user passes
						 * CAPTCHA test.
						 *
						 * @param string $remoteIp   IP address of end user.
						 * @param string $response   response string from recaptcha verification.
						 *
						 * @return ReCaptchaResponse
						 */
						public function verifyResponse($remoteIp, $response)
						{
							// Discard empty solution submissions
							if ($response == null || strlen($response) == 0) {
								$recaptchaResponse = new ReCaptchaResponse();
								$recaptchaResponse->success = false;
								$recaptchaResponse->errorCodes = 'missing-input';
								return $recaptchaResponse;
							}
							$getResponse = $this->_submitHttpGet(
								self::$_siteVerifyUrl,
								array (
									'secret' => $this->_secret,
									'remoteip' => $remoteIp,
									'v' => self::$_version,
									'response' => $response
								)
							);
							$answers = json_decode($getResponse, true);
							$recaptchaResponse = new ReCaptchaResponse();
							if (trim($answers ['success']) == true) {
								$recaptchaResponse->success = true;
							} else {
								$recaptchaResponse->success = false;
								$recaptchaResponse->errorCodes = $answers [error-codes];
							}
							return $recaptchaResponse;
						}
					} 
					// Get a key from https://www.google.com/recaptcha/admin/create
					 if ($_POST["g-recaptcha-response"]) {
						 //ini_set('display_errors', 1);ini_set('display_startup_errors', 1);error_reporting(E_ALL);
						  $secret = "";
						  $response = null;
						 // comprueba la clave secreta
						 $reCaptcha = new ReCaptcha($secret);
						 $response = $reCaptcha->verifyResponse(
						 $_SERVER["REMOTE_ADDR"],
						 $_POST["g-recaptcha-response"]
						 );
						 if ($response != null && $response->success) {
						// Si el c&oacute;digo es correcto, seguimos procesando el formulario como siempre
						//exit("si");
$rut	=Decodear3($_SESSION["toku"]);
$clave	=Decodear3($_SESSION["tokc"]);




//echo "rut $rut, clave $clave";
$existe_base = UsuarioEnBasePersonas($rut, $rutcontodo);
//print_r($existe_base);
	if ($existe_base) {
		$rut = $existe_base[0]->rut;
		if ($existe_base[0]->vigencia == 1) {
			echo "<script>    window.location='?sw=logout'    </script>";
			exit;
		}
		$total_intentos = 3;
		$verifica_clave = VerificaClaveAcceso($rut, $clave);
		if ($verifica_clave) {
			// INGRESO CORRECTO
$_SESSION["user_"] = $rut;
			InsertTblAnalitica($rut, $existe_base[0]->id_empresa, "LOGIN", "LoginRut");
			if (($verifica_clave[0]->cambiado == "0" or $verifica_clave[0]->clave_encodeada == "") and $word == '') {
				session_start();
				$_SESSION["user_"] = $rut;
				$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
				echo "    <script>    location.href='?sw=chp';    </script>";
				exit;
			}
			else {
				session_start();
				$_SESSION["user_"] = $rut;
				$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
				ValidarSesion("visitas", $_SESSION["id_empresa"]);
				$datos_empresa = DatosEmpresa($existe_base[0]->id_empresa);
				$intentos_fallidos = TraeIntendosAccesosFallidos($rut);
				//echo "intento fallido $intentos_fallidos";
				$intentos_restantes = $total_intentos - count($intentos_fallidos);
				
				
					echo "
<script>location.href='?sw=" . $datos_empresa[0]->case_home . "';</script>";
					exit;
				
			}
		}
		else {
			// CLAVE INCORRECTA
			session_start();

				echo "<script>location.href='https://www.masconectadosbch.cl';</script>";
				exit;
			
		}
	}
				else   
					{
						echo " <script>alert('Ups, las credenciales no son correctas'); location.href='?sw=logout';    </script>";exit;
					}
		}		
	} else {
			echo "<script>location.href='https://www.masconectadosbch.cl';</script>";
				exit;	
		
	}
}



	else if ($seccion == "entrada") {
		
		
		if(isset($_POST['post'])) {
		// print_r($_POST);
		$url = "https://www.google.com/recaptcha/api/siteverify";
		$data = [
			'secret' => "",
			'response' => $_POST['token'],
			// 'remoteip' => $_SERVER['REMOTE_ADDR']
		];

		$options = array(
		    'http' => array(
		      'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
		      'method'  => 'POST',
		      'content' => http_build_query($data)
		    )
		  );

		$context  = stream_context_create($options);
  		$response = file_get_contents($url, false, $context);

		$res = json_decode($response, true);
		if($res['success'] == true) {

			// Perform you logic here for ex:- save you data to database
  			/*echo '<div class="alert alert-success">
			  		<strong>Success!</strong> Your inquiry successfully submitted.
		 		  </div>';*/
		} else {
			echo "
				<script>
				alert('Ups, las credenciales no son correctas');
				location.href='https://www.bancodepuntosbch.cl/';
				</script>";
				exit;
		}
	}
	
	
	
	$id_empresa_desde_login = Decodear3($_POST["iem"]);
	$rut = (trim($_POST["user"]));
	$rut = htmlentities(trim($rut));
	
	
    $rut_enviado_enc = Decodear7($_GET["rutenc"]);
    if($rut_enviado_enc<>""){

    $token = ($_GET["token"]);
		//echo "hola $rut_enviado_enc, $token"; 

    $secret = "";
    $word = $rut_enviado_enc . $secret;
    $token_hash = hash('sha256', $word);  	
    if($token_hash<>$token){
    	 echo "    <script>         location.href='https://masconectadosbch.cl';     </script>"; exit;
    }
    //echo "<br>token hash ".$token_hash;
    }
    
	$total_intentos=3;
	$clave = (trim($_POST["newpass"]));
	$clave = htmlentities(trim($clave));
	$word = trim($_GET["word"]);
	$tema = Decodear3(trim(($_POST["tema"])));
	$rutcontodo = str_replace(" ", "", $rut);
	$rut = str_replace(".", "", $rut);
	$rut = str_replace(" ", "", $rut);
	$arreglo_rut = explode("-", $rut);
	$rut = $arreglo_rut[0];
	   
	//echo "rut $rut";
	if($rut=="" and $rut_enviado_enc<>''){$rut=$rut_enviado_enc;}	

	$existe_base = UsuarioEnBasePersonas($rut, $rutcontodo);
	//print_r($existe_base);
	//exit();
	if ($existe_base) {
		$rut = $existe_base[0]->rut;
		if ($existe_base[0]->vigencia == 1) {
			echo "<script>    window.location='?sw=logout'    </script>";
			exit;
		}
		$total_intentos = 3;
		$verifica_clave = VerificaClaveAcceso($rut, $clave);
		
		
if($rut_enviado_enc<>''){          
	$clave_rut_enc=buscaclaveEncodeardarut($rut_enviado_enc, $id_empresa);
	//echo 
	//$clave=$clave_rut_enc[0]->clave;
	//$clave=Decodear3($clave_rut_enc[0]->clave_encodeada);
	//echo "clave $clave"; exit();
	$verifica_clave = VerificaClaveAccesoEncryot($rut, $clave_rut_enc[0]->clave_encodeada);

}
else {
 
$verifica_clave = VerificaClaveAcceso($rut, $clave);


}		
		
		//echo "<br>rut $rut, clave ";
		//print_r($verifica_clave); exit();
		if ($verifica_clave) {

			// INGRESO CORRECTO
			session_start();
			$_SESSION["user_"] = $rut;
			$_SESSION["id_empresa"] = 81;
			//print_r($_SESSION);
			InsertTblAnalitica($rut, $existe_base[0]->id_empresa, "LOGIN", "LoginRut");
			if (($verifica_clave[0]->cambiado == "0" or $verifica_clave[0]->clave_encodeada == "") and $word == '') {
				session_start();
				$_SESSION["user_"] = $rut;
				$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
				echo "    <script>    location.href='?sw=chp';    </script>";
				exit;
			}
			else {
				session_start();
				
				$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
				ValidarSesion("visitas", $_SESSION["id_empresa"]);
				$datos_empresa = DatosEmpresa($existe_base[0]->id_empresa);
				$intentos_fallidos = TraeIntendosAccesosFallidos($rut);
				//echo "intento fallido $intentos_fallidos";
				$intentos_restantes = $total_intentos - count($intentos_fallidos);
				if ($intentos_restantes < 0) {
					$intentos_restantes = 0;
				}

				if ($intentos_restantes === 0) {
					$_SESSION["toku"] = Encodear3($rut);
					$_SESSION["tokc"] = Encodear3($clave);
					echo "<script>location.href='?sw=prevCa';</script>";
					exit;
				}
				else {
					
					echo "
<script>location.href='?sw=" . $datos_empresa[0]->case_home . "';</script>";
					exit;
				}
			}
		}
		else {

			// CLAVE INCORRECTA
			//echo "aca";
			session_start();
			$_SESSION["toku"] = Encodear3($rut);
			$_SESSION["tokc"] = Encodear3($clave);
			$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
			InsertaAccesoIntento($rut);
			$intentos_fallidos = TraeIntendosAccesosFallidos($rut);
			$intentos_restantes = $total_intentos - count($intentos_fallidos);
			//echo "intentos_restantes $intentos_restantes";
			if ($intentos_restantes < 0) {
				$intentos_restantes = 0;
				
			}

			if ($intentos_restantes === 0) {
				echo "<script>location.href='?sw=prevCa';</script>";
				exit;
			} else {
				echo " <script>alert('Ups, las credenciales no son correctas'); location.href='?sw=logout';    </script>";exit;
			}
		}
	}
	else {
		
		echo "<script>location.href='?sw=prevCa';</script>";
				exit;
		//echo " <script>alert('Ups, las credenciales no son correctas'); location.href='?sw=logout';    </script>";exit;
	}
}

else if($seccion=="logsso"){
	
	 $PRINCIPAL = FuncionesTransversales(file_get_contents("views/home/login_sso.html"));
        $token_fecha_hora = Encodear3(date("Y-m-d") . " " . date("H:i:s"));
        $PRINCIPAL = str_replace("{TOKEN_FECHA_HORA}", $token_fecha_hora, $PRINCIPAL);
        session_start();
        $_SESSION["token"] = $token_fecha_hora;
        echo $PRINCIPAL;
		
		
}

elseif ($seccion == "LogEmail") {
    //session_destroy();
    //session_start();
    $_SESSION["id_empresa"] = "78";
    $email = DecodearEmail($_REQUEST["email"]);
    $email_request=$_REQUEST["email"];
    if($email==""){
        $error="BP Email Error Vacio #01 ";
        LogEmail_Log_Login_data_home($email, $email_request, $rut, $error);
        echo "   <script> location.href='https://www.bancodepuntosbch.cl/'; </script>";	exit();
    }
    $rut_usuario = VerificaUsuarioEmail($email, $_SESSION["id_empresa"]);
    if($rut_usuario==""){
        $error="BP Email Error Vacio #02";
        LogEmail_Log_Login_data_home($email, $email_request, $rut_usuario, $error);
        $rut_usuario = VerificaUsuarioEmailBK($email, $_SESSION["id_empresa"]);
        if($rut_usuario==""){
            $error="BP Email Error Vacio #03";
            LogEmail_Log_Login_data_home($email, $email_request, $rut_usuario, $error);
            echo "   <script> location.href='https://www.bancodepuntosbch.cl/'; </script>";
            exit();
        } else {
            $error="BP Ok #01_1";
            LogEmail_Log_Login_data_home($email, $email_request, $rut_usuario, $error);
            $_SESSION["user_"] = $rut_usuario;
            echo "   <script> location.href='?sw=com_vota_canjea'; </script>";
            exit();
        }
        $error="BP Email Error Vacio #04";
        LogEmail_Log_Login_data_home($email, $email_request, $rut_usuario, $error);
        echo "   <script> location.href='https://www.bancodepuntosbch.cl/'; </script>";
        exit();
    } else {
        $error="BP Ok #01_2";
        LogEmail_Log_Login_data_home($email, $email_request, $rut_usuario, $error);
        $_SESSION["user_"] = $rut_usuario;
        echo "   <script> location.href='?sw=com_vota_canjea'; </script>";
        exit();
    }
    $error="BP Email Error Vacio #04";
    LogEmail_Log_Login_data_home($email, $email_request, $rut_usuario, $error);
    echo "    <script>         location.href='?sw=login';     </script>";
    exit();
}

  else if ($seccion == "entrada_token") {

  	$t = Decodeartk($_GET["t"]);
    $tk = explode("-", $t);
    if ($tk[1] > 0) {
        $token = Encodeartk($tk[1]);
    } else {
    		echo " <script>location.href='https://www.bancodepuntosbch.cl/';</script>";
        exit();
    }
    $fecha_hoy = date("ymdhi");
    $resto = $fecha_hoy - $tk[0];
    if ($resto >= 0 and $resto < 6) {
    } else {
        echo " <script>location.href='https://www.bancodepuntosbch.cl/';</script>";
        exit;
    }
    $_SESSION["user_"] = $token;
    if ($_SESSION["user_"] <> "") {
    } else {
    		echo " <script>location.href='https://www.bancodepuntosbch.cl/';</script>";
        exit();
    }
     if ($tk[2] <> "") {
    		$_SESSION["perfil"]=$tk[2];    
    } else {
    		echo " <script>location.href='https://www.bancodepuntosbch.cl/';</script>";
        exit();
    }
    
    		echo " <script>location.href='?sw=com_vota_canjea';</script>";
   		 	exit();

}

  else if ($seccion == "entrada_token_web") {
      //exit();
        //echo "b";
    if($_GET["user"]=="12345" and $_GET["rut_enviado"]<>""){
        $_SESSION["user_"] = $_GET["rut_enviado"];
        $_SESSION["id_empresa"] = "78";
    }
    //print_r($_SESSION);
      echo " <script>location.href='?sw=com_vota_canjea';</script>";
      exit();

  }
    else if ($seccion == "entradac") {
        $rut = (trim($_POST["user"]));
        $rut = str_replace(".", "", $rut);
        $arreglo_rut = explode("-", $rut);
        $rut = $arreglo_rut[0];
        // Verifico si tiene correo en la base.
        $datos_usuario = UsuarioEnBasePersonas($rut, $rut);
        $id_empresa = $datos_usuario[0]->id_empresa;
        $datos_empresa = DatosEmpresa($id_empresa);
        if ($datos_usuario[0]->email) {
            EnviarCorreos($rut, 1, "");
            echo "
        <script>
        alert('Corren enviado a " . $datos_usuario[0]->email . "');
        location.href='/emiliana';
        </script>";
        }
        else {
            echo "
        <script>
        alert('No tienes correo en la base de datos. Debes contactacte con soporte@sgd.cl');
        location.href='/emiliana';
        </script>";
        }
    }
    else if ($seccion == "entradapassc") {
        $pass = (trim($_POST["newpass"]));
        // print_r($pass);exit;
        $repass = (trim($_POST["repass"]));
        if ($pass <> $repass) {
            echo "
        <script>
        alert('Claves no concuerdan.');
        location.href='?sw=nwp';
        </script>";
        }
        else if (strlen($pass) < 8) {
            echo "<script>location.href='?sw=nwp';    </script>";
        }
        else if (!preg_match("#[0-9]+#", $pass)) {
            $errors[] = "Password must include at least one number!";
            echo "<script>alert('La Clave debe contener por lo menos 1 numero.');location.href='?sw=nwp';    </script>";
        }
        else if (!preg_match("#[a-zA-Z]+#", $pass)) {
            $errors[] = "Password must include at least one letter!";
            echo "<script>alert('La Clave debe contener por lo menos una letra.');location.href='?sw=nwp';    </script>";
        }
        else {
            CambiarClave($_SESSION["user_"], $pass);
            $existe_base = UsuarioEnBasePersonas($_SESSION["user_"]);
            $_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
            $datos_empresa = DatosEmpresa($existe_base[0]->id_empresa);
            InsertarClaveNueva($_SESSION["user_"], $pass);
            echo "
        <script>
        alert('Clave creada exitosamente.');
        location.href='?sw=" . $datos_empresa[0]->case_home . "';
        </script>";
        }
    }
    else if ($seccion == "entradapass") {
        $pass = (trim($_POST["newpass"]));
        // print_r($pass);exit;
        $repass = (trim($_POST["repass"]));
        if ($pass <> $repass) {
            echo "
        <script>
        alert('Claves no concuerdan.');
        location.href='?sw=chp';
        </script>";
        }
        else if (strlen($pass) < 8) {
            echo "<script>location.href='?sw=chp';    </script>";
        }
        else if (!preg_match("#[0-9]+#", $pass)) {
            echo "<script>alert('La Clave debe contener por lo menos 1 numero.');location.href='?sw=chp';    </script>";
        }
        else if (!preg_match("#[a-zA-Z]+#", $pass)) {
            echo "<script>alert('La Clave debe contener por lo menos una letra.');location.href='?sw=chp';    </script>";
        }
        else if (strlen($pass) < 8) {
            echo "
        <script>alert('La Clave debe contener por lo menos 8 caracteres.');
        location.href='?sw=chp';
        </script>";
        }
        else {
            // echo "aca";exit;
            // Actualizo la clave, y dejo en estado 0 el campo cambiada.
            CambiarClave($_SESSION["user_"], $pass);
            // print_r($_SESSION);exit;
            $existe_base = UsuarioEnBasePersonas($_SESSION["user_"]);
            $_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
            $datos_empresa = DatosEmpresa($existe_base[0]->id_empresa);
            echo "
        <script>
        location.href='?sw=" . $datos_empresa[0]->case_home . "';
        </script>";
        }
    }
    

     else if ($seccion == "home_landing") {

        unset($_SESSION['id_malla']); // will delete just the name data
        $rut = $_SESSION["user_"];
        $id_empresa = $_SESSION["id_empresa"];

        if ($id_empresa == "78") {
             echo "<script>location.href='?sw=com_vota_canjea';</script>";exit();
            $puntos_usuario=premios_buscadatos($rut, $id_empresa);
            $saldo_puntos_array=premios_buscaSaldo($rut, $id_empresa);
            $abonos=$saldo_puntos_array[0]->puntos;
            $cargos=$saldo_puntos_array[1]->puntos;
            $saldo_puntos=round($abonos-$cargos);
            //echo "saldo puntos ".$saldo_puntos;


        }
        if ($id_empresa == "52") {
            // echo "<script>location.href='?sw=home_intro';</script>";exit();


        }



        if($id_empresa=="81"){

        $avance1=BuscaASignacionPuntosGamificado("perfil", $rut, $id_empresa);
        $avance2=BuscaASignacionPuntosGamificado("faltr01", $rut, $id_empresa);
        $avance3=BuscaASignacionPuntosGamificado("fal_rc_fmn", $rut, $id_empresa);
        $avance4=BuscaASignacionPuntosGamificado("falFNYM1", $rut, $id_empresa);
        $avance5=BuscaASignacionPuntosGamificado("fal0", $rut, $id_empresa);
        $avance6=BuscaASignacionPuntosGamificado("reco", $rut, $id_empresa);
        $avance7=BuscaASignacionPuntosGamificado("ranking_vista", $rut, $id_empresa);


        $avance_general=round(100*($avance1+$avance2+$avance3+$avance4+$avance5+$avance6+$avance7)/7);
        if($avance_general>=100){$avance_general=100;}
         //echo "avance avance 1 avancge general $avance_general $avance1, $avance2, $avance3, $avance4, $avance5, $avance6, $avance7";
        }

        ActualizaIdInscripcionNull_RUT($rut);
        BuscaInscripcionCierreDuplicadosRut($rut);
       // $time_elapsed_secs = microtime(true) - $start;
       // $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
       //  echo "<br />Tiempo1: $time_elapsed";
        // $start = microtime(true);
        $Arreglo_Datos_usuario = TraeDatosBiografiayUsuario($rut, $id_empresa);
        //print_r($Arreglo_Datos_usuario);
        $nombre_completo = $Arreglo_Datos_usuario[0]->nombre_completo;
        $cargo = $Arreglo_Datos_usuario[0]->cargo;
        $unidad_negocio = $Arreglo_Datos_usuario[0]->unidad_negocio;
        $gerencia = $Arreglo_Datos_usuario[0]->gerencia;
        $area = $Arreglo_Datos_usuario[0]->area;
        $division = $Arreglo_Datos_usuario[0]->division;
        $departamento = $Arreglo_Datos_usuario[0]->departamento;
        $local = $Arreglo_Datos_usuario[0]->local;
        $sucursal = $Arreglo_Datos_usuario[0]->sucursal;
        $regional = $Arreglo_Datos_usuario[0]->regional;
        $telefono = $Arreglo_Datos_usuario[0]->telefono;
        $anexo = $Arreglo_Datos_usuario[0]->anexo;
        $email = $Arreglo_Datos_usuario[0]->email;
        $biografia = $Arreglo_Datos_usuario[0]->biografia;
        $sueno = $Arreglo_Datos_usuario[0]->sueno;
        $logros = $Arreglo_Datos_usuario[0]->logros;
        $celular = $Arreglo_Datos_usuario[0]->micelular;
        $avatar = $Arreglo_Datos_usuario[0]->miavatar;
        $tipocargo = $Arreglo_Datos_usuario[0]->tipo_cargo;
        $foto_avatar = VerificaFotoPersonal($rut);
        if ($id_empresa == "52") {
            $vio_intro = VioBannerMalla($rut, $id_empresa, "intro_wtv");
            if ($vio_intro <> 0) {
            }
            else if ($vio_intro == 0) {
                InsertaVioBannerMalla($rut, $id_empresa, "intro_wtv");
                echo "
                            <script>
                                location.href='?sw=videos_tv_intro';
                            </script>";
            }
            // echo "<script>location.href='?sw=home_intro';</script>";exit();
        }
        $PRINCIPAL = (FuncionesTransversales(file_get_contents("views/home_landing/" . $id_empresa . "_index_landing.html")));
        // $PRINCIPAL=ColocaIndicadoresVarios($PRINCIPAL);
        // $PRINCIPAL=BloqueMovimientosInternos($PRINCIPAL, "", $id_empresa);
        $PRINCIPAL = BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = ColocarSliderPorNoticia($PRINCIPAL, $id_empresa);
        $PRINCIPAL = ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
        // $arreglo_row_bcicoins=lms_busca_puntos_reportes($rut, $id_empresa);
        if ($id_empresa == "78") {
            $tiene_induccion = BuscaProgramaInd($rut, $id_empresa, "bch_induc");
            // print_r($tiene_induccion);
            if ($tiene_induccion[0]->cuenta > 0) {
                $PRINCIPAL = str_replace("{BANNER1_LANDING_MOD_LINK}", "home_bchile_induccion_intro", $PRINCIPAL);
                $PRINCIPAL = str_replace("{BANNER1_LANDING_MOD_NOMBRE}", "Inducci&oacute;n", $PRINCIPAL);
            }
            else {
                $PRINCIPAL = str_replace("{BANNER1_LANDING_MOD_LINK}", "home_misprogramas", $PRINCIPAL);
                $PRINCIPAL = str_replace("{BANNER1_LANDING_MOD_NOMBRE}", "Mis Cursos", $PRINCIPAL);
            }
        }

                if ($id_empresa == "75") {
            // echo "<script>location.href='?sw=home_intro';</script>";exit();

             $impulsa_habilitado=BuscarFiltroPositivoFC($rut, $id_empresa);
            //echo "<br>rut $rut, impulsa_habilitado $impulsa_habilitado";
            if($impulsa_habilitado>0){
                        $url_impulsa="<a href='?sw=formacion_continua'>";
                        $PRINCIPAL = str_replace("{URL_LINK_IMPULSA}", $url_impulsa, $PRINCIPAL);
                        $PRINCIPAL = str_replace("{ESTILO_URL_LINK_IMPULSA}", "", $PRINCIPAL);

            }   else {
                         $url_impulsa="<a href='?sw=pronto_no'>";
                        $PRINCIPAL = str_replace("{URL_LINK_IMPULSA}", $url_impulsa, $PRINCIPAL);
                        $PRINCIPAL = str_replace("{ESTILO_URL_LINK_IMPULSA}", " img_bn_grasycale ", $PRINCIPAL);

            }
        }
        //$time_elapsed_secs = microtime(true) - $start;
        //$time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        // echo "<br />Tiempo2: $time_elapsed";
        // $start = microtime(true);
        // $PRINCIPAL = str_replace("{NOMBRE_COMPLETO}",$nombre_completo, $PRINCIPAL);
        $PRINCIPAL = str_replace("{ROW_BCI_COINS_CARTOLA}", $arreglo_row_bcicoins[0], $PRINCIPAL);
        $arreglo_row_bcicursosrealizados = lms_busca_cursos_realizados($rut, $id_empresa);
        $PRINCIPAL = str_replace("{ROW_BCI_MIS_CURSOS_REALIZADOS}", $arreglo_row_bcicursosrealizados[0], $PRINCIPAL);
        $PRINCIPAL = str_replace("{SUMATOTAL_PUNTOS_REPORTES}", $arreglo_row_bcicoins[1], $PRINCIPAL);
        $arreglo_oferta_abierta = lms_busca_posibles_postulaciones($rut, $id_empresa);

        //$time_elapsed_secs = microtime(true) - $start;
        //$time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        // echo "<br />Tiempo3: $time_elapsed";
        // $start = microtime(true);
        if ($id_empresa == "83") {
            $carrusel_ultimos_diez = lms_busca_carrusel_top_diez_perfil_puntos_medallas($rut, $id_empresa);
            $PRINCIPAL = str_replace("{LISTA_CARRUSEL_PERSONAL_10}", $carrusel_ultimos_diez, $PRINCIPAL);
        }



        $PRINCIPAL = str_replace("{NOMBRE_COMPLETO}", ($nombre_completo) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{CARGO}", ($cargo) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{UNIDAD_NEGOCIO}", ($unidad_negocio) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{GERENCIA}", ($gerencia) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{AREA}", ($area) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{DIVISION}", ($division) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{TELEFONO}", $telefono, $PRINCIPAL);
        $PRINCIPAL = str_replace("{EMAIL}", $email, $PRINCIPAL);
        $PRINCIPAL = str_replace("{BIOGRAFIA}", ($biografia) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{SUENO}", ($sueno) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{LOGROS}", ($logros) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{CELULAR}", $celular, $PRINCIPAL);
        $PRINCIPAL = str_replace("{AVATAR}", $foto_avatar, $PRINCIPAL);
        $PRINCIPAL = str_replace("{DEPARTAMENTO}", $departamento, $PRINCIPAL);
        $PRINCIPAL = str_replace("{TIPOCARGO}", $tipocargo, $PRINCIPAL);
        $PRINCIPAL = str_replace("{SUCURSAL}", $sucursal, $PRINCIPAL);
        $PRINCIPAL = str_replace("{REGIONAL}", $regional, $PRINCIPAL);
        $PRINCIPAL = str_replace("{ANEXO}", $anexo, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LOCAL}", $local, $PRINCIPAL);
        $PRINCIPAL = str_replace("{RUT}", $rut, $PRINCIPAL);
        $array_puntos_emblemas = BuscaPuntosEmblemas($rut, $id_empresa);
        $PRINCIPAL = str_replace("{PUNTOS_USUARIO}", $array_puntos_emblemas[0]->puntos, $PRINCIPAL);
        $PRINCIPAL = str_replace("{EMBLEMAS_USUARIO}", $array_puntos_emblemas[0]->emblemas, $PRINCIPAL);
        $PRINCIPAL = str_replace("{MEDALLAS_USUARIO}", $array_puntos_emblemas[0]->medallas, $PRINCIPAL);

        //sleep(2);
        //$time_elapsed_secs = microtime(true) - $start;
        //$time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        // echo "<br />Tiempo4: $time_elapsed";
        $start = microtime(true);

        if ($id_empresa == "52") {
            $array_malla = buscamalla($rut, $id_empresa);
            $id_malla = $array_malla[0]->id_malla;
            // echo "hola";
            $array_Rank = Wa_Ranking_desafios($rut, $id_malla, $id_empresa, "");
            $avance = $array_Rank[0]->avance;
            $aprobacion = round(100 * $array_Rank[0]->num_aprobados / $array_Rank[0]->total_cursos);
            if ($avance >= 100) {
                $avance = 100;
            }
            if ($aprobacion >= 100) {
                $aprobacion = 100;
            }
            $PRINCIPAL = str_replace("{WA_AVANCE}", $avance, $PRINCIPAL);
            $PRINCIPAL = str_replace("{WA_APROBACION}", $aprobacion, $PRINCIPAL);
            $PRINCIPAL = str_replace("{WA_ESTRELLAS}", $array_Rank[0]->total_puntos, $PRINCIPAL);
            $PRINCIPAL = str_replace("{WA_MEDALLAS}", $array_Rank[0]->total_medallas, $PRINCIPAL);
            //$array_Rank_all = Wa_Ranking_desafios("", $id_malla, $id_empresa, "");
            // print_r($array_Rank_all); exit();
           /* $avance = 0;
            $aprobacion = 0;
            foreach($array_Rank_all as $unico) {
                $cuenta_rank++;
                $datos_usuarios = TraeDatosBiografiayUsuario($unico->rut, $id_empresa);
                $avance = $unico->avance;
                $aprobacion = round(100 * $unico->num_aprobados / $unico->total_cursos);
                $row_ranking_wa.= "<tr>
    <td>" . $cuenta_rank . "</td>




    <td><div class='avatar'><img src='" . VerificaFotoPersonal($unico->rut) . "'></div></td>
    <td><span class='wa_name'>" . ($datos_usuarios[0]->nombre_completo) . "</span><br /><small>" . ($datos_usuarios[0]->cargo) . "</small></td>
    <td><span class='wa_number'> " . $unico->total_medallas . " </span> </td>
    <td> <span class='wa_number'>" . $unico->total_puntos . "</span>  </td>

    <td><ul class='skill-list list-0'>
    <li>" . $aprobacion . "% Aprobaci&oacute;n
    <div class='progress skills-animated'><div class='progress-bar progress-bar-success progress-bar-striped progress-animation' role='progressbar' aria-valuenow='" . $aprobacion . "' aria-valuemin='0' aria-valuemax='100' style='width: " . $aprobacion . "%'></div></div>
    </li>
    <li>" . $avance . "% Avance
    <div class='progress skills-animated'><div class='progress-bar progress-bar-success progress-bar-striped progress-animation' role='progressbar'
    aria-valuenow='" . $avance . "' aria-valuemin='0' aria-valuemax='100' style='width: " . $avance . "%'></div></div>
    </li>
    </ul></td></tr>"; *
            }
            $PRINCIPAL = str_replace("{WA_RANKING}", $row_ranking_wa, $PRINCIPAL);
            */
        }

        $time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        // echo "<br />Tiempo5: $time_elapsed";

        $array_Reco_Gracias = BuscaDatosReconocimientoAgradecimientos($rut, $id_empresa);
        if ($array_Reco_Gracias[0]->num_gracias > 0) {
            $num_gracias = $array_Reco_Gracias[0]->num_gracias;
        }
        else {
            $num_gracias = 0;
        }
        if ($array_Reco_Gracias[0]->num_reconocimientos > 0) {
            $num_reconocimientos = $array_Reco_Gracias[0]->num_reconocimientos;
        }
        else {
            $num_reconocimientos = 0;
        }
        $PRINCIPAL = str_replace("{NUM_RECONOCIMIENTOS}", $num_reconocimientos, $PRINCIPAL);
        $PRINCIPAL = str_replace("{NUM_GRACIAS}", $num_gracias, $PRINCIPAL);
        $arreglo_biografias = BuscaBioCarrouselUsuario($rut);
        foreach($arreglo_biografias as $arreglo_biografia) {
            $carrousel.= "<div class='item vc_col-md-12 relative text-white'><div class='testimonail-content'>" . ($arreglo_biografia->texto) . "</div></div>";
        }
       /* $time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
         echo "<br />Tiempo5: $time_elapsed";     */

         //$start = microtime(true);

        $PRINCIPAL = str_replace("{BCH_BIO_CARROUSEL}", $carrousel, $PRINCIPAL);
        $PRINCIPAL = str_replace("{SLIDING}", "slidingDivPerfilAvanzado", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VERMAS_PERFILCOL}", "<span class='btn btn-warning btn-sm' style='margin-top: 5px;'> Ver mi Perfil </span>", $PRINCIPAL);
        $PRINCIPAL = str_replace("{LINK_CURSOS_HISTORICOS}", "<a href='?sw=lms_lista_historicos'><span class='azul'>", $PRINCIPAL);
        $PRINCIPAL = str_replace("{LINK_CURSOS_HISTORICOS_FIN}", "</span></a>", $PRINCIPAL);
        $cuenta_reconocimientos = CuentaReconocimientosGraciasJefe($rut, $id_empresa);
        if ($cuenta_reconocimientos[0]->cuenta > 0) {
            $PRINCIPAL = str_replace("{ESTRELLA_RECONOCIMIENTO}", "
                <div class='positioner_star'>
                    <div class='icon_star'>
                            <img src='img/bch_star_reco.png'>
                    </div>
                </div>", $PRINCIPAL);
            // bch_star_reco.png
        }
        else {
            $PRINCIPAL = str_replace("{ESTRELLA_RECONOCIMIENTO}", "", $PRINCIPAL);
        }
        //$start = microtime(true);
        $PRINCIPAL = colocarColaboradoresPorRutSoloClick($PRINCIPAL, $id_empresa, $rut);
        /*$time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        echo "<br />Tiempo1: $time_elapsed";
        $start = microtime(true);   */
        $PRINCIPAL = colocarReconocimientosGraciasPorRut($PRINCIPAL, $id_empresa, $rut);
        $PRINCIPAL = colocarPuntosPorRut($PRINCIPAL, $id_empresa, $rut);
        $PRINCIPAL = colocarReconocimientosPerfilPorRut($PRINCIPAL, $id_empresa, $rut);

        $PRINCIPAL = str_replace("{SALDO_PUNTOS_POR_RUT}", $saldo_puntos, $PRINCIPAL);


        /*
        $time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        echo "<br />Tiempo2: $time_elapsed";
        $start = microtime(true); */
        $PRINCIPAL = colocarListaReconocimientosPorRut($PRINCIPAL, $id_empresa, $rut);
        $PRINCIPAL = colocarlogrosBadgesPorRut($PRINCIPAL, $id_empresa, $rut);
        /*$time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        echo "<br />Tiempo3: $time_elapsed";
        $start = microtime(true);   */
        $PRINCIPAL = colocarKpiPorRut($PRINCIPAL, $id_empresa, $rut);
        $hoy = date("Y-m-d");
        $PRINCIPAL = colocarNotificacionesEncuestas($PRINCIPAL, $id_empresa, $rut, $hoy);
        /*$time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        echo "<br />Tiempo4: $time_elapsed";
        $start = microtime(true);    */
        // $start = microtime(true);
        $PRINCIPAL = colocarNotificacionesFormacionContinua($PRINCIPAL, $id_empresa, $rut);
        /*$time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        echo "<br />Tiempo5: $time_elapsed";     */
        // $start = microtime(true);
        $PRINCIPAL = colocarMedidorAnimo($PRINCIPAL, $id_empresa, $rut, $hoy, "8", "9");
        $boton_editar = "<a href='?sw=home_profile_intro_form_profile' class='btn btn-info btn-sm'> <span style='color:#fff; !important'><i class='icon-pencil icons'></i> Editar Perfil</span></a>";
        $PRINCIPAL = str_replace("{EDITAR_PERFIL_RECONOCIMIENTOS}", $boton_editar, $PRINCIPAL);
        $boton_cambiar_clave = "<a href='?sw=chp' class='btn btn-info btn-sm'> <span style='color:#fff; !important'><i class='fas fa-key'></i> Cambiar Clave</span></a>";
        $PRINCIPAL = str_replace("{EDITAR_CLAVE}", $boton_cambiar_clave, $PRINCIPAL);
        $PRINCIPAL = str_replace("{BOTON3}", $boton3, $PRINCIPAL);
        // print_r($arreglo_oferta_abierta);
        // ActualizaTablatblLmsReportePorRut($rut);

        //$time_elapsed_secs = microtime(true) - $start;
        //$time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
        //echo "<br />Tiempo6: $time_elapsed";
        //$start = microtime(true);
        $arreglo_row_avance = lms_integracion_programas($rut, $id_empresa, "");
        $PRINCIPAL = str_replace("{AVANCEMALLATOTAL}", $arreglo_row_avance[1], $PRINCIPAL);
        $PRINCIPAL = str_replace("{ROW_LISTA_PROGRAMAS_OBLIGATORIOS}", $arreglo_row_avance[0], $PRINCIPAL);
        if ($id_empresa == "75") {
            $nota_trivia = Trivia_BuscaNotaCierre($id_curso, $id_empresa, $rut);
            $avance_gamificada = 0;
            if ($nota_trivia > 0) {
                $avance_gamificada = 100;
            }
            $avance_global = round((80 * $arreglo_row_avance[1] + 20 * $avance_gamificada) / 100);
            $PRINCIPAL = str_replace("{AVANCE_MISION_LANDING}", $avance_global, $PRINCIPAL);
        }
            if ($id_empresa == "81") {
            $nota_trivia = Trivia_BuscaNotaCierre($id_curso, $id_empresa, $rut);
            $avance_gamificada = 0;
            if ($nota_trivia > 0) {
                $avance_gamificada = 100;
            }
            $avance_global = round((80 * $arreglo_row_avance[1] + 20 * $avance_gamificada) / 100);
            $PRINCIPAL = str_replace("{AVANCE_MISION_LANDING}", $avance_general, $PRINCIPAL);
        }
        // opcional
        // $arreglo_row_avance_opcional=lms_integracion_programas($rut, $id_empresa, "opcional");
        $PRINCIPAL = str_replace("{ROW_LISTA_PROGRAMAS_OPCIONAL}", $arreglo_row_avance_opcional[0], $PRINCIPAL);
        $PRINCIPAL = str_replace("{SECCION_PREGUNTA}", ColocaBloquePreguntaPorObjeto($datos_objeto[0]->id, $rut, 4) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{ROW_PESTANAS_LI_FOCOS}", ColocaPestanasFocosHome($rut, $id_empresa) , $PRINCIPAL);
        $array_estadisticas = BuscaEstadisticasUsuario($rut, $id_empresa);
        // print_r($array_estadisticas);
        /*
        $time_elapsed_secs = microtime(true) - $start;
        $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);   */
        // echo "<br />Tiempo8: $time_elapsed";
        // $start = microtime(true);
        $PRINCIPAL = str_replace("{ESTADISTICA_FECHA_INICIO}", $array_estadisticas[0]->fecha_inicio, $PRINCIPAL);
        $PRINCIPAL = str_replace("{ESTADISTICA_ULTIMA_VISITA}", $array_estadisticas[0]->fecha_ultima, $PRINCIPAL);
        $PRINCIPAL = str_replace("{ESTADISTICA_CURSOS_APROBADOS}", $array_estadisticas[0]->cursos_aprobados, $PRINCIPAL);
        if ($rut == "10033383" OR $rut == "15720101" or $rut == "16886519" or $rut == "bchile") {
            $PRINCIPAL = str_replace("{LI_RECONOCE}", "<li class='ui-state-default ui-corner-top' role='tab' tabindex='-1' aria-controls='tabs-10' aria-labelledby='ui-id-22' aria-selected='false' aria-expanded='false'>
                    <a href='#tabs-10' class='ui-tabs-anchor' role='presentation' tabindex='-1' id='ui-id-22'> <i class='i-rounded2 i-circled2 i-bordered2 icon-star'></i> <span class=''>Reconocimientos</span></a>
                    </a>
               </li>", $PRINCIPAL);
        }
        else {
            $PRINCIPAL = str_replace("{LI_RECONOCE}", "", $PRINCIPAL);
        }
//echo $division;
        if ($rut == "10033383" OR $division == "Division Personas y Organizacion" or $rut == "16886519" or $rut == "bchile") {
            $PRINCIPAL = str_replace("{LI_BANCOPUNTOS}", "<li class='ui-state-default ui-corner-top' role='tab' tabindex='-1' aria-controls='tabs-10' aria-labelledby='ui-id-20' aria-selected='false' aria-expanded='false'>
                    <a href='#tabs-8' class='ui-tabs-anchor' role='presentation' tabindex='-1' id='ui-id-22'> <i class='i-rounded2 i-circled2 i-bordered2 fas fa-globe'></i> <span class=''>Banco de Puntos</span></a>
                    </a>
               </li>", $PRINCIPAL);
        }
        else {
            $PRINCIPAL = str_replace("{LI_BANCOPUNTOS}", "", $PRINCIPAL);
        }

        // echo "<br />Tiempo9: $time_elapsed";
        // $start = microtime(true);
        $PRINCIPAL = ColocaDatosPerfil($PRINCIPAL, $rut);

        // echo "<br />Tiempo10: $time_elapsed";
        //$time_elapsed_secs = microtime(true) - $start;
       // $time_elapsed = gmdate("H:i:s", $time_elapsed_secs);
         //echo "<br />Tiempo10: $time_elapsed";
        if ($id_empresa == "52") {
            // echo "Tiempo: $time_elapsed";
        }
        echo $PRINCIPAL;
    }   

    else if ($seccion == "home_profile_intro_form_profile") {
         echo "<script>location.href='?sw=com_vota_canjea';</script>";exit();  
        $rut = $_SESSION["user_"];
        $id_empresa = $_SESSION["id_empresa"];
        $PRINCIPAL = (FuncionesTransversales(file_get_contents("views/home_intro/" . $id_empresa . "_intro_form.html")));
        $PRINCIPAL = BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = ColocarSliderPorNoticia($PRINCIPAL, $id_empresa);
        $PRINCIPAL = ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
        $PRINCIPAL = str_replace("{ROW_BCI_COINS_CARTOLA}", $arreglo_row_bcicoins[0], $PRINCIPAL);
        $PRINCIPAL = str_replace("{ROW_BCI_MIS_CURSOS_REALIZADOS}", $arreglo_row_bcicursosrealizados[0], $PRINCIPAL);
        $PRINCIPAL = str_replace("{SUMATOTAL_PUNTOS_REPORTES}", $arreglo_row_bcicoins[1], $PRINCIPAL);
        $PRINCIPAL = str_replace("{AVANCEMALLATOTAL}", $arreglo_row_avance[1], $PRINCIPAL);
        $PRINCIPAL = str_replace("{ROW_LISTA_PROGRAMAS_OBLIGATORIOS}", $arreglo_row_avance[0], $PRINCIPAL);
        $PRINCIPAL = str_replace("{ROW_LISTA_PROGRAMAS_OPCIONAL}", $arreglo_row_avance_opcional[0], $PRINCIPAL);
        $PRINCIPAL = str_replace("{SECCION_PREGUNTA}", ColocaBloquePreguntaPorObjeto($datos_objeto[0]->id, $rut, 4) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{ROW_PESTANAS_LI_FOCOS}", ColocaPestanasFocosHome($rut, $id_empresa) , $PRINCIPAL);
        $Arreglo_Datos_usuario = TraeDatosBiografiayUsuario($rut, $id_empresa);

    //    print_r($Arreglo_Datos_usuario);

        $nombre_pila = $Arreglo_Datos_usuario[0]->nombre;
        $nombre_completo = $Arreglo_Datos_usuario[0]->nombre_completo;
        $cargo = $Arreglo_Datos_usuario[0]->cargo;
        $unidad_negocio = $Arreglo_Datos_usuario[0]->unidad_negocio;
        $gerencia = $Arreglo_Datos_usuario[0]->gerencia;
        $area = $Arreglo_Datos_usuario[0]->area;
        $division = $Arreglo_Datos_usuario[0]->departamento;
        $telefono = $Arreglo_Datos_usuario[0]->telefono;
        $email = $Arreglo_Datos_usuario[0]->email;
        $biografia = $Arreglo_Datos_usuario[0]->biografia;
        $sueno = $Arreglo_Datos_usuario[0]->sueno;
        $logros = $Arreglo_Datos_usuario[0]->logros;
        $celular = $Arreglo_Datos_usuario[0]->micelular;
        $avatar = $Arreglo_Datos_usuario[0]->miavatar;
        $estudios = $Arreglo_Datos_usuario[0]->estudios;
        $institucion = $Arreglo_Datos_usuario[0]->profesion;

        $fecha_ingreso = $Arreglo_Datos_usuario[0]->fecha_ingreso;
        $recuerdos = $Arreglo_Datos_usuario[0]->recuerdos;
        $fecha_cumpleanos = $Arreglo_Datos_usuario[0]->fecha_cumpleanos;
        $capacitacion = $Arreglo_Datos_usuario[0]->capacitacion;
        $titulo = $Arreglo_Datos_usuario[0]->titulo;







        $foto_avatar = VerificaFotoPersonal($rut);
        // echo "//to_avatar $foto_avatar";
        $PRINCIPAL = str_replace("{NOMBRE_COMPLETO}", ($nombre_completo) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{BIOGRAFIA}", ($biografia) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{LOGROS}", ($logros) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{SUENO}", ($sueno) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{CELULAR}", ($celular) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{ESTUDIOS}", ($estudios) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{INSTITUCION}", ($institucion) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{NOMBRE_PILA}", ($nombre_pila) , $PRINCIPAL);

        $PRINCIPAL = str_replace("{FECHA_INGRESO}", ($fecha_ingreso) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{RECUERDOS}", ($recuerdos) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{FECHA_CUMPLEAÑOS}", ($fecha_cumpleanos) , $PRINCIPAL);
        $PRINCIPAL = str_replace("{OPTION_CAPACITACION}", "<option value=".($capacitacion)." >".($capacitacion)."" , $PRINCIPAL);
        $PRINCIPAL = str_replace("{TITULO}", ($titulo) , $PRINCIPAL);



        $PRINCIPAL = str_replace("{AVATAR}", ($foto_avatar) , $PRINCIPAL);

        $PRINCIPAL = ColocaDatosPerfil($PRINCIPAL, $rut);
        echo $PRINCIPAL;
    }




else if($seccion=="com_vota_canjea_test"){
	
	
	    $message = file_get_contents("views/emails_notificaciones/78_template_notificacion.html");
//echo "hola ".$message;
	
}

else if($seccion=="com_vota_canjea"){

    CanjePuntosValidaCanjes7dias($id_empresa);
    $rut=$_SESSION["user_"];
    //echo "rut $rut";
    $id_empresa=$_SESSION["id_empresa"];
    $id_premio=Decodear3($_GET["id_premio"]);
    $swa="";
    $fecha_solicitud=$_POST["fecha_limite_".$id_premio];
    //echo "rut $rut"; sleep(1);
    //echo "<br> $id_premio $fecha_solicitud $rut";
    $fechas_sol = explode("/", $fecha_solicitud);
    $fecha_ingles=$fechas_sol[2]."-".$fechas_sol[1]."-".$fechas_sol[0];
    $hora_desde=$_POST["hora_desde_".$id_premio];
    $hora_hasta=$_POST["hora_hasta_".$id_premio];
    $puntos_usuario=premios_buscadatos($rut, $id_empresa);
    $saldo_puntos_array=premios_buscaSaldo($rut, $id_empresa);
    $abonos         =$saldo_puntos_array[0]->puntos;
    $cargos         =$saldo_puntos_array[1]->puntos;
    $saldo_puntos   =round($abonos-$cargos);

    //echo "puntos a vencer $puntos_a_vencer fecha $fecha_a_vencer";
    if($id_premio<>''){
        //echo "id premio $id_premio"; sleep(1);

        $datos_premio=traigoPremios($id_premio, $id_empresa);
        $datosautor            =mp_buscaDATOSPERSONAS($rut, $id_empresa);
        //echo "<br>autor<br>";    print_r($datosautor); sleep(3);
        $datosjefe            =mp_buscaDATOSPERSONAS($datosautor[0]->jefe, $id_empresa);

        //echo "<br>autor<br>";    print_r($datosautor); sleep(3);
        //print_r($datos_premio);

        //echo "<br><br>";

        //print_r($_POST); sleep(3);
        //echo "<br><br>";

        if($datos_premio[0]->solicitadia=="SI"){


            $dia=$_POST["dia"];
            //$dia="2018-07-05";
            //echo "dia $dia<br><br>";
            $fecha_valida=(validateDate($dia, $format = 'Y-m-d'));
            $nombre_dia=FechaaNombredia($dia);
            $validacionFecha=2;
            if($fecha_valida=="SI"){
                $validacionFecha=1;
            } else {
                $validacionFecha=2;
            }
            //echo  "<br>fecha_valida $fecha_valida, validacionFecha $validacionFecha";
            //echo  "<br>nombre dia $nombre_dia";  sleep(20);


            if($datos_premio[0]->dia<>''){

                if($validacionFecha<>1)
                {
                    echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <br><br><br><div class="alert alert-danger" role="alert">
            <center> <strong>Atenci&oacute;n</strong>: La fecha elegida no es valida, recuerda que debe tener formato 31/12/2018 (dd/mm/yyyy) para el Canje</center>
            </div>';

                    echo "<script>location.href='?sw=com_vota_canjea';</script>";sleep(7);
                    exit();

                }

                //echo $nombre_dia;
                //echo "<br><br>debe estar en ";echo $datos_premio[0]->dia;
                //sleep(5);


                //$nombre_dia="LU";
                //echo "<br>";

                if (strpos($datos_premio[0]->dia, $nombre_dia) !== false) {
                    //echo 'true';
                } else {
                    echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <br><br><br><div class="alert alert-danger" role="alert">
            <center> <strong>Atenci&oacute;n</strong>: El día elegido no corresponde con los disponibles para el Canje</center>
            </div>';

                    echo "<script>location.href='?sw=com_vota_canjea';</script>";sleep(7);
                    exit();

                }

            }

        }

        $fecha_solicitud=$dia;

        //print_r($datosautor);
        //echo "<br>jefe";
        //print_r($datosjefe);
        //echo "rut $rut, premio puntos ".$datos_premio[0]->puntos." < saldo $saldo_puntos"; sleep(4);
        $fecha_castellano="";
        if($fecha_solicitud<>''){
            $fecha_castellano=fechaCastellano($fecha_solicitud);
            $infocanjeadicional=" para el ".$fecha_castellano; } else {$infocanjeadicional="";}

        if($datos_premio[0]->puntos>$saldo_puntos){
            echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <br><br><br><div class="alert alert-danger" role="alert">
            <center> <strong>Atenci&oacute;n</strong>: No tienes puntos suficientes para realizar el Canje</center>
            </div>';

            echo "<script>location.href='?sw=com_vota_canjea';</script>";sleep(7);

            //?sw=com_vota_canjea

            exit();
        }

        //$datosjefe=mp_buscaDATOSPERSONAS($rut, $id_empresa);
        //print_r($datos_premio);

        //echo "antes de enviar emails, id_empresa $id_empresa";

        if($datos_premio[0]->aprobacionjefe=="SI"){
            $estado_premios="2";
        } else {
            $estado_premios="1";
        }

        //echo "hola estado_premios $estado_premios";
        $fecha_ingles  =$fecha_solicitud;
        $last_id=premios_guarda_solicitud_estado($datosautor[0]->rut, $id_premio, $datosjefe[0]->rut,$id_empresa,$fecha_solicitud,$fecha_ingles,$hora_desde,$hora_hasta,$estado_premios);

        if($id_empresa=='78'){
            //SEND GRID

            //echo "email";
            //CON VALIDACION
            if($datos_premio[0]->aprobacionjefe=="SI"){





                //echo "jefe";

                //email a Postulante
                $titulo1="¡Muchas gracias! Hemos recibido tu solicitud de canje ".($datos_premio[0]->premio)."";
                $subject="¡Muchas gracias! Hemos recibido tu solicitud de canje ".($datos_premio[0]->premio)."";
                $subtitulo1=($datosautor[0]->nombre_completo).",
                                        has solicitado el canje ".($datos_premio[0]->premio)." $infocanjeadicional";
                //$texto1="Solo resta la aprobaci&oacute;n de tu jefatura, ".($datosjefe[0]->nombre_completo).", con un tiempo de respuesta máximo de 48 horas.";
                //$texto2="Puedes revisar el estado de tu canje en la cartola de puntos. Tu orden está pendiente";
                $texto1="";
                $texto2="";
                $texto3=($datos_premio[0]->alertaemailusuario);
                $tipomensaje="Email_Postulacion_Beneficio_usuario";
                $rut=$datosautor[0]->rut;
                $key=$datosautor[0]->rut;
                $to=$datosautor[0]->email;
                //$to="rod@gop.cl";
                $url=$url_base;
                $nombreto=($datosautor[0]->nombre_completo);
                SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");


                //email a Jefatura
                $titulo1="¡Excelente! Alguien de tu equipo canje&oacute; sus puntos";
                $subject="Banco de puntos [".$last_id."]: Solicitud pendiente de ".($datosautor[0]->nombre_completo)."";
                $subtitulo1=($datosautor[0]->nombre_completo).",
                                        ha solicitado canjear el ítem ".($datos_premio[0]->premio)." $infocanjeadicional";
                //$texto1="Solo resta tu aprobaci&oacute;n, en un tiempo de respuesta máximo de 48 horas. <br>Ingresando a la plataforma verás la Postulaci&oacute;n pendiente para que la apruebes o rechaces.";
                $texto1="";
                $texto2="";
                $texto3=($datos_premio[0]->alertaemailjefe);
                $tipomensaje="Email_Postulacion_Beneficio_usuario";
                $rut=$datosjefe[0]->rut;
                $key=$datosjefe[0]->rut;
                $to=$datosjefe[0]->email;
                //$to="rod@gop.cl";
                $url=$url_base;
                $nombreto=($datosautor[0]->nombre_completo);
                SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");

                $estado_premios="2";

            } else {
                //echo "usuario";

                //email a Postulante
                $titulo1="¡Muchas gracias! Has canjeado ".($datos_premio[0]->premio)."";
                $subject="¡Muchas gracias! Has canjeado ".($datos_premio[0]->premio)."";
                $subtitulo1=($datosautor[0]->nombre_completo).",
                                        canjeaste ".($datos_premio[0]->premio)." $infocanjeadicional";
                $texto1="";
                $texto2="Puedes revisar el estado de tu canje en la cartola de puntos. Tu orden está confirmada";
                $texto3=($datos_premio[0]->alertaemailusuario);
                $tipomensaje="Email_Postulacion_Beneficio_usuario";
                $rut=$datosautor[0]->rut;
                $key=$datosautor[0]->rut;
                $to=$datosautor[0]->email;
                //$to="rod@gop.cl";
                $url=$url_base;
                $nombreto=($datosautor[0]->nombre_completo);
                SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");


                //email a Jefatura
                $titulo1="¡Excelente! Alguien de tu equipo canje&oacute; sus puntos";
                $subject="Banco de puntos [".$last_id."]: Solicitud de canje actualizada";
                $subtitulo1=($datosautor[0]->nombre_completo).",
                                        canje&oacute; el ítem ".($datos_premio[0]->premio)." $infocanjeadicional";
                $texto1="";
                $texto2="";
                $texto3=($datos_premio[0]->alertaemailjefe);
                $tipomensaje="Email_Postulacion_Beneficio_usuario";
                $rut=$datosjefe[0]->rut;
                $key=$datosjefe[0]->rut;
                $to=$datosjefe[0]->email;
                //$to="rod@gop.cl";
                $url=$url_base;
                $nombreto=($datosautor[0]->nombre_completo);
                SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");

                $estado_premios="1";
            }

        }
        //print_r($datosautor );
    }
    //echo $swa;
    //BUSCADATOSPERSONALES CANJES
    $rut=$_SESSION["user_"];

    $puntos_usuario=premios_buscadatos($rut, $id_empresa);
    $saldo_puntos_array=premios_buscaSaldo($rut, $id_empresa);
    $abonos=$saldo_puntos_array[0]->puntos;
    $cargos=$saldo_puntos_array[1]->puntos;
    $saldo_puntos=round($abonos-$cargos);
    $puntos_cartola=premios_busca_cartola($rut, $id_empresa, "5");
    //print_r($puntos_cartola);
    $cuenta_cartola=0;
    foreach($puntos_cartola as $unico){

        $cuenta_cartola++;

        if($cuenta_cartola>=10){
            continue;
        }
        $row_puntos.=FuncionesTransversales(file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_row_cartola.html"));

        //echo "id premio ".$unico->tipo;
        $Prem=DatosPremioId($unico->tipo, $id_empresa);
        //print_r($Prem);
        $LinkPdf_directo="";
        if($Prem[0]->concodigopremiounico=="1"){

            if($rut=="12345"){
                //echo "<br>Usuario Prueba ".$unico->tipo;
            }

            $CuentaLinkPdfMultiple=PuntosCodigoPremioMultiplesUnico($unico->tipo, $rut);
            if($rut=="12345"){
                //echo "<br>concodigopremiounico 1, cuenta ".count($CuentaLinkPdfMultiple);
                //print_r($CuentaLinkPdfMultiple);
            }
            if(count($CuentaLinkPdfMultiple)>1){
                foreach($CuentaLinkPdfMultiple as $unicM){
                    if($unicM->linkpdf<>""){
                        $LinkPdf_directo.="<a href='".$unicM->linkpdf."' target='blank' class='btn btn-info'>Accede a tu canje</a>";
                    }

                }
                //echo "<br>Cuentamayor1";
                if($rut=="12345"){
                    //echo "<br>A";
                }

            } else {
                if($rut=="12345"){
                    // echo "<br>B";
                }
                $LinkPdf=PuntosCodigoPremioUnico($unico->tipo, $rut);
                $LinkPdf_directo="<a href='".$LinkPdf[0]->linkpdf."' target='blank' class='btn btn-info'>Accede a tu canje</a>";

            }
        }
        if($Prem[0]->link_externo<>""){
            $LinkPdf_directo="<a href='".$Prem[0]->link_externo."' target='blank' class='btn btn-info'>Accede a Link</a>";
            if($Prem[0]->concodigopremiounico=="1"){
                $LinkPdf=PuntosCodigoPremioMultiplesUnico($unico->tipo, $rut);
                //echo "<br>link externo";
                foreach ($LinkPdf as $unicoMultiple ){
                    //print_r($unicoMultiple);
                    if($unicoMultiple->codigo<>""){
                        $LinkPdf_directo.="<br> - Codigo: ".$unicoMultiple->codigo;
                    }

                }
            }
        }
        if($Prem[0]->id_premio=="bch_lolla2023"){
            $LinkPdf_directo.="/ ".BuscaDia_Canje_2022_lolla($unico->id);
        }



        //print_r($LinkPdf);

        if($unico->ingreso=="egreso")    {
            $icon="<span class='badge badge-danger'><span class='blanco'><i class='fas fa-angle-left'></i></span></span>";
            $NombrePremio=PremioBuscaNombre($unico->tipo, $id_empresa);
            $estado="";
            if($unico->descripcion==1){
                $estado="Canjeado";
            } elseif($unico->descripcion==2){
                $estado="Pendiente";
            }


            $descripcion=$icon." ".$NombrePremio." ".$LinkPdf_directo;
            $cargos=$unico->puntos;
            $abonos="";
        }
        if($unico->ingreso=="ingreso")    {
            $icon="<span class='badge badge-success'><span class='blanco'><i class='fas fa-angle-right'></i></span></span>";

            if($unico->descripcion=="Puntos Vencidos"){
                $icon="<span class='badge badge-danger'><span class='blanco'><i class='fas fa-angle-left'></i></span></span>";
            }
            $descripcion=$icon." ".$unico->descripcion;
            $abonos=$unico->puntos;
            $cargos="";
            $estado="";

        }


        if($unico->descripcion=="Puntos Vencidos"){
            $fecha = date('Y-m-d', strtotime($unico->fecha . ' +1 day'));
        } else {
            $fecha=$unico->fecha;
        }

        $row_puntos = str_replace("{FECHA}",($fecha),$row_puntos);
        $row_puntos = str_replace("{DESCRIPCION}",(($descripcion)),$row_puntos);
        $row_puntos = str_replace("{ESTADO}",(($estado)),$row_puntos);
        $row_puntos = str_replace("{CARGOS}",($cargos),$row_puntos);
        $row_puntos = str_replace("{ABONOS}",($abonos),$row_puntos);

    }

    //print_r($row_puntos);

    $vv=(trim($_GET["vv"]));

    if($vv==1){inserta_vio_video($rut, "bchile_puntos", $id_empresa);}

    $viovideo_visto=0;
    $viovideoarray=vio_vide_intro($rut, "bchile_puntos", $id_empresa);
    $cuentaVideoArray=$viovideoarray[0]->cuenta;


    if($cuentaVideoArray>0){$viovideo_visto=1;}

    //echo "$vv $viovideo_visto";




    if($id_empresa=="78"){

        if($viovideo_visto==0){$modal_condiciones="
                            <div class='modal show' id='myModal' tabindex='-1' role='dialog' aria-labelledby='myModalLabel'>
                          <div class='modal-dialog' role='document'>
                            <div class='modal-content'>
                              <div class='modal-header'>

                               <h4 class='modal-title' id='myModalLabel'>Términos y condiciones plataforma “Banco de Puntos”</h4>
                              </div>
                              <div class='modal-body'>

                          Términos y condiciones plataforma “Banco de Puntos”

La plataforma <strong>Banco de puntos</strong> (www.bancodepuntosbch.cl en adelante también el “sitio”) es un programa de canjes administrado por Aquiles Gómez y Compañía limitada Rol Único Tributario N° 78.71.330-8, domiciliado en calle Huérfanos Nº 801 oficina 440, comuna y ciudad de Santiago (en adelante el “Administrador”) para los colaboradores de Banco de Chile, que les permite la acumulación de Puntos en razón de su calidad de contratado de forma indefinida u otros motivos a definir. Estos términos permiten que los colaboradores “Usuarios” accedan y usen el sitio y los servicios, además de su contenido, y constituyen un contrato con Edusport y Banco de Chile, en adelante, también la “Empresa” para todos los efectos legales.

<br><br><strong>1. Aspectos Generales  </strong><br><br>

El acceso, uso y ventas de los servicios ofrecidos por la Empresa, dentro del Sitio se rigen por los Términos y Condiciones descritos a continuación, así como por la legislación que sea aplicable en la República de Chile. En consecuencia, todas las visitas, contratos y transacciones que se realicen en este sitio, como asimismo sus efectos jurídicos, quedarán regidos por estas disposiciones y la legislación pertinente. Cualquier persona que no acepte estos términos y condiciones generales y las políticas de privacidad, los cuales tienen un carácter obligatorio y vinculante, deberá abstenerse de utilizar el sitio y/o los servicios. Se entenderán conocidos y aceptados estos Términos y Condiciones por el sólo hecho de ingresar y hacer uso de nuestro Sitio por el Usuario, lo que implicará la aceptación plena de las condiciones establecidas en este documento y en las Políticas de Privacidad de Edusport y Corporación Banco de Chile por la utilización del sitio y/o sus servicios, el Usuario se obligará a cumplir expresamente con las mismas, no pudiendo alegar el desconocimiento de los Términos y Condiciones Generales y de la Política de Privacidad.

<br><br><strong>2. Registro y uso del Sitio  </strong><br><br>

La Empresa informará, de manera fácil y accesible, los pasos que el Usuario debe seguir para adquirir los convenios ofrecidos por medio del Sitio, y le informará vía correo electrónico una vez que sea recibida la solicitud de compra del producto. Esta solicitud pasará por un proceso de validación de los datos del Usuario, de recolección de los productos del pedido en base al stock disponible, validación del canje por parte del Usuario y, finalmente, se cerrará el canje emitiéndose el correo correspondiente. El sólo hecho que el Usuario siga los pasos que para tales efectos se indican en este sitio para efectuar un canje, equivale a aceptar que la Empresa ha dado cumplimiento efectivo a las condiciones contenidas en esta cláusula. Indicará, además, su dirección de correo electrónico y los medios técnicos a disposición del Usuario para identificar y corregir errores en el envío.
La Empresa se reserva el derecho de restringir el acceso al Sitio, la Empresa podrá cancelar, eliminar o bloquear la cuenta de cualquier Usuario en el Sitio sin justificación ni previo aviso, y ello no dará al Usuario derecho a reclamar ninguna indemnización. La confidencialidad de los datos de la cuenta y contraseña del Usuario son de su exclusiva responsabilidad.

<br><br><strong>3. Ítems Banco de Puntos  </strong><br><br>

La Empresa podrá modificar el nombre, descripción, imagen, stock o cualquier otra característica de los ítems canjeables, como también eliminar uno del Sitio sin justificación ni previo aviso, y ello no dará al Usuario derecho a reclamar ninguna indemnización.

<br><br><strong>4. Derechos de los Usuarios  </strong><br><br>

Los Usuarios gozarán de todos los derechos que le reconoce la legislación sobre protección al consumidor vigente en el territorio de Chile, y además los que se le otorgan en estos términos y condiciones. La sola visita de este sitio en el cual se ofrecen determinados bienes, no impone a los Usuarios obligación alguna, a menos que haya aceptado en forma inequívoca las condiciones ofrecidas por la Empresa, en la forma indicada en estos Términos y Condiciones.

<br><br><strong>5. Responsabilidad del Usuario  </strong><br><br>

La confidencialidad de los datos de la cuenta y contraseña del Usuario así como todas las actividades realizadas en el Sitio bajo su nombre de Usuario y contraseña son de su exclusiva responsabilidad. El acceso y uso del Sitio, como el uso de la información y contenidos incluidos en el mismo, serán de exclusiva responsabilidad del Usuario. El Usuario es el único responsable por cualquier información, dato, texto, fotografía, video, música, sonido, software o cualquier otro tipo de obra o expresión que publique o transmita en el Sitio.

<br><br><strong>6. Tratamiento de datos personales  </strong><br><br>

El colaborador que acepta la incorporación al Programa supone la entrega de antecedentes o datos de carácter personal que ha proporcionado al Administrador, en adelante la “Información”, y que por este acto el colaborador declara que son sustancialmente correctos y corresponden a la realidad, obligándose a que cualquier cambio de los mismos deberá ser comunicado tan pronto se produjere. Para el Administrador, este es un elemento determinante para la incorporación al programa de canjes. En consideración a lo anterior, el colaborador consiente expresamente, y por lo tanto manifiesta su voluntad de manera inequívoca, en autorizar al Administrador del Programa y a Edusport para almacenar, tratar y usar sus datos personales, para enviarle información de sus beneficios, ofrecerle nuevos servicios, realizar estudios y desarrollar estadísticas para mejorar su experiencia como usuario.

<br><br><strong>7. Generación de puntos, vigencia e información  </strong><br><br>

Los colaboradores con contrato indefinido generarán y acumularán puntos del modo y en la forma establecidos en el presente instrumento, y de acuerdo a lo siguiente:
<br><br>
Formas de Obtener puntos<br>
<br>1° Semestre (1° día hábil) 4.000
<br>2° Semestre (1° día hábil) 4.000
<br>Otros. Se podrán definir otras formas de obtener puntos
<br><br>
Para los nuevos ingresos se anticiparán los puntos que le corresponden por semestre de forma proporcional una vez se apruebe la inducción. Tomando como día corte para considerar el mes completo, hasta el 15 del mes anterior. Los puntos tendrán una vigencia de 1 año desde la carga y se cargaran dentro de los primeros 5 días hábiles del mes.

<br><br><strong>8. Canje de puntos  </strong><br><br>

El canje es el acto por medio del cual el usuario dispone de sus puntos acumulados como una unidad de descuento en el sitio www.bancodepuntosbch.cl. Cada vez que recibamos un canje, éste será confirmado vía correo electrónico al Usuario que realizó el desembolso de Puntos para confirmar la recepción de éste e iniciar el proceso de confirmación y despacho de productos.
Banco de Puntos pone a disposición convenios, no productos, exclusivos para los colaboradores de la Corporación Banco de Chile, con contrato indefinido vigente, las cuales son canjeables por puntos que no tienen equivalencia en dinero y son personales e intransferibles, por lo que no es remuneración. No se permiten cancelaciones de canjes.

<br><br><strong>9. Vigencia del programa Banco de puntos  </strong><br><br>

El Programa tiene un plazo de vigencia indefinido, pudiendo el Administrador del Programa ponerle término en cualquier tiempo. La terminación del sitio se comunicará a los usuarios con al menos 60 días corridos de anticipación a la fecha de expiración efectiva, mediante aviso publicado www.bancodepuntosbch.cl o mediante correo electrónico. Expirado el Programa, los puntos acumulados mantendrán su vigencia original.

<br><br><strong>10. Garantía de productos  </strong><br><br>

Los convenios que ofrece Banco de Puntos en su Sitio es para la adquisición de productos y servicios, que tienen garantía, pero no hay derecho a retracto del canje, además es muy importante que leas atentamente cómo funciona la garantía de cada producto o servicio canjeado en el sitio web de cada proveedor ya que queda bajo la responsabilidad de cada Empresa Proveedora cumplir con las garantías, producto o servicio ofrecido.

<br><br><strong>11. Despacho de los productos  </strong><br><br>

Los productos adquiridos a través del sitio quedan sujetos a las condiciones de despacho y definidas en la descripción del convenio y aceptadas por el Usuario y disponibles en el sitio. La información del lugar de envío será el correo electrónico y a la sucursal donde trabaja el colaborador de la Corporación Banco de Chile.

<br><br><strong>12. Responsabilidad de Banco de Puntos  </strong><br><br>

Banco de Puntos hará lo posible, dentro de sus capacidades, para que la transmisión del Sitio sea ininterrumpida y libre de errores. Sin embargo, dada la naturaleza de la Internet, dichas condiciones no pueden ser garantizadas. En el mismo sentido, el acceso del Usuario a la cuenta puede ser ocasionalmente restringido o suspendido con el objeto de efectuar reparaciones, mantenimiento o introducir nuevos servicios.

<br><br><strong>13. Indemnidad  </strong><br><br>

El Usuario se obliga a indemnizar y mantener indemne y libre de daños a La Empresa, sus subsidiarias, controladores, y/o empresas vinculadas de y contra toda y cualquier acción o juicio de responsabilidad, reclamo, denuncia, penalidad, intereses, costos, gastos, multas, honorarios, iniciado por terceros debido a o con origen en cualquiera de sus acciones en el Sitio.

<br><br><strong>14. Propiedad Intelectual e Industrial.  </strong><br><br>

Los textos, imágenes, logos, signos distintivos, sonidos, animaciones, videos, códigos fuente y resto de contenidos incluidos en este sitio son propiedad de la Empresa, o ésta dispone, en su caso, del derecho de reproducción de los mismos y, en tal sentido, constituyen bienes protegidos por la legislación de propiedad intelectual e industrial vigente y aplicable.
Sin perjuicio de la reproducción temporal de los contenidos referidos en el número anterior sólo para efectos del correcto acceso y utilización del Sitio de acuerdo a estos Términos y Condiciones, queda expresamente prohibida y son consideradas un delito según los términos de la Ley 17.336 de Propiedad Intelectual, cuando corresponda, cualquier forma de reproducción, distribución, exhibición, transmisión, retransmisión, emisión en cualquier forma, almacenamiento en cualquier forma, digitalización, puesta a disposición, traducción, adaptación, arreglo comunicación pública o cualquier otro tipo acto por el cual el Usuario pueda servirse comercial o no comercialmente, directa o indirectamente, en su totalidad o parcialmente de cualquiera de los contenidos de las obras sujetas a los derechos descriptos anteriormente. El incumplimiento de lo señalado dará lugar a la aplicación de las sanciones penales y civiles que correspondan.

<br><br><strong>15. Reclamos y/o Controversias  </strong><br><br>

En caso que un Usuario considere que sus derechos personales, morales, intelectuales o cualquier otro están siendo violados de cualquier forma en el Sitio, se le agradecerá enviar un e-mail a la siguiente dirección de correo electrónico: ctaatencionrrhh@bancochile.cl con sus datos personales, una descripción de la situación que afirma viola sus derechos y los detalles que nos permitan ubicar la situación que el Usuario afirma viola sus derechos dentro del Sitio. Una vez recibida la comunicación del Usuario, la Empresa analizará la procedencia de su reclamo y, de corresponder a su sólo criterio, procederá de acuerdo a lo solicitado.
Toda controversia surgida entre el Usuario y la Empresa en relación con la interpretación y cumplimiento de los presentes Términos y Condiciones y a las compras y ventas que dichas partes celebren en virtud de aquéllos, será sometida y resuelta por los Tribunales Ordinarios de Justicia de Santiago, a cuya jurisdicción y competencia el Usuario y la Empresa se someten expresamente. Asimismo, para todos los efectos legales que fueren procedentes, estos términos y condiciones se regirán por las leyes de la República de Chile que le fueren aplicables en cada caso determinado.

<br><br><strong>16. Cambios a los Términos y Condiciones  </strong><br><br>

Banco de Puntos podrá modificar los Términos y Condiciones en cualquier momento, haciendo públicos en el sitio los términos modificados. Todos los términos modificados entrarán en vigencia cumplidos 10 (diez) días de su publicación. Dentro de los 5 (cinco) días siguientes a la publicación de las modificaciones introducidas, el Usuario deberá comunicar por e-mail otorgando un plazo de 10 (diez) días de su publicación para que el Usuario decida si no acepta las mismas; en ese caso quedará disuelto el vínculo contractual y será inhabilitado como miembro. Vencido este plazo, se considerará que el Usuario acepta los nuevos términos y el contrato continuará vinculando a ambas partes.
<br><br>
Estos Términos y Condiciones fueron actualizados por última vez el 02-08-2018.


                            <br><br><br><br><br><br><br><br>

                              </div>
                              <div class='modal-footer'>

                                <a href='?sw=com_vota_canjea&vv=1'><button type='button' class='btn btn-primary'>Aceptar Términos y Condiciones</button></a>
                                 <a href='https://www.bancodepuntosbch.cl'><button type='button' class='btn btn-danger' data-dismiss='modal'>Salir</button></a>
                              </div>
                            </div>
                          </div>
                        </div>";

        } else {

            $modal_condiciones="";

        }

    }


    $popup_bp=BuscaPopup_BP();

    if($popup_bp[0]->activo=="1"){

        $sweetalert_imagen="

			<style>
			.sweet-alert {
			    background-color: #ffffff;
			    width: 791px;
				left: 40%;
			}

			.sweet-alert .sa-icon {
			    width: 760px !important;
			    height: 400px !important;
			    border: 4px solid gray;
			    border-radius: 50%;
			    margin: 20px auto;
			    position: relative;
			    box-sizing: content-box;
			}

				@media (max-width: 767px) {
							.sweet-alert {
							    background-color: #ffffff;
							    width: 365px;
								left: 0%;
							}


							.sweet-alert .sa-icon {
							    width: 365px !important;
							    height: 200px !important;
							    border: 4px solid gray;
							    border-radius: 50%;
							    margin: 20px auto;
							    position: relative;
							    box-sizing: content-box;
							}

			}

			</style>

			<script>swal({
			            title: '',
			            text: '',
									imageUrl: '".$popup_bp[0]->imagen."',
			            type: '',
									showCancelButton: false,
									showCloseButton: true,
									cancelButtonText: 'No, en otro momento',
									confirmButtonText: 'Cerrar',
			            },
			              function(){
			              
			              });
			</script>


		";

    } else {
        $sweetalert_imagen="";
    }

    //$sweetalert_imagen="";
    //echo "modal $modal_condiciones";

    $PRINCIPAL=FuncionesTransversales(file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea.html"));
    $PRINCIPAL = str_replace("{MODAL_TERMINOS}",($modal_condiciones),$PRINCIPAL);

    //$Fecha_Vencer_2021	=	BancodePuntos_2021_BuscaFechaVencer();
    //$DatosVencimiento		=	BancoDePuntos_2021_SaldoAVencer($rut, $Fecha_Vencer_2021);

    $PuntosaVencer2023    = BancodePuntos_2023_puntos_avancer_data_porrut($rut);
    if($saldo_puntos>0){
        $PRINCIPAL = str_replace("{DISPLAY_VENCIMITNO}",	"",	$PRINCIPAL);
    } else {
        $PRINCIPAL = str_replace("{DISPLAY_VENCIMITNO}",	"display:none!important;",	$PRINCIPAL);
    }

    if($PuntosaVencer2023[0]->puntos_a_vencer>0){
        $tipo_vencimiento=checkCartolaNoVence($rut, $PuntosaVencer2023[0]->fecha_a_vencer, $vc->puntos);
        //echo "vencimiento ".$tipo_vencimiento;
        if($tipo_vencimiento=="SIN_VENCIMIENTO"){
            $PRINCIPAL = str_replace("{PUNTOS_A_VENCER_2023}",	"0",$PRINCIPAL);
            $PRINCIPAL = str_replace("{FECHA_A_VENCER_2023}",	"".fechaCastellano2($PuntosaVencer2023[0]->fecha_a_vencer),	$PRINCIPAL);
            $PRINCIPAL = str_replace("{DISPLAY_VENCIMITNO_PROXIMO}",	"display:none!important;",	$PRINCIPAL);
        } else {
            $puntos_vencidos = (-1) * $PuntosaVencer2023[0]->puntos_saldo_vencidos;

            if($PuntosaVencer2023[0]->puntos_a_vencer>$puntos_vencidos){
                $puntos_vencer_casoB=$puntos_vencidos;
            } else {
                $puntos_vencer_casoB=$PuntosaVencer2023[0]->puntos_a_vencer;
            }
            $PRINCIPAL = str_replace("{PUNTOS_A_VENCER_2023}",	($puntos_vencer_casoB),$PRINCIPAL);
            $PRINCIPAL = str_replace("{FECHA_A_VENCER_2023}",	"".fechaCastellano2($PuntosaVencer2023[0]->fecha_a_vencer)."",	$PRINCIPAL);

        }

    }
    elseif($PuntosaVencer2023[0]->puntos_a_vencer<=0){

        $cartola_proximos_rut=CartolaProximas_rut_2023($rut);
        //print_r($cartola_proximos_rut);
        foreach ($cartola_proximos_rut as $vc) {
            if ($vc->puntos > 0) {
                $tipo_vencimiento = checkCartolaNoVence($rut, $vc->fecha, $vc->puntos);

                if ($tipo_vencimiento == "SIN_VENCIMIENTO") {
                    continue;
                }

                $cuenta_cartola_venc++;

                if ($cuenta_cartola_venc == 1) {
                    if (!empty($PuntosaVencer2023) && isset($PuntosaVencer2023[0])) {
                        if ($PuntosaVencer2023[0]->puntos_a_vencer > $puntos_vencidos) {
                            $puntos_vencer_casoB = $puntos_vencidos;
                        } else {
                            $puntos_vencer_casoB = $PuntosaVencer2023[0]->puntos_a_vencer;
                        }

                        $PuntosaVencer2023[0]->puntos_a_vencer = $puntos_vencer_casoB;
                        $PuntosaVencer2023[0]->fecha_a_vencer = $vc->fecha;
                    } else {
                        // Handle the case where $PuntosaVencer2023 is empty or not set
                        // You can initialize it here if needed
                    }
                }
            }
        }



        $PuntosaVencer2023_cartola    = BancodePuntos_2023_puntos_avancer_data_porrut($rut);
        $PRINCIPAL = str_replace("{PUNTOS_A_VENCER_2023}",	($PuntosaVencer2023[0]->puntos_a_vencer),$PRINCIPAL);
        $PRINCIPAL = str_replace("{FECHA_A_VENCER_2023}",	"".fechaCastellano2($PuntosaVencer2023[0]->fecha_a_vencer),	$PRINCIPAL);

    }


    $PRINCIPAL = str_replace("{TOTAL_PUNTOS_RECIBIDOS}",($puntos_usuario[0]->puntosrecibidos),$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOTAL_PUNTOS_CANJEADOS}",($puntos_usuario[0]->puntoscanjeados),$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOTAL_PUNTOS_SALDOS}",($puntos_usuario[0]->puntossaldo),$PRINCIPAL);
    if($swa=="solicitud"){
        $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_solicitud_ingresada.html"),$PRINCIPAL);
    }elseif($swa=="sinpuntos"){
        $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_notienepuntos.html"),$PRINCIPAL);
    }elseif($swa=="solicitudyarealizada"){
        $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_solicitudyaingresada.html"),$PRINCIPAL);
    }else{
        $PRINCIPAL = str_replace("{SWEET_ALERT}","",$PRINCIPAL);
    }


    $arreglo_puntos_a_vencer_fecha=premios_puntos_a_vencer_2020($rut, $id_empresa);
    $puntos_a_vencer=$arreglo_puntos_a_vencer_fecha[0]->puntos;
    $fecha_a_vencer=$arreglo_puntos_a_vencer_fecha[0]->fecha;
    $fecha_a_vencer = date("d-m-Y", strtotime($fecha_a_vencer));

    $PRINCIPAL = str_replace("{PUNTOS_A_VENCER}",$puntos_a_vencer, $PRINCIPAL);
    $PRINCIPAL = str_replace("{FECHA_A_vENCER}",$fecha_a_vencer, $PRINCIPAL);
    $PRINCIPAL = str_replace("{SWEETALERT_IMAGEN}",$sweetalert_imagen, $PRINCIPAL);
    $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
    $PRINCIPAL=ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
    $PRINCIPAL = str_replace("{LI_RECIENTE}","PRUEB", $PRINCIPAL);
    $PRINCIPAL = str_replace("{FOTO_AUTOR}",VerificaFotoPersonal($rut),$PRINCIPAL);
    $PRINCIPAL = str_replace("{LI_RECIENTE}",$LI_RECIENTE, $PRINCIPAL);
    $PRINCIPAL = str_replace("{LI_POPULARES}",$LI_POPULARES, $PRINCIPAL);
    $PRINCIPAL = str_replace("{LI_MISPRACTICAS}",$LI_MISPRACTICAS, $PRINCIPAL);
    $PRINCIPAL = str_replace("{LI_MISFAVORITAS}",$LI_MISFAVORITAS, $PRINCIPAL);
    $PRINCIPAL = str_replace("{LI_CATEGORIA}",$LI_CATEGORIA, $PRINCIPAL);
    $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
    $PRINCIPAL = str_replace("{MENU_SECUNDARIO}","", $PRINCIPAL);
    $PRINCIPAL = str_replace("{BARRA_NAVEGACION_BUSCADOR}","", $PRINCIPAL);
    $PRINCIPAL = str_replace("{INSIGNIA}","", $PRINCIPAL);
    $PRINCIPAL = str_replace("{VALUE_NOMBRE}","", $PRINCIPAL);
    $PRINCIPAL = str_replace("{CONTENIDO_INGRESADO}","", $PRINCIPAL);
    $PRINCIPAL = str_replace("{VALUE_OBJETIVO}","", $PRINCIPAL);
    $PRINCIPAL = str_replace("{LISTA_CARTOLA_PUNTOS}",$row_puntos,$PRINCIPAL );
    $PRINCIPAL = str_replace("{TOTAL_ABONOS}",$abonos,$PRINCIPAL );
    $PRINCIPAL = str_replace("{TOTAL_CARGOS}",$cargos,$PRINCIPAL );
    $PRINCIPAL = str_replace("{SALDO_PUNTOS}",$saldo_puntos,$PRINCIPAL );
    $PRINCIPAL=ColocaDatosPerfil($PRINCIPAL, $rut);
    //$PRINCIPAL=ColocaDatosMallaCapacitacion(FuncionesTransversales($PRINCIPAL), $rut, $id_empresa);
    //$PRINCIPAL=ColocaMPEstadisticas($PRINCIPAL, $id_empresa);
    //$segmento='Casa Matriz';
    $segmento=RF_buscasegmento($rut, $id_empresa);

    //print_r($segmento);
    $segmento_col=($segmento[0]->mundo);
    //echo $segmento_col;

    if($segmento[0]->mundo==""){$segmento="Comercial";} else {$segmento=$segmento[0]->mundo;}

    $PRINCIPAL  =Com_Premios_ListadoPremios($PRINCIPAL, $segmento, $id_empresa);
    $premios_al_rut=Com_Premios_ListadoPremios_RUT($rut, $id_empresa);
    //echo "<br>premios_al_rut $premios_al_rut";
    $PRINCIPAL = str_replace("{LISTADO_PREMIOS_RUT_2022}",$premios_al_rut, $PRINCIPAL);
    // vista de Postulaciones
    $arr_mis_postulaciones=Postulaciones_busca_CanjePuntos($rut, $segmento, $id_empresa);
    //print_r($arr_mis_postulaciones);
    foreach($arr_mis_postulaciones as $unico){



        $fecha_castellano="";
        if($unico->fecha_texto){
            $fecha_castellano=fechaCastellano($unico->fecha_texto);
            $infocanjeadicional=", a canjear el ".$fecha_castellano; } else {$infocanjeadicional="";}

        if($unico->hora_inicio){

            $infocanjeadicional.=" a las ".$unico->hora_inicio;
        }


        $cuenta_postulaciones++;


        if($unico->estadovalidacion=='2'){

            $estilo="warning";
            $estado="Falta Aprobaci&oacute;n de Jefatura";
        }

        if($unico->estadovalidacion=='1'){

            continue;
        }



        $txt_data_postulaciones.="
    <div class=''>
        <div class='col-lg-4 col-md-4 col-sm-4 col-xs-4'><strong><i class='fas fa-chevron-circle-right'></i> ".$unico->fecha."</strong></div>
        <div class='col-lg-5 col-md-5 col-sm-5 col-xs-5'>".($unico->premio)." $infocanjeadicional</div>
        <div class='col-lg-3 col-md-3 col-sm-3 col-xs-3'><span class='badge badge-".$estilo."'><span class='blanco'>".$estado."</span></span><br><small>".$recomendacion."</small></div>

    </div>
    <hr>
        ";

    }
    $txt_data_postulaciones."<br>";

    //echo "cuenta $cuenta_postulaciones";
    $txt_titulo_postulaciones="";
    if($cuenta_postulaciones>0){
        $txt_titulo_postulaciones="
        <div class='alert alert-warning' role='alert'><strong>Mis solicitudes a Beneficios (".$cuenta_postulaciones.")</strong></div>";
    }

    $arr_mis_postulaciones_validar=Postulaciones_busca_BeneficiosValidar($rut, $id_empresa);
    //print_r($arr_mis_postulaciones_validar);

    foreach($arr_mis_postulaciones_validar as $unico){
        $cuenta_postulacionesvalidar++;


        $fecha_castellano="";
        if($unico->fecha_texto){
            $fecha_castellano=fechaCastellano($unico->fecha_texto);
            $infocanjeadicional=", a canjear el ".$fecha_castellano; } else {$infocanjeadicional="";}


        if($unico->hora_inicio){
            $infocanjeadicional.=" a las ".$unico->hora_inicio;
        }


        $rut_encodeado=Encodear3($unico->rut);
        $id_encodeado=Encodear3($unico->id);

        $txt_data_postulacionesvalidar.="
    <div class=''>
        <div class='col-lg-4 col-md-4 col-sm-4 col-xs-4'><strong><i class='fas fa-chevron-circle-right'></i> ".$unico->nombre_completo."</strong></div>
        <div class='col-lg-5 col-md-5 col-sm-5 col-xs-5'>".($unico->premio)." $infocanjeadicional</div>
        <div class='col-lg-3 col-md-3 col-sm-3 col-xs-3'>

        <a href='?sw=ActualizaJefe_beneficios&rut_enc=".$rut_encodeado."&idpremio=".$id_encodeado."&v=1' class='btn btn-success'>Validar</a>
        <a href='?sw=ActualizaJefe_beneficios&rut_enc=".$rut_encodeado."&idpremio=".$id_encodeado."&v=2' class='btn btn-danger'>Rechazar</a>

    </div>
    <hr>
        ";

    }

    $txt_data_postulacionesvalidar."<br>";
    $txt_titulo_postulacionesvalidar="";
    if($cuenta_postulacionesvalidar>0){
        $txt_titulo_postulacionesvalidar="
        <div class='alert alert-danger' role='alert'><strong>Solicitudes de mi Equipo (".$cuenta_postulacionesvalidar.")</strong></div>";
    }

    $PRINCIPAL = str_replace("{TITULO_MISPOSTULACIONES}",$txt_titulo_postulaciones, $PRINCIPAL);
    $PRINCIPAL = str_replace("{DATA_MISPOSTULACIONES}", $txt_data_postulaciones, $PRINCIPAL);
    $PRINCIPAL = str_replace("{TITULO_VALIDACIONPOSTULACIONES}",$txt_titulo_postulacionesvalidar, $PRINCIPAL);
    $PRINCIPAL = str_replace("{DATA_VALIDACIONPOSTULACIONES}", $txt_data_postulacionesvalidar, $PRINCIPAL);

    $PRINCIPAL=CartolaPuntosAVencer($PRINCIPAL, $rut);

    $PRINCIPAL=BannerHome_2023($PRINCIPAL, $rut);





    echo $PRINCIPAL;
}


    else if($seccion=="ActualizaJefe_beneficios"){




    $rut=$_SESSION["user_"];
    $idpremio=Decodear3($_GET["idpremio"]);
    //echo "rut $rut, idpremio $idpremio";sleep(2);
    $id_empresa=$_SESSION["id_empresa"];
    //echo "<br>id emresa $id_empresa";
    //sleep(2);
    $rut_enc=Decodear3($_GET["rut_enc"]);


        $id_premio=buscaDatosPremio($idpremio, $id_empresa);

        $datos_item            =DatosPremioId($id_premio, $id_empresa);
        $datosautor            =mp_buscaDATOSPERSONAS($rut_enc, $id_empresa);
        $datosjefe            =mp_buscaDATOSPERSONAS($rut, $id_empresa);

        //echo "rut_enc $rut_enc";sleep(4);

    $v=($_GET["v"]);

    //echo "rut $rut, d_empresa $id_empresa, v $v";sleep(10);

    if($v==1){$v="1";
		$txt_subject="¡Felicidades, tu canje ".($datos_item[0]->premio)." ha sido aprobado!";
		$txt_usuario="¡Felicidades! Tu solicitud de canje ".($datos_item[0]->premio)." ha sido aprobada";
			
        $txt_usuario2=$datosautor[0]->nombre_completo.", asegúrate de haber seguido todas las instrucciones del canje. Si tienes dudas comunícate con tu jefatura o Centro de Atención Personas. ";
        $txt_usuario3=" ";}

    if($v==2){$v="3";
        $txt_subject="Lo lamentamos, tu canje ".($datos_item[0]->premio)." no ha sido aprobado";
		$txt_usuario="Lo lamentamos, tu canje ".($datos_item[0]->premio)." no ha sido aprobado";

        $txt_usuario2="Lástima, éstas cosas pueden pasar.<br><br> Si ya conversaste con tu jefatura ya conoces las razones.<br>Si no conoces las razones te invitamos a conversar con tu jefatura";
        //$txt_usuario3="Banco de Puntos tiene este y muchos otros canjes para ti! Revisa todas nuestras categorías y descubre otros canjes pensados en ti. ";
		$txt_usuario3=" ";
    }

    //echo "<br>22561";

    //echo "v $v";
    Beneficios_UPDATEJEFE($idpremio,$id_empresa,$v);
    ////echo "<br>22561";

    if($v=="3" or $v=="2"){
        EliminaCanjePuntosCero($idpremio, $id_empresa, "0");
    }


    //echo "actualiza";
    //exit();
        //

        //echo "<br>txt usuario $txt_usuario";
        //echo "<br>txt usuario2 $txt_usuario2";
        //echo "<br>txt usuario3 $txt_usuario3";



    if($id_empresa=='78'){
    //SEND GRID
    //email a Postulante
    $titulo1=$txt_usuario;
    $subject=$txt_subject;
    $subtitulo1=$txt_usuario2;
    $texto1=$txt_usuario3;

    $texto2="";
    if($v=="1"){
    $texto3=($datos_item[0]->alertaemailusuario);
    }



    $tipomensaje="Email_ValidacionBeneficio_usuario";
    $rut=$datosautor[0]->rut;
    $key=$datosautor[0]->rut;
    $to=$datosautor[0]->email;

    //print_r($datosautor);
    //exit();
    //echo "user to $to";
    //$to="rod@gop.cl";
    $url=$url_base;

    $nombreto=($datosautor[0]->nombre_completo);
    SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");



    //email a jefatura

    $titulo1=" Solicitud de canje actualizada";
    $subject="Banco de Puntos [".$idpremio."]: Solicitud de canje actualizada";
    $subtitulo1=($datosjefe[0]->nombre_completo).", ya cerraste la solicitud de ".($datosautor[0]->nombre_completo)."
    por canje de ".($datos_item[0]->premio)." ";

    $texto1="";

    $texto2="Hemos enviado una notificaci&oacute;n al colaborador";
    if($v=="1"){
    $texto3=($datos_item[0]->alertaemailjefe);
    }

    $tipomensaje="Email_ValidacionBeneficio_usuario";
    $rut=$datosjefe[0]->rut;
    $key=$datosjefe[0]->rut;
    $to=$datosjefe[0]->email;

    //echo "jefe to $to";

    //$to="rod@gop.cl";
    $url=$url_base;


    $nombreto=($datosautor[0]->nombre_completo);
    SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");



    //email a admin
    //$titulo1="¡Nueva Postulaci&oacute;n a ".$beca_nombre."!";
    //$subject="¡Nueva Postulaci&oacute;n a ".$beca_nombre."!";
    //$subtitulo1=($datosautor[0]->nombre_completo).", ha postulado a ".$beca_nombre;
    //$texto1="";
    //$texto2="Recuerda que debes ingresar al administrador para validar sus antecedentes";
    //$tipomensaje="Email_Postulacion_admin";
    //$rut=$arreglo_MP[0]->rut;
    //$key=$arreglo_MP[0]->id_mp;
    //$to="beneficiosrf@cencosud.cl";
    //$to="rod@gop.cl";
    //$url=$url_base;
    //$nombreto=($datosautor[0]->nombre_completo);
    //SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "template_notificacion_general");

    }



    echo "<script>location.href='?sw=com_vota_canjea';</script>";
    exit();

    }
    else if($seccion=="ActualizaJefe_beneficios_validar"){


    $rut=$_SESSION["user_"];
    //echo "rut $rut, idpremio $idpremio";sleep(2);
    $id_empresa=$_SESSION["id_empresa"];
    //echo "<br>id emresa $id_empresa";
    //sleep(2);

    $rut_enc=Decodear3($_GET["rut_enc"]);
    $idbeneficioenc=Decodear3($_GET["idbeneficioenc"]);
    $idbeneitemenc=Decodear3($_GET["iditemenc"]);

    //echo   "rut $rut_enc id beneficio $idbeneficioenc, idbeneitemenc $idbeneitemenc";

    $datos_item            =buscaDatosBeneItem($idbeneitemenc, $id_empresa);
    $datosautor            =mp_buscaDATOSPERSONAS($rut_enc, $id_empresa);
    $datosjefe             =mp_buscaDATOSPERSONAS($rut, $id_empresa);
    //echo "<br>datos_item<br>";
    //print_r($datos_item);exit();
        //echo "rut_enc $rut_enc";sleep(4);

    $v=($_GET["v"]);

    //echo "rut $rut, d_empresa $id_empresa, v $v";sleep(10);

    if($v==1){$v="1";
        $txt_usuario="¡Felicidades ".$datosautor[0]->nombre_completo.", tu solicitud:".($datos_item)." ha sido validada por tu Jefatura!";

        $txt_usuario2=" ";
        $txt_usuario3=" ";}

    if($v==2){$v="3";
        $txt_usuario="Lo lamentamos, tu solicitud: ".($datos_item)." no ha sido aprobado por tu jefatura";

        $txt_usuario2="<br><br> Si tienes dudas conversa con tu jefatura y vuelve a intentarlo.";
        $txt_usuario3="";

    }
     ActualizaJefe_beneficios_validar($idbeneficioenc, $v, $id_empresa);

    //echo "<br>22561";

    //echo "v $v";
    //Beneficios_UPDATEJEFE($idpremio,$id_empresa,$v);
    ////echo "<br>22561";




    //echo "actualiza";
    //exit();
        //

        //echo "<br>txt usuario $txt_usuario";
        //echo "<br>txt usuario2 $txt_usuario2";
        //echo "<br>txt usuario3 $txt_usuario3";



    if($id_empresa=='61'){
    //SEND GRID
    //email a Postulante
    $titulo1=$txt_usuario;
    $subject=$txt_usuario;
    $subtitulo1=$txt_usuario2;
    $texto1=$txt_usuario3;

    $texto2="";
    if($v=="1"){
    $texto3=($datos_item[0]->alertaemailusuario);
    }



    $tipomensaje="Email_ValidacionBeneficio_usuario";
    $rut=$datosautor[0]->rut;
    $key=$datosautor[0]->rut;
    $to=$datosautor[0]->email;

    //print_r($datosautor);
    //exit();
    //echo "user to $to";
    //$to="rod@gop.cl";
    $url=$url_base;

    $nombreto=($datosautor[0]->nombre_completo);
    $template_correo="template_notificacion_beneficios";

    SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url, $texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $template_correo);



    //email a jefatura

    $titulo1=" Solicitud de Beneficio Actualizada";
    $subject=" Solicitud de Beneficio Actualizada";
    $subtitulo1=($datosjefe[0]->nombre_completo).", ya cerraste la solicitud de ".($datosautor[0]->nombre_completo)."
    por el beneficio: ".($datos_item)." ";

    $texto1="";

    $texto2="Hemos enviado una notificaci&oacute;n a ".($datosautor[0]->nombre_completo);
    if($v=="1"){
    $texto3=($datos_item[0]->alertaemailjefe);
    }

    $tipomensaje="Email_ValidacionBeneficio_usuario";
    $rut=$datosjefe[0]->rut;
    $key=$datosjefe[0]->rut;
    $to=$datosjefe[0]->email;

    //echo "jefe to $to";

    //$to="rod@gop.cl";
    $url=$url_base;

     $template_correo="template_notificacion_beneficios";

    SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url, $texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $template_correo);

    $nombreto=($datosautor[0]->nombre_completo);



    //email a admin
    //$titulo1="¡Nueva Postulaci&oacute;n a ".$beca_nombre."!";
    //$subject="¡Nueva Postulaci&oacute;n a ".$beca_nombre."!";
    //$subtitulo1=($datosautor[0]->nombre_completo).", ha postulado a ".$beca_nombre;
    //$texto1="";
    //$texto2="Recuerda que debes ingresar al administrador para validar sus antecedentes";
    //$tipomensaje="Email_Postulacion_admin";
    //$rut=$arreglo_MP[0]->rut;
    //$key=$arreglo_MP[0]->id_mp;
    //$to="beneficiosrf@cencosud.cl";
    //$to="rod@gop.cl";
    //$url=$url_base;
    //$nombreto=($datosautor[0]->nombre_completo);
    //SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "template_notificacion_general");

    }

    echo "<script>location.href='?sw=home_beneficios';</script>";
    exit();

    }
    else if($seccion=="FC_ActualizaJefe_postulacion"){


    }
    else if($seccion=="com_vota_canjea_cartola"){
         //   ini_set('display_errors', 1);ini_set('display_startup_errors', 1);error_reporting(E_ALL);
        $rut=$_SESSION["user_"];
        $id_empresa=$_SESSION["id_empresa"];
        $id_premio=$_GET["id_premio"];
        $swa="";
        $fecha_solicitud=$_POST["fecha_limite_".$id_premio];

				//if($rut=="12345"){
		$Fecha_Vencer_2021=BancodePuntos_2021_BuscaFechaVencer();
		BancoDePuntos_2021_SaldoAVencer($rut, $Fecha_Vencer_2021);
				//}

        $fechas_sol = explode("/", $fecha_solicitud);
        $fecha_ingles=$fechas_sol[2]."-".$fechas_sol[1]."-".$fechas_sol[0];
        $hora_desde=$_POST["hora_desde_".$id_premio];
        $hora_hasta=$_POST["hora_hasta_".$id_premio];

        $puntos_usuario=premios_buscadatos($rut, $id_empresa);
        $saldo_puntos_array=premios_buscaSaldo($rut, $id_empresa);
        $abonos=$saldo_puntos_array[0]->puntos;
        $cargos=$saldo_puntos_array[1]->puntos;
        $saldo_puntos=round($abonos-$cargos);

        //echo $swa;
        //BUSCADATOSPERSONALES CANJES
        $rut=$_SESSION["user_"];

        $puntos_cartola=premios_busca_cartola($rut, $id_empresa, "");
        //print_r($puntos_cartola);
        $cuenta_cartola=0;
        foreach($puntos_cartola as $unico){

        $cuenta_cartola++;


            $row_puntos.=FuncionesTransversales(file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_row_cartola.html"));


            $Prem=DatosPremioId($unico->tipo, $id_empresa);
            //print_r($Prem);
            $LinkPdf_directo="";

            if($Prem[0]->concodigopremiounico=="1"){
                $CuentaLinkPdfMultiple=PuntosCodigoPremioMultiplesUnico($unico->tipo, $rut);
                //echo "<br>concodigopremiounico 1, cuenta ".count($CuentaLinkPdfMultiple);
                if($CuentaLinkPdfMultiple>1){
                    foreach($CuentaLinkPdfMultiple as $unicM){
                        if($unicM->linkpdf<>""){
                            $LinkPdf_directo.="<a href='".$unicM->linkpdf."' target='blank' class='btn btn-info'>Accede a tu canje</a>";
                        }

                    }
                    //echo "<br>Cuentamayor1";


                } else {
                    $LinkPdf=PuntosCodigoPremioUnico($unico->tipo, $rut);
                    $LinkPdf_directo="<a href='".$LinkPdf[0]->linkpdf."' target='blank' class='btn btn-info'>Accede a tu canje</a>";

                }
            }
            if($Prem[0]->link_externo<>""){
                $LinkPdf_directo="<a href='".$Prem[0]->link_externo."' target='blank' class='btn btn-info'>Accede a Link</a>";
                if($Prem[0]->concodigopremiounico=="1"){
                    $LinkPdf=PuntosCodigoPremioMultiplesUnico($unico->tipo, $rut);
                    //echo "<br>link externo";
                    foreach ($LinkPdf as $unicoMultiple ){
                        //print_r($unicoMultiple);
                        if($unicoMultiple->codigo<>""){
                            $LinkPdf_directo.="<br> - Codigo: ".$unicoMultiple->codigo;
                        }

                    }
                }
            }

            //echo "<br>".$Prem[0]->id_premio." ".$Prem[0]->link_externo." ".$LinkPdf_directo;


                if($unico->ingreso=="egreso")    {
                $icon="<span class='badge badge-danger'><span class='blanco'><i class='fas fa-angle-left'></i></span></span>";
                $NombrePremio=PremioBuscaNombre($unico->tipo, $id_empresa);
                $estado="";
                if($unico->descripcion==1){
                $estado="Canjeado";
                } elseif($unico->descripcion==2){
                $estado="Pendiente";
                }


                $descripcion=$icon." ".$NombrePremio." ".$LinkPdf_directo;;
                $cargos=$unico->puntos;
                $abonos="";
                }
                if($unico->ingreso=="ingreso")    {
                $icon="<span class='badge badge-success'><span class='blanco'><i class='fas fa-angle-right'></i></span></span>";
                
                if($unico->descripcion=="Puntos Vencidos"){
                	 $icon="<span class='badge badge-danger'><span class='blanco'><i class='fas fa-angle-left'></i></span></span>";
                }

                    $descripcion=$icon." ".$unico->descripcion." ".$LinkPdf_directo;

                //$descripcion=$icon." ".$unico->descripcion;
                $abonos=$unico->puntos;
                $cargos="";
                $estado="";

                }

            if($unico->tipo=="bch_lolla2023"){
                $descripcion.="/ ".BuscaDia_Canje_2022_lolla($unico->id);
            }



							if($unico->descripcion=="Puntos Vencidos"){
								$fecha = date('Y-m-d', strtotime($unico->fecha . ' +0 day'));
							} else {
								$fecha=$unico->fecha;
							}

                $row_puntos = str_replace("{FECHA}",($fecha),$row_puntos);
                $row_puntos = str_replace("{DESCRIPCION}",(($descripcion)),$row_puntos);
                $row_puntos = str_replace("{ESTADO}",(($estado)),$row_puntos);
                $row_puntos = str_replace("{CARGOS}",($cargos),$row_puntos);
                $row_puntos = str_replace("{ABONOS}",($abonos),$row_puntos);





            //echo "<br>->a ".$row_puntos;


        }

        //echo "<pre>";print_r($row_puntos);        echo "<br>-> id_empresa $id_empresa";
        $PRINCIPAL=FuncionesTransversales(file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_cartola.html"));


        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_RECIBIDOS}",($puntos_usuario[0]->puntosrecibidos),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_CANJEADOS}",($puntos_usuario[0]->puntoscanjeados),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_SALDOS}",($puntos_usuario[0]->puntossaldo),$PRINCIPAL);
        if($swa=="solicitud"){
            $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_solicitud_ingresada.html"),$PRINCIPAL);
        }elseif($swa=="sinpuntos"){
            $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_notienepuntos.html"),$PRINCIPAL);
        }elseif($swa=="solicitudyarealizada"){
            $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_solicitudyaingresada.html"),$PRINCIPAL);
            }else{
        $PRINCIPAL = str_replace("{SWEET_ALERT}","",$PRINCIPAL);
        }
        $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL=ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
        $PRINCIPAL = str_replace("{LI_RECIENTE}","PRUEB", $PRINCIPAL);
        $PRINCIPAL = str_replace("{FOTO_AUTOR}",VerificaFotoPersonal($rut),$PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_RECIENTE}",$LI_RECIENTE, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_POPULARES}",$LI_POPULARES, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISPRACTICAS}",$LI_MISPRACTICAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISFAVORITAS}",$LI_MISFAVORITAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_CATEGORIA}",$LI_CATEGORIA, $PRINCIPAL);
        $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = str_replace("{MENU_SECUNDARIO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{BARRA_NAVEGACION_BUSCADOR}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{INSIGNIA}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_NOMBRE}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{CONTENIDO_INGRESADO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_OBJETIVO}","", $PRINCIPAL);


        $PRINCIPAL = str_replace("{LISTA_CARTOLA_PUNTOS}",$row_puntos,$PRINCIPAL );

        $PRINCIPAL = str_replace("{TOTAL_ABONOS}",$abonos,$PRINCIPAL );
        $PRINCIPAL = str_replace("{TOTAL_CARGOS}",$cargos,$PRINCIPAL );
        $PRINCIPAL = str_replace("{SALDO_PUNTOS}",$saldo_puntos,$PRINCIPAL );


        $PRINCIPAL=ColocaDatosPerfil($PRINCIPAL, $rut);
        //$PRINCIPAL=ColocaDatosMallaCapacitacion(FuncionesTransversales($PRINCIPAL), $rut, $id_empresa);
        //$PRINCIPAL=ColocaMPEstadisticas($PRINCIPAL, $id_empresa);
        //$segmento='Casa Matriz';


        /*$segmento=RF_buscasegmento($rut, $id_empresa);

        $segmento_col=($segmento[0]->mundo);

        if($segmento[0]->mundo==""){$segmento="Comercial";} else {
        $segmento=$segmento[0]->mundo;

        }

        $PRINCIPAL=Com_Premios_ListadoPremios($PRINCIPAL, $segmento, $id_empresa);
        $PRINCIPAL=Com_Premios_ListadoPremios_RUT($PRINCIPAL, $rut, $id_empresa);

        $PRINCIPAL=Com_Premios_ListadoPremios_SinDimension_items($PRINCIPAL,  $segmento, $id_empresa);


    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL,"bch_tl",  $segmento, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento, $id_empresa);*/


    //echo "hol2";

    // vista de Postulaciones
    $arr_mis_postulaciones=Postulaciones_busca_CanjePuntos($rut, $segmento, $id_empresa);
    //print_r($arr_mis_postulaciones);

    foreach($arr_mis_postulaciones as $unico){
    $cuenta_postulaciones++;


    if($unico->estadovalidacion=='2'){

        $estilo="warning";
        $estado="Falta Aprobaci&oacute;n de Jefatura";
    }

    if($unico->estadovalidacion=='1'){

        $estilo="success";
        $estado="Beneficio Aprobado por Jefatura";
    }



    $txt_data_postulaciones.="
    <div class=''>
        <div class='col-lg-4 col-md-4 col-sm-4 col-xs-4'><strong><i class='fas fa-chevron-circle-right'></i> ".$unico->fecha."</strong></div>
        <div class='col-lg-5 col-md-5 col-sm-5 col-xs-5'>".($unico->premio)."</div>
        <div class='col-lg-3 col-md-3 col-sm-3 col-xs-3'><span class='badge badge-".$estilo."'><span class='blanco'>".$estado."</span></span><br><small>".$recomendacion."</small></div>

    </div>
    <hr>
        ";

    }
    $txt_data_postulaciones."<br>";


    //echo "cuenta $cuenta_postulaciones";
    $txt_titulo_postulaciones="";
    if($cuenta_postulaciones>0){
        $txt_titulo_postulaciones="
        <div class='alert alert-warning' role='alert'><strong>Mis solicitudes a Beneficios (".$cuenta_postulaciones.")</strong></div>";
    }



    $arr_mis_postulaciones_validar=Postulaciones_busca_BeneficiosValidar($rut, $id_empresa);
    //print_r($arr_mis_postulaciones_validar);

    foreach($arr_mis_postulaciones_validar as $unico){
    $cuenta_postulacionesvalidar++;

    $rut_encodeado=Encodear3($unico->rut);
    $id_encodeado=Encodear3($unico->id);

    $txt_data_postulacionesvalidar.="
    <div class=''>
        <div class='col-lg-4 col-md-4 col-sm-4 col-xs-4'><strong><i class='fas fa-chevron-circle-right'></i> ".$unico->nombre_completo."</strong></div>
        <div class='col-lg-5 col-md-5 col-sm-5 col-xs-5'>".($unico->premio)."</div>
        <div class='col-lg-3 col-md-3 col-sm-3 col-xs-3'>

        <a href='?sw=ActualizaJefe_beneficios&rut_enc=".$rut_encodeado."&idpremio=".$id_encodeado."&v=1' class='btn btn-success'>Validar</a>

        <a href='?sw=ActualizaJefe_beneficios&rut_enc=".$rut_encodeado."&idpremio=".$id_encodeado."&v=2' class='btn btn-danger'>Rechazar</a>

    </div>
    <hr>
        ";

    }

            $txt_data_postulacionesvalidar .= "<br>";
            $txt_titulo_postulacionesvalidar = "";
            if ($cuenta_postulacionesvalidar > 0) {
                $txt_titulo_postulacionesvalidar = '
                    <div class="alert alert-danger" role="alert">
                        <strong>Solicitudes de mi Equipo (' . htmlspecialchars($cuenta_postulacionesvalidar, ENT_QUOTES, 'UTF-8') . ')</strong>
                    </div>';
            }
            $PRINCIPAL = str_replace("{TITULO_MISPOSTULACIONES}", htmlspecialchars($txt_titulo_postulaciones, ENT_QUOTES, 'UTF-8'), $PRINCIPAL);
            $PRINCIPAL = str_replace("{DATA_MISPOSTULACIONES}", htmlspecialchars($txt_data_postulaciones, ENT_QUOTES, 'UTF-8'), $PRINCIPAL);
            $PRINCIPAL = str_replace("{TITULO_VALIDACIONPOSTULACIONES}", htmlspecialchars($txt_titulo_postulacionesvalidar, ENT_QUOTES, 'UTF-8'), $PRINCIPAL);
            $PRINCIPAL = str_replace("{DATA_VALIDACIONPOSTULACIONES}", htmlspecialchars($txt_data_postulacionesvalidar, ENT_QUOTES, 'UTF-8'), $PRINCIPAL);
    echo $PRINCIPAL;


 }
    else if ($seccion == "canjea_ve_faq") {
            $rut = isset($_SESSION["user_"]) ? htmlspecialchars($_SESSION["user_"], ENT_QUOTES, 'UTF-8') : '';
            $id_empresa = isset($_SESSION["id_empresa"]) ? htmlspecialchars($_SESSION["id_empresa"], ENT_QUOTES, 'UTF-8') : '';

            // Validate and sanitize the variables $rut and $id_empresa as per your application's requirements

            $faq_html_file = "views/faq/" . $id_empresa . "_bch_banco_de_puntos.html";
            $PRINCIPAL = FuncionesTransversales(file_get_contents($faq_html_file));

            echo $PRINCIPAL;
        }



        else if($seccion=="canjea_ve_condiciones"){

        $rut=$_SESSION["user_"];
        $id_empresa=$_SESSION["id_empresa"];
        $PRINCIPAL=FuncionesTransversales(file_get_contents("views/faq/".$id_empresa."_bch_banco_condiciones.html"));


        echo $PRINCIPAL;
        }

    else if($seccion=="com_vota_canjea_items"){
        $rut=$_SESSION["user_"];
        $id_empresa	=	$_SESSION["id_empresa"];
        $id_premio	=	$_GET["id_premio"];

        $id_dim			=	Decodear3($_GET["iddim"]);
        $swa="";
        $fecha_solicitud=$_POST["fecha_limite_".$id_premio];
        //echo "<br> dim $id_dim";
        $puntos_usuario=premios_buscadatos($rut, $id_empresa);
        $saldo_puntos_array=premios_buscaSaldo($rut, $id_empresa);

        $abonos=$saldo_puntos_array[0]->puntos;
        $cargos=$saldo_puntos_array[1]->puntos;
        $saldo_puntos=$abonos-$cargos;

        $fechas_sol = explode("/", $fecha_solicitud);
        $fecha_ingles=$fechas_sol[2]."-".$fechas_sol[1]."-".$fechas_sol[0];
        $hora_desde=$_POST["hora_desde_".$id_premio];
        $hora_hasta=$_POST["hora_hasta_".$id_premio];
        if($id_premio<>''){

        $datosjefe=mp_buscaDATOSPERSONAS($rut, $id_empresa);
        $swa=premios_guarda_solicitud($rut, $id_premio, $datosjefe[0]->jefe,$id_empresa,$fecha_solicitud,$fecha_ingles,$hora_desde,$hora_hasta);
        $datos_premio=traigoPremios($id_premio, $id_empresa);
            if($swa=="solicitud"){
            //EnviaCorreoPuntosGenerico($rut, $datosjefe[0]->jefe, "SolicitudColaborador",file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_email.html"), $datos_premio[0]->premio, $fecha_solicitud);
            //EnviaCorreoPuntosGenerico($rut, $datosjefe[0]->jefe, "SolicitudJefe",file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_email.html"), $datos_premio[0]->premio, $fecha_solicitud);
            }
        //echo $swa;/
        }
        //echo $swa;
        //BUSCADATOSPERSONALES CANJES
        $puntos_usuario=premios_buscadatos($rut, $id_empresa);
        //print_r($puntos_usuario);
        $PRINCIPAL=FuncionesTransversales(file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_items.html"));
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_RECIBIDOS}",($puntos_usuario[0]->puntosrecibidos),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_CANJEADOS}",($puntos_usuario[0]->puntoscanjeados),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_SALDOS}",($puntos_usuario[0]->puntossaldo),$PRINCIPAL);
        if($swa=="solicitud"){
            $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_solicitud_ingresada.html"),$PRINCIPAL);
        }elseif($swa=="sinpuntos"){
            $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_notienepuntos.html"),$PRINCIPAL);
        }elseif($swa=="solicitudyarealizada"){
            $PRINCIPAL = str_replace("{SWEET_ALERT}",file_get_contents("views/reconoce_vota/".$id_empresa."_sweet_alert_solicitudyaingresada.html"),$PRINCIPAL);
            }else{
        $PRINCIPAL = str_replace("{SWEET_ALERT}","",$PRINCIPAL);
        }
        $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL=ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
        $PRINCIPAL = str_replace("{LI_RECIENTE}","PRUEB", $PRINCIPAL);
        $PRINCIPAL = str_replace("{FOTO_AUTOR}",VerificaFotoPersonal($rut),$PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_RECIENTE}",$LI_RECIENTE, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_POPULARES}",$LI_POPULARES, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISPRACTICAS}",$LI_MISPRACTICAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISFAVORITAS}",$LI_MISFAVORITAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_CATEGORIA}",$LI_CATEGORIA, $PRINCIPAL);
        $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = str_replace("{MENU_SECUNDARIO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{BARRA_NAVEGACION_BUSCADOR}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{INSIGNIA}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_NOMBRE}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{CONTENIDO_INGRESADO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_OBJETIVO}","", $PRINCIPAL);

        $PRINCIPAL = str_replace("{TOTAL_ABONOS}",$abonos,$PRINCIPAL );
        $PRINCIPAL = str_replace("{TOTAL_CARGOS}",$cargos,$PRINCIPAL );
        $PRINCIPAL = str_replace("{SALDO_PUNTOS}",$saldo_puntos,$PRINCIPAL );
        $PRINCIPAL = str_replace("{RUT_ENCODEADO}",Encodear3($rut),$PRINCIPAL );

        $PRINCIPAL=ColocaDatosPerfil($PRINCIPAL, $rut);
        //$PRINCIPAL=ColocaDatosMallaCapacitacion(FuncionesTransversales($PRINCIPAL), $rut, $id_empresa);
        //$PRINCIPAL=ColocaMPEstadisticas($PRINCIPAL, $id_empresa);
        //$segmento='Casa Matriz';
        $segmento=RF_buscasegmento($rut, $id_empresa);
        $segmento_col=($segmento[0]->mundo);

        if($segmento[0]->mundo==""){$segmento[0]->mundo="TODOS";}
        //echo $segmento_col;
        $PRINCIPAL=Com_Premios_ListadoPremios_dimension_items($PRINCIPAL, $segmento[0]->mundo, $id_dim, $id_empresa);

        //$PRINCIPAL=Com_Premios_ListadoPremios_RUT($PRINCIPAL, $rut, $id_empresa);
    		//$PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento[0]->mundo, $id_empresa);
   			// $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento[0]->mundo, $id_empresa);
   			// $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL,"bch_tl",  $segmento[0]->mundo, $id_empresa);
   			// $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento[0]->mundo, $id_empresa);

            if ($_GET["iddim"] === "YTBSZ2wzZUJuWm1HRnlHMTF4cm05Zz09") {
                $sweetalert_imagen = "
    <style>
        .sweet-alert {
            background-color: #ffffff;
            width: 791px;
            left: 40%;
        }

        .sweet-alert .sa-icon {
            width: 760px !important;
            height: 400px !important;
            border: 4px solid gray;
            border-radius: 50%;
            margin: 20px auto;
            position: relative;
            box-sizing: content-box;
        }
    </style>

    <script>
        swal({
            title: '',
            text: '',
            imageUrl: 'https://www.bancodepuntosbch.cl/front/img/bch_Pop_up_Mobike_2.png?v31',
            showCancelButton: false,
            showCloseButton: true,
            cancelButtonText: 'No, en otro momento',
            confirmButtonText: 'Cerrar',
        });
    </script>";
            } else {
                $sweetalert_imagen = "";
            }

            $PRINCIPAL = str_replace("{SWEETALERT_IMAGEN}", htmlspecialchars($sweetalert_imagen, ENT_QUOTES, 'UTF-8'), $PRINCIPAL);


            echo $PRINCIPAL;
        }
    else if($seccion=="com_vota_canjea_save"){
			$rut=$_SESSION["user_"];
		    $dia=$_POST["dia"];
            //$dia="2023-08-14";
            if($dia<>""){
                if (validateDateToday($dia)) {
                      // echo "dia A $dia";
                } else {
                        //echo "dia B $dia";
                    echo "
                        <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC' crossorigin='anonymous'>
                            <div class='alert alert-info text-center'>Fecha no es v&aacute;lida<br><a href='?sw=com_vota_canjea'>Volver a Banco de Puntos</a></div>";
                    exit();

                }
            }


		    $direccion=$_POST["direccion"];
            $id_empresa=$_SESSION["id_empresa"];
            $id_premio=Decodear3($_GET["id_premio"]);
		    $array_premio=traigoPremio_data($id_premio, $id_empresa);
            if($id_premio=="bch_lolla2023"){
                $saldo_lolla=BuscaSaldoLolla2023("bch_lolla2023",$direccion);
                $array_premio[0]->saldo=$saldo_lolla;
            }

        if($array_premio[0]->vecespordia>0){
            $veces_canje=BuscoCanjeHoy($id_premio, $rut, $id_empresa, $hoy);
            if($array_premio[0]->vecespordia<=$veces_canje){
                echo "<script>alert('Este item no se puede canjear mas de ".$array_premio[0]->vecespordia." por dia');location.href='?sw=com_vota_canjea';</script>";
                exit();
            }
        }
                                            if($array_premio[0]->saldo>0){
                                             
                                            }   else {
                                                echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
                                                <br><br><br><div class="alert alert-danger" role="alert">
                                                <center> <strong>Atenci&oacute;n</strong>: No hay Stock disponible</center>
                                                </div>';

                                                echo "<script>alert('No hay Stock disponible');location.href='?sw=com_vota_canjea';</script>";
                                                exit();
                                            }
                                            
                                            
                                            
							 $datos_premio						=traigoPremios($id_premio, $id_empresa);
							//print_r($datos_premio);

							 if($datos_premio[0]->restriccion_rut=="1"){
							 	$vecerut=VerificaCanjeRutAnterior($id_premio, $rut, $id_empresa);

							 	if($vecerut>0){
							 	            echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
							            <br><br><br><div class="alert alert-danger" role="alert">
							            <center> <strong>Atenci&oacute;n</strong>: Solo puedes canjear 1 sola vez este item</center>
							            </div>';

							            echo "<script>location.href='?sw=com_vota_canjea';</script>";
							            exit();	
							 	}

							 }

        if($datos_premio[0]->premio_al_rut=="1") {

            $existe_premio_al_rut=VerificaPremioAlRut($id_premio, $rut);
            //echo "premio al rut existe_premio_al_rut $existe_premio_al_rut"; exit();
            if($existe_premio_al_rut>0){

            } else {
                echo "<script>alert('No tienes permisos para canjear este item');location.href='?sw=com_vota_canjea';</script>";
                exit();
            }
        }


				//print_r($_POST);

        $swa="";
        $fecha_solicitud=$_POST["fecha_limite_".$id_premio];
        //echo "rut $rut"; sleep(1);
        //echo "<br> $id_premio $fecha_solicitud $rut";

        $fechas_sol = explode("/", $fecha_solicitud);
        $fecha_ingles=$fechas_sol[2]."-".$fechas_sol[1]."-".$fechas_sol[0];
        $hora_desde=$_POST["hora_desde_".$id_premio];
        $hora_hasta=$_POST["hora_hasta_".$id_premio];

        //$puntos_usuario=premios_buscadatos($rut, $id_empresa);
        //$saldo_puntos_array=premios_buscaSaldo($rut, $id_empresa);		
		
		
        $puntos_usuario			=premios_buscadatos($rut, $id_empresa);
        $saldo_puntos_array	=premios_buscaSaldo($rut, $id_empresa);
        $abonos=$saldo_puntos_array[0]->puntos;
        $cargos=$saldo_puntos_array[1]->puntos;
        $saldo_puntos=round($abonos-$cargos);


        //echo "saldo_puntos  $saldo_puntos, saldo  fecha $fecha_a_vencer";


		
		
		
        if($id_premio<>''){
						        $datosautor            	=DatosUsuario_($rut, $id_empresa);
						        $datosjefe            	=DatosUsuario_($datosautor[0]->jefe, $id_empresa);

        if($datos_premio[0]->solicitadia=="SI" or $datos_premio[0]->solicitadia=="SIHORA"){


            $dia=$_POST["dia"];
            //$dia="2018-07-05";
            //echo "dia $dia<br><br>";
            $fecha_valida=(validateDate($dia, $format = 'Y-m-d'));
            $nombre_dia=FechaaNombredia($dia);
            $validacionFecha=2;
            if($fecha_valida=="SI"){
                $validacionFecha=1;
								$valida_fecha_doble_canje=ChequeaDobleCanjeEseDia_data($dia, $id_premio, $rut, $id_empresa);
								//echo "<br>valida_fecha_doble_canje $valida_fecha_doble_canje";
				
				
				
            } else {
               $validacionFecha=2;
            }



          if($valida_fecha_doble_canje>0)
             {
                echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <br><br><br><div class="alert alert-danger" role="alert">
            <center> <strong>Atenci&oacute;n</strong>: La fecha elegida no es valida pues ya tienes un item canjeado en dicho día</center>
            </div>';

             echo "<script>location.href='?sw=com_vota_canjea';</script>";
             exit();

            }


            if($datos_premio[0]->dia<>''){

          if($validacionFecha<>1)
             {
                echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <br><br><br><div class="alert alert-danger" role="alert">
            <center> <strong>Atenci&oacute;n</strong>: La fecha elegida no es valida, recuerda que debe tener formato 31/12/2018 (dd/mm/yyyy) para el Canje</center>
            </div>';

             echo "<script>location.href='?sw=com_vota_canjea';</script>";
             exit();

            }


            //echo $nombre_dia;
            //echo "<br><br>debe estar en ";echo $datos_premio[0]->dia;
            //sleep(5);


            //$nombre_dia="LU";
            //echo "<br>";

            if (strpos($datos_premio[0]->dia, $nombre_dia) !== false) {
                    //echo 'true';
            } else {
                echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <br><br><br><div class="alert alert-danger" role="alert">
            <center> <strong>Atenci&oacute;n</strong>: El día elegido no corresponde con los disponibles para el Canje</center>
            </div>';

             echo "<script>location.href='?sw=com_vota_canjea';</script>";
             exit();

				}

            }

        }

			        $fecha_solicitud=$dia;
							$hora_desde= $dia=$_POST["hora_inicio"];
			        //print_r($datosautor);
			        //echo "<br>jefe";
			        //print_r($datosjefe);
			        //echo "rut $rut, premio puntos ".$datos_premio[0]->puntos." < saldo $saldo_puntos"; sleep(4);
        				$fecha_castellano="";
					    if($fecha_solicitud<>''){
										    $fecha_castellano=fechaCastellano($fecha_solicitud);
										    $fecha_castellano2=fechaCastellano2($fecha_solicitud);

												$textfecha = str_replace('-', '/', $fecha_castellano);

										    $infocanjeadicional=" para el ".$fecha_castellano2; 
					    } else {
					    					$infocanjeadicional="";
					    				}

									if($hora_desde<>''){
										$texthora_desde = str_replace(':', ' ', $hora_desde);
										$infocanjeadicional.=" a las ".$texthora_desde;	
										}

						        if($datos_premio[0]->puntos>$saldo_puntos){
						            echo '<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
						            <br><br><br><div class="alert alert-danger" role="alert">
						            <center> <strong>Atenci&oacute;n</strong>: No tienes puntos suficientes para realizar el Canje</center>
						            </div>';

						             echo "<script>location.href='?sw=com_vota_canjea';</script>";

						            //?sw=com_vota_canjea

						            exit();
						        }
					            if($datos_premio[0]->aprobacionjefe=="SI"){
												$estado_premios="2"; 
															} else {
												$estado_premios="1"; 
															}
        //echo "hola estado_premios $estado_premios"; 
            $fecha_ingles  =$fecha_solicitud;
            
            //echo "antes de SAVE";
          
          if($datos_premio[0]->concodigopremiounico=="1"){
          	$celular=$_POST["celular"];
          	$id_codigo_entrega=PuntosActualizaBuscaCodigoPremio($id_premio, $rut, $celular, $id_empresa);
         	  $infocanjeadicional="<br>Tu Código es ".$id_codigo_entrega."<br>";        	
          }
          elseif($datos_premio[0]->concodigopremiounico=="3"){
          	$celular=$_POST["celular"];
          	$id_codigo_entrega=PuntosActualizaBuscaCodigoPremio($id_premio, $rut, $celular, $id_empresa);
          	$id_codigo_entrega2=PuntosActualizaBuscaCodigoPremio($id_premio, $rut, $celular, $id_empresa);
          	$id_codigo_entrega3=PuntosActualizaBuscaCodigoPremio($id_premio, $rut, $celular, $id_empresa);
         	  $infocanjeadicional="<br>Tus Códigos son:<br> ".$id_codigo_entrega."<br>".$id_codigo_entrega2."<br>".$id_codigo_entrega3."<br>";
          }          
           else {
          	
          }

            if($id_premio=="bch_lolla2023"){
                $infocanjeadicional=" / ".$direccion;
                //
            }
          
            //echo "<br>".$datosautor[0]->rut.", $id_premio, ".$datosjefe[0]->rut.",$id_empresa,$fecha_solicitud,$fecha_ingles,$hora_desde,$hora_hasta,$estado_premios<br> $infocanjeadicional<br>";
           // exit();
            //print_r($_POST);exit();
            $last_id=premios_guarda_solicitud_estado($datosautor[0]->rut, $id_premio, $datosjefe[0]->rut,$id_empresa,$fecha_solicitud,$fecha_ingles,$hora_desde,$hora_hasta,$estado_premios, $direccion,$_POST["celular_personal"],$_POST["email_personal"]);
								 if($id_empresa=='78'){
								                            //SEND GRID

								            //echo "email";
								            //CON VALIDACION
								            if($datos_premio[0]->aprobacionjefe=="SI"){

								                            

								   
											
											    //echo "jefe";

								                    //email a Postulante
								                    $titulo1="¡Muchas gracias! Hemos recibido tu solicitud de canje ".($datos_premio[0]->premio)."";
								                    $subject="¡Muchas gracias! Hemos recibido tu solicitud de canje ".($datos_premio[0]->premio)."";
								                    $subtitulo1=($datosautor[0]->nombre_completo).",
								                    has solicitado el canje ".($datos_premio[0]->premio)." $infocanjeadicional";
								                    //$texto1="Solo resta la aprobaci&oacute;n de tu jefatura, ".($datosjefe[0]->nombre_completo).", con un tiempo de respuesta máximo de 48 horas.";
								                    //$texto2="Puedes revisar el estado de tu canje en la cartola de puntos. Tu orden está pendiente";
								                    $texto1="";
													$texto2="";
													$texto3=($datos_premio[0]->alertaemailusuario);
								                    $tipomensaje="Email_Postulacion_Beneficio_usuario";
								                    $rut=$datosautor[0]->rut;
								                    $key=$datosautor[0]->rut;
								                    $to=$datosautor[0]->email;
								                    //$to="rod@gop.cl";
								                    $url=$url_base;
								                    $nombreto=($datosautor[0]->nombre_completo);
								                    SendGrid_Email($to, $to, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");
								 

								                    //email a Jefatura
								                    $titulo1="¡Excelente! Alguien de tu equipo canjeó sus puntos";
								                    $subject="Banco de puntos [".$last_id."]: Solicitud pendiente de ".($datosautor[0]->nombre_completo)."";
								                    $subtitulo1=($datosautor[0]->nombre_completo).",
								                    ha solicitado canjear el ítem ".($datos_premio[0]->premio)." $infocanjeadicional<br>
													El plazo máximo para aprobar esta solicitud es de 7 días, de lo contrario se aprobará de forma automática.";
								                    //$texto1="Solo resta tu aprobaci&oacute;n, en un tiempo de respuesta máximo de 48 horas. <br>Ingresando a la plataforma verás la Postulaci&oacute;n pendiente para que la apruebes o rechaces.";
								                    $texto1="";
													$texto2="";
								                    $texto3=($datos_premio[0]->alertaemailjefe);
								                    $tipomensaje="Email_Postulacion_Beneficio_usuario";
								                    $rut=$datosjefe[0]->rut;
								                    $key=$datosjefe[0]->rut;
								                    $to=$datosjefe[0]->email;
								                    //$to="rod@gop.cl";
								                    $url=$url_base;
								                    $nombreto=($datosautor[0]->nombre_completo);
								                    SendGrid_Email($to, $to, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");

								                    $estado_premios="2";

								            } else {
								                    //echo "usuario";

								                    //email a Postulante
								                   // $titulo1="¡Muchas gracias! Has canjeado ".($datos_premio[0]->premio)."";
								                   // $subject="¡Muchas gracias! Has canjeado ".($datos_premio[0]->premio)."";
								                   $titulo1="¡Muchas gracias! Hemos recibido tu solicitud de canje de ".($datos_premio[0]->premio)."";
								                   $subject="¡Muchas gracias! Hemos recibido tu solicitud de canje de ".($datos_premio[0]->premio)."";                  
								                   
								                   
								                   
								                    $subtitulo1=($datosautor[0]->nombre_completo).",
								                    canjeaste ".($datos_premio[0]->premio)." $infocanjeadicional";
								                    $texto1="";
								                    $texto2="Puedes revisar el estado de tu canje en la cartola de puntos. Tu orden está confirmada";
								                    $texto3=($datos_premio[0]->alertaemailusuario);
								                    $tipomensaje="Email_Postulacion_Beneficio_usuario";
								                    $rut=$datosautor[0]->rut;
								                    $key=$datosautor[0]->rut;
								                    $to=$datosautor[0]->email;
								                    //$to="rod@gop.cl";
								                    $url=$url_base;
								                    $nombreto=($datosautor[0]->nombre_completo);
								                    SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");


								if($datos_premio[0]->concodigopremiounico=="1"){} else {
								                    //email a Jefatura
								                    $titulo1="¡Excelente! Alguien de tu equipo canje&oacute; sus puntos";
								                    $subject="Banco de puntos [".$last_id."]: Solicitud de canje actualizada";
								                    $subtitulo1=($datosautor[0]->nombre_completo).",
								                    canje&oacute; el ítem ".($datos_premio[0]->premio)." $infocanjeadicional";
								                    $texto1="";
								                    $texto2="";
								                    $texto3=($datos_premio[0]->alertaemailjefe);
								                    $tipomensaje="Email_Postulacion_Beneficio_usuario";
								                    $rut=$datosjefe[0]->rut;
								                    $key=$datosjefe[0]->rut;
								                    $to=$datosjefe[0]->email;
								                    //$to="rod@gop.cl";
								                    $url=$url_base;
								                    $nombreto=($datosautor[0]->nombre_completo);
								                    SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");
								}
								                    $estado_premios="1";
								            }

								    }			
        //print_r($datosautor );


        }
        //echo $swa;
        //BUSCADATOSPERSONALES CANJES
        $rut=$_SESSION["user_"];

        $puntos_usuario=premios_buscadatos($rut, $id_empresa);
        $saldo_puntos_array=premios_buscaSaldo($rut, $id_empresa);
        $abonos=$saldo_puntos_array[0]->puntos;
        $cargos=$saldo_puntos_array[1]->puntos;
        $saldo_puntos=round($abonos-$cargos);

        Recalculo_puntos_vencer_2023($rut);


            if($datos_premio[0]->id_premio=="bch_soap_auto"){

                $link_soap=PremiosLink2022($datos_premio[0]->id_premio);

                        echo "
                <script>
                alert('Solicitud Ingresada, recibirás confirmación en tu email proximamente');
                location.href='".$link_soap."';
                </script>";
                exit();
            } else if($datos_premio[0]->id_premio=="bch_soap_camioneta"){

            $link_soap=PremiosLink2022($datos_premio[0]->id_premio);
                        echo "
                <script>
                alert('Solicitud Ingresada, recibirás confirmación en tu email proximamente');
                location.href='".$link_soap."';
                </script>";
                exit();
            } else {

            }
        header("Location: ?sw=com_vota_canjea");exit();



	
	}	
    else if($seccion=="com_vota_canjea_items_detalle"){
        $rut=$_SESSION["user_"];
        $id_empresa=$_SESSION["id_empresa"];
        $idi=Decodear3($_GET["idi"]);

        $id_dim=Decodear3($_GET["iddim"]);
        $swa="";
        $fecha_solicitud=$_POST["fecha_limite_".$id_premio];

        //echo "<br> idi $idi, id_dim $id_dim";
        $fechas_sol = explode("/", $fecha_solicitud);
        $fecha_ingles=$fechas_sol[2]."-".$fechas_sol[1]."-".$fechas_sol[0];
        $hora_desde=$_POST["hora_desde_".$id_premio];
        $hora_hasta=$_POST["hora_hasta_".$id_premio];
        if($id_premio<>''){

        $datosjefe=mp_buscaDATOSPERSONAS($rut, $id_empresa);
        $swa=premios_guarda_solicitud($rut, $id_premio, $datosjefe[0]->jefe,$id_empresa,$fecha_solicitud,$fecha_ingles,$hora_desde,$hora_hasta);
        $datos_premio=traigoPremios($id_premio, $id_empresa);
            if($swa=="solicitud"){
                //EnviaCorreoPuntosGenerico($rut, $datosjefe[0]->jefe, "SolicitudColaborador",file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_email.html"), $datos_premio[0]->premio, $fecha_solicitud);
                //EnviaCorreoPuntosGenerico($rut, $datosjefe[0]->jefe, "SolicitudJefe",file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_email.html"), $datos_premio[0]->premio, $fecha_solicitud);
            }
        //echo $swa;/
        }

        //echo $swa;
        //BUSCADATOSPERSONALES CANJES
        $puntos_usuario=premios_buscadatos($rut, $id_empresa);
        //print_r($puntos_usuario);
        $segmento=RF_buscasegmento($rut, $id_empresa);
        $segmento_col=($segmento[0]->mundo);

        if($segmento[0]->mundo==""){$segmento[0]->mundo="TODOS";}

            //echo "<br> idi $idi, id_dim $id_dim";

        $arr_item_detalle=Com_Premios_Detalle($segmento[0]->mundo, $idi, $id_empresa);
        //echo "<pre>";print_r($arr_item_detalle);
        $PRINCIPAL=FuncionesTransversales(file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_items_detalle.html"));
        $array_premio=traigoPremio_data($idi, $id_empresa);
                                            //print_r($array_premio);
                                            if($array_premio[0]->saldo>0){



									//print_r($array_premio);
									if($array_premio[0]->id_grupo_top=="TOP"){


										if($array_premio[0]->vecespordia>0){
											
											//echo "busco si hay canjes nhoy de alguno de los versiones";
											$bloqueo_versiones=0;
												$array_agrupados=BuscaPremiosAgrupados($array_premio[0]->id_premio, $id_empresa);
											foreach ($array_agrupados as $unico){
												$hoy=date("Y-m-d");
												$id_canje=BuscoCanjeHoy($unico->id_premio, $rut, $id_empresa, $hoy);
												
												if($id_canje>0){$bloqueo_versiones=1;}
												
											}
											
											
											
										}

									$boton_form.="	
													<div class=' blanco card-info mb-3 text-center'>
															<div class='card-block'>
																<center> <i class='fas fa-globe'></i> Versiones de Canje</center></div>
															</div>

													<div class='card card-outline-info mb-3 text-center'>
													<div class='card-block'>";

																		
										$array_agrupados=BuscaPremiosAgrupados($array_premio[0]->id_premio, $id_empresa);
										foreach ($array_agrupados as $unico){
										
									if($bloqueo_versiones==1){
										
										$boton_form="<center>[ No puedes canjear más de un item por día ]</center>";
										
									} else {
										
										$boton_form.="




										
										<div class='row'>
											<div class='col-lg-8 '><h4 class='card-title' style='text-align:left'><i class='fas fa-angle-double-right'></i> 
											".$unico->premio."</h4></div>
											<div class='col-lg-4'>
											<form action='?sw=com_vota_canjea_items_detalle_preview&idi=".Encodear3($unico->id_premio)."&iddim=".Encodear3($unico->id_dimension)."' method='POST' name='Form_".Encodear3($unico->id_premio)."' id='Form_".Encodear3($unico->id_premio)."'>
											<div class='col-xs-12 col-lg-12'><center><input type='submit'  value='> Solicitar Canje Aquí <' class='btn btn-info '> </center><br></div></form>
											</div>
										</div>";
											
									}
											
										}
										
										$boton_form.="</div></div>";
										
									} else {
										$boton_form="<form action='?sw=com_vota_canjea_items_detalle_preview&idi={IDI_ENCODEADO}&iddim={IDDIM_ENCODEADO}' method='POST' name='Form_{ID_PREMIO}' id='Form_{ID_PREMIO}'>
										<div class='col-xs-12 col-lg-12'><center><input type='submit'  value='> Solicitar Canje Aquí <' class='btn btn-info '> </center><br></div></form>";	
									}
											

																		
																		
                                            }   else {
                   if($array_premio[0]->stock==0){
               
                    $boton_form="
                    
                    <span class='badge badge-warning'><span class='blanco'>
                     Canje suspendido temporalmente
                    </span> </span>
                    ";
                   	
                   } else {
               
                    
                    $boton_form="
                    
                    <span class='badge badge-danger'><span class='blanco'>
                    Sin stock disponible</span> </span>";
                   	
                   }   
                                            }
											
											
       $num_canjes_rut=num_canjes_rut($rut,$idi, $id_empresa);
      // echo "num_canjes_rut $num_canjes_rut"; 
	   
	   
	   if($arr_item_detalle[0]->restriccion_rut>0 and $num_canjes_rut>=$arr_item_detalle[0]->restriccion_rut){
         // echo "A"; 
		   $boton_form="<span class='badge badge-danger'><span class='blanco'>
                    Ya canjeaste el máximo de veces permitido este año </span> </span>";
                    $estilo_imagen=" img_bn_grasycale ";
         }
       $num_canjes_semestral_rut=num_canjes_semestral_rut($rut,$idi, $id_empresa);

	   if($arr_item_detalle[0]->restriccion_rut_semestral>0 and $num_canjes_semestral_rut>=$arr_item_detalle[0]->restriccion_rut_semestral){
        //  echo "B"; 
		   $boton_form="<span class='badge badge-danger'><span class='blanco'>
                    Ya canjeaste el máximo de veces permitido este semestre </span> </span>";
                    $estilo_imagen=" img_bn_grasycale ";
         }


if($arr_item_detalle[0]->id_premio=="bch_20191101a" or
		$arr_item_detalle[0]->id_premio=="bch_20191101b" or
		$arr_item_detalle[0]->id_premio=="bch_20191101c" ){
			
							$boton_form="<form action='?sw=com_vota_canjea_items_detalle_preview&idi={IDI_ENCODEADO}&iddim={IDDIM_ENCODEADO}' method='POST' name='Form_{ID_PREMIO}' id='Form_{ID_PREMIO}'>
							<div class='col-xs-12 col-lg-12' style='text-align: left;font-size: 14px;'>
							<br>Ingresa Dirección de Despacho<br>
							<br><strong>Calle</strong><br>
							<input type='text'  class='form form-control' name='calle' required>
							<strong>N&uacute;mero</strong><br>
							<input type='text'  class='form form-control' name='numero' required>
							<strong>Comentarios</strong><br>
							<input type='text'  class='form form-control' name='comentarios_direccion'>
							<strong>Comuna</strong><br>
							<select name='comuna' class='form form-control' required>
						  <option value=''></option>

						<option value='Cerrillos'>Cerrillos</option>
						<option value='Cerro Navia'>Cerro Navia</option>
						<option value='Conchalí'>Conchalí</option>
						<option value='El Bosque'>El Bosque</option>
						<option value='Estación Central'>Estación Central</option>
						<option value='Huechuraba'>Huechuraba</option>
						<option value='Independencia'>Independencia</option>
						<option value='La Cisterna'>La Cisterna</option>
						<option value='La Florida'>La Florida</option>
						<option value='La Granja'>La Granja</option>
						<option value='La Pintana'>La Pintana</option>
						<option value='La Reina'>La Reina</option>
						<option value='Las Condes'>Las Condes</option>
						<option value='Lo Barnechea'>Lo Barnechea</option>
						<option value='Lo Espejo'>Lo Espejo</option>
						<option value='Lo Prado'>Lo Prado</option>
						<option value='Macul'>Macul</option>
						<option value='Maipú'>Maipú</option>
						<option value='Ñuñoa'>Ñuñoa</option>
						<option value='Pedro Aguirre Cerda'>Pedro Aguirre Cerda</option>
						<option value='Peñalolén'>Peñalolén</option>
						<option value='Providencia'>Providencia</option>
						<option value='Pudahuel'>Pudahuel</option>
						<option value='Quilicura'>Quilicura</option>
						<option value='Quinta Normal'>Quinta Normal</option>
						<option value='Recoleta'>Recoleta</option>
						<option value='Renca'>Renca</option>
						<option value='San Joaquín'>San Joaquín</option>
						<option value='San Miguel'>San Miguel</option>
						<option value='San Ramón'>San Ramón</option>
						<option value='Vitacura'>Vitacura</option>
						<option value='Puente Alto'>Puente Alto</option>
						<option value='Pirque'>Pirque</option>
						<option value='San José de Maipo'>San José de Maipo</option>
						<option value='Colina'>Colina</option>
						<option value='Lampa'>Lampa</option>
						<option value='TilVl'>TilVl</option>
						<option value='San Bernardo'>San Bernardo</option>
						<option value='Buin'>Buin</option>
						<option value='Calera de Tango'>Calera de Tango</option>
						<option value='Paine'>Paine</option>
						<option value='Melipilla'>Melipilla</option>
						<option value='Alhué'>Alhué</option>
						<option value='Curacaví'>Curacaví</option>
						<option value='María Pinto'>María Pinto</option>
						<option value='San Pedro'>San Pedro</option>
						<option value='Talagante'>Talagante</option>
						<option value='El Monte'>El Monte</option>
						<option value='Isla de Maipo'>Isla de Maipo</option>
						<option value='Padre Hurtado'>Padre Hurtado</option>
						<option value='Peñaflor'>Peñaflor</option>


						</select>

						<center><a href='img/BCH_MandatoDescuentoporPlanilla.pdf' target='_blank' class='btn btn-info'>Formulario de descuento por planilla</a></center>

							<br><br>
							
							
							<center><input type='submit'  value='> Solicitar Canje Aquí <' class='btn btn-info '> </center><br></div></form>";	
									
		}

		//print_r($arr_item_detalle);exit();
		
		if($arr_item_detalle[0]->formulario=="direccion_despacho"){
			
							$boton_form="<form action='?sw=com_vota_canjea_items_detalle_preview&idi={IDI_ENCODEADO}&iddim={IDDIM_ENCODEADO}' method='POST' name='Form_{ID_PREMIO}' id='Form_{ID_PREMIO}'>
							<div class='col-xs-12 col-lg-12' style='text-align: left;font-size: 14px;'>
							
							<br>Ingresa Dirección de Despacho<br>

							<br><strong>Tel&eacute;fono</strong><br>
							<input type='text'  class='form form-control' name='telefono' required>
							
							<br><strong>Calle</strong><br>
							<input type='text'  class='form form-control' name='calle' required>
							
							<strong>N&uacute;mero</strong><br>
							<input type='text'  class='form form-control' name='numero' required>
							
							<strong>Departamento</strong> (<em>Opcional</em>)<br>
							<input type='text'  class='form form-control' name='departamento'>

							<strong>Comuna</strong><br>
							<input type='text'  class='form form-control' name='comuna' required>

							<strong>Regi&oacute;n</strong><br>
							<input type='text'  class='form form-control' name='region' required>
							
							<strong>Referencias de Direcci&oacute;n</strong> (<em>Opcional</em>) 
									(ej: intersección de calle/nombre de condominio/nombre de villa)<br>
							<input type='text'  class='form form-control' name='referencias'>
							
							
							<br><br>
							
							
							<center><input type='submit'  value='> Solicitar Canje Aquí <' class='btn btn-info '> </center><br></div></form>";	
									
		}

        if($arr_item_detalle[0]->formulario=="lolla2023"){

            $boton_form="<form action='?sw=com_vota_canjea_items_detalle_preview&idi={IDI_ENCODEADO}&iddim={IDDIM_ENCODEADO}' method='POST' name='Form_{ID_PREMIO}' id='Form_{ID_PREMIO}'>
							<div class='col-xs-12 col-lg-12' style='text-align: left;font-size: 14px;'>
							
							    <br>Selecciona el dia que deseas asistir:<br>

							    <select name='lolla' id='lolla' required>
							            <option value=''></option>
							            <option value='Viernes 17'>Viernes 17</option>
							            <option value='Sabado 18'>Sabado 18</option>
							            <option value='Domingo 19'>Domingo 19</option>
							            
							            
                        </select>
                               <br>
			                   <br>Ingresa tu email personal:<br>
							   <input type='email' name='lolla_email' id='lolla_email' class='form form-control' required>
                               <br>
			                   <br>Ingresa tu celular personal:<br>
							   <input type='text' name='lolla_cel' id='lolla_cel' class='form form-control' required>							
							<br><br>
							
							
							<center><input type='submit'  value='> Solicitar Canje Aquí <' class='btn btn-info '> </center><br></div></form>";

        }
        if($arr_item_detalle[0]->formulario=="brincus"){

            $boton_form="<form action='?sw=com_vota_canjea_items_detalle_preview&idi={IDI_ENCODEADO}&iddim={IDDIM_ENCODEADO}' method='POST' name='Form_{ID_PREMIO}' id='Form_{ID_PREMIO}'>
							<div class='col-xs-12 col-lg-12' style='text-align: left;font-size: 14px;'>                               <br>
			                   <br>Ingresa tu email personal:<br>
							   <input type='email' name='email' id='email' class='form form-control' required>
                               <br>
			          						
							<br><br>
							
							
							<center><input type='submit'  value='> Solicitar Canje Aquí <' class='btn btn-info '> </center><br></div></form>";

        }

        if($arr_item_detalle[0]->formulario=="reserva"){

            $boton_form="<form action='?sw=com_vota_canjea_items_detalle_preview&idi={IDI_ENCODEADO}&iddim={IDDIM_ENCODEADO}' method='POST' name='Form_{ID_PREMIO}' id='Form_{ID_PREMIO}'>
							<div class='col-xs-12 col-lg-12' style='text-align: left;font-size: 14px;'>
                               <br>
			                   <br>Ingresa n&uacute;mero de reserva de caba&ntilde;a:<br>
                                <input type='text'  class='form form-control' name='numero' required>

                               <br>
							<br><br>
							<center><input type='submit'  value='> Solicitar Canje Aquí <' class='btn btn-info '> </center><br></div></form>";

        }

				//print_r($arr_item_detalle);							

        $PRINCIPAL = str_replace("{ID_PREMIO}",($arr_item_detalle[0]->id_premio),$PRINCIPAL);


        $PRINCIPAL = str_replace("{DIMENSION}",($arr_item_detalle[0]->dimension),$PRINCIPAL);
        $PRINCIPAL = str_replace("{NOMBRE_PREMIO}",($arr_item_detalle[0]->premioludico),$PRINCIPAL);
        $PRINCIPAL = str_replace("{DESCRIPCION}",($arr_item_detalle[0]->premio_descripcion),$PRINCIPAL);
        $PRINCIPAL = str_replace("{CONDICIONES}",($arr_item_detalle[0]->condiciones),$PRINCIPAL);
        $PRINCIPAL = str_replace("{PUNTOS}",($arr_item_detalle[0]->puntos),$PRINCIPAL);
        $PRINCIPAL = str_replace("{IMAGEN}",($arr_item_detalle[0]->premio_icono),$PRINCIPAL);
        $PRINCIPAL = str_replace("{FOTO}",($arr_item_detalle[0]->imagen_2022),$PRINCIPAL);
        $PRINCIPAL = str_replace("{FORM_CANJEA_ITEMS_DETALLE}",($boton_form),$PRINCIPAL);



        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_RECIBIDOS}",($puntos_usuario[0]->puntosrecibidos),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_CANJEADOS}",($puntos_usuario[0]->puntoscanjeados),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_SALDOS}",($puntos_usuario[0]->puntossaldo),$PRINCIPAL);

        $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL=ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
        $PRINCIPAL = str_replace("{LI_RECIENTE}","PRUEB", $PRINCIPAL);
        $PRINCIPAL = str_replace("{FOTO_AUTOR}",VerificaFotoPersonal($rut),$PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_RECIENTE}",$LI_RECIENTE, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_POPULARES}",$LI_POPULARES, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISPRACTICAS}",$LI_MISPRACTICAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISFAVORITAS}",$LI_MISFAVORITAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_CATEGORIA}",$LI_CATEGORIA, $PRINCIPAL);
        $PRINCIPAL=BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = str_replace("{MENU_SECUNDARIO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{BARRA_NAVEGACION_BUSCADOR}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{INSIGNIA}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_NOMBRE}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{CONTENIDO_INGRESADO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_OBJETIVO}","", $PRINCIPAL);
        $PRINCIPAL=ColocaDatosPerfil($PRINCIPAL, $rut);
        //$PRINCIPAL=ColocaDatosMallaCapacitacion(FuncionesTransversales($PRINCIPAL), $rut, $id_empresa);
        //$PRINCIPAL=ColocaMPEstadisticas($PRINCIPAL, $id_empresa);
        //$segmento='Casa Matriz';
        $segmento=RF_buscasegmento($rut, $id_empresa);
        $segmento_col=($segmento[0]->mundo);
        //echo $segmento_col;


        //$PRINCIPAL=Com_Premios_ListadoPremios_RUT($PRINCIPAL, $rut, $id_empresa);

    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento[0]->mundo, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento[0]->mundo, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL,"bch_tl",  $segmento[0]->mundo, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento[0]->mundo, $id_empresa);
    $PRINCIPAL=Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, "bch_tl", $segmento[0]->mundo, $id_empresa);
        $PRINCIPAL = str_replace("{RUT_ENCODEADO}",Encodear3($rut),$PRINCIPAL );
        $PRINCIPAL = str_replace("{IDI_ENCODEADO}",$_GET["idi"], $PRINCIPAL);
        $PRINCIPAL = str_replace("{IDDIM_ENCODEADO}",$_GET["iddim"], $PRINCIPAL);
        echo $PRINCIPAL;
}
    else if($seccion=="com_vota_canjea_items_detalle_preview"){
			
        $rut			=$_SESSION["user_"];
        $id_empresa		=$_SESSION["id_empresa"];
        $idi			=Decodear3($_GET["idi"]);
        $id_dim			=Decodear3($_GET["iddim"]);


				$info_direccion1=$_POST["telefono"];
				$info_direccion2=$_POST["calle"];
				$info_direccion3=$_POST["numero"];
				$info_direccion4=$_POST["departamento"];
				$info_direccion5=$_POST["comuna"];
				$info_direccion6=$_POST["region"];
				$info_direccion7=$_POST["referencias"];
                $info_direccion8=$_POST["email"];
                $info_direccion9=$_POST["numero"];


            $info_direccion_lolla=$_POST["lolla"];
            $info_direccion_lolla_email=$_POST["lolla_email"];
            $info_direccion_lolla_celular=$_POST["lolla_cel"];


        $swa			="";
        $fecha_solicitud=$_POST["fecha_limite_".$id_premio];

        //echo "<br> idi $idi, id_dim $id_dim";
        $fechas_sol = explode("/", $fecha_solicitud);
        $fecha_ingles=$fechas_sol[2]."-".$fechas_sol[1]."-".$fechas_sol[0];
        $hora_desde=$_POST["hora_desde_".$id_premio];
        $hora_hasta=$_POST["hora_hasta_".$id_premio];
        if($id_premio<>''){

        $datosjefe=mp_buscaDATOSPERSONAS($rut, $id_empresa);
        $swa=premios_guarda_solicitud($rut, $id_premio, $datosjefe[0]->jefe,$id_empresa,$fecha_solicitud,$fecha_ingles,$hora_desde,$hora_hasta);
        $datos_premio=traigoPremios($id_premio, $id_empresa);
            if($swa=="solicitud"){
            //EnviaCorreoPuntosGenerico($rut, $datosjefe[0]->jefe, "SolicitudColaborador",file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_email.html"), $datos_premio[0]->premio, $fecha_solicitud);
            //EnviaCorreoPuntosGenerico($rut, $datosjefe[0]->jefe, "SolicitudJefe",file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_email.html"), $datos_premio[0]->premio, $fecha_solicitud);
            }
        //echo $swa;/
        }
        //echo $swa;
        //BUSCADATOSPERSONALES CANJES
        $puntos_usuario=premios_buscadatos($rut, $id_empresa);
        //print_r($puntos_usuario);
        $segmento=RF_buscasegmento($rut, $id_empresa);
        $segmento_col=($segmento[0]->mundo);

        if($segmento[0]->mundo==""){$segmento[0]->mundo="TODOS";}
            //echo "<br> idi $idi, id_dim $id_dim";
        $arr_item_detalle=Com_Premios_Detalle($segmento[0]->mundo, $idi, $id_empresa);

        //print_r($arr_item_detalle);

        if($arr_item_detalle[0]->concodigopremiounico=="1"){
        $hoy=date("Y-m-d");
        //echo "hola";


        $campo_fecha="    <div class='alert alert-warning' role='alert'>
            <center><strong>Para este canje debes ingresar tu número de <strong>celular</strong>.
                </div>
            <center>
        	<input type='text' name='celular' id='celular' class='form form-control' required style='width:200px'></center><br>";
					$campo_fecha=" ";
        }


        elseif($arr_item_detalle[0]->solicitadia=="SI"){
        $hoy=date("Y-m-d");

        $campo_fecha="    <div class='alert alert-warning' role='alert'>
        <center><strong>Para este canje debes elegir la <strong>fecha de inicio</strong>.
        <br> Recuerda que ésta debe estar de acuerdo a la descripci&oacute;n del mismo.<br>
        </div>
        <center><SMALL style='    font-size: 12px;
    font-weight: 400;
    color: #999;'>[Usa las flechas para usar el calendario]</SMALL>
        <input type='date' name='dia' id='dia' class='form form-control' min='".$hoy."' required style='width:200px'></center><br>";

        }

				elseif($arr_item_detalle[0]->solicitadia=="SIHORA"){
        $hoy=date("Y-m-d");

        $campo_fecha="    <div class='alert alert-warning' role='alert'>
        <center><strong>Para este canje debes elegir la <strong>fecha de inicio</strong> y <strong>hora de inicio</strong>.
        <br> Recuerda que ésta debe estar de acuerdo a la descripci&oacute;n del mismo.<br>
        </div>
        <center><SMALL style='    font-size: 12px;
    font-weight: 400;
    color: #999;'>[Usa las flechas para usar el calendario]</SMALL>
        <input type='date' name='dia' id='dia' class='form form-control' min='".$hoy."' required style='width:200px'></center><br>

        <small style='    font-size: 12px;
    font-weight: 400;
    color: #999;'>Hora</small>
	<center>
        <input type='time' name='hora_inicio' id='hora_inicio' class='form form-control' min='08:00:00' required style='width:200px'></center><br>";



        }
		elseif($arr_item_detalle[0]->solicitadia=="SIMES"){
        $hoy=date("Y-m-d");
		$mes=$arr_item_detalle[0]->solomes;
		$min	="2019-".$mes."-01";
		$max	="2019-".$mes."-31";
		
        $campo_fecha="    <div class='alert alert-warning' role='alert'>
        <center><strong>Para este canje debes elegir la <strong>fecha de inicio</strong>  en el <strong>Mes</strong> específicado en la descripción.
        <br> Recuerda que ésta debe estar de acuerdo a la descripci&oacute;n del mismo.<br>
        </div>
        <center><SMALL style='    font-size: 12px;
    font-weight: 400;
    color: #999;'>[Usa las flechas para usar el calendario]</SMALL>
        <input type='date' name='dia' id='dia' class='form form-control' min='".$min."' max='".$max."' required style='width:200px'></center><br>";




        }
		else {

        $campo_fecha="    ";

        }
        
       //echo "$info_direccion1"; 
        
        if($info_direccion1<>"" and $info_direccion2<>"" and $info_direccion3<>""){
        	
        	$direccion="Datos de Despacho;Telefono:$info_direccion1;Calle:$info_direccion2;Numero:$info_direccion3;Comuna:$info_direccion5;Region:$info_direccion6;Departamento:$info_direccion4;Referencias:$info_direccion7";
        	$campo_fecha="Datos de Despacho<br><br>
        	Tel&eacute;fono:$info_direccion1<br>
        	Calle: $info_direccion2<br> Número: $info_direccion3<br>Comuna: $info_direccion5, Regi&oacute;n: $info_direccion6.<br>
        	Comentarios: $info_direccion4 $info_direccion7<br><br>
        	
        	<input type='hidden' name='direccion' id='direccion' class='form form-control' value='$direccion'>
        	
        	";
        	
        	
        	
        	
        	//echo "<h1>Esta Dentro A.$campo_fecha</h1>"	;
        }
    if ($info_direccion_lolla <> "") {
         $campo_fecha = "Dia Seleccionado<br>
        $info_direccion_lolla<br>
        <br><br>

        <input type='hidden' name='direccion' id='direccion' class='form form-control' value='$info_direccion_lolla'>
        <input type='hidden' name='celular_personal' id='celular_personal' class='form form-control' value='$info_direccion_lolla_celular'>
        <input type='hidden' name='email_personal' id='email_personal' class='form form-control' value='$info_direccion_lolla_email'>";
            }

        if($info_direccion8<>""){
            $campo_fecha="<input type='hidden' name='email_personal' id='email_personal' class='form form-control' value='$info_direccion8'>";
        }
            if($info_direccion9<>""){
                $campo_fecha="<input type='hidden' name='direccion' id='direccion' class='form form-control' value='$info_direccion9'>";
            }
       // echo "<br><h3> campo fecha $campo_fecha </h3>";
        //vertifica si es con validacion o no de jefe
        if($arr_item_detalle[0]->aprobacionjefe=="SI"){

        $alerta="<div class='alert alert-info' role='alert'>
        <strong>Importante:</strong> Al presionar el bot&oacute;n <strong>Confirmar Solicitud</strong> se te descontarán
        ".$arr_item_detalle[0]->puntos." puntos y se enviará un email con la notificaci&oacute;n a tu jefatura para validar el canje.
        </div>";

        $alerta="<div class='alert alert-info' role='alert'>
        <strong>Importante:</strong> Al presionar el bot&oacute;n <strong>Confirmar Solicitud</strong> se enviará un email a tu Jefatura para que valide el canje.
        <br><br>Si éste valida, tú aceptas que se te descontarán ".$arr_item_detalle[0]->puntos." puntos
        para canjear ".($arr_item_detalle[0]->premioludico)."</div>";

        } else {

        $alerta="<div class='alert alert-info' role='alert'>
        <strong>Importante:</strong> Al presionar el bot&oacute;n <strong>Confirmar Solicitud</strong> aceptas que se te descontarán ".$arr_item_detalle[0]->puntos." puntos
        para canjear ".($arr_item_detalle[0]->premioludico)."</div>";

        }

        $PRINCIPAL=FuncionesTransversales(file_get_contents("views/reconoce_vota/".$id_empresa."_rec_vot_home_canjea_items_detalle_preview.html"));
                $array_premio=traigoPremio_data($idi, $id_empresa);
                                            //print_r($array_premio);
                                            if($array_premio[0]->saldo>0){
                                                $boton_form=" <input type='submit' value='> Confirmar Solicitud <' class='btn btn-info '>";
                                            }   else {
                                            	
                   if($array_premio[0]->stock==0){
               $boton_form="<span class='badge badge-warning'><span class='blanco'>
                     Canje suspendido temporalmente</span> </span>";
                                      
                   	
                   } else {
               
                                                    $boton_form="<span class='badge badge-danger'><span class='blanco'>
                    Sin stock disponible</span> </span>";
                   	
                   }                                            	
                                            	

                                            }
        $PRINCIPAL = str_replace("{ID_PREMIO}",Encodear3($arr_item_detalle[0]->id_premio),$PRINCIPAL);
        $PRINCIPAL = str_replace("{DIMENSION}",($arr_item_detalle[0]->dimension),$PRINCIPAL);
        $PRINCIPAL = str_replace("{NOMBRE_PREMIO}",($arr_item_detalle[0]->premioludico),$PRINCIPAL);
        $PRINCIPAL = str_replace("{DESCRIPCION}",($arr_item_detalle[0]->premio_descripcion),$PRINCIPAL);
        $PRINCIPAL = str_replace("{CONDICIONES}",    ($arr_item_detalle[0]->condiciones),$PRINCIPAL);
        $PRINCIPAL = str_replace("{PUNTOS}",        ($arr_item_detalle[0]->puntos),$PRINCIPAL);
        $PRINCIPAL = str_replace("{IMAGEN}",($arr_item_detalle[0]->premio_icono),$PRINCIPAL);
        $PRINCIPAL = str_replace("{FOTO}",    ($arr_item_detalle[0]->imagen_2022),$PRINCIPAL);
        $PRINCIPAL = str_replace("{ALERTA}",($alerta),$PRINCIPAL);
        $PRINCIPAL = str_replace("{ALERTA_ADICIONAL}", ($arr_item_detalle[0]->alertaweb),$PRINCIPAL);
        $PRINCIPAL = str_replace("{CAMPO_FECHA}",($campo_fecha),$PRINCIPAL);
        $PRINCIPAL = str_replace("{FORM_CANJEA_ITEMS_DETALLE}",($boton_form),$PRINCIPAL);

        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_RECIBIDOS}",($puntos_usuario[0]->puntosrecibidos),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_CANJEADOS}",($puntos_usuario[0]->puntoscanjeados),$PRINCIPAL);
        $PRINCIPAL = str_replace("{TOTAL_PUNTOS_SALDOS}",($puntos_usuario[0]->puntossaldo),$PRINCIPAL);
        $PRINCIPAL = BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = ColocaMenuSecundario($PRINCIPAL, $_SESSION["id_empresa"]);
        $PRINCIPAL = str_replace("{LI_RECIENTE}","PRUEB", $PRINCIPAL);
        $PRINCIPAL = str_replace("{FOTO_AUTOR}",VerificaFotoPersonal($rut),$PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_RECIENTE}",$LI_RECIENTE, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_POPULARES}",$LI_POPULARES, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISPRACTICAS}",$LI_MISPRACTICAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_MISFAVORITAS}",$LI_MISFAVORITAS, $PRINCIPAL);
        $PRINCIPAL = str_replace("{LI_CATEGORIA}",$LI_CATEGORIA, $PRINCIPAL);
        $PRINCIPAL = BarraNavegacion($PRINCIPAL, $seccion);
        $PRINCIPAL = str_replace("{MENU_SECUNDARIO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{BARRA_NAVEGACION_BUSCADOR}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{INSIGNIA}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_NOMBRE}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{CONTENIDO_INGRESADO}","", $PRINCIPAL);
        $PRINCIPAL = str_replace("{VALUE_OBJETIVO}","", $PRINCIPAL);
        $PRINCIPAL=ColocaDatosPerfil($PRINCIPAL, $rut);
        $segmento=RF_buscasegmento($rut, $id_empresa);
        $segmento_col=($segmento[0]->mundo);
        echo $PRINCIPAL;
        } else {
            session_start();
            $_SESSION = array();
            if (isset($_COOKIE[session_name() ])) {
                setcookie(session_name() , '', time() - 42000, '/');
            }
            session_destroy();
            echo "    <script>         location.href='https://www.bancodepuntosbch.cl/front/views/home/login_sso.html';     </script>"; exit();
        }
?>