<?php
function checkCartolaPunstoSaldoVencidos($rut, $fecha){

    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $date=date("Y-m-d");
    $database->setDb($c_db);
    $sql="select tipo_vencimiento,puntos_saldo_vencidos from tbl_puntos_vencimientos_modalidad_2023 
            where rut='$rut' and fecha_vencimiento='$fecha' ";
    //echo $sql;
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod;
}
function premios_puntos_usuarios_full()
{
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $sql      = "
        select h.*
        from tbl_premios_puntos_usuarios h
        inner join tbl_reportes_online_usuario w on w.rut=h.rut
        group by h.rut
        
    ";
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod;
}
function premios_puntos_insert_vencimiento_version_2023($rut,$saldo_puntos, $puntos_vencer,$fecha_vencimiento, $fecha_ingreso, $canjes, $puntos_saldo_vencidos, $puntos_vencimientos_acumulados, $tipo_vencimiento)
{
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $sql   = "insert into tbl_puntos_vencimientos_modalidad_2023 (rut,saldo_puntos,puntos_vencer,fecha_vencimiento, fecha_ingreso, canjes, puntos_saldo_vencidos, puntos_vencimientos_acumulados, tipo_vencimiento)
        VALUES
        ('$rut','$saldo_puntos','$puntos_vencer','$fecha_vencimiento','$fecha_ingreso','$canjes','$puntos_saldo_vencidos','$puntos_vencimientos_acumulados','$tipo_vencimiento');";

    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod;
}
function premios_puntos_truncate_vencimiento_version_2023()
{
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $sql      = "truncate tbl_puntos_vencimientos_modalidad_2023";
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod;
}
function SumaCanjes_2023_rango($rut, $fi, $ft)
{
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    $sql = " SELECT SUM(puntos) as canjes FROM tbl_premios_canje WHERE rut = '$rut' AND id_empresa = '78' and fecha>='$fi' and fecha<='$ft' ";
    //echo $sql;
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod;
}

function checkCartolaNoVence($rut, $fecha, $puntos_vencer){

    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $date=date("Y-m-d");
    $database->setDb($c_db);
    $sql="select tipo_vencimiento from tbl_puntos_vencimientos_modalidad_2023 
            where rut='$rut' and fecha_vencimiento='$fecha' and puntos_vencer='$puntos_vencer'";
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod[0]->tipo_vencimiento;
}
function Recalculo_puntos_vencer_2023($rut)
{
    $hoy = date('Y-m-d');
    $hoy_hace_ano = date("Y-m-d", strtotime($hoy . '-1 year'));

    $connexion = new DatabasePDO();

    $id_empresa = "78";
    $sql_delete_modalidad = "DELETE FROM tbl_puntos_a_vencer_modalidad_solo_2022 WHERE rut = :rut";
    $connexion->query($sql_delete_modalidad);
    $connexion->bind(':rut', $rut);
    $connexion->execute();

    $sql_delete_puntos = "DELETE FROM tbl_puntos_a_vencer WHERE rut = :rut";
    $connexion->query($sql_delete_puntos);
    $connexion->bind(':rut', $rut);
    $connexion->execute();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql_vencer_2023 = "SELECT ..."; // Your complex SQL query
    $connexion->query($sql_vencer_2023);
    $cod_vencer_2023 = $connexion->resultset();

    foreach ($cod_vencer_2023 as $u) {
        $puntossaldo=$u->puntos_recibidos_a_fecha-$u->puntoscanjeados;
        //1550 >= 4000
        if( $puntossaldo>=$u->puntos_proximos){
            $puntos_a_vencer=$u->puntos_proximos;
            $fecha_a_vencer_mas_ano=date("Y-m-d",strtotime($u->fecha_proximos.' +1 year'));
            $fecha_a_vencer= $fecha_a_vencer_mas_ano;
            $modalidad="A puntossaldopuntos igual recibidos a fecha menos puntoscanjeados mayor puntos proximos";
        }
        elseif( $puntossaldo<$u->puntos_proximos){
            $puntos_a_vencer=$puntossaldo;
            $fecha_a_vencer_mas_ano=date("Y-m-d",strtotime($u->fecha_proximos.' +1 year'));
            $fecha_a_vencer= $fecha_a_vencer_mas_ano;
            $modalidad="F puntossaldopuntos igual recibidos a fecha menos puntoscanjeados menor puntos proximos";
        }

        //1550 > 0 and 13000<4000
        else if($puntossaldo>0 and $u->puntossaldo<$u->puntos_proximos){
            $puntos_a_vencer=$u->puntossaldo;
            $fecha_a_vencer_mas_ano=date("Y-m-d",strtotime($u->fecha_proximos.' +1 year'));
            $fecha_a_vencer= $fecha_a_vencer_mas_ano;
            $modalidad="B puntossaldopuntos igual recibidos a fecha menos puntoscanjeados mayor cero y puntossaldo menos puntos_proximos";
        }
        else if( $puntossaldo<0){
            if($u->puntossaldo>$u->puntos_proximos){
                $puntos_a_vencer=$u->puntos_proximos;
            } else {
                $puntos_a_vencer=$u->puntossaldo;
            }
            //$modalidad="D";
            $fecha_a_vencer_mas_ano=date("Y-m-d",strtotime($u->fecha_proximos.' +1 year'));
            $fecha_a_vencer= $fecha_a_vencer_mas_ano;
            $puntos_a_vencer="";
            $fecha_a_vencer="";
            $modalidad="D puntossaldopuntos igual recibidos a fecha menos puntoscanjeados menor cero"; // saldo negativo

            if($u->puntossaldo>0){

            } else {
                $modalidad="E"; // sin saldo
            }

        } else {
            $puntos_a_vencer="";
            $fecha_a_vencer="";
            $modalidad="C Sin IF";
        }

        $sql2 = "INSERT INTO tbl_puntos_a_vencer_modalidad_solo_2022 (...) VALUES (...)";
        $connexion->query($sql2);
        $connexion->execute();

        $sql3 = "INSERT INTO tbl_puntos_a_vencer (...) VALUES (...)";
        $connexion->query($sql3);
        $connexion->execute();
    }
}
function LogExcepciones($rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_login_excepciones WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}
function LogEmail_Log_Login_data_home($email, $email_request, $rut, $error) {
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql = "
    INSERT INTO tbl_log_login (fecha, hora, email, email_request, rut, error)
    VALUES (:fecha, :hora, :email, :email_request, :rut, :error)";

    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':email', $email);
    $connexion->bind(':email_request', $email_request);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':error', $error);

    $connexion->execute();

    //echo "    <script>         location.href='?sw=Tickets_AutoAtencion_2020&sa_rating=1';     </script>"; exit;
}
function Banners_2023_data($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_slider WHERE activo='1' ORDER BY orden";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function CartolaProximas_rut($rut)
{
    $connexion = new DatabasePDO();
    $date = date("Y-m-d");
    $sql = "
        SELECT rut, puntos_a_vencer AS puntos, fecha_a_vencer AS fecha, 'PUNTOS_A_VENCER' AS tipo,
               (SELECT modalidad FROM tbl_puntos_a_vencer_modalidad_solo_2022 WHERE rut=:rut) AS modalidad
        FROM tbl_puntos_a_vencer WHERE rut = :rut
        UNION
        SELECT rut, puntos AS puntos, DATE_ADD(fecha, INTERVAL 365 DAY) AS fecha, 'PUNTOS_USUARIOS' AS tipo,
               (SELECT modalidad FROM tbl_puntos_a_vencer_modalidad_solo_2022 WHERE rut=:rut) AS modalidad
        FROM tbl_premios_puntos_usuarios WHERE rut = :rut
        AND DATE_ADD(fecha, INTERVAL 365 DAY) >= :date
        AND id_empresa = '78'
        AND descripcion <> 'Puntos Vencidos'
        AND descripcion <> 'Carga de puntos periodo 20/22'";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':date', $date);
    $cod = $connexion->resultset();
    return $cod;
}

function PuntosModalidadD($rut, $fecha_correcta)
{
    $fecha = date('Y-m-d', strtotime('-1 year', strtotime($fecha_correcta)));

    $connexion = new DatabasePDO();
    $date = date("Y-m-d");
    $sql = "
        SELECT
            h.rut,
            COALESCE((SELECT SUM(puntos) FROM tbl_premios_canje WHERE rut = h.rut AND id_empresa = h.id_empresa), 0) AS puntoscanjeados,
            (SELECT SUM(puntos) FROM tbl_premios_puntos_usuarios WHERE rut = x.rut AND fecha <= (SELECT fecha FROM tbl_premios_puntos_usuarios WHERE rut = h.rut AND fecha >= :fecha AND puntos > 0 ORDER BY fecha LIMIT 1)) AS puntos_recibidos_a_fecha,
            (SELECT SUM(puntos) FROM tbl_premios_puntos_usuarios WHERE rut = x.rut AND fecha <= (SELECT fecha FROM tbl_premios_puntos_usuarios WHERE rut = h.rut AND fecha >= :fecha AND puntos > 0 ORDER BY fecha LIMIT 1)) - COALESCE((SELECT SUM(puntos) FROM tbl_premios_canje WHERE rut = h.rut AND id_empresa = h.id_empresa), 0) AS puntossaldo
        FROM
            tbl_premios_puntos_usuarios h
            JOIN tbl_usuario x ON x.rut = h.rut 
        WHERE
            h.id_empresa = '78'
            AND h.rut = :rut
        GROUP BY
            h.rut";
        
    if ($rut == "24395448") {
        // echo "<br><br>$sql";
    }

    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    // echo "<br>-> ".$cod[0]->puntossaldo;
    return $cod[0]->puntossaldo;
}

function VerificaCanjeRutAnterior_2022_lolla($id_premio, $rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT count(id) AS cuenta FROM tbl_premios_canje WHERE id_premio = :id_premio AND id_empresa = :id_empresa AND rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function BuscaDia_Canje_2022_lolla($id_canje)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT direccion FROM tbl_premios_canje WHERE id = :id_canje";
    $connexion->query($sql);
    $connexion->bind(':id_canje', $id_canje);
    $cod = $connexion->resultset();
    return $cod[0]->direccion;
}

function PremiosStock2022($id_premio)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT stock FROM tbl_premios WHERE id_premio = :id_premio";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $cod = $connexion->resultset();
    return $cod[0]->stock;
}

function BuscaSaldoLolla2023($id_premio, $direccion)
{
    $stock_full = PremiosStock2022($id_premio);
    $dias = 3;
    $stock_por_dia = $stock_full / $dias;

    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(id) AS cuenta FROM tbl_premios_canje WHERE id_premio = :id_premio AND direccion = :direccion";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':direccion', $direccion);
    $cod = $connexion->resultset();
    $canjeados = $cod[0]->cuenta;
    $saldo_lolla = $stock_por_dia - $canjeados;
    return $saldo_lolla;
}

function PremiosLink2022($id_premio)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT link_externo FROM tbl_premios WHERE id_premio = :id_premio";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $cod = $connexion->resultset();
    return $cod[0]->link_externo;
}

function BancodePuntos_2021_BuscaFechaVencer()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT fecha_a_vencer FROM tbl_puntos_fecha_a_vencer_2021 ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    $fecha_real = $cod[0]->fecha_a_vencer;
    $date = strtotime("$fecha_real -1 year");
    $fecha_a_vencer = date('Y-m-d', $date);
    return $fecha_a_vencer;
}

function BancodePuntos_2021_SaldoAVencer_data($rut, $fecha_a_vencer)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT SUM(puntos) AS suma_puntos_a_vencer FROM tbl_premios_puntos_usuarios WHERE rut = :rut AND fecha <= :fecha_a_vencer";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha_a_vencer', $fecha_a_vencer);
    $cod = $connexion->resultset();
    return $cod[0]->suma_puntos_a_vencer;
}

function BancodePuntos_2023_puntos_avancer_data($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT SUM(puntos) AS suma_puntos_a_vencer FROM tbl_premios_puntos_usuarios WHERE rut = :rut AND fecha <= :fecha_a_vencer";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha_a_vencer', $fecha_a_vencer);
    $cod = $connexion->resultset();
    return $cod;
}

function BancodePuntos_2023_puntos_avancer_data_porrut($rut) {
    $connexion = new DatabasePDO();
    $sql = "select h.*, j.tipo_vencimiento, j.puntos_saldo_vencidos from tbl_puntos_a_vencer h 
                                                        LEFT JOIN tbl_puntos_vencimientos_modalidad_2023 j on j.rut=h.rut and j.fecha_vencimiento=h.fecha WHERE h.rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function BancodePuntos_2021_Canjeados_data($rut) {
    $connexion = new DatabasePDO();
    $sql = "select sum(h.puntos) as suma_puntos_a_canjeados from tbl_premios_canje h WHERE h.rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->suma_puntos_a_canjeados;
}

function valor_usuario_pendientes_real_derecho($dias_pendientes_real, $dias_derecho) {
    if ($dias_derecho != 0) {
        $valor = $dias_pendientes_real / $dias_derecho;
        return $valor;
    } else {
        return 0; // or any other appropriate value when $dias_derecho is zero
    }
}


function BuscaPopup_BP() {
    $connexion = new DatabasePDO();
    $sql = "select * from tbl_banco_puntos_popup order by id DESC limit 1";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Premios_puntos_a_vencer_2020_data($rut, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select puntos_a_vencer as puntos, fecha_a_vencer as fecha from tbl_puntos_a_vencer where rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function UsuarioAdminRutEmpresa($rut) {
    $connexion = new DatabasePDO();
    $sql = "select * from tbl_admin where user = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function VerificaClaveAccesoAdmin($rut, $clave)
{
    $clave = utf8_decode($clave);
    // echo "<br>VerificaClaveAccesoAdmin C rut $rut, clave $clave";
    $clave = Encriptar($clave);

    $clave1 = Encriptar("1735_Bchpuntos!2020");
    $clave2 = Encriptar("1628_Bchpuntos!2020");
    $clave3 = Encriptar("gop2020#!");

    // echo "<br>$clave";
    // echo "<br>$clave1";
    // echo "<br>$clave2";
    // echo "<br>$clave3";

    // exit();
    // echo "<br>RUT $rut Encript $clave";        // exit();
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_admin WHERE user = :rut AND clave_encodeada = :clave";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':clave', $clave);
    $cod = $connexion->resultset();

    if (empty($cod[0]->id)) {
        $existe_base = UsuarioEnBasePersonas($rut, $rutcontodo);
        $NoCambiaClaveArr = VerificaNoCambiaClaveAccesoObligatorio($existe_base[0]->id_empresa);
        $NoCambiaClave = $NoCambiaClaveArr[0]->nocambiaclaveobligatorio;

        if ($NoCambiaClave <> 1) {
            $obligatorio = 0;
        } else {
            $obligatorio = 1;
        }

        $rutcuatroprimeros = substr($rut, 0, 4);
        $sql = "INSERT INTO tbl_clave (rut, cambiado, fecha, id_empresa, clave_encodeada) VALUES (:rut, :obligatorio, :fecha, :id_empresa, :clave_encodeada)";
        $connexion->query($sql);
        $connexion->bind(':rut', $rut);
        $connexion->bind(':obligatorio', $obligatorio);
        $connexion->bind(':fecha', date("Y-m-d"));
        $connexion->bind(':id_empresa', $existe_base[0]->id_empresa);
        $connexion->bind(':clave_encodeada', Encriptar($rutcuatroprimeros));
        $connexion->execute();

        $sql = "SELECT * FROM tbl_clave WHERE rut = :rut AND clave_encodeada = :clave";
        $connexion->query($sql);
        $connexion->bind(':rut', $rut);
        $connexion->bind(':clave', $clave);
        $cod = $connexion->resultset();
    }

    return $cod;
}

function BancoPuntos_2020_Ganadores($id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
            (SELECT nombre_completo FROM tbl_usuario WHERE rut=h.rut) AS nombre_completo_2
            FROM tbl_premios_canje h
            WHERE h.id_premio = :id_premio AND h.id_empresa = :id_empresa AND estadovalidacion = '1'";

    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function Canje_BuscaNotificaciones_Vencimiento($id_empresa, $fi, $ft)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
            (SELECT nombre_completo FROM tbl_usuario WHERE rut=h.rut) AS nombre_completo,
            (SELECT email FROM tbl_usuario WHERE rut=h.rut) AS email
            FROM tbl_puntos_a_vencer h
            WHERE h.fecha_a_vencer >= :fi AND h.fecha_a_vencer <= :ft";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fi', $fi);
    $connexion->bind(':ft', $ft);
    $cod = $connexion->resultset();
    return $cod;
}

function PuntosCodigoPremioUnico($id_premio, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_premios_codigo_unico WHERE rut = :rut AND id_premio = :id_premio LIMIT 1";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_premio', $id_premio);
    $cod = $connexion->resultset();
    return $cod;
}

function PuntosCodigoPremioMultiplesUnico($id_premio, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_premios_codigo_unico WHERE rut = :rut AND id_premio = :id_premio";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_premio', $id_premio);
    $cod = $connexion->resultset();
    return $cod;
}

function PuntosActualizaBuscaCodigoPremio($id_premio, $rut, $celular, $id_empresa)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora  = date("H:i:s");
    
    $sql = "UPDATE tbl_premios_codigo_unico SET fecha_canje=:fecha, rut=:rut, id_empresa=:id_empresa, hora_canje=:hora, celular=:celular WHERE rut IS NULL AND id_premio=:id_premio LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':celular', $celular);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->execute();
    
    $sql_2 = "SELECT codigo FROM tbl_premios_codigo_unico WHERE rut=:rut AND id_premio=:id_premio ORDER BY id DESC LIMIT 1";
    $connexion->query($sql_2);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod[0]->codigo;
}

function TraeIntendosAccesosFallidos($rut)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $sql = "SELECT * FROM tbl_login_intento_acceso WHERE rut=:rut AND fecha=:fecha";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function InsertaAccesoIntento($rut)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora  = date("H:i:s");
    $sql = "INSERT INTO tbl_login_intento_acceso (rut, fecha, hora, ip_compartido, ip_proxy, ip_acceso)
        VALUES
        (:rut, :fecha, :hora, :ip_compartido, :ip_proxy, :ip_acceso)";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':ip_compartido', $_SERVER['HTTP_CLIENT_IP']);
    $connexion->bind(':ip_proxy', $_SERVER['HTTP_X_FORWARDED_FOR']);
    $connexion->bind(':ip_acceso', $_SERVER['REMOTE_ADDR']);
    $connexion->execute();
}
function ChequeaDobleCanjeEseDia_data($dia, $id_premio, $rut, $id_empresa){
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");

    $sql = "SELECT COUNT(h.id) AS cuenta,
            (SELECT tipo_grupo FROM tbl_premios WHERE id_premio = :id_premio) AS tipo_grupo
            FROM tbl_premios_canje h
            WHERE h.rut = :rut AND h.fecha_solicitud = :dia AND h.id_empresa = :id_empresa";

    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':dia', $dia);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod[0]->cuenta;
}

function BuscoCanjeHoy($id_premio, $rut, $id_empresa, $hoy){
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    //echo "BuscoCanjeHoy($id_premio, $rut, $id_empresa, $hoy)";
    $sql = "SELECT COUNT(id) AS cuenta
            FROM tbl_premios_canje
            WHERE rut = :rut AND id_premio = :id_premio AND fecha = :hoy AND id_empresa = :id_empresa";
    //echo $sql;exit();
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':hoy', $fecha);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod[0]->cuenta;
}

function BuscaCanjesValida7dias($id_empresa){
    $connexion = new DatabasePDO();
    $fecha_1semanatras = date("Y-m-d", strtotime("-1 week"));

    $sql = "SELECT h.* FROM tbl_premios_canje h
            WHERE h.estadovalidacion = '2' AND h.fecha >= '2019-05-01'
            AND h.fecha <= :fecha_1semanatras AND h.id_empresa = :id_empresa";

    $connexion->query($sql);
    $connexion->bind(':fecha_1semanatras', $fecha_1semanatras);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function CanjePuntosActualizaValidacion($id){
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_premios_canje SET estadovalidacion = '1' WHERE id = :id";

    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

function MP_SearchBannedWordsInjection($id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_sql_injection";

    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();

    return $cod;
}

function InsertTblAnalitica($rut, $id_empresa, $ambiente, $detalle){
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $fechahora = date("Y-m-d H:i:s");

    $sql = "INSERT INTO tbl_analitica (rut, ambiente, detalle, fecha, hora, fechahora, id_empresa)
            VALUES (:rut, :ambiente, :detalle, :fecha, :hora, :fechahora, :id_empresa)";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':ambiente', $ambiente);
    $connexion->bind(':detalle', $detalle);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':fechahora', $fechahora);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}

function VerificaUsuarioEmail($email, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT rut FROM tbl_usuario WHERE email = :email AND id_empresa = :id_empresa";

    $connexion->query($sql);
    $connexion->bind(':email', $email);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();

    return $cod[0]->rut;
}

function LogEmailInsertUsuario($rut, $nombre, $email, $rut_empresa, $codigo, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT id FROM tbl_usuario WHERE id_empresa = :id_empresa AND rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    $nombre = utf8_decode($nombre);

    if ($cod[0]->id > 0) {
        $sql = "UPDATE tbl_usuario SET nombre_completo = :nombre, email = :email, empresa_holding = :rut_empresa, division = :codigo WHERE rut = :rut";
    } else {
        $sql = "INSERT INTO tbl_usuario (rut, id_empresa, nombre_completo, email, empresa_holding, division) VALUES (:rut, :id_empresa, :nombre, :email, :rut_empresa, :codigo)";
    }

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':nombre', $nombre);
    $connexion->bind(':email', $email);
    $connexion->bind(':rut_empresa', $rut_empresa);
    $connexion->bind(':codigo', $codigo);
    $connexion->execute();

    return $codigo;
}

function LogInsertUsuario($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "INSERT INTO tbl_usuario (rut, id_empresa) VALUES (:rut, :id_empresa)";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    return $codigo;
}

function premios_puntos_abonos_porrut($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_premios_puntos_usuarios WHERE rut = :rut AND id_empresa = :id_empresa ORDER BY fecha ASC";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function VerificaRutPremioExclusion($rut, $id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT id FROM tbl_premios_puntos_excepcion WHERE rut = :rut AND id_premio = :id_premio AND id_empresa = :id_empresa LIMIT 1";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod[0]->id;
}

function premios_puntos_gastados_porrut($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT SUM(puntos) AS gastado FROM tbl_premios_canje WHERE rut = :rut AND id_empresa = :id_empresa AND puntos > 0";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->gastado;
}

function premios_puntos_a_vencer($rut, $saldo_puntos, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT SUM(puntos) AS puntos, fecha FROM tbl_premios_puntos_usuarios WHERE rut = :rut AND id_empresa = :id_empresa GROUP BY fecha ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    $puntos = $cod[0]->puntos;
    if ($puntos >= $saldo_puntos) {
        $puntos_a_vencer = $saldo_puntos;
    } else {
        $puntos_a_vencer = $puntos;
    }
    $new_fecha = date('Y-m-d H:i:s', strtotime('+1 years', strtotime($cod[0]->fecha)));
    $arreglo[0]->puntos = $puntos_a_vencer;
    $arreglo[0]->fecha = $new_fecha;
    return $arreglo;
}

function premios_buscaSaldo($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT SUM(puntos) AS puntos, 'ingreso' FROM tbl_premios_puntos_usuarios WHERE rut = :rut AND id_empresa = :id_empresa UNION SELECT (1) * SUM(puntos) AS puntos, 'egreso' FROM tbl_premios_canje WHERE rut = :rut AND id_empresa = :id_empresa AND estadovalidacion <> '3'";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function PremioBuscaNombre($id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT premio FROM tbl_premios WHERE id_premio = :id_premio AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->premio;
}

function premios_busca_cartola($rut, $id_empresa, $limit)
{
    $connexion = new DatabasePDO();
    if ($limit != '') {
        $qlimit = " LIMIT $limit";
    } else {
        $qlimit = "";
    }
    $sql = "SELECT id, rut, fecha, puntos, tipo, descripcion, 'ingreso'
            FROM tbl_premios_puntos_usuarios
            WHERE rut = :rut AND id_empresa = :id_empresa
            UNION
            SELECT id, rut, fecha, puntos, id_premio, estadovalidacion, 'egreso'
            FROM tbl_premios_canje
            WHERE rut = :rut AND id_empresa = :id_empresa AND estadovalidacion <> '3'
            ORDER BY fecha DESC, id DESC $qlimit";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function buscaDatosPremio($ide, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id_premio FROM tbl_premios_canje WHERE id_empresa = :id_empresa AND id = :ide LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':ide', $ide);
    $cod = $connexion->resultset();
    return $cod[0]->id_premio;
}

function mp_buscaDATOSPERSONAS($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT h.*,
    (SELECT biografia FROM tbl_usuario_biografia WHERE rut=h.rut AND id_empresa=h.id_empresa LIMIT 1) AS biografia,
    (SELECT sueno FROM tbl_usuario_biografia WHERE rut=h.rut AND id_empresa=h.id_empresa LIMIT 1) AS sueno,
    (SELECT logros FROM tbl_usuario_biografia WHERE rut=h.rut AND id_empresa=h.id_empresa LIMIT 1) AS logros,
    (SELECT avatar FROM tbl_usuario_biografia WHERE rut=h.rut AND id_empresa=h.id_empresa LIMIT 1) AS avatarcomunidad,
    (SELECT celular FROM tbl_usuario_biografia WHERE rut=h.rut AND id_empresa=h.id_empresa LIMIT 1) AS celular
    FROM tbl_usuario h
    WHERE h.id_empresa = :id_empresa AND h.rut = :rut
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}

function ActualizaJefe_beneficios_validar($idimte, $validacion, $id_empresa)
{
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $sql = "
    UPDATE tbl_becas
    SET validacionok = :validacion, fechavalidacion = :hoy
    WHERE id_empresa = :id_empresa AND id = :idimte
    LIMIT 1
    ";

    $connexion->query($sql);
    $connexion->bind(':validacion', $validacion);
    $connexion->bind(':hoy', $hoy);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':idimte', $idimte);
    $connexion->execute();
}

function buscaDatosBeneItem($ide, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT nombre
    FROM tbl_beneficios
    WHERE id_empresa = :id_empresa AND id_beneficios = :ide
    LIMIT 1
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':ide', $ide);
    $cod = $connexion->resultset();

    return $cod[0]->nombre;
}

function EliminaCanjePuntosCero($id, $id_empresa, $puntos) {
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_premios_canje SET puntos='0' WHERE id_empresa=:id_empresa AND id=:id";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

function DatosPremioId($id_premio, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_premios h WHERE h.id_empresa=:id_empresa AND h.id_premio=:id_premio LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_premio', $id_premio);
    $cod = $connexion->resultset();
    return $cod;
}

function Postulaciones_busca_CanjePuntos($rut, $segmento, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT premio FROM tbl_premios WHERE id_premio=h.id_premio AND segmento=:segmento) AS premio
            FROM tbl_premios_canje h
            WHERE h.id_empresa=:id_empresa AND h.rut=:rut AND h.estadovalidacion<>'3' AND h.estadovalidacion<>'1'
            ORDER BY id DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':segmento', $segmento);
    $cod = $connexion->resultset();
    return $cod;
}

function Postulaciones_busca_BeneficiosValidar($rut, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT tbl_premios_canje.*, tbl_usuario.nombre_completo AS nombre_completo, tbl_premios.premio AS premio, tbl_usuario.jefe AS jefe
            FROM tbl_premios_canje
            INNER JOIN tbl_usuario ON tbl_usuario.rut=tbl_premios_canje.rut
            INNER JOIN tbl_premios ON tbl_premios.id_premio=tbl_premios_canje.id_premio
            WHERE tbl_premios_canje.id_empresa=:id_empresa AND tbl_usuario.jefe=:rut AND tbl_premios_canje.estadovalidacion='2'";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function VerificaUsuarioEmailBK($email, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT rut FROM tbl_usuario WHERE emailBK = :email AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':email', $email);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->rut;
}

function Postulaciones_busca_PostulacionesValidar($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT h.*,
    (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.rut) AS nombre_completo,
    (SELECT dimension FROM tbl_postulables WHERE id_postulable = h.id_postulable) AS dimension,
    (SELECT nombre FROM tbl_postulables WHERE id_postulable = h.id_postulable) AS nombre,
    (SELECT descripcion FROM tbl_postulables WHERE id_postulable = h.id_postulable) AS descripcion,
    h.jefe
    FROM tbl_postulaciones h
    WHERE h.id_empresa = :id_empresa AND h.jefe = :rut AND h.jefeok = ''
    ";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function Becas_Datos_Tipo($rut, $id_empresa, $tipo)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT *
    FROM tbl_becas
    WHERE tipo_beca = :tipo AND rut = :rut AND id_empresa = :id_empresa
    ";
    $connexion->query($sql);
    $connexion->bind(':tipo', $tipo);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaUsuarioDadoidgr($idgr)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT *
    FROM tbl_reconoce_gracias
    WHERE id = :idgr
    ";
    $connexion->query($sql);
    $connexion->bind(':idgr', $idgr);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaUsuarioDadoFullTexto($q, $id_empresa)
{
    $connexion = new DatabasePDO();
    $q = utf8_decode($q);
    if ($id_empresa == "78") {
        $queryFiltro = " and tbl_usuario.division='Division Personas y Organizacion' ";
        $queryFiltro = " ";
    } else {
        $queryFiltro = " ";
    }
    $sql = "
    SELECT tbl_usuario.*,
       MATCH (nombre_completo) AGAINST (:q) AS relevance
    FROM tbl_usuario
    WHERE MATCH (nombre_completo) AGAINST (:q) and MATCH (nombre_completo) AGAINST (:q) > 0
    $queryFiltro
    ORDER BY relevance DESC limit 12;
    ";
    $connexion->query($sql);
    $connexion->bind(':q', $q);
    $cod = $connexion->resultset();
    return $cod;
}

function UsuarioEnBasePersonaPorEmpresa($rut, $id_empresa)
{

    /*echo "<br>".$host = DB_HOST;
    echo "<br>".$user = DB_USER;
    echo "<br>".$pass = DB_PASS;
    echo "<br>".$dbname = DB_NAME;

    echo "<br>$rut, $id_empresa";*/
    // Check if $rut and $id_empresa are null and assign default values
    $connexion = new DatabasePDO();
    $sql = "select * from tbl_usuario  where rut=:rut and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function UsuarioEnBasePersonas($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_usuario WHERE rut = :rut AND rut <> '' AND vigencia = '0'";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    $rutKey = $cod[0]->rut;


        return $cod;

    exit;
}

function InsertaLogSistema($rut, $ambiente, $id_empresa, $id_detalle, $subcategoria, $id_archivo, $nivel, $id_menu_nivel)
{
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_log_sistema (rut, ambiente, fecha, hora, ip, id_empresa, id_detalle, subcategoria, id_archivo, menu_nivel, id_menu_nivel, variables_post, variables_get) " . "VALUES (:rut, :ambiente, :fecha, :hora, :ip, :id_empresa, :id_detalle, :subcategoria, :id_archivo, :nivel, :id_menu_nivel, :variables_post, :variables_get)";
    
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':ambiente', $ambiente);
    $connexion->bind(':fecha', date("Y-m-d"));
    $connexion->bind(':hora', date("H:i:s"));
    $connexion->bind(':ip', $_SERVER['REMOTE_ADDR']);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_detalle', $id_detalle);
    $connexion->bind(':subcategoria', $subcategoria);
    $connexion->bind(':id_archivo', $id_archivo);
    $connexion->bind(':nivel', $nivel);
    $connexion->bind(':id_menu_nivel', $id_menu_nivel);
    $connexion->bind(':variables_post', json_encode($_POST));
    $connexion->bind(':variables_get', json_encode($_GET));

    $connexion->execute();
}

function DatosProceso()
{

}
function DatosEmpresa($id_empresa)
{

}
function MenuNivel0PorEmpresa($id_empresa, $id_tema)
{

}
function DatosEmpresaHolding($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_empresa_holding WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function EsJefeLidertblUsuario($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(id) AS cuenta FROM tbl_usuario WHERE (jefe = :rut OR lider = :rut) AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function DatosUsuario_($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*
            FROM tbl_usuario h
            WHERE rut = :rut AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function vio_vide_intro($rut, $ambiente, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(h.id) AS cuenta FROM tbl_banner_visto h WHERE h.rut = :rut AND h.id_empresa = :id_empresa AND h.ambiente = :ambiente";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':ambiente', $ambiente);
    $cod = $connexion->resultset();
    return $cod;
}

function inserta_vio_video($rut, $ambiente, $id_empresa)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $sql = "INSERT INTO tbl_banner_visto (rut, id_empresa, ambiente, fecha) VALUES (:rut, :id_empresa, :ambiente, :fecha)";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':ambiente', $ambiente);
    $connexion->bind(':fecha', $fecha);
    $connexion->execute();
}

function premio_solicitud_jefe_validacion($id, $id_empresa, $rut, $tipo)
{
    $connexion = new DatabasePDO();
    if ($tipo == 1) {
        $sql = "UPDATE tbl_premios_canje SET estadovalidacion = '1' WHERE id = :id";
    } elseif ($tipo == 3) {
        $sql = "DELETE FROM tbl_premios_canje WHERE id = :id";
    }
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function rutesvigente($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT vigencia FROM tbl_usuario h WHERE h.rut = :rut AND h.id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->vigencia;
}

function rutesjefe($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(h.id) AS cuenta FROM tbl_usuario h WHERE h.jefe = :rut AND h.id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function premios_solicitudes_pendientes($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
        (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.rut) AS nombre_persona,
        (SELECT premio FROM tbl_premios WHERE id_premio = h.id_premio AND id_empresa = :id_empresa) AS nombre_premio
        FROM tbl_premios_canje h
        WHERE (h.rut = :rut OR h.rut_jefe = :rut OR (SELECT responsable FROM tbl_usuario WHERE rut = h.rut AND id_empresa = h.id_empresa LIMIT 1) = :rut OR (SELECT lider FROM tbl_usuario WHERE rut = h.rut AND id_empresa = h.id_empresa LIMIT 1) = :rut)
        AND h.id_empresa = :id_empresa AND h.estadovalidacion = '2'
        ORDER BY h.id DESC";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function premios_guarda_solicitud($rut, $id_premio, $rut_jefe, $id_empresa, $fecha_texto, $fecha_solicitud, $hora_inicio, $hora_termino)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    
    $sql2 = "SELECT * FROM tbl_premios WHERE id_premio = :id_premio AND id_empresa = :id_empresa";
    $connexion->query($sql2);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod2 = $connexion->resultset();
    
    $sql3 = "SELECT * FROM tbl_premios_canje WHERE id_premio = :id_premio AND id_empresa = :id_empresa AND rut = :rut AND fecha = :fecha AND hora_inicio = :hora_inicio AND hora_termino = :hora_termino";
    $connexion->query($sql3);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora_inicio', $hora_inicio);
    $connexion->bind(':hora_termino', $hora_termino);
    $cod3 = $connexion->resultset();
    
    $data_usuario_puntos = premios_buscadatos($rut, $id_empresa);
    $validacionpuntos = 0;
    if ($data_usuario_puntos[0]->puntossaldo >= $cod2[0]->puntos) {
        $validacionpuntos = 1;
    }
    
    $swa = '';
    
    if (count($cod3) == 0 && $validacionpuntos == 1) {
        $sql = "INSERT INTO tbl_premios_canje (rut, id_premio, fecha, hora, puntos, rut_jefe, id_empresa, estadovalidacion, fecha_texto, fecha_solicitud, hora_inicio, hora_termino) VALUES (:rut, :id_premio, :fecha, :hora, :puntos, :rut_jefe, :id_empresa, '2', :fecha_texto, :fecha_solicitud, :hora_inicio, :hora_termino)";
        $connexion->query($sql);
        $connexion->bind(':rut', $rut);
        $connexion->bind(':id_premio', $id_premio);
        $connexion->bind(':fecha', $fecha);
        $connexion->bind(':hora', $hora);
        $connexion->bind(':puntos', $cod2[0]->puntos);
        $connexion->bind(':rut_jefe', $rut_jefe);
        $connexion->bind(':id_empresa', $id_empresa);
        $connexion->bind(':fecha_texto', $fecha_texto);
        $connexion->bind(':fecha_solicitud', $fecha_solicitud);
        $connexion->bind(':hora_inicio', $hora_inicio);
        $connexion->bind(':hora_termino', $hora_termino);
        $connexion->execute();
        $swa = "solicitud";
    } elseif ($validacionpuntos == 0) {
        $swa = "sinpuntos";
    } elseif (count($cod3) > 0) {
        $swa = "solicitudyarealizada";
    }
    
    return $swa;
}

function premios_guarda_solicitud_estado($rut, $id_premio, $rut_jefe, $id_empresa, $fecha_texto, $fecha_solicitud, $hora_inicio, $hora_termino, $estado, $direccion, $celular, $email)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    
    $sql2 = "SELECT * FROM tbl_premios WHERE id_premio = :id_premio AND id_empresa = :id_empresa";
    $connexion->query($sql2);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod2 = $connexion->resultset();
    
    $sql3 = "SELECT * FROM tbl_premios_canje WHERE id_premio = :id_premio AND id_empresa = :id_empresa AND rut = :rut AND fecha = :fecha AND hora_inicio = :hora_inicio AND hora_termino = :hora_termino";
    $connexion->query($sql3);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora_inicio', $hora_inicio);
    $connexion->bind(':hora_termino', $hora_termino);
    $cod3 = $connexion->resultset();
    
    $cod3 = array(); // Resetting the variable
    
    $data_usuario_puntos = premios_buscadatos($rut, $id_empresa);
    $validacionpuntos = 0;
    if ($data_usuario_puntos[0]->puntossaldo >= $cod2[0]->puntos) {
        $validacionpuntos = 1;
    }
    
    $direccion = utf8_decode($direccion);
    
    $cod_last = null;
    $swa = '';
    
    if (count($cod3) == 0 && $validacionpuntos == 1) {
        $sql = "INSERT INTO tbl_premios_canje (rut, id_premio, fecha, hora, puntos, rut_jefe, id_empresa, estadovalidacion, fecha_texto, fecha_solicitud, hora_inicio, hora_termino, direccion, celular_personal, email_personal) VALUES (:rut, :id_premio, :fecha, :hora, :puntos, :rut_jefe, :id_empresa, :estado, :fecha_texto, :fecha_solicitud, :hora_inicio, :hora_termino, :direccion, :celular, :email)";
        $connexion->query($sql);
        $connexion->bind(':rut', $rut);
        $connexion->bind(':id_premio', $id_premio);
        $connexion->bind(':fecha', $fecha);
        $connexion->bind(':hora', $hora);
        $connexion->bind(':puntos', $cod2[0]->puntos);
        $connexion->bind(':rut_jefe', $rut_jefe);
        $connexion->bind(':id_empresa', $id_empresa);
        $connexion->bind(':estado', $estado);
        $connexion->bind(':fecha_texto', $fecha_texto);
        $connexion->bind(':fecha_solicitud', $fecha_solicitud);
        $connexion->bind(':hora_inicio', $hora_inicio);
        $connexion->bind(':hora_termino', $hora_termino);
        $connexion->bind(':direccion', $direccion);
        $connexion->bind(':celular', $celular);
        $connexion->bind(':email', $email);
        $connexion->execute();
        
        $sql_last = "SELECT id FROM tbl_premios_canje WHERE rut = :rut AND id_premio = :id_premio ORDER BY id DESC LIMIT 1";
        $connexion->query($sql_last);
        $connexion->bind(':rut', $rut);
        $connexion->bind(':id_premio', $id_premio);
        $connexion->execute();
        $cod_last = $connexion->resultset();
        
        $swa = "solicitud";
    } elseif ($validacionpuntos == 0) {
        $swa = "sinpuntos";
    } elseif (count($cod3) > 0) {
        $swa = "solicitudyarealizada";
    }
    
    return $cod_last[0]->id;
}

function premios_buscadatos($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "
        select sum(h.puntos) as puntosrecibidos,
        (IFNULL((select sum(puntos) from tbl_premios_canje where rut=:rut and id_empresa=:id_empresa), 0)) as puntoscanjeados,
        (sum(h.puntos) - (IFNULL((select sum(puntos) from tbl_premios_canje where rut=:rut and id_empresa=:id_empresa), 0))) as puntossaldo
        from tbl_premios_puntos_usuarios h where h.rut=:rut and h.id_empresa=:id_empresa";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function premios_ultimos_canjes($id_empresa, $rut, $limit)
{
    $connexion = new DatabasePDO();
    $sql = "
        select h.*,(select premio from tbl_premios where id_premio=h.id_premio  and id_empresa=:id_empresa) as nombre_premio
        from tbl_premios_canje h
        where h.rut=:rut and h.id_empresa=:id_empresa order by fecha DESC limit :limit";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':limit', $limit, PDO::PARAM_INT);
    $cod = $connexion->resultset();
    return $cod;
}

function premios_ranking_canjes($id_empresa, $limit)
{
    $connexion = new DatabasePDO();
    $sql = "
        select h.*,count(h.id) as cuenta, (select premio from tbl_premios where id_premio=h.id_premio and id_empresa=:id_empresa) as nombre_premio
        from tbl_premios_canje h
        where h.id_empresa=:id_empresa and h.estadovalidacion='1'
        group by h.id_premio
        order by count(h.id) DESC limit :limit";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':limit', $limit, PDO::PARAM_INT);
    $cod = $connexion->resultset();
    return $cod;
}

function premios_ultimos_canjes_globales($id_empresa, $limit)
{
    $connexion = new DatabasePDO();
    $sql = "
        select h.*,(select premio from tbl_premios where id_premio=h.id_premio and id_empresa=:id_empresa) as nombre_premio
        from tbl_premios_canje h
        where h.id_empresa=:id_empresa and h.estadovalidacion='1' order by fecha DESC limit :limit";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':limit', $limit, PDO::PARAM_INT);
    $cod = $connexion->resultset();
    return $cod;
}

function premios_ultimos_puntos_recibidos($id_empresa, $rut, $limit)
{
    $connexion = new DatabasePDO();
    $sql = "
        select h.*
        from tbl_premios_puntos_usuarios h
        where h.rut=:rut and h.id_empresa=:id_empresa order by fecha DESC limit :limit";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':limit', $limit, PDO::PARAM_INT);
    $cod = $connexion->resultset();
    return $cod;
}

function traigoDimensionPremios_data($segmento, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (select count(id) from tbl_premios where id_dimension=h.id_dimension and segmento=h.segmento) as cuenta from tbl_premios_dimension h WHERE h.segmento=:segmento and h.id_empresa=:id_empresa";

    $connexion->query($sql);
    $connexion->bind(':segmento', $segmento);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function TraeDatosBiografiayUsuario($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "select h.*
        from tbl_usuario h
        where rut=:rut and id_empresa=:id_empresa";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function DatosUsuarioLeftJefeDeTblUsuario($rut)
{
    $connexion = new DatabasePDO();
    $sql = "
        SELECT
            tbl_usuario.*,
            base_jefe.nombre as nombre_jefe,
            base_jefe.apaterno as apaterno_jefe,
            base_jefe.amaterno as amaterno_jefe
        FROM
            tbl_usuario
        left join tbl_usuario as base_jefe on base_jefe.rut=tbl_usuario.jefe
        WHERE
            tbl_usuario.rut = :rut";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function RF_buscasegmento($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.mundo FROM tbl_usuario h WHERE h.id_empresa = :id_empresa AND h.rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function DatosRegionUsuario_($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.regional FROM tbl_usuario h WHERE h.rut = :rut AND h.id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->regional;
}

function traigoDimensionPremiosDimension_Item_data($id_dim, $segmento, $id_empresa)
{
    $connexion = new DatabasePDO();
    if ($id_dim == "") {
        $queryDim = "";
    } else {
        $queryDim = "AND id_dimension = :id_dim";
    }

    $sql = "SELECT * FROM tbl_premios_dimension WHERE segmento = :segmento $queryDim AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':segmento', $segmento);
    $connexion->bind(':id_dim', $id_dim);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function traigoDimensionPremiosDimension_Item_Todos_data($segmento, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_premios_dimension WHERE segmento = :segmento AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':segmento', $segmento);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function traigoDimensionPremios_data_rut($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, p.premio, p.premioludico, p.puntos, p.id_premio, p.id_dimension, p.condiciones, p.requisitos, p.imagen_banner_2023, p.premio_descripcion
            FROM tbl_premios_al_rut h
            JOIN tbl_premios p ON h.id_premio = p.id_premio
            WHERE h.rut = :rut AND h.id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function VerificaPremioAlRut($id_premio, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id
            FROM tbl_premios_al_rut h 
            WHERE h.rut = :rut AND h.id_premio = :id_premio";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_premio', $id_premio);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}

function BuscaPremiosAgrupados($id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*
            FROM tbl_premios h
            WHERE h.tipo_grupo = :id_premio AND h.id_empresa = :id_empresa
            ORDER BY h.orden ASC";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function traigoPremios_data($segmento, $id_empresa, $iddimension)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
            (SELECT COUNT(id) FROM tbl_premios_canje WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa AND puntos > 0) AS canjes,
            (h.stock - (SELECT COUNT(id) FROM tbl_premios_canje WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa AND puntos > 0)) AS saldo
            FROM tbl_premios h
            WHERE h.segmento = :segmento AND h.id_empresa = :id_empresa AND h.id_dimension = :iddimension AND h.tipo_grupo IS NULL
            ORDER BY h.orden ASC";
    $connexion->query($sql);
    $connexion->bind(':segmento', $segmento);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':iddimension', $iddimension);
    $cod = $connexion->resultset();
    return $cod;
}

function traigoPremio_data($id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
            (SELECT COUNT(id) FROM tbl_premios_canje WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa AND puntos > 0) AS canjes,
            (h.stock - (SELECT COUNT(id) FROM tbl_premios_canje WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa AND puntos > 0)) AS saldo
            FROM tbl_premios h
            WHERE h.id_premio = :id_premio AND h.id_empresa = :id_empresa
            LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function VerificaCanjeRutAnterior($id_premio, $rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(id) AS cuenta
            FROM tbl_premios_canje
            WHERE id_premio = :id_premio AND id_empresa = :id_empresa AND rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function traigoPremios_Portfolio_data($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
            (SELECT COUNT(id) FROM tbl_premios_canje WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa AND puntos > 0) AS canjes,
            (h.stock - (SELECT COUNT(id) FROM tbl_premios_canje WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa AND puntos > 0)) AS saldo
            FROM tbl_premios h
            WHERE h.id_empresa = :id_empresa
            ORDER BY h.orden ASC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function traigoPremios($id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * from tbl_premios WHERE id_premio=:id_premio and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function traigoIdCanjePremiosId($id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * from tbl_premios_canje WHERE id=:id_premio and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function busca_premios_datos_usuario($rut, $tipo, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT dato from tbl_premios_datos_usuarios WHERE rut=:rut and id_empresa=:id_empresa and tipo=:tipo";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo', $tipo);
    $cod = $connexion->resultset();
    return $cod;
}

function busca_datos_rf($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT mundo, tipo_servicio from tbl_usuario WHERE rut=:rut and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function busca_premios_solicitudes_jefe($rut, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "
        SELECT h.rut,
            (SELECT rut_completo FROM tbl_usuario WHERE rut=h.rut) as RutCompleto,
            (SELECT nombre_completo FROM tbl_usuario WHERE rut=h.rut) as Nombre,
            (SELECT cargo FROM tbl_usuario WHERE rut=h.rut) as Cargo,
            (SELECT gerencia FROM tbl_usuario WHERE rut=h.rut) as Gerencia,
            (SELECT premio FROM tbl_premios WHERE id_premio=h.id_premio) as NombrePremio,
            h.*
        FROM tbl_premios_canje h
        WHERE (SELECT jefe FROM tbl_usuario WHERE rut=h.rut) = :rut
            OR (SELECT lider FROM tbl_usuario WHERE rut=h.rut) = :rut
            OR (SELECT responsable FROM tbl_usuario WHERE rut=h.rut) = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function VerificaSesionChequeado($rut, $id_imparticion, $id_empresa, $sesionid)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT count(id) as cuenta FROM rel_lms_inscripcion_usuario_checkin WHERE rut=:rut and codigo_imparticion=:id_imparticion and id_empresa=:id_empresa and sesion=:sesionid";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_imparticion', $id_imparticion);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':sesionid', $sesionid);
    $cod = $connexion->resultset();
    return $cod;
}

function num_canjes_rut($rut, $id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $ano = date("Y");
    $sql = "SELECT count(id) as cuenta
        FROM tbl_premios_canje
        WHERE rut=:rut and id_premio=:id_premio and YEAR(fecha)=:ano and id_empresa=:id_empresa and estadovalidacion<>'3' limit 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':ano', $ano);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function num_canjes_semestral_rut($rut, $id_premio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $ano = date("Y");
    $mes = date("m");
    $hoy = date("Y-m-d");
    $fecha_array = explode("-", $hoy);
    $mes = $fecha_array[1];

    if ($mes == "01" || $mes == "02" || $mes == "03" || $mes == "04" || $mes == "05" || $mes == "06") {
        $semestre = 1;
    }

    if ($mes == "07" || $mes == "08" || $mes == "09" || $mes == "10" || $mes == "11" || $mes == "12") {
        $semestre = 2;
    }

    if ($semestre == 1) {
        $query_semestre = " and (MONTH(fecha)='01' OR MONTH(fecha)='02' OR MONTH(fecha)='03' OR MONTH(fecha)='04' OR MONTH(fecha)='05' OR MONTH(fecha)='06')";
    }
    if ($semestre == 2) {
        $query_semestre = " and (MONTH(fecha)='07' OR MONTH(fecha)='08' OR MONTH(fecha)='09' OR MONTH(fecha)='10' OR MONTH(fecha)='11' OR MONTH(fecha)='12')";
    }

    $sql = "SELECT count(id) as cuenta
        FROM tbl_premios_canje
        WHERE rut=:rut and id_premio=:id_premio and YEAR(fecha)=:ano
        $query_semestre
        and id_empresa=:id_empresa and estadovalidacion<>'3' limit 1";
    
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_premio', $id_premio);
    $connexion->bind(':ano', $ano);
    $connexion->bind(':id_empresa', $id_empresa);
    
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function Com_Premios_Detalle($segmento, $idi, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT foto FROM tbl_premios_dimension WHERE id_dimension=h.id_dimension LIMIT 1) AS foto
            FROM tbl_premios h
            WHERE h.id_premio=:idi AND h.id_empresa=:id_empresa AND h.segmento=:segmento";

    $connexion->query($sql);
    $connexion->bind(':idi', $idi);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':segmento', $segmento);
    $cod = $connexion->resultset();
    return $cod;
}

function SaveLogEmails($id_empresa, $tipo, $subject, $to, $nombreto, $fecha, $statusCode, $headers, $response, $tipomensaje, $rut, $key)
{
    $connexion = new DatabasePDO();

    $sql = "INSERT INTO tbl_log_emails (tipo, asunto, rut, id_empresa, fecha, statusCode, headers, body, dato, email)
            VALUES (:tipomensaje, '', :rut, :id_empresa, :fecha, '', '', '', :key, '')";

    $connexion->query($sql);
    $connexion->bind(':tipomensaje', $tipomensaje);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':key', $key);
    $connexion->execute();
}

function Postulaciones_UPDATEJEFE($id, $id_empresa, $v)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $fecha_estado = $fecha;

    $sql = "UPDATE tbl_postulaciones SET jefeok=:v, fechajefe=:fecha WHERE id_empresa=:id_empresa AND id=:id";

    $connexion->query($sql);
    $connexion->bind(':v', $v);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

function Beneficios_UPDATEJEFE($id, $id_empresa, $v)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $fecha_estado = $fecha;

    $sql = "UPDATE tbl_premios_canje SET estadovalidacion=:v, fechavalidacion=:fecha WHERE id_empresa=:id_empresa AND id=:id";

    $connexion->query($sql);
    $connexion->bind(':v', $v);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

?>