<?php
function validateDateToday($dia) {
    if (!empty($dia)) {
        $currentDate = new DateTime();
        $hoy=date("Y-m-d");
        $inputDate = DateTime::createFromFormat('Y-m-d', $dia);
        if ($inputDate && $inputDate->format('Y-m-d') === $dia) {
            
            if($dia>=$hoy){
                return true;
            } else {
                //echo "B1";
            }
        }
    }

    return false; // Not a valid date or doesn't meet the criteria
}
function BannerHome_2023($PRINCIPAL, $rut){
    $Sliders = Banners_2023_data($rut);
    // print_r($Sliders);
    if(count($Sliders) > 0){
        foreach ($Sliders as $s){
            $carrusel_2023_bancopuntos .= "<div class='item'>
                                                <a href='".($s->url)."' >
                                                    <img src='img/".$s->imagen."' style='border-radius:20px'>
                                                </a>
                                            </div>";
        }
    } else {
        $carrusel_2023_bancopuntos = "";
    }

    $PRINCIPAL = str_replace("{DIV_CARRUSEL_2023_POR_BANCOPUNTOS}", $carrusel_2023_bancopuntos, $PRINCIPAL);
    return $PRINCIPAL;
}

function CartolaPuntosAVencer($PRINCIPAL, $rut)
{
    $array=CartolaProximas_rut($rut);
    foreach ($array as $u){
        if($u->fecha<>$ultima_fecha){

        } elseif($u->fecha==$ultima_fecha and $u->tipo==$ultimo_tipo){

        } else {
            //echo "NO MUESTRO";
            continue;
        }

        if($u->puntos>0){

        } else {
            continue;
        }

        $tipo_vencimiento=checkCartolaNoVence($rut, $u->fecha, $u->puntos);
        if($tipo_vencimiento=="SIN_VENCIMIENTO"){
            continue;
        }

        if($u->modalidad=="E"){
            $row_cartolas_vencimiento="
                <tr>
                    <td>No tienes pr&oacute;ximos vencimientos</td>
                    <td></td>
                </tr>
            ";
        } elseif($u->modalidad=="D"){

            $puntos_saldo=PuntosModalidadD($rut, $u->fecha);
            //print_r($Var);
            if($puntos_saldo<0){
                continue;
            }
            $cuentaModalidadD++;
            if($cuentaModalidadD=="1"){
                $u->puntos=$puntos_saldo;
            } else {
                $u->puntos=$u->puntos;
            }
            $SaldosVencidos=checkCartolaPunstoSaldoVencidos($rut, $u->fecha);
            //print_r($SaldosVencidos);
            $saldo_puntos_vencidos_dato=(-1)*$SaldosVencidos[0]->puntos_saldo_vencidos;
            if($saldo_puntos_vencidos_dato>0 and $saldo_puntos_vencidos_dato<$u->puntos){
                $puntos_vencimiento=$saldo_puntos_vencidos_dato;
            } else {
                $puntos_vencimiento=$u->puntos;
            }

            $row_cartolas_vencimiento.="
                <tr>
                    <td>".$puntos_vencimiento." </td>
                    <td> ".$u->fecha."</td>
                </tr>";
        } else {
            $SaldosVencidos=checkCartolaPunstoSaldoVencidos($rut, $u->fecha);
            //print_r($SaldosVencidos);
            $saldo_puntos_vencidos_dato=(-1)*$SaldosVencidos[0]->puntos_saldo_vencidos;
            if($saldo_puntos_vencidos_dato>0 and $saldo_puntos_vencidos_dato<$u->puntos){
                $puntos_vencimiento=$saldo_puntos_vencidos_dato;
            } else {
                $puntos_vencimiento=$u->puntos;
            }
            $row_cartolas_vencimiento.="
                <tr>
                    <td>$puntos_vencimiento</td>
                    <td> ".$u->fecha."</td>
                </tr>
            ";
        }
        $ultima_fecha=$u->fecha;
        $ultimo_tipo=$u->tipo;
    }
    $PRINCIPAL             = str_replace("{ROW_CARTOLAS_PROXIMOS_VENCIMIENTOS}", ($row_cartolas_vencimiento), $PRINCIPAL);
    return ($PRINCIPAL);
}
function BancoDePuntos_2021_SaldoAVencer($rut, $fecha_a_vencer){
		$date2 = strtotime('$fecha_a_vencer +1 year');
		$fecha_a_vencer2=date('Y-m-d', $date2); 
        $date_actual = strtotime(" $fecha_a_vencer +1 year");
        $fecha_a_vencer_date_actual=date('Y-m-d', $date_actual); 
        //echo "<br>-> date_actual $fecha_a_vencer_date_actual";
		$AVencer_potencial	        =	BancodePuntos_2021_SaldoAVencer_data($rut, $fecha_a_vencer);
		$Canjeados					=	BancodePuntos_2021_Canjeados_data($rut);
		$AVencer					=	$AVencer_potencial-$Canjeados;
		//echo "<br>-> AVencer $AVencer, Canjeados $Canjeados 				<h1>$AVencer</h1>";
		if($AVencer>0){
		} else {
			$AVencer=0;
		}
		$arreglo[0]=fechaCastellano2($fecha_a_vencer_date_actual);
		$arreglo[1]=$AVencer;
		return $arreglo;
}
function my_simple_crypt_decodeartk($string)
{
    $secret_key = getenv('BDP_ENC_SECRET_TK');
    $secret_iv  = getenv('BDP_ENC_SECRET_IV_TK');
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash('sha256', $secret_key);
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    return $output;
}
function Decodeartk($valor)
{
    $valor = my_simple_crypt_decodeartk($valor);
    $valor = VerificaArregloSQLInjectionDecodear($valor);
    return ($valor);
}
function my_simple_crypt_encodeartk($string)
{
    $secret_key = getenv('BDP_ENC_SECRET_TK');
    $secret_iv  = getenv('BDP_ENC_SECRET_IV_TK');
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash('sha256', $secret_key);
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    $output = base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
    return $output;
}
function Encodeartk($valor)
{
    $valor = my_simple_crypt_encodeartk($valor);
    return ($valor);
}
function Com_Premios_ListadoPremios_dimension_items($PRINCIPAL, $segmento, $iddim, $id_empresa)
{
	
				//echo "<br>FN Com_Premios_ListadoPremios_dimension_items $segmento, $iddim, $id_empresa<br>";
				
				$Usua=DatosUsuario_($_SESSION["user_"], $id_empresa);
				$organica=$Usua[0]->organica;
				//echo "<br>organica $organica<br>";
				$dias_pendientes_real=$Usua[0]->dias_pendientes_real;
				$dias_derecho=$Usua[0]->dias_derecho;
				//echo "<br>dias_pendientes_real $dias_pendientes_real / dias_derecho $dias_derecho";
				$valor_usuario_pendientes_real_derecho=valor_usuario_pendientes_real_derecho($dias_pendientes_real,$dias_derecho);
				//echo "<br>valor_usuario_pendientes_real_derecho $valor_usuario_pendientes_real_derecho<br>";

			//$valor_usuario_pendientes_real_derecho="2.1";
    $traigoDimensionPremios = traigoDimensionPremiosDimension_Item_data($iddim, $segmento, $id_empresa);

    foreach ($traigoDimensionPremios as $traigoDimensionPremio) {
        // print_r($traigoDimensionPremio);
        $row .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_Lista_Item_row_dimensiones_premios.html");
        $row           = str_replace("{IMAGEN_DIMENSION}", $traigoDimensionPremio->foto, $row);
        $row           = str_replace("{ID_DIMENSION}", $traigoDimensionPremio->id_dimension, $row);
        $row           = str_replace("{ID_DIMENSION_ENCODEADA}", Encodear3($traigoDimensionPremio->id_dimension), $row);
        $row           = str_replace("{NOMBRE_DIMENSION}", $traigoDimensionPremio->dimension, $row);

        $traigoPremios = traigoPremios_data($segmento, $id_empresa, $traigoDimensionPremio->id_dimension);
        $row_premio    = "";
        foreach ($traigoPremios as $traigoPremio) {
        //echo "<br>";
        //print_r($traigoPremio);


										if($organica=="24" or $organica=="30" or $organica=="34" or $organica=="35"){
											if($traigoPremio->id_premio=="bch_50" or 
												$traigoPremio->id_premio=="bch_c01" or 
												$traigoPremio->id_premio=="bch_c44" or 
												$traigoPremio->id_premio=="bch_c44_01" or 
												$traigoPremio->id_premio=="bch_c44_02" or 
												$traigoPremio->id_premio=="bch_c44_03"
											
											){						
												continue;
											}
										}
										
										if($valor_usuario_pendientes_real_derecho>=2){
											if($traigoPremio->id_premio=="bch_c02" or 
												$traigoPremio->id_premio=="bch_c03" or 
												$traigoPremio->id_premio=="bch_c04"
											
											){	
												//echo "<h1>Continue</h1>";					
												continue;
											}
										}	 else 
										{
											//echo "<h1>Lo Veo</h1>";
										}			
				
				//echo "<br>id_premio ".$traigoPremio->id_premio;
				
        $rut=$_SESSION["user_"];
        $exclusion=VerificaRutPremioExclusion($rut,$traigoPremio->id_premio, $id_empresa);
        if($exclusion>0){continue;}

    		$num_canjes_rut=num_canjes_rut($rut,$traigoPremio->id_premio, $id_empresa);
				$stock_txt="";
     		$estilo_imagen=" ";
		     		
		     		/** echo "<br>premio ".$traigoPremio->id_premio." ".$traigoPremio->premio."
		         Saldo ".$traigoPremio->saldo." stock ".$traigoPremio->stock." ultimas ".$traigoPremio->alertaultimasunidades.
		         " temporalidad ".$traigoPremio->temporalidad. " restriccion ".$traigoPremio->restriccion_rut." num canjes ".$num_canjes_rut." region ".$traigoPremio->region;  
							*/
						if($traigoPremio->region<>""){
							$love="";
										$Usua=DatosUsuario_($rut, $id_empresa);
										$porciones = explode(";",$traigoPremio->region);
										foreach ($porciones as $unico){
											//echo "<br>unico $unico";
											
											if($unico==$Usua[0]->regional){
												$love=1;
											}
											
											
										}
									if($love>0){
										
									} else 
									{continue;
										}
										

						}
		         
		         if($traigoPremio->restriccion_rut>0 and $num_canjes_rut>=$traigoPremio->restriccion_rut){
		           //echo "hola"; 
				   $stock_txt="<span class='badge badge-danger'><span class='blanco'>
		                    Ya canjeaste el máximo de veces permitido este año </span> </span>";
		                    $estilo_imagen=" img_bn_grasycale ";
		         }
       
            if($traigoPremio->saldo<=$traigoPremio->alertaultimasunidades){

        			$stock_txt="<span class='badge badge-warning'><span class='blanco'><i class='fab fa-hotjar'></i>
        			Quedan sólo ".$traigoPremio->saldo." disponibles </span> </span>";

            }

            if($traigoPremio->saldo==0 or $traigoPremio->saldo<0){
                //echo "CERO";
                
                //print_r($traigoPremio);
                
                if($traigoPremio->temporalidad==''){
                   // echo "C";
                   
                   if($traigoPremio->stock==0){
                    $stock_txt="<span class='badge badge-warning'><span class='blanco'>
                    Canje suspendido temporalmente</span> </span>";
                   	
                   } else {
                    $stock_txt="<span class='badge badge-danger'><span class='blanco'>
                    Sin stock disponible</span> </span>";
                   	
                   }
                    $estilo_imagen=" img_bn_grasycale ";
                   
                }

                if($traigoPremio->temporalidad=='SI'){
                     //echo "B";
                     continue;
                }
            }

						$nomuestraganadores="";
               // echo "<br>".$traigoPremio->premio." ";
               // echo "<br>fecha inicio ".$traigoPremio->fecha_inicio;
               // echo "<br>fecha_vencimiento ".$traigoPremio->fecha_vencimiento;
            $hoy=date("Y-m-d");
             if($traigoPremio->fecha_inicio=='0000-00-00' or $traigoPremio->fecha_inicio=='')
               {

               } else {
                    //echo "<br>".$traigoPremio->premio." SI&nbsp;TIENE fecha inicio";
                    if($traigoPremio->fecha_inicio>$hoy){continue; $nomuestraganadores=1;}
               }

               if($traigoPremio->fecha_vencimiento=='0000-00-00' or $traigoPremio->fecha_vencimiento=='')
               {
               } else {
                   if($traigoPremio->fecha_vencimiento<$hoy){continue;}
                   // echo "<br>".$traigoPremio->premio." SI&nbsp;TIENE fecha_vencimiento";

               }

            $row_premio .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_Lista_Item_row_premios.html");
            $row_premio = str_replace("{ID_PREMIO_ENCODEADO}", Encodear3($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{ID_DIMENSION_ENCODEADO}", Encodear3($iddim), $row_premio);
            $row_premio = str_replace("{TITULO_PREMIO}", ($traigoPremio->premio), $row_premio);
            $row_premio = str_replace("{TITULO_PREMIOLUDICO}", ($traigoPremio->premioludico), $row_premio);
            $row_premio = str_replace("{DESCRIPCION_PREMIO}",resumir(($traigoPremio->premio_descripcion), 120," ", "..."), $row_premio);
            $row_premio = str_replace("{NUM_PUNTOS}", ($traigoPremio->puntos), $row_premio);
            $row_premio = str_replace("{ID_PREMIO}", ($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{CONDICIONES}", ($traigoPremio->condiciones), $row_premio);
            $row_premio = str_replace("{REQUISITOS}", ($traigoPremio->requisitos), $row_premio);
            $row_premio = str_replace("{ICONO}", ($traigoPremio->premio_icono), $row_premio);
            $row_premio = str_replace("{IMAGEN}", ($traigoPremio->imagen_2022), $row_premio);
            $row_premio = str_replace("{ESTILO_IMAGEN}", $estilo_imagen, $row_premio);
						$row_ganadores="";
						if($traigoPremio->ganadores==1 and $nomuestraganadores==""){
								$lista_ganadores="";
										$Array_Ganadores	=	BancoPuntos_2020_Ganadores($traigoPremio->id_premio, $id_empresa);
										$row_ganadores="";
										if(count($Array_Ganadores)>0){
																						$row_ganadores="";
																						foreach ($Array_Ganadores as $unico){
																							$row_ganadores.="<div class='col col-lg-12' style='font-size: 14px;text-align: left;'><i class='fas fa-angle-right'></i> ".$unico->nombre_completo."</div><br>";
																						}	
																						
																						
										} else {
																							$row_ganadores="<center>[ Sin ganadores hasta el momento ]</center>";
																						
										}
										

							$boton_ganadores="
							
									<button type='button' class='btn btn-info' data-toggle='modal' data-target='#exampleModal".Encodear3($traigoPremio->id_premio)."'>
									  Ver Ganadores
									</button>

									<div class='modal fade' id='exampleModal".Encodear3($traigoPremio->id_premio)."' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel".Encodear3($traigoPremio->id_premio)."' aria-hidden='true'>
									  <div class='modal-dialog' role='document'>
									    <div class='modal-content'>
									      <div class='modal-header'>
									        <h5 class='modal-title' id='exampleModalLabel'>Lista de Ganadores ".($traigoPremio->premio)."</h5>
									        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
									          <span aria-hidden='true'>&times;</span>
									        </button>
									      </div>
									      <div class='modal-body'>
									        ".$row_ganadores."
									      </div>
									      <div class='modal-footer'>
									        <button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>
									      </div>
									    </div>
									  </div>
									</div>
							
							";
							
							
						} else {
							$boton_ganadores="";
						}

            $row_premio = str_replace("{PUNTOS}", ($traigoPremio->puntos), $row_premio);
            $row_premio = str_replace("{STOCK}", $stock_txt, $row_premio);
            $row_premio = str_replace("{BOTON_VER_GANADORES_2020}", $boton_ganadores, $row_premio);

     }

        $row = str_replace("{ROW_PREMIOS}", $row_premio, $row);
    }
    $PRINCIPAL = str_replace("{LISTADO_DIMENSION_PREMIOS_ITEMS}", $row, $PRINCIPAL);
    return $PRINCIPAL;
}
function DecodearEmail($valor)
{
    //$valor=Decodear(Decodear(Decodear($valor)));
    //print_r($valor);
    $valor = my_simple_crypt_decodearEmail($valor, 'd');
    $valor      = VerificaArregloSQLInjectionDecodear($valor);

    return ($valor);
}
function my_simple_crypt_decodearEmail($string)
{
    // you may change these values to your own
    $secret_key     = getenv('BDP_ENC_SECRET_EMAIL');
    $secret_iv      = getenv('BDP_ENC_SECRET_IV_EMAIL');
    $minutos				= date("H:i");
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv.$minutos), 0, 16);
    $output         = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    return $output;
}
function VerificaArregloSQLInjectionDecodear($arreglo)
{
    $total_arreglo = count($arreglo);
            /*
            if($_SESSION["user_"]=="12345"){
                echo "<br>FN VerificaArregloSQLInjectionDecodear<br>";
                print_r($arreglo);
                echo "<br>total_arreglo $total_arreglo";
                echo "<h1>Arreglo <br>$arreglo</h1>";
            }
            */
				
        $arreglo = str_replace('"', "", $arreglo);
        $arreglo = str_replace("+'", "", $arreglo);
        $arreglo = str_replace('--', "", $arreglo);
        $arreglo = str_replace('--', "", $arreglo);
        $arreglo = str_replace('--', "", $arreglo);
        $arreglo = str_replace('&', "", $arreglo);
        $arreglo = str_replace('.php', "", $arreglo);
        $arreglo = str_replace('.js', "", $arreglo);
        $arreglo = str_replace('.vbs', "", $arreglo);
        $arreglo = str_replace('%', "", $arreglo);
        $arreglo = str_replace('&', "", $arreglo);
        $arreglo = str_replace('&amp;', "", $arreglo);
        $arreglo = str_replace('&#38;', "", $arreglo);
        $arreglo = str_replace('&lt;', "", $arreglo);
        $arreglo = str_replace('&#60;', "", $arreglo);
        $arreglo = str_replace('&gt;', "", $arreglo);
        $arreglo = str_replace('&#62;', "", $arreglo);
        $arreglo = str_replace('&quot;', "", $arreglo);
        $arreglo = str_replace('&#34;', "", $arreglo);
        $arreglo = str_replace('&#39;', "", $arreglo);
        $arreglo = str_replace('select', "", $arreglo);
        $arreglo = str_replace('tables', "", $arreglo);
        $arreglo = str_replace('union', "", $arreglo);
        $arreglo = str_replace('information_schema', "", $arreglo);
        $arreglo = str_replace('delete', "", $arreglo);
        $arreglo = str_replace('update', "", $arreglo);
        $arreglo = str_replace('show', "", $arreglo);
        $arreglo = str_replace('|', "", $arreglo);
        $arreglo = str_replace('user()', "", $arreglo);
        /*
        if($_SESSION["user_"]=="12345"){
            echo "<br>FN VerificaArregloSQLInjectionDecodear<br>";
            print_r($arreglo);
            echo "<br>total_arreglo $total_arreglo";
            echo "<h1>Arreglo <br>$arreglo</h1>";
        }
        */
    return ($arreglo);
}
function my_simple_crypt_encodearEmail($string)
{
    // you may change these values to your own
    $secret_key     = getenv('BDP_ENC_SECRET_EMAIL');
    $secret_iv      = getenv('BDP_ENC_SECRET_IV_EMAIL');
    $minutos				= date("H:i");
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv.$minutos), 0, 16);
    $output         = base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
    return $output;
}
function my_simple_crypt_decodear7($string)
{
    // you may change these values to your own
    $secret_key     = getenv('BDP_ENC_SECRET_ENC7');
    $secret_iv      = getenv('BDP_ENC_SECRET_IV_ENC7');
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv), 0, 16);
    $output         = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    return $output;
}
function my_simple_crypt_encodear7($string)
{
    // you may change these values to your own
    $secret_key     = getenv('BDP_ENC_SECRET_ENC7');
    $secret_iv      = getenv('BDP_ENC_SECRET_IV_ENC7');
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv), 0, 16);
    $output         = base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
    return $output;
}
function Encodear7($valor)
{
    //$valor=Encodear(Encodear(Encodear($valor)));
    $valor = my_simple_crypt_encodear7($valor, 'e');
    return ($valor);
}
function Decodear7($valor)
{
    //$valor=Decodear(Decodear(Decodear($valor)));
    //print_r($valor);
    $valor = my_simple_crypt_decodear7($valor, 'd');
    return ($valor);
}
function NotificacionesAutomaticas_envio_vencimientos($id_empresa, $url_front, $url_front_admin, $logo, $from, $nombrefrom, $fecha_inicio, $fecha_termino){
        $hoy=date("Y-m-d");
        //$hoy="2018-02-20";
        $Array=Canje_BuscaNotificaciones_Vencimiento($id_empresa, $fecha_inicio, $fecha_termino);
  			
/*  			echo "Arreglo";
  			print_r($Array);      
   			echo "Arreglo";
 */  		
   			
   			
  		ini_set('output_buffering', 0);
		ini_set('zlib.output_compression', 0);
		if( !ob_get_level() ){ ob_start(); }
		else { ob_end_clean(); ob_start(); }
        $count_total_loop=count($Array);
        foreach($Array as $unico){
        	
    

        	
$id_empresa=$unico->id_empresa;

$from=($unico->desde);
$nombrefrom=($unico->nombrefrom);
$tipo=$unico->tipo;
$subject="".$unico->puntos_a_vencer." Puntos a Vencer en BancodePuntosBch";
$titulo1="Estimado(a) ".$unico->nombre_completo.":";
$subtitulo1=($unico->subtitulo1);

$fecha_castellano=fechaCastellano2($unico->fecha_a_vencer);

$texto1="Te queremos informar que el día <strong>".$fecha_castellano."</strong> vencerán <strong>".$unico->puntos_a_vencer."</strong> puntos de tu cartola del BancodePuntosBch.
<br><br>Aprovéchalos hoy ingresando a Banco de Puntos y canjéalos en los distintos items que tenemos para ti.<br><br>
Saludos
<br><br><strong>Banco de Puntos Bch</strong>";
$url=$unico->url;
$texto_url=($unico->texto_url);
$logo=$unico->logo;
$texto2=($unico->texto2);
$texto3=($unico->texto3);
$texto4=($unico->texto4);
$tipomensaje=$unico->tipomensaje;
$rut=$unico->clave;
$key=$unico->clave;
$template=$unico->template;

$to=$unico->email;
$nombreto=$unico->email;

//$to					="rod@gop.cl";

 	
$nombreto		= $unico->email;   
$from				="notificaciones@bancodepuntosbch.cl";
$nombrefrom	="notificaciones@bancodepuntosbch.cl";


        					$cuenta_loop++;
        echo "<center><span style='position: absolute;z-index:$current;background:#36C6D3; padding:10px; color:#FFF'>Envio  ".$to." ".$nombreto." $cuenta_loop de $count_total_loop Registros</span></center>";
        flush();
 				ob_flush();


/*
echo "<br>to $to, nombre $nombreto, fro $from, nombrefrom $nombrefrom, tipo $tipo, subject $subject,  titulo1 $titulo1, subtitulo1 $subtitulo1,  texto1 $texto1, url $url,  texto_url $texto_url,
texto2 $texto2, texto3 $texto3,  texto4 $texto4, logo $logo, id_empresa $id_empresa, url $url, tipomensaje $tipomensaje, rut $rut,key $key, template $template";
sleep(5); */
SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url, $texto_url,
$texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $template);
//echo "<br>to $to, nombre $nombreto,$subject";
//Not_Actualiza_estado($unico->id,"ENVIADA");
        }
}
function VerificaArregloSQLInjectionV2($arreglo)
{
    $total_arreglo = count($arreglo);

    foreach ($arreglo as $clave => $valor) {

        if (strtoupper(trim($valor)) == "") {
            continue;
        }
        $valor = str_replace("'", "", $valor);
        $valor = str_replace('"', "", $valor);
        $valor = str_replace("+'", "", $valor);
        $valor = str_replace('--', "", $valor);
        $valor = str_replace('--', "", $valor);
        $valor = str_replace('--', "", $valor);
        $valor = str_replace('&', "", $valor);
        $valor = str_replace('.php', "", $valor);
        $valor = str_replace('.js', "", $valor);
        $valor = str_replace('%', "", $valor);
        $valor = str_replace('&', "", $valor);
        $valor = str_replace('&amp;', "", $valor);
        $valor = str_replace('&#38;', "", $valor);
        $valor = str_replace('<', "", $valor);
        $valor = str_replace('&lt;', "", $valor);
        $valor = str_replace('&#60;', "", $valor);
        $valor = str_replace('>', "", $valor);
        $valor = str_replace('&gt;', "", $valor);
        $valor = str_replace('&#62;', "", $valor);
        $valor = str_replace('&quot;', "", $valor);
        $valor = str_replace('&#34;', "", $valor);
        $valor = str_replace('&#39;', "", $valor);
        $valor = str_replace('select', "", $valor);
        $valor = str_replace('delete', "", $valor);
        $valor = str_replace('update', "", $valor);
        $valor = str_replace('show', "", $valor);
        $valor = str_replace('|', "", $valor);

        $arreglo[$clave]= $valor;
    }
    return ($arreglo);
}
function CanjePuntosValidaCanjes7dias($id_empresa){
	
	
	$array_canjes=BuscaCanjesValida7dias($id_empresa);
	//print_r($array_canjes); exit();
	foreach ($array_canjes as $unico){
		
	//print_r($unico);
		CanjePuntosActualizaValidacion($unico->id);
		

        $datos_premio=traigoPremios($unico->id_premio, $id_empresa);
        $datosautor  =mp_buscaDATOSPERSONAS($unico->rut, $id_empresa);
        $datosjefe   =mp_buscaDATOSPERSONAS($datosautor[0]->jefe, $id_empresa);	

                    //print_r($datos_premio);
                    //print_r($datosautor);
                     $from="notificaciones@bancodepuntosbch.cl";
	 
		             //email a Postulante
                    $titulo1="¡Muchas gracias! Has canjeado ".($datos_premio[0]->premio)."";
                    $subject="¡Muchas gracias! Has canjeado ".($datos_premio[0]->premio)."";
                    $subtitulo1=($datosautor[0]->nombre_completo).",
                    canjeaste ".($datos_premio[0]->premio)." $infocanjeadicional";
                    $texto1="";
                    $texto2="Puedes revisar el estado de tu canje en la cartola de puntos. Tu orden está confirmada";
                    $texto3=($datos_premio[0]->alertaemailusuario);
                    $tipomensaje="Email_Postulacion_Beneficio_usuario";
                    $rut=$datosautor[0]->rut;
                    $key=$datosautor[0]->rut;
                    $to=$datosautor[0]->email;
                    //$to="rod@gop.cl";
                    $url=$url_base;
                    $nombreto=($datosautor[0]->nombre_completo);
                    SendGrid_Email($to, $to, $from, $from, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");


                    //email a Jefatura
                    $titulo1="¡Excelente! Alguien de tu equipo canje&oacute; sus puntos";
                    $subject="Banco de puntos [".$last_id."]: Solicitud de canje actualizada";
                    $subtitulo1=($datosautor[0]->nombre_completo).",
                    canje&oacute; el ítem ".($datos_premio[0]->premio)." $infocanjeadicional";
                    $texto1="";
                    $texto2="";
                    $texto3=($datos_premio[0]->alertaemailjefe);
                    $tipomensaje="Email_Postulacion_Beneficio_usuario";
                    $rut=$datosjefe[0]->rut;
                    $key=$datosjefe[0]->rut;
                    $to=$datosjefe[0]->email;
                    //$to="rod@gop.cl";
                    $url=$url_base;
                    $nombreto=($datosautor[0]->nombre_completo);
                    SendGrid_Email($to, $to, $from, $from, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, "");

                    $estado_premios="1";
		
		
	}
	
	
	
}
function Encriptar($valor) {     
    $salt_text = "+YrpMRqf+*dD6Fr6G+HFsX-nkJ3jY3+kf%Ks26+sBMD6wcy8+UYy&K7*deJSBd*dkLUsr_!FyQffV4gDLXFtZ5hKzf@8Zpfm4e-CSB25PCNVbFmdhf!t%B!wyzs8aV&sP-GRc!Y4+?9z489-$yRzwJ!+S#CDzff4=!ak$SjQNENJPaBf7EYss_*f2_aqQ?stEfPPY!6pfwW#LJ*n25DTuY-mLBzsn#W8zKzXBgZdNBHf!maYdmLbQhtcb5&7wSMS";
    $salt = hash('sha256', $salt_text);
    $hash_text = $salt. $valor;
    $hash = hash('sha256', $hash_text);
    return $hash;
}
function Encriptar_2($valor, $rut) {     
    $salt_text = "+YrpMRqf+*dD6Fr6G+HFsX-nkJ3jY3+kf%Ks26+sBMD6wcy8+UYy&K7*deJSBd*dkLUsr_!FyQffV4gDLXFtZ5hKzf@8Zpfm4e-CSB25PCNVbFmdhf!t%B!wyzs8aV&sP-GRc!Y4+?9z489-$yRzwJ!+S#CDzff4=!ak$SjQNENJPaBf7EYss_*f2_aqQ?stEfPPY!6pfwW#LJ*n25DTuY-mLBzsn#W8zKzXBgZdNBHf!maYdmLbQhtcb5&7wSMS";
    $salt = hash('sha256', $salt_text);
    $hash_text = $salt. $valor;
    $hash = hash('sha256', $hash_text);

    $salt_text_rut = "+YrpMRqf+*dD6Fr6G+HFsX-nkJ3jY3+kf%Ks26+sBMD6wcy8+UYy&K7*deJSBd*dkLUsr_!FyQffV4gDLXFtZ5hKzf@8Zpfm4e-CSB25PCNVbFmdhf!t%B!wyzs8aV&sP-GRc!Y4+?9z489-$yRzwJ!+S#CDzff4=!ak$SjQNENJPaBf7EYss_*f2_aqQ?stEfPPY!6pfwW#LJ*n25DTuY-mLBzsn#W8zKzXBgZdNBHf!maYdmLbQhtcb5&7wSMS";
    $salt_rut = hash('sha256', $salt_text_rut);
    $hash_text_rut = $salt_rut. $rut;
    $hash_rut = hash('sha256', $hash_text_rut);	
		
    return hash('sha256',$hash.$hash_rut.$hash_rut);
}
function premios_puntos_a_vencer_2019_abonos($rut, $id_empresa) {


$cuenta_primera_vez=0;$pasounavez=0;
$array_abonos	=premios_puntos_abonos_porrut($rut, $id_empresa);
$gastado		=premios_puntos_gastados_porrut($rut, $id_empresa);
if($gastado==""){$gastado=0;}
foreach ($array_abonos as $unico){



	$recibido_acumulado=$unico->puntos+$recibido_acumulado;
	$saldo_relativo=$recibido_acumulado-$gastado;
	//echo "<br>saldo relativo $saldo_relativo, gastado $gastado, acumulado recibido $recibido_acumulado,  recibido ".$unico->puntos." fecha ".$unico->fecha;
	
	
	if($saldo_relativo>0){
		$cuenta_primera_vez++;
		$puntos_a_vencer=$saldo_relativo;
		$fecha_a_vencer=$unico->fecha;
		
	if($cuenta_primera_vez==1){
		//echo "RESULTADO FINAL $puntos_a_vencer el $fecha_a_vencer";
		$puntos_a_vencer_final=$puntos_a_vencer;
		$fecha_a_vencer_final_comparacion=$fecha_a_vencer;
		$fecha_a_vencer_final_str= strtotime('+ 1 year', $fecha_a_vencer);
		$fecha_a_vencer_final=date('Y-m-d', $fecha_a_vencer_final_str);

$date = strtotime(date("Y-m-d", strtotime($fecha_a_vencer)) . " +12 month");
$fecha_a_vencer_final = date("Y-m-d",$date);
		;
		$pasounavez++;
		
	}	
	
	//echo "<br>paso una vez $pasounavez<br>";
	if($fecha_a_vencer_final_comparacion==$unico->fecha and $cuenta_primera_vez==2){
		$pasounavez++;
		//echo "misma fecha anterior ".$fecha_a_vencer_final_comparacion." saldo ".$puntos_a_vencer;
		$puntos_a_vencer_final=$puntos_a_vencer;
		//echo "<br>RESULTADO FINAL $puntos_a_vencer el $fecha_a_vencer, final $puntos_a_vencer_final";


	}
	
	
		
	}
	
	
	
	//$saldo_relativo=
	
	
}


$date = new DateTime($fecha_a_vencer_final); // For today/now, don't pass an arg.
$fecha_final_menos=$date->modify("-1 day");

//echo "<br>ARREGLO FINAL $puntos_a_vencer_final el $fecha_a_vencer_final, final_dia_menos $final_dia_menos";


$arreglo[0]=$puntos_a_vencer_final;
$arreglo[1]=$fecha_a_vencer_final;

return $arreglo;

}
function premios_puntos_a_vencer_2020($rut, $id_empresa) {
					$Puntos_Vencer=Premios_puntos_a_vencer_2020_data($rut, $id_empresa);
					return $Puntos_Vencer;
}
function FechaaNombredia($date){

//Convert the date string into a unix timestamp.
$unixTimestamp = strtotime($date);
//Get the day of the week using PHP's date function.
$dayOfWeek = date("l", $unixTimestamp);
//Print out the day that our date fell on.
//echo $date . ' fell on a ' . $dayOfWeek;


if($dayOfWeek=="Sunday")    {$dia="DO";}
if($dayOfWeek=="Monday")    {$dia="LU";}
if($dayOfWeek=="Tuesday")    {$dia="MA";}
if($dayOfWeek=="Wednesday")    {$dia="MI";}
if($dayOfWeek=="Thursday")    {$dia="JU";}
if($dayOfWeek=="Friday")    {$dia="VI";}
if($dayOfWeek=="Saturday")    {$dia="SA";}


        return $dia;

}
function VerificaArregloSQLInjection($arreglo)
{
    //print_R($arreglo);
    //echo "aca";
    $flag          = "Todo Bien";
    //veo si es un arreglo
    $total_arreglo = count($arreglo);

    foreach ($arreglo as $clave => $valor) {
        //echo "El valor de $clave es: $valor<br><br>";
        //lo paso por la tabla de sql_injection
        if (strtoupper(trim($valor)) == "") {
            continue;
        }
        $valor = str_replace("'", "", $valor);
        $valor = str_replace('"', "", $valor);
        $valor = str_replace("+'", "", $valor);
        $valor = str_replace('--', "", $valor);





        $palabra_injection = buscaPalabraSqlInjection(strtoupper(trim($valor)));
        if ($palabra_injection) {
            //echo "<br><span class='badge_small badge-azul'> SQL INJECTION</span><br>";
            //echo $arreglo[$clave];
            $arreglo[$clave] = "";
            //echo "variable limpiada ".$arreglo[$clave]." <- <br>";
            //exit;
        } else {
            //Ahora traigo todas las palabras de la tabla, y las busco si estan, s
            $palabras = TraePalabraSqlInjection();
            foreach ($palabras as $pal) {
                $arreglo[$clave] = str_replace($pal->palabra, "", $arreglo[$clave]);
                $arreglo[$clave] = str_replace(strtoupper($pal->palabra), "", $arreglo[$clave]);
                $arreglo[$clave] = str_replace(strtolower($pal->palabra), "", $arreglo[$clave]);
            }
            //echo "<br>";
        }
    }
    exit;
    return ($arreglo);
}
function fechaCastellano2($fecha){
	
$fecha = substr($fecha, 0, 10);
  $numeroDia = date('d', strtotime($fecha));
  $dia = date('l', strtotime($fecha));
  $mes = date('F', strtotime($fecha));
  $anio = date('Y', strtotime($fecha));
  $dias_ES = array("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");
  $dias_EN = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
  $nombredia = str_replace($dias_EN, $dias_ES, $dia);
$meses_ES = array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
  $meses_EN = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
  $nombreMes = str_replace($meses_EN, $meses_ES, $mes);
  return $nombredia." ".$numeroDia." de ".$nombreMes." de ".$anio;	
	
}
function fechaCastellano($fecha)
{
    $fecha     = substr($fecha, 0, 10);
    $numeroDia = date('d', strtotime($fecha));
    $dia       = date('l', strtotime($fecha));
    $mes       = date('F', strtotime($fecha));
    $anio      = date('Y', strtotime($fecha));
    $dias_ES   = array(
        "Lunes",
        "Martes",
        "Miércoles",
        "Jueves",
        "Viernes",
        "Sábado",
        "Domingo"
    );
    $dias_EN   = array(
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
    );
    $nombredia = str_replace($dias_EN, $dias_ES, $dia);
    $meses_ES  = array(
    "Enero",
        "Febrero",
        "Marzo",
        "Abril",
        "Mayo",
        "Junio",
        "Julio",
        "Agosto",
        "Septiembre",
        "Octubre",
        "Noviembre",
        "Diciembre"
    );
    $meses_EN  = array(
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    );
    $nombreMes = str_replace($meses_EN, $meses_ES, $mes);
    return $fecha;
    //return $nombredia . " " . $numeroDia . " de " . $nombreMes . " de " . $anio;
}
function buscaarrobadomain($texto, $id_mp, $rut, $id_empresa)
{
   // echo "<br>texto $texto";
    $porciones = explode("@", $texto);
   // print_R($porciones);   sleep(2);

    for ($i = 0; $i < count($porciones); $i++) {
           //echo   "<br>porciones ".$porciones[$i];
            $texto=str_replace(' ', '_', $texto);
            $texto=str_replace(',', '_', $texto);
            $texto=str_replace(';', '_', $texto);
            $texto=str_replace('-', '_', $texto);
            $texto=str_replace('_', '_', $texto);
                    $porcionesX = explode("_", $texto);
                    for ($j = 0; $j < count($porcionesX); $j++) {
                     // echo   "<br>porciones X ".$porcionesX[$j];
                     if(substr( $porcionesX[$j], 0, 1 ) === "@"){
                       // echo $porcionesX[$j];

                       $arreglo[]= $porcionesX[$j];

                      }

                    }

                    //echo "<br> arreglo";



        }
    $i=0;
    $arreglo=(array_unique($arreglo));
    //print_r($arreglo);
    foreach ($arreglo as $unico){
       // echo "UNICO $unico";
      $tagueados[$i] = SaveMpTagPeople($unico, $id_mp, $rut, $id_empresa);
      $i++;
    }
                    // echo "<br>";sleep(4);


      // print_r($tagueados); exit();

        return $tagueados;
}
function FormularioPostPregunta($PRINCIPAL, $id_mp, $id_empresa)
{
    $unico = com_mp_full_data($id_empresa, $id_mp);
    if ($unico) {
        $PRINCIPAL = str_replace("{VALOR_BOTON}", "Editar Pregunta", $PRINCIPAL);
        $PRINCIPAL = str_replace("{ACTION}", "com_mp_edit_post_question", $PRINCIPAL);
        $PRINCIPAL = str_replace("{ID_MP}", Encodear3($id_mp), $PRINCIPAL);
    } else {
        $PRINCIPAL = str_replace("{VALOR_BOTON}", "Preguntar", $PRINCIPAL);
        $PRINCIPAL = str_replace("{ACTION}", "com_mp_save_post_question", $PRINCIPAL);
    }
    $PRINCIPAL          = str_replace("{TITULO}", ($unico[0]->nombre), $PRINCIPAL);
    $PRINCIPAL          = str_replace("{CONTENIDO}", ($unico[0]->contenido), $PRINCIPAL);
    $PRINCIPAL          = str_replace("{RESUMEN}", ($unico[0]->resumen), $PRINCIPAL);
    $contador           = 1;
    $categorias_mp      = TraeCategoriasMejoresPracticas($id_empresa);
    $options_categorias = "";
    foreach ($categorias_mp as $cat) {
        if ($unico[0]->id_categoria == $cat->id_categoria) {
            $options_categorias .= "<option value='" . $cat->id_categoria . "' selected='selected'>" . $cat->categoria . "</option>";
        } else {
            $options_categorias .= "<option value='" . $cat->id_categoria . "'>" . $cat->categoria . "</option>";
        }
    }
    $array_MP_template = MP_BuscaTemplate($rut, $id_empresa);
    if ($array_MP_template[0]->template <> '') {
        $template = $array_MP_template[0]->template . "";
    } else {
        $template = "";
    }
    $ambitos_mp      = TraeAmbitosMejoresPracticas($id_empresa, $template);
    $options_ambitos = "";
    $options_ambitos .= "<option value='' >[ SELECCIONA ]</option>";
    foreach ($ambitos_mp as $ambito) {
        if ($unico[0]->id_ambito == $ambito->id_ambito) {
            $options_ambitos .= "<option value='" . $ambito->id_ambito . "' selected='selected'>" . $ambito->ambito . "</option>";
        } else {
            $options_ambitos .= "<option value='" . $ambito->id_ambito . "'>" . $ambito->ambito . "</option>";
        }
    }
    $PRINCIPAL = str_replace("{CATEGORIAS}", ($options_categorias), $PRINCIPAL);
    $PRINCIPAL = str_replace("{AMBITOS}", ($options_ambitos), $PRINCIPAL);
    return ($PRINCIPAL);
}
function ColocaClasificacionesPrevia($PRINCIPAL, $id_empresa, $id_malla, $id_programa)
{
    $listado_clasificaciones = TraeClasificacionesPorEmpresaPrograma($id_empresa, $id_programa);
    foreach ($listado_clasificaciones as $list) {
        $row_listado .= file_get_contents("views/cursos/capacitacion/" . $id_empresa . "_row_avance_clasificacion_home_plan.html");
        $row_listado = str_replace("{TITULO}", $list->nombre_clasificacion, $row_listado);
        $row_listado = str_replace("{DESCRIPCION}", $list->descripcion_clasificacion, $row_listado);
        $row_listado = str_replace("{CLAS_IMG_NIVEL}", $list->imagen_clasificacion, $row_listado);
        $row_listado = str_replace("{ID_MALLA_ENCODEADA}", Encodear3($id_malla), $row_listado);
    }
    $PRINCIPAL = str_replace("{ROWS_LISTADO_CLASIFICACIONES}", ($row_listado), $PRINCIPAL);
    return ($PRINCIPAL);
}
function Com_Premios_ListadoPremios_RUT($rut, $id_empresa)
{
    $row_premio       = "";
    $traigoPremiosRut = traigoDimensionPremios_data_rut($rut, $id_empresa);
    //print_r($traigoPremiosRut);
    foreach ($traigoPremiosRut as $traigoPremioRut) {
        //print_r($traigoPremioRut);

        if($traigoPremioRut->id_premio=="bch_lolla2023"){
            //NUMERO DE CANJES
            $canjes_realizados=VerificaCanjeRutAnterior_2022_lolla($traigoPremioRut->id_premio, $rut, $id_empresa);
            $maximo=2;
            $badge_llevas_x_de_y="<span class='badge'>".$canjes_realizados." de m&aacute;ximo $maximo entradas reservadas</span> ";

            if($canjes_realizados>=2){
                $nno_disponible="<div class='alert alert-info' >Ya completaste tus 2 canjes permitidos</div> ";
                $row_premio_alrut .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_row_premios_al_rut_no_disponible.html");
            } else {
                $nno_disponible="";
                if($traigoPremioRut->id_premio=="bch_lolla2023"){
                    $row_premio_alrut .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_row_premios_al_rut_lolla.html");
                } else {
                    $row_premio_alrut .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_row_premios_al_rut.html");
                }
            }
        } else {
            $row_premio_alrut .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_row_premios_al_rut.html");

        }


        $row_premio_alrut = str_replace("{IMAGEN_BANNER_2023}", ($traigoPremioRut->imagen_banner_2023), $row_premio_alrut);


        $row_premio_alrut = str_replace("{LLEVAS_X_DE_Y}", ($badge_llevas_x_de_y), $row_premio_alrut);
        $row_premio_alrut = str_replace("{NO_DISPONIBLE}", ($nno_disponible), $row_premio_alrut);
        $row_premio_alrut = str_replace("{TITULO_PREMIO}", ($traigoPremioRut->premio), $row_premio_alrut);
        $row_premio_alrut = str_replace("{TITULO_PREMIOLUDICO}", ($traigoPremioRut->premioludico), $row_premio_alrut);
        $row_premio_alrut = str_replace("{DESCRIPCION_PREMIOLUDICO}", ($traigoPremioRut->premio_descripcion), $row_premio_alrut);
        $row_premio_alrut = str_replace("{NUM_PUNTOS}", ($traigoPremioRut->puntos), $row_premio_alrut);
        $row_premio_alrut = str_replace("{ID_PREMIO}", ($traigoPremioRut->id_premio), $row_premio_alrut);
        $row_premio_alrut = str_replace("{DESCRIPCION}", ($traigoPremioRut->descripcion), $row_premio_alrut);

        $row_premio_alrut = str_replace("{CONDICIONES}", ($traigoPremioRut->condiciones), $row_premio_alrut);
        $row_premio_alrut = str_replace("{REQUISITOS}", ($traigoPremioRut->requisitos), $row_premio_alrut);
        $row_premio_alrut = str_replace("{IDI_ENC}", Encodear3($traigoPremioRut->id_premio), $row_premio_alrut);
        $row_premio_alrut = str_replace("{IDM_ENC}", Encodear3($traigoPremioRut->id_dimension), $row_premio_alrut);

    }

    //echo "<br>-> $row_premio_alrut";
    //$row = str_replace("{ROW_PREMIOS}",$row_premio,$row);
    //print_r($row_premio);
    return $row_premio_alrut;
}
function Com_Premios_ListadoPremios($PRINCIPAL, $segmento, $id_empresa)
{
		$rut=$_SESSION["user_"];
		$Region=DatosRegionUsuario_($rut, $id_empresa);
		//echo "region $Region";
    $traigoDimensionPremios = traigoDimensionPremios_data($segmento, $id_empresa);
    //print_r($traigoDimensionPremios);
    foreach ($traigoDimensionPremios as $traigoDimensionPremio) {
       // print_r($traigoDimensionPremio);
       
       if($Region<>"13" and $traigoDimensionPremio->id_dimension=="bch_cont"){continue;}
       
        $row .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_row_dimensiones_premios.html");
        $row           = str_replace("{IMAGEN_DIMENSION}", $traigoDimensionPremio->foto, $row);
        $row           = str_replace("{ID_DIMENSION}", $traigoDimensionPremio->id_dimension, $row);
        $row           = str_replace("{ID_DIMENSION_ENCODEADA}", Encodear3($traigoDimensionPremio->id_dimension), $row);
        $row           = str_replace("{NOMBRE_DIMENSION}", $traigoDimensionPremio->dimension, $row);
        $row           = str_replace("{NUM_ITEMS_DIMENSION}", $traigoDimensionPremio->cuenta, $row);


        $traigoPremios = traigoPremios_data($segmento, $id_empresa, $traigoDimensionPremio->id_dimension);
        $row_premio    = "";
        foreach ($traigoPremios as $traigoPremio) {
            //if($traigoPremio->saldo<0){continue;}
            //print_r($traigoPremio);
            $row_premio .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_row_premios.html");
            $row_premio = str_replace("{TITULO_PREMIO}",        ($traigoPremio->premio), $row_premio);
            $row_premio = str_replace("{TITULO_PREMIOLUDICO}",  ($traigoPremio->premioludico), $row_premio);
            $row_premio = str_replace("{NUM_PUNTOS}",           ($traigoPremio->puntos), $row_premio);
            $row_premio = str_replace("{ID_PREMIO}",            ($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{CONDICIONES}",          ($traigoPremio->condiciones), $row_premio);
            $row_premio = str_replace("{REQUISITOS}",           ($traigoPremio->requisitos), $row_premio);
        }
        $row = str_replace("{ROW_PREMIOS}", $row_premio, $row);
    }
    $PRINCIPAL = str_replace("{LISTADO_PREMIOS}", $row, $PRINCIPAL);
    return $PRINCIPAL;
}
function Com_Premios_ListadoPremios_SinDimension_items($PRINCIPAL, $segmento, $id_empresa)
{
    $traigoDimensionPremios = traigoDimensionPremiosDimension_Item_Todos_data( $segmento, $id_empresa);

   foreach ($traigoDimensionPremios as $traigoDimensionPremio) {
        //print_r($traigoDimensionPremio);
        $row .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_Lista_Item_row_dimensiones_premios.html");
        $row           = str_replace("{IMAGEN_DIMENSION}", $traigoDimensionPremio->foto, $row);
        $row           = str_replace("{ID_DIMENSION}", $traigoDimensionPremio->id_dimension, $row);
        $row           = str_replace("{ID_DIMENSION_ENCODEADA}", Encodear3($traigoDimensionPremio->id_dimension), $row);
        $row           = str_replace("{NOMBRE_DIMENSION}", $traigoDimensionPremio->dimension, $row);

        $traigoPremios = traigoPremios_data($segmento, $id_empresa, $traigoDimensionPremio->id_dimension);
        $row_premio    = "";
        foreach ($traigoPremios as $traigoPremio) {
        //print_r($traigoPremio);

        $rut=$_SESSION["user_"];
        $exclusion=VerificaRutPremioExclusion($rut,$traigoPremio->id_premio, $id_empresa);

        if($exclusion>0){continue;}

        $estilo_imagen=" ";
        // echo "<br>premio ".$traigoPremio->id_premio." Saldo ".$traigoPremio->saldo." ultimas ".$traigoPremio->alertaultimasunidades."";

        $stock_txt="";
    
    if($traigoPremio->stock<=$traigoPremio->alertaultimasunidades){
 
        		$stock_txt="<span class='badge badge-warning'><span class='blanco'><i class='fab fa-hotjar'></i>
						Quedan sólo ".$traigoPremio->saldo." disponibles </span> </span>";
        }

            if($traigoPremio->stock==0 and $traigoPremio->temporalidad==''){

                   if($traigoPremio->stock==0){
                    $stock_txt="<span class='badge badge-warning'><span class='blanco'>
                    Canje suspendido temporalmente</span> </span>";
                   } else {
                    $stock_txt="<span class='badge badge-danger'><span class='blanco'>
                    Sin stock disponible</span> </span>";
                   }
                   
                   $estilo_imagen=" img_bn_grasycale ";
                   
            }
                if($traigoPremio->stock==0 and $traigoPremio->temporalidad=='SI'){
                    continue;
            }



            $row_premio .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_Lista_Item_row_premios.html");

            $row_premio = str_replace("{ID_PREMIO_ENCODEADO}", Encodear3($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{ID_DIMENSION_ENCODEADO}", Encodear3($iddim), $row_premio);

            $row_premio = str_replace("{TITULO_PREMIO}", ($traigoPremio->premio), $row_premio);
            $row_premio = str_replace("{TITULO_PREMIOLUDICO}", ($traigoPremio->premioludico), $row_premio);

            $row_premio = str_replace("{DESCRIPCION_PREMIO}",resumir(($traigoPremio->premio_descripcion), 80," ", "..."), $row_premio);

            $row_premio = str_replace("{NUM_PUNTOS}", ($traigoPremio->puntos), $row_premio);
            $row_premio = str_replace("{ID_PREMIO}", ($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{CONDICIONES}", ($traigoPremio->condiciones), $row_premio);
            $row_premio = str_replace("{REQUISITOS}", ($traigoPremio->requisitos), $row_premio);
            $row_premio = str_replace("{ICONO}", ($traigoPremio->premio_icono), $row_premio);
            $row_premio = str_replace("{IMAGEN}", ($traigoPremio->imagen), $row_premio);

            $row_premio = str_replace("{ESTILO_IMAGEN}", $estilo_imagen, $row_premio);


            $row_premio = str_replace("{PUNTOS}", ($traigoPremio->puntos), $row_premio);
            $row_premio = str_replace("{STOCK}", $stock_txt, $row_premio);



     }

        $row = str_replace("{ROW_PREMIOS}", $row_premio, $row);
    }
    $PRINCIPAL = str_replace("{LISTADO_DIMENSION_PREMIOS_ITEMS}", $row, $PRINCIPAL);
    return $PRINCIPAL;
}
function devuelveNombreMes($numero_mes)
{
    if ($numero_mes == "1") {
        return ("Enero");
    } else if ($numero_mes == "2") {
        return ("Febrero");
    } else if ($numero_mes == "3") {
        return ("Marzo");
    } else if ($numero_mes == "4") {
        return ("Abril");
    } else if ($numero_mes == "5") {
        return ("Mayo");
    } else if ($numero_mes == "6") {
        return ("Junio");
    } else if ($numero_mes == "7") {
        return ("Julio");
    } else if ($numero_mes == "8") {
        return ("Agosto");
    } else if ($numero_mes == "9") {
        return ("Septiembre");
    } else if ($numero_mes == "10") {
        return ("Octubre");
    } else if ($numero_mes == "11") {
        return ("Noviembre");
    } else if ($numero_mes == "12") {
        return ("Diciembre");
    }
}


function SendGrid_Email_admin_v2($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,
                              $texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url2, $tipomensaje, $rut, $key, $otro_template)
{
    /*echo "<h1>Funcion Front SendGrid_Email_admin<h1>";
    echo"<br>to $to, nombre $nombreto, fropm $from, nombrefrom $nombrefrom, tipo $tipo, subject $subject, titulo1 $titulo1, subtitulo1 $subtitulo1, texto1 $texto1, url $url,
    texto_url $texto_url,texto2  $texto2,texto3 $texto3, texto4 $texto4,logo $logo,id_empresa $id_empresa,url $url, tipomensaje $tipomensaje, rut $rut,key  $key, otro_template $otro_template<br>";
    */
   

    if($tipo==""){$tipo="text/html";}

    $id_empresa="78";

    $message = file_get_contents("../front/views/emails_notificaciones/78_template_notificacion_mc.html");
    //echo "<br>mensaje<br><br>$message";
    //echo "<br>https://www.bancodepuntosbch.cl/front/views/emails_notificaciones/78_template_notificacion.html";
    //print_r($message);

    $message = str_replace("{TITULO1}", $titulo1, $message);
    $message = str_replace("{SUBTITULO1}", $subtitulo1, $message);
    $message = str_replace("{TEXTO1}", $texto1, $message);
    $message = str_replace("{URL}", $url, $message);
    $message = str_replace("{TEXTO_URL}", $texto_url, $message);
    $message = str_replace("{TEXTO2}", $texto2, $message);
    $message = str_replace("{TEXTO3}", $texto3, $message);
    $message = str_replace("{TEXTO4}", $texto4, $message);
    $message = str_replace("{LOGO}", $logo, $message);
    $tipo="text/html";
    require("script/sendgrid-php/sendgrid-php.php");
    global $from_2022,$nombrefrom_2022,$api_key_2022;
    $nombrefrom_2022="Mas Conectados Bch";
    $from_2022="notificaciones@masconectadosbch.cl";
    $from       = new SendGrid\Email($nombrefrom_2022, $from_2022);
    $to         = new SendGrid\Email($nombreto, $to);
    $content    = new SendGrid\Content($tipo, $message);
    $mail       = new SendGrid\Mail($from, $subject, $to, $content);
    $apiKey     = $api_key_2022;
    $sg         = new \SendGrid($apiKey);
    $response   = $sg->client->mail()->send()->post($mail);

    $statuscode = $response->statusCode();
    $headers    = $response->headers();
    $body       = $response->body();
    $fecha      = date("Y-m-d");

    //echo "<br><br>statuscode_";    print_r($statuscode);   echo "<br><br>headers_";    print_r($headers);    echo "<br><br>body_";    print_r($body);exit();

    SaveLogEmails($id_empresa, $tipo, $subject, $to, $nombreto, $fecha, $statuscode, $headers, $body, $tipomensaje, $rut, $key);
}

function SendGrid_Email_admin($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,
$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url2, $tipomensaje, $rut, $key, $otro_template)
{

/*echo "<h1>Funcion Front SendGrid_Email_admin<h1>";
echo"<br>to $to, nombre $nombreto, fropm $from, nombrefrom $nombrefrom, tipo $tipo, subject $subject, titulo1 $titulo1, subtitulo1 $subtitulo1, texto1 $texto1, url $url,
texto_url $texto_url,texto2  $texto2,texto3 $texto3, texto4 $texto4,logo $logo,id_empresa $id_empresa,url $url, tipomensaje $tipomensaje, rut $rut,key  $key, otro_template $otro_template<br>";
*/

if($tipo==""){$tipo="text/html";}


$id_empresa="78";
  /*echo "<br>otro template ".$otro_template." id empresa $id_empresa
  <br>
  $to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,
	$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template";*/

/*
$to="rod@gop.cl";
$nombreto="name";
$titulo1="c";
 $subtitulo1="e";
$subject="b";
  $texto1="aaa";      
 $texto2="a";
 $texto3="a";
 $texto4="a";
 $logo="a";
 $texto_url="a";
 $url="url";

$nombrefrom="ppp";
 $from="go@gcloud.cl";*/
  /*
    echo "<br>SendGrid_Email<br>
     <br>to $to,
     <br>nombreto $nombreto,
     <br>from $from, <br>nombrefrom $nombrefrom,
     <br> tipo $tipo,<br>
     subject $subject,<br> titulo1 $titulo1,
     <br> subtitulo1 $subtitulo1,<br>texto1 $texto1,<br>url $url,<br>txto url $texto_url,
     <br>texto2 $texto2, <br>texto3 $texto3, <br>texto4 $texto4, <br>logo $logo, <br>id_empresa $id_empresa, <br>url $url, <br>tipomensaje $tipomensaje,<br>    rut $rut,

";
*/
	    $message = file_get_contents("../front/views/emails_notificaciones/78_template_notificacion.html");
			//echo "<br>mensaje<br><br>$message"; 
			//echo "<br>https://www.bancodepuntosbch.cl/front/views/emails_notificaciones/78_template_notificacion.html";
			//print_r($message);

    $message = str_replace("{TITULO1}", $titulo1, $message);
    $message = str_replace("{SUBTITULO1}", $subtitulo1, $message);
    $message = str_replace("{TEXTO1}", $texto1, $message);
    $message = str_replace("{URL}", $url, $message);
    $message = str_replace("{TEXTO_URL}", $texto_url, $message);
    $message = str_replace("{TEXTO2}", $texto2, $message);
    $message = str_replace("{TEXTO3}", $texto3, $message);
    $message = str_replace("{TEXTO4}", $texto4, $message);
    $message = str_replace("{LOGO}", $logo, $message);
		$tipo="text/html";
    require("script/sendgrid-php/sendgrid-php.php");
    global $from_2022,$nombrefrom_2022,$api_key_2022;
    $from       = new SendGrid\Email($nombrefrom_2022, $from_2022);
    $to         = new SendGrid\Email($nombreto, $to);
    $content    = new SendGrid\Content($tipo, $message);
    $mail       = new SendGrid\Mail($from, $subject, $to, $content);
    $apiKey     = $api_key_2022;
    $sg         = new \SendGrid($apiKey);
    $response   = $sg->client->mail()->send()->post($mail);

    $statuscode = $response->statusCode();
    $headers    = $response->headers();
    $body       = $response->body();
    $fecha      = date("Y-m-d");
		
		//echo "<br><br>statuscode_";    print_r($statuscode);   echo "<br><br>headers_";    print_r($headers);    echo "<br><br>body_";    print_r($body);exit();

SaveLogEmails($id_empresa, $tipo, $subject, $to, $nombreto, $fecha, $statuscode, $headers, $body, $tipomensaje, $rut, $key);
}
function SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,
$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url2, $tipomensaje, $rut, $key, $otro_template)
{


 if($tipo==""){$tipo="text/html";}


$id_empresa="78";
  /*echo "<br>otro template ".$otro_template." id empresa $id_empresa";
  echo "<br>$to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,
$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template";

/*
$to="rod@gop.cl";
$nombreto="name";
$titulo1="c";
 $subtitulo1="e";
$subject="b";
  $texto1="aaa";      
 $texto2="a";
 $texto3="a";
 $texto4="a";
 $logo="a";
 $texto_url="a";
 $url="url";

$nombrefrom="ppp";
 $from="go@gcloud.cl";*/
  /*
    echo "<br>SendGrid_Email<br>
     <br>to $to,
     <br>nombreto $nombreto,
     <br>from $from, <br>nombrefrom $nombrefrom,
     <br> tipo $tipo,<br>
     subject $subject,<br> titulo1 $titulo1,
     <br> subtitulo1 $subtitulo1,<br>texto1 $texto1,<br>url $url,<br>txto url $texto_url,
     <br>texto2 $texto2, <br>texto3 $texto3, <br>texto4 $texto4, <br>logo $logo, <br>id_empresa $id_empresa, <br>url $url, <br>tipomensaje $tipomensaje,<br>    rut $rut,

";
*/
	    $message = file_get_contents("views/emails_notificaciones/78_template_notificacion.html");

/*
echo "<br>mensaje<br><br>$message"; 
print_r($message);
*/
    $message = str_replace("{TITULO1}", $titulo1, $message);
    $message = str_replace("{SUBTITULO1}", $subtitulo1, $message);
    $message = str_replace("{TEXTO1}", $texto1, $message);
    $message = str_replace("{URL}", $url, $message);
    $message = str_replace("{TEXTO_URL}", $texto_url, $message);
    $message = str_replace("{TEXTO2}", $texto2, $message);
    $message = str_replace("{TEXTO3}", $texto3, $message);
    $message = str_replace("{TEXTO4}", $texto4, $message);
    $message = str_replace("{LOGO}", $logo, $message);
		$tipo="text/html";
    require("script/sendgrid-php/sendgrid-php.php");
    global $from_2022,$nombrefrom_2022,$api_key_2022;
    $from       = new SendGrid\Email($nombrefrom_2022, $from_2022);
    $to         = new SendGrid\Email($nombreto, $to);
    $content    = new SendGrid\Content($tipo, $message);
    $mail       = new SendGrid\Mail($from, $subject, $to, $content);
   $apiKey     = $api_key_2022;
    $sg         = new \SendGrid($apiKey);
    $response   = $sg->client->mail()->send()->post($mail);

    $statuscode = $response->statusCode();
    $headers    = $response->headers();
    $body       = $response->body();
    $fecha      = date("Y-m-d");/*
echo "<br><br>statuscode_";    print_r($statuscode);   echo "<br><br>headers_";    print_r($headers);    echo "<br><br>body_";    print_r($body); sleep(10);

exit();*/

SaveLogEmails($id_empresa, $tipo, $subject, $to, $nombreto, $fecha, $statuscode, $headers, $body, $tipomensaje, $rut, $key);
}
function SendGrid_Email_template($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url, $texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url2, $tipomensaje, $rut, $key, $template)
{

      if($id_empresa==""){ $id_empresa = $_SESSION["id_empresa"];}

    //$to="rod@gop.cl";

// echo "<br>SendGrid_Email_template<br><br>to $to, nombre $nombreto, from $from, nombre $nombrefrom, tipo $tipo,<br>
// subject $subject, titulo1 $titulo1, subtitulo1 $subtitulo1, t1 $texto1,url $url, texto url $texto_url, texto2 $texto2,
// texto3 $texto3, texto4 $texto4,
// logo $logo, idempresa $id_empresa, url $url, tipomensaje $tipomensaje, rut $rut, key $key template $template";
 //echo "<br>";    echo "https://".$_SERVER['SERVER_NAME']."/front/views/emails_notificaciones/".$id_empresa."_template_notificacion.html";    echo "<br>";

    $message = file_get_contents("".$template."");
    //echo "<br>message url $message";
    $message = str_replace("{TITULO1}", $titulo1, $message);
    $message = str_replace("{SUBTITULO1}", $subtitulo1, $message);
    $message = str_replace("{TEXTO1}", $texto1, $message);
    $message = str_replace("{URL}", $url, $message);
    $message = str_replace("{TEXTO_URL}", $texto_url, $message);
    $message = str_replace("{TEXTO2}", $texto2, $message);
    $message = str_replace("{TEXTO3}", $texto3, $message);
    $message = str_replace("{TEXTO4}", $texto4, $message);
    $message = str_replace("{LOGO}", $logo, $message);

    require("script/sendgrid-php/sendgrid-php.php");
    global $from_2022,$nombrefrom_2022,$api_key_2022;
    $from       = new SendGrid\Email($nombrefrom_2022, $from_2022);
    $to         = new SendGrid\Email($nombreto, $to);
    $content    = new SendGrid\Content($tipo, $message);
    $mail       = new SendGrid\Mail($from, $subject, $to, $content);
    $apiKey     = $api_key_2022;
    $sg         = new \SendGrid($apiKey);
    $response   = $sg->client->mail()->send()->post($mail);
    $statuscode = $response->statusCode();
    $headers    = $response->headers();
    $body       = $response->body();
    $fecha      = date("Y-m-d");

    //echo "<br><br>statuscode_";    print_r($statuscode);   echo "<br><br>headers_";    print_r($headers);    echo "<br><br>body_";    print_r($body); sleep(10);
    SaveLogEmails($id_empresa, $tipo, $subject, $to, $nombreto, $fecha, $statuscode, $headers, $body, $tipomensaje, $rut, $key);
}
function SendGrid_Email_Gcloud($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url, $texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url2, $tipomensaje, $rut, $key)
{

    //echo "ro $to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1,$subtitulo1,$texto1,$url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url,$tipomensaje, $rut, $key";
    $message = file_get_contents("https://gcloud.cl/front/views/emails_notificaciones/gcloud_template_notificacion.html");
    //$message =file_get_contents("views/emails_notificaciones/gcloud_template_notificacion.html");
    $message = str_replace("{TITULO1}", $titulo1, $message);
    $message = str_replace("{SUBTITULO1}", $subtitulo1, $message);
    $message = str_replace("{TEXTO1}", $texto1, $message);
    $message = str_replace("{URL}", $url, $message);
    $message = str_replace("{TEXTO_URL}", $texto_url, $message);
    $message = str_replace("{TEXTO2}", $texto2, $message);
    $message = str_replace("{TEXTO3}", $texto3, $message);
    $message = str_replace("{TEXTO4}", $texto4, $message);
    $message = str_replace("{LOGO}", $logo, $message);
    require("script/sendgrid-php/sendgrid-php.php");

    global $from_2022,$nombrefrom_2022,$api_key_2022;
    $from       = new SendGrid\Email($nombrefrom_2022, $from_2022);
    $to         = new SendGrid\Email($nombreto, $to);
    $content    = new SendGrid\Content($tipo, $message);
    $mail       = new SendGrid\Mail($from, $subject, $to, $content);
    $apiKey     = $api_key_2022;
    $sg         = new \SendGrid($apiKey);
    $response   = $sg->client->mail()->send()->post($mail);
    //echo "$message";
    $statuscode = $response->statusCode();
    $headers    = $response->headers();
    $body       = $response->body();
    $fecha      = date("Y-m-d");
    //echo "<br><br>statuscode_";
    //print_r($statuscode);
    //echo "<br><br>headers_";
    //print_r($headers);
    //echo "<br><br>tipo_";
    //print_r($tipo);
    //echo "<br><br>body_";
    //print_r($body);
    sleep(3);
    SaveLogEmails($id_empresa, $tipo, $subject, $to, $nombreto, $fecha, $statuscode, $headers, $body, $tipomensaje, $rut, $key);
}
function ValidarSesion($ambiente, $id_empresas, $url_front)
{
    //print_r($_SESSION);
    //sleep(5);
    if ($_SESSION["user_"]) {
        //Tiene session
        //Veo si el usuario esta en la base
        $existe_usuario_en_la_base = $datos_usuario = UsuarioEnBasePersonas($_SESSION["user_"]);

        if (!$existe_usuario_en_la_base) {
            $PRINCIPAL = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login.html"));
            $token_fecha_hora = Encodear3(date("Y-m-d") . " " . date("H:i:s"));

            // Sanitize the token before including it in the output
            $token_fecha_hora = htmlspecialchars($token_fecha_hora, ENT_QUOTES, 'UTF-8');

            $PRINCIPAL = str_replace("{TOKEN_FECHA_HORA}", $token_fecha_hora, $PRINCIPAL);
            session_start();

            // Sanitize the session token before storing it
            $_SESSION["token"] = htmlspecialchars($token_fecha_hora, ENT_QUOTES, 'UTF-8');

            echo $PRINCIPAL;
            exit;
        } else {
            if ($existe_usuario_en_la_base[0]->vigencia == "1") {
                $PRINCIPAL = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login.html"));
                $token_fecha_hora = Encodear3(date("Y-m-d") . " " . date("H:i:s"));

                // Sanitize the token before including it in the output
                $token_fecha_hora = htmlspecialchars($token_fecha_hora, ENT_QUOTES, 'UTF-8');

                $PRINCIPAL = str_replace("{TOKEN_FECHA_HORA}", $token_fecha_hora, $PRINCIPAL);
                session_start();

                // Sanitize the session token before storing it
                $_SESSION["token"] = htmlspecialchars($token_fecha_hora, ENT_QUOTES, 'UTF-8');

                echo $PRINCIPAL;
                exit;
            }
        }




        if ($ambiente == "detnot") {
            InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, Decodear($_GET["id"]), "", "", "", "");
        } else if ($ambiente == "GuardaLogVideoVisto") {
            InsertaLogSistema($_SESSION["user_"], $ambiente . "_" . $_POST["tipo_video"], $id_empresas, "", "", "", "", "");
        } else if ($ambiente == "veperfil") {
            $rut = $_POST["buscarRut"];
            if (!$rut) {
                $rut = Decodear3($_GET["r"]);
            }
            InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, $rut, "", "", "", "");
        } else if ($ambiente == "biblioteca") {
            InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, $_GET["id"], $_GET["p"], "", "", "");
        } else if ($ambiente == "detalle_cursoCap") {
            InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, Decodear3($_GET["idc"]), "", "", "", "");
        } else if ($ambiente == "contenido") {
            InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, Decodear3($_GET["i"]), "", "", "", "");
        } else if ($ambiente == "web") {
            //InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, "", "", $_GET["i"], $_GET["i"], $_GET["niv"]);
            InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, $_GET["id"], $_GET["p"], "", ($_GET["niv"]), Decodear3($_GET["i"]));
        } else {
            InsertaLogSistema($_SESSION["user_"], $ambiente, $id_empresas, "", "", "", "", "");
        }
    } else {
        if ($ambiente <> "CreateNewUser" && $ambiente <> "logsso"&& $ambiente <> "LogEmail" && $ambiente <> "entrada_inscripcion"  && $ambiente <> "entrada" && $ambiente <> "entradaCap" && $ambiente <> "logexternos" && $ambiente <> "entrada_matriz_externos" && $ambiente <> "prevCa" && $ambiente <> "entradacl" && $ambiente <> "entradaclg" && $ambiente <> "ext_Desk" && $ambiente <> "prevCa" && $ambiente <> "registerac" && $ambiente <> 'chpex' && $ambiente <> 'listMejIVPH' && $ambiente <> "homeEncuesta"
            && $ambiente <> "entrada_token" && $ambiente <> "entrada_token_web"  && $ambiente <> "autoLoginRel" && $ambiente <> "SF" && $ambiente <> "go_save_data_ext" && $ambiente <> "RegistraRelator" && $ambiente <> "checkUser" && $ambiente <> "checkUserLosAndes" && $ambiente <> "checkUserTaylor" && $ambiente <> "checkUserExt" && $ambiente <> "checkUserExterno" && $ambiente <> "checkUserBci" && $ambiente <> "CheckValRec" && $ambiente <> "regis" && $ambiente <> "oco" && $ambiente <> "entradac" && $ambiente <> "sendSolicitud" && $ambiente <> "sendClave" && $ambiente <> "iex") {
            if ($ambiente == "logwatts") {
                $PRINCIPAL = FuncionesTransversales(file_get_contents("views/home/login.html"));
                echo $PRINCIPAL;
                exit;
            }
            else if ($ambiente == "login_ext") {
                // Unset and destroy the session to ensure a clean start
                session_start();
                session_unset();
                session_destroy();

                // Clear session cookies
                if (isset($_COOKIE[session_name()])) {
                    setcookie(session_name(), '', time() - 42000, '/');
                }

                // Sanitize the $_GET variables before using them
                $ambiente = htmlspecialchars($_GET["ambiente"], ENT_QUOTES, 'UTF-8');
                $im = htmlspecialchars($_GET["im"], ENT_QUOTES, 'UTF-8');
                $id_mp = htmlspecialchars($_GET["id_mp"], ENT_QUOTES, 'UTF-8');
                $sess = htmlspecialchars($_GET["sess"], ENT_QUOTES, 'UTF-8');

                // Load the content from the file and apply necessary replacements
                $PRINCIPAL = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login_ext.html"));
                $PRINCIPAL = str_replace("{AMBIENTE}", $ambiente, $PRINCIPAL);
                $PRINCIPAL = str_replace("{IM}", $im, $PRINCIPAL);
                $PRINCIPAL = str_replace("{ID_MP}", $id_mp, $PRINCIPAL);
                $PRINCIPAL = str_replace("{SESS}", $sess, $PRINCIPAL);

                echo $PRINCIPAL;
            }


            else if ($ambiente == "login_externo") {
                // Unset and destroy the session to ensure a clean start
                session_start();
                session_unset();
                session_destroy();

                // Clear session cookies
                if (isset($_COOKIE[session_name()])) {
                    setcookie(session_name(), '', time() - 42000, '/');
                }

                // Sanitize the $_GET variables before using them
                $ambiente = htmlspecialchars($_GET["ambiente"], ENT_QUOTES, 'UTF-8');
                $im = htmlspecialchars($_GET["im"], ENT_QUOTES, 'UTF-8');
                $id_mp = htmlspecialchars($_GET["id_mp"], ENT_QUOTES, 'UTF-8');
                $amb = htmlspecialchars($_GET["amb"], ENT_QUOTES, 'UTF-8');
                $idcat = htmlspecialchars($_GET["idcat"], ENT_QUOTES, 'UTF-8');
                $idc = htmlspecialchars($_GET["idc"], ENT_QUOTES, 'UTF-8');
                $site = htmlspecialchars($_GET["site"], ENT_QUOTES, 'UTF-8');
                $linkext = htmlspecialchars($_GET["linkext"], ENT_QUOTES, 'UTF-8');

                // Load the content from the file and apply necessary replacements
                $PRINCIPAL = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login_externo.html"));
                $PRINCIPAL = str_replace("{AMBIENTE}", $ambiente, $PRINCIPAL);
                $PRINCIPAL = str_replace("{IM}", $im, $PRINCIPAL);
                $PRINCIPAL = str_replace("{ID_MP}", $id_mp, $PRINCIPAL);
                $PRINCIPAL = str_replace("{AMB}", $amb, $PRINCIPAL);
                $PRINCIPAL = str_replace("{IDCAT}", $idcat, $PRINCIPAL);
                $PRINCIPAL = str_replace("{IDC}", $idc, $PRINCIPAL);
                $PRINCIPAL = str_replace("{SITE}", $site, $PRINCIPAL);
                $PRINCIPAL = str_replace("{LINKEXT}", $linkext, $PRINCIPAL);

                echo utf8_encode($PRINCIPAL);
            }

             else if ($ambiente == "log_imperial") {
                $PRINCIPAL = FuncionesTransversales(file_get_contents(""));
                echo $PRINCIPAL;
                exit;
            } else {
                //echo "aca";
                session_start();
                $_SESSION = array();
                if (isset($_COOKIE[session_name()])) {
                    setcookie(session_name(), '', time() - 42000, '/');
                }
                session_destroy();
                $PRINCIPAL        = FuncionesTransversales(file_get_contents("" . $url_front . "/front/views/home/login.html"));
                $token_fecha_hora = Encodear3(date("Y-m-d") . " " . date("H:i:s"));
                $PRINCIPAL        = str_replace("{TOKEN_FECHA_HORA}", $token_fecha_hora, $PRINCIPAL);
                session_start();
                $_SESSION["token"] = $token_fecha_hora;
                echo $PRINCIPAL;
                exit;
            }
        } else {
        }
    }
}
function FuncionesTransversales($html)
{
    $environment_sw               = $_GET["sw"];
    $rut                          = $_SESSION["user_"];
    $datos_empresa                = DatosEmpresa($_SESSION["id_empresa"]);
    $rut_sesion                   = $_SESSION["user_"];
    $id_empresa                   = $_SESSION["id_empresa"];
    $datos_usuario                = UsuarioEnBasePersonas($rut_sesion, "");
    //print_r($datos_usuario);
    $html                         = str_replace("{FECHAHOY}", formatearFechaCompleta(date("Y-m-d")), $html);
    $html                         = str_replace("{NOMBRE_USUARIO}", $datos_usuario[0]->nombre_completo, $html);
    $html                         = str_replace("{RUT_USUARIO_LOGUEADO}", $datos_usuario[0]->rut, $html);
    $id_tema                      = $_SESSION["tema"];
    $rand                         = rand(1, 4);
    $html = str_replace("{RANDOM}", $rand , $html);
    $html = str_replace("{MENU_SUPERIOR}", file_get_contents("views/menu/menu_superior.html"), $html);
    $html = str_replace("{IMAGEN_BANNER_FORM_CONTRATO}", $datos_empresa[0]->imagen_banner_form_contacto, $html);
    if ($datos_empresa[0]->template_footer) {
        $html = str_replace("{BLOQUEFOOTERCONTENIDO}", file_get_contents("views/footer_contenido/" . $datos_empresa[0]->template_footer . ""), $html);
    } else {
        $html = str_replace("{BLOQUEFOOTERCONTENIDO}", "", $html);
    }
    $html = str_replace("{IMAGEN_BANNER_FORM_CONTRATO}", $datos_empresa[0]->imagen_banner_form_contacto, $html);
    //MENU INFERIOR
    if ($datos_empresa[0]->template_menu_inferior) {
        $html = str_replace("{MENU_INFERIOR}", file_get_contents("views/menu/" . $datos_empresa[0]->template_menu_inferior . ""), $html);
    } else {
        $html = str_replace("{MENU_INFERIOR}", file_get_contents("views/menu/menu_inferior.html"), $html);
    }
    $html                  = str_replace("{FOOTER}", file_get_contents("views/footer.html"), $html);
    $datos_empresa_holding = DatosEmpresaHolding($datos_usuario[0]->nombre_empresa_holding);
    $html   = str_replace("{HEAD}", file_get_contents("views/head.html"), $html);
    $html   = str_replace("{HEAD_DINAMICO}",     file_get_contents("views/head/" . $id_empresa . "_head.html"), $html);
    $html   = str_replace("{MENU_DINAMICO}",     file_get_contents("views/menu/" . $id_empresa . "_menu_principal.html"), $html);
    $html   = str_replace("{FOOTER_DINAMICO}",file_get_contents("views/head/" . $id_empresa . "_footer.html"), $html);
    $html   = str_replace("{PERFIL_DINAMICO}",file_get_contents("views/menu/" . $id_empresa . "_perfil_principal.html"), $html);
    $html   = str_replace("{MENU_DINAMICO_BOTON_MI_EQUIPO}","", $html);
    $html   = str_replace("{MENU_DINAMICO_BOTON_MI_EQUIPO2}","", $html);
    $html   = str_replace("{MENU_DINAMICO_BOTON_RECONOCE}","", $html);
    $html   = str_replace("{MENU_DINAMICO_BOTON_COMUNIDAD}","", $html);
    $html   = str_replace("{MENU_DINAMICO_BOTON_RECONOCE}","", $html);
    $html   = str_replace("{HEAD}", file_get_contents("views/head.html"), $html);
    $html   = str_replace("{TITULO_PAGINA}", ($datos_empresa[0]->titulo_pagina), $html);
    $html   = str_replace("{ICO}", $datos_empresa[0]->ico, $html);
    $html   = str_replace("{CASE_HOME}", $datos_empresa[0]->case_home, $html);
    $html   = str_replace("{LOGO_EMPRESA}", ($datos_empresa[0]->archivo), $html);
    return ($html);
}
function formatearFechaCompleta($valor_fecha)
{
    $dia = date("d", strtotime($valor_fecha));
    $mes = devuelveNombreMes(date("m", strtotime($valor_fecha)));
    $ano = date("Y", strtotime($valor_fecha));
    //return($fecha2=date("d-m-Y",strtotime($valor_fecha)));
    return ($dia . " de " . $mes . " de " . $ano);
}

function my_simple_crypt_encodear($string)
{
    // you may change these values to your own
    $secret_key     = getenv('BDP_ENC_SECRET_ENC1');
    $secret_iv      = getenv('BDP_ENC_SECRET_IV_ENC1');
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv), 0, 16);
    $output         = base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
    return $output;
}

function my_simple_crypt_decodear($string)
{
    // you may change these values to your own
    $secret_key     = getenv('BDP_ENC_SECRET_ENC1');
    $secret_iv      = getenv('BDP_ENC_SECRET_IV_ENC1');
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv), 0, 16);
    $output         = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    return $output;
}

function Encodear3($valor)
{
    //$valor=Encodear(Encodear(Encodear($valor)));
    $valor = my_simple_crypt_encodear($valor, 'e');
    return ($valor);
}

function Decodear3($valor)
{
    //$valor=Decodear(Decodear(Decodear($valor)));
    //print_r($valor);
    $valor = my_simple_crypt_decodear($valor, 'd');
    return ($valor);
}

function Encodear($valor)
{
    $valor = base64_encode(base64_encode(base64_encode($valor)));
    return ($valor);
}

function Decodear($valor)
{
    $valor = base64_decode(base64_decode(base64_decode($valor)));
    return ($valor);
}

function BarraNavegacion($PRINCIPAL, $seccion)
{
        $PRINCIPAL = str_replace("{BARRA_NAVEGACION_BUSCADOR}", "", $PRINCIPAL);
        $PRINCIPAL = str_replace("{SECCION_VOLVER}", "", $PRINCIPAL);
    return ($PRINCIPAL);
}

function ColocaMenuSecundario($PRINCIPAL, $id_empresa)
{
    
    $PRINCIPAL = str_replace("{MENU_SECUNDARIO}", ($menu), $PRINCIPAL);
    return ($PRINCIPAL);
}

function VerificaFotoPersonal($rut)
{
    $imagen = "img/sinfoto.png";
    return ($imagen);
}
function ColocaDatosPerfil($PRINCIPAL, $rut)
{
    $PRINCIPAL             = str_replace("{FOTO_PERSONA}", VerificaFotoPersonal($rut), $PRINCIPAL);
    $datos_usuario         = DatosUsuarioLeftJefeDeTblUsuario($rut);
    //Datos JEfe
    $arreglo_rut_jefe      = explode("-", $datos_usuario[0]->jefe);
    $datos_personales_jefe = DatosUsuarioLeftJefeDeTblUsuario($arreglo_rut_jefe[0]);
    $PRINCIPAL             = str_replace("{NOMBRE}", ($datos_usuario[0]->nombre . " " . $datos_usuario[0]->apaterno . " " . $datos_usuario[0]->amaterno), $PRINCIPAL);
    $PRINCIPAL             = str_replace("{CARGO}", ($datos_usuario[0]->cargo), $PRINCIPAL);
    $PRINCIPAL             = str_replace("{GERENCIA}", ($datos_usuario[0]->gerencia), $PRINCIPAL);
    $PRINCIPAL             = str_replace("{DIVISION}", ($datos_usuario[0]->division), $PRINCIPAL);
    $PRINCIPAL             = str_replace("{CORREO}", $datos_usuario[0]->email, $PRINCIPAL);
    $PRINCIPAL             = str_replace("{RUT_ENCODEADO}", Encodear3($rut), $PRINCIPAL);
    
    return ($PRINCIPAL);
}

function resumir($texto, $limite, $car=".", $final="…")
{
if(strlen($texto) <= $limite) return $texto;
  if(false !== ($breakpoint = strpos($texto, $car, $limite)))
  {
   $val=strlen($texto)-1;
   if( $breakpoint < $val)
   {
    $texto= substr($texto, 0, $breakpoint) . $final;
   }
  }
return $texto;
}
function Com_Premios_ListadoPremios_ITEMS($PRINCIPAL, $id_dimension, $segmento, $id_empresa)
{


        $traigoPremios = traigoPremios_data($segmento, $id_empresa, $id_dimension);
        $row_premio    = "";
        foreach ($traigoPremios as $traigoPremio) {
            //print_r($traigoPremio);
            $row_premio .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_row_premios.html");
            $row_premio = str_replace("{TITULO_PREMIO}", ($traigoPremio->premio), $row_premio);
            $row_premio = str_replace("{TITULO_PREMIOLUDICO}", ($traigoPremio->premioludico), $row_premio);
            $row_premio = str_replace("{NUM_PUNTOS}", ($traigoPremio->puntos), $row_premio);
            $row_premio = str_replace("{ID_PREMIO}", ($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{CONDICIONES}", ($traigoPremio->condiciones), $row_premio);
            $row_premio = str_replace("{REQUISITOS}", ($traigoPremio->requisitos), $row_premio);
            $row_premio = str_replace("{DESCRIPCION}", ($traigoPremio->premio_descripcion), $row_premio);
        }

    $PRINCIPAL = str_replace("{LISTADO_PREMIOS_ITEMS}", $row_premio, $PRINCIPAL);
    return $PRINCIPAL;
}
function Com_Premios_ListadoPremios_ITEMS_portfolio($PRINCIPAL, $id_empresa)
{


        $traigoPremios = traigoPremios_Portfolio_data($id_empresa);
       // print_r($traigoPremios);
        $row_premio    = "";
        foreach ($traigoPremios as $traigoPremio) {
            //print_r($traigoPremio);
            $row_premio .= file_get_contents("views/reconoce_vota/" . $id_empresa . "_Lista_Item_row_premios.html");
            $row_premio = str_replace("{TITULO_PREMIO}", ($traigoPremio->premio), $row_premio);
            $row_premio = str_replace("{TITULO_PREMIOLUDICO}", ($traigoPremio->premioludico), $row_premio);
            $row_premio = str_replace("{NUM_PUNTOS}", ($traigoPremio->puntos), $row_premio);
            $row_premio = str_replace("{ID_PREMIO}", ($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{CONDICIONES}", ($traigoPremio->condiciones), $row_premio);
            $row_premio = str_replace("{REQUISITOS}", ($traigoPremio->requisitos), $row_premio);
            $row_premio = str_replace("{DESCRIPCION_PREMIOS}", ($traigoPremio->premio_descripcion), $row_premio);
            $row_premio = str_replace("{IMAGEN}", ($traigoPremio->imagen), $row_premio);

            $row_premio = str_replace("{ID_DIMENSION}", ($traigoPremio->id_dimension), $row_premio);
            $row_premio = str_replace("{ID_PREMIO_ENCODEADO}",      Encodear3($traigoPremio->id_premio), $row_premio);
            $row_premio = str_replace("{ID_DIMENSION_ENCODEADO}",   Encodear3($traigoPremio->id_dimension), $row_premio);

        }

    $PRINCIPAL = str_replace("{LISTADO_PREMIOS_ITEMS}", $row_premio, $PRINCIPAL);
    return $PRINCIPAL;
}
function validateDate($date, $format = 'Y-m-d')
{
if (DateTime::createFromFormat('Y-m-d', $date) !== FALSE) {
    // it's a date
    return("SI");
}
}
