<?php

function UsuarioAdminRutEmpresa($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_admin WHERE user = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $result = $connexion->resultset();
    return $result;
}

function VerificaClaveAccesoAdmin_v2($rut, $clave)
{
    $connexion = new DatabasePDO();
    $clave = utf8_decode($clave);
    $sql = "SELECT * FROM tbl_admin WHERE user = :rut AND pass = :clave";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':clave', $clave);
    $result = $connexion->resultset();
    return $result;
}

function BuscaEmpresaUserRut($rut)
{
    $connexion = new DatabasePDO();
    $arreglo_rut = $arreglo_archivo = explode("-", $rut);
    $key = $arreglo_rut[0];

    $sql = "SELECT h.*, (SELECT home FROM tbl_admin_perfiles WHERE id = h.acceso) AS home_admin FROM tbl_admin h WHERE h.user = :rut";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}

function PerfilAdmin($id)
{
    $connexion = new DatabasePDO();

    $sql = "select * from tbl_admin_perfiles where id= :id";

    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();

    return $cod;
}
function VerificaTipoDePerfilAdminAcceso($user)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT tbl_admin.*, tbl_admin_perfiles.template 
            FROM tbl_admin 
            INNER JOIN tbl_admin_perfiles ON tbl_admin_perfiles.id = tbl_admin.acceso 
            WHERE tbl_admin.user = :user";

    $connexion->query($sql);
    $connexion->bind(':user', $user);
    $cod = $connexion->resultset();

    return $cod;
}

function UsuarioEnBasePersonas($rut)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_usuario WHERE rut = :rut AND rut <> '' AND vigencia = '0'";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}

function Tickets_MonthYear()
{
    $connexion = new DatabasePDO();

    $sql1 = "SELECT YEAR(fecha) AS year FROM tbl_tickets WHERE estado <> 'registro' AND id_empresa = '78' GROUP BY YEAR(fecha);";
    $connexion->query($sql1);
    $cod1 = $connexion->resultset();

    $sql2 = "SELECT MONTH(fecha) AS month FROM tbl_tickets WHERE estado <> 'registro' AND id_empresa = '78' GROUP BY MONTH(fecha);";
    $connexion->query($sql2);
    $cod2 = $connexion->resultset();

    $arreglo[0] = $cod1;
    $arreglo[1] = $cod2;
    return $arreglo;
}


function Tickets_Estadisticas_Vistas_Home_Cap_2022($id_empresa, $year) {
    $connexion = new DatabasePDO();
    $year_date = $year . "-08-01";

    $sql = "SELECT h.fecha, YEAR(h.fecha) AS fecha_year, MONTH(h.fecha) AS fecha_month, COUNT(h.id) AS cuenta 
            FROM tbl_log_sistema_historicos h 
            WHERE h.ambiente = 'cap_2021' AND YEAR(h.fecha) = :year 
            GROUP BY h.ambiente, YEAR(h.fecha), MONTH(h.fecha);";

    $connexion->query($sql);
    $connexion->bind(':year', $year);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_Estadisticas_Vistas_Home_Diario_Cap_2022($id_empresa, $month, $year) {
    $connexion = new DatabasePDO();
    $year_date = date("Y")."-08-01";

    $sql = "SELECT h.fecha, YEAR(h.fecha) AS fecha_year, MONTH(h.fecha) AS fecha_month, COUNT(h.id) AS cuenta 
            FROM tbl_log_sistema_historicos h 
            WHERE h.ambiente = 'cap_2021' AND YEAR(h.fecha) = :year AND MONTH(h.fecha) = :month
            GROUP BY h.ambiente, h.fecha;";

    $connexion->query($sql);
    $connexion->bind(':year', $year);
    $connexion->bind(':month', $month);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_lista_tickets_registro_month_year_data($id_empresa, $tipo, $rut, $perfil, $fecha_inicio, $fecha_termino) {
    // $connexion = new DatabasePDO();

    // $year = date("Y");
    // $month = date("m");
//$day = date("d");

    // if ($perfil == "ejecutivo_superadmin") {
    //  $JQuery_Ejecutivo = " ";
    // } elseif ($perfil == "ejecutivo_derivado") {
    //    $JQuery_Ejecutivo = " AND (h.rut_derivado = :rut) ";
    //     $tipo = "derivado";
    // } elseif ($perfil == "ejecutivo") {
    //     $JQuery_Ejecutivo = " AND (h.rut_ejecutivo = :rut OR h.rut_ejecutivo = '' OR h.rut_ejecutivo IS NULL) ";
    // } else {
    //     $JQuery_Ejecutivo = " AND h.rut_ejecutivo = :rut ";
    //     $tipo = "todos";
    // }

    // $QFi = "";
    // if ($fecha_inicio <> "") {
    //     $QFi = " AND h.fecha >= :fecha_inicio ";
    // }

    // $QFt = "";
    // if ($fecha_termino <> "") {
    //     $QFt = " AND h.fecha <= :fecha_termino ";
    // }

    // if ($fecha_inicio == "") {
    //     $fecha_inicio = $year . "-" . $month . "-" . $day;
    //     $QFi = " AND h.fecha >= :fecha_inicio ";
    // }

    // $tipo = "registro";
    //$Jquery_Tipo = " AND h.estado = :tipo ";

    //$sql = "SELECT h.*,
    //            (SELECT sla FROM tbl_tickets_categoria WHERE id = h.id_categoria) AS sla_categoria
    //        FROM tbl_tickets h
    //       WHERE h.id_empresa = :id_empresa $Jquery_Tipo $JQuery_Ejecutivo
    //            $QFi $QFt
    //        ORDER BY fecha DESC, hora DESC";

    // $connexion->query($sql);
    // $connexion->bind(':id_empresa', $id_empresa);
    //  $connexion->bind(':tipo', $tipo);
    //  $connexion->bind(':rut', $rut);
    //  $connexion->bind(':fecha_inicio', $fecha_inicio);
    //  $connexion->bind(':fecha_termino', $fecha_termino);
    //  $connexion->execute();

    // $cod = $connexion->resultset();
    // return $cod;
}


function UpdateInsertPregRespuestas2022_data($id_pregunta_edicion, $pregunta1, $pregunta2, $pregunta3,
                                             $pregunta4, $pregunta5, $pregunta6, $pregunta7,
                                             $pregunta8, $pregunta9, $pregunta10,
                                             $respuesta, $categoria, $subcategoria, $borrar) {
    $connexion = new DatabasePDO();

    $pregunta1 = utf8_decode($pregunta1);
    $pregunta2 = utf8_decode($pregunta2);
    $pregunta3 = utf8_decode($pregunta3);
    $pregunta4 = utf8_decode($pregunta4);
    $pregunta5 = utf8_decode($pregunta5);
    $pregunta6 = utf8_decode($pregunta6);
    $pregunta7 = utf8_decode($pregunta7);
    $pregunta8 = utf8_decode($pregunta8);
    $pregunta9 = utf8_decode($pregunta9);
    $pregunta10 = utf8_decode($pregunta10);

    $respuesta = utf8_decode($respuesta);
    $categoria = utf8_decode($categoria);
    $subcategoria = utf8_decode($subcategoria);

    if ($borrar > 0) {
        $sql = "UPDATE tbl_tickets_preguntas_2021
            SET id_empresa='99'
            WHERE id=:borrar";

        $connexion->query($sql);
        $connexion->bind(':borrar', $borrar);
        $connexion->execute();
    } else {
        if ($id_pregunta_edicion > 0) {
            $sql = "UPDATE tbl_tickets_preguntas_2021
            SET pregunta1=:pregunta1, pregunta2=:pregunta2, pregunta3=:pregunta3, pregunta4=:pregunta4, pregunta5=:pregunta5,
                pregunta6=:pregunta6, pregunta7=:pregunta7, pregunta8=:pregunta8, pregunta9=:pregunta9, pregunta10=:pregunta10,
                respuesta=:respuesta, categoria=:categoria, subcategoria=:subcategoria
            WHERE id=:id_pregunta_edicion";

            $connexion->query($sql);
            $connexion->bind(':pregunta1', $pregunta1);
            $connexion->bind(':pregunta2', $pregunta2);
            $connexion->bind(':pregunta3', $pregunta3);
            $connexion->bind(':pregunta4', $pregunta4);
            $connexion->bind(':pregunta5', $pregunta5);
            $connexion->bind(':pregunta6', $pregunta6);
            $connexion->bind(':pregunta7', $pregunta7);
            $connexion->bind(':pregunta8', $pregunta8);
            $connexion->bind(':pregunta9', $pregunta9);
            $connexion->bind(':pregunta10', $pregunta10);
            $connexion->bind(':respuesta', $respuesta);
            $connexion->bind(':categoria', $categoria);
            $connexion->bind(':subcategoria', $subcategoria);
            $connexion->bind(':id_pregunta_edicion', $id_pregunta_edicion);
            $connexion->execute();
        } else {
            $sql_2 = "SELECT MAX(id_respuesta) AS max FROM tbl_tickets_preguntas_2021";
            $connexion->query($sql_2);
            $cod_2 = $connexion->resultset();
            $max_id_respuesta = $cod_2[0]->max + 1;
            echo "<br>max_id_respuesta $max_id_respuesta ";

            $sql = "INSERT INTO tbl_tickets_preguntas_2021 (pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
                pregunta6, pregunta7, pregunta8, pregunta9, pregunta10, id_respuesta,
                respuesta, categoria, subcategoria, id_empresa)
                VALUES (:pregunta1, :pregunta2, :pregunta3, :pregunta4, :pregunta5, :pregunta6, :pregunta7, :pregunta8, :pregunta9, :pregunta10,
                :max_id_respuesta, :respuesta, :categoria, :subcategoria, '78')";

            $connexion->query($sql);
            $connexion->bind(':pregunta1', $pregunta1);
            $connexion->bind(':pregunta2', $pregunta2);
            $connexion->bind(':pregunta3', $pregunta3);
            $connexion->bind(':pregunta4', $pregunta4);
            $connexion->bind(':pregunta5', $pregunta5);
            $connexion->bind(':pregunta6', $pregunta6);
            $connexion->bind(':pregunta7', $pregunta7);
            $connexion->bind(':pregunta8', $pregunta8);
            $connexion->bind(':pregunta9', $pregunta9);
            $connexion->bind(':pregunta10', $pregunta10);
            $connexion->bind(':max_id_respuesta', $max_id_respuesta);
            $connexion->bind(':respuesta', $respuesta);
            $connexion->bind(':categoria', $categoria);
            $connexion->bind(':subcategoria', $subcategoria);
            $connexion->execute();
        }
    }
}


function Insert_Bitacora_data($row) {
    $connexion = new DatabasePDO();

    $sql = "
        INSERT INTO tbl_tickets (rut, fecha, id_categoria, id_subcategoria, asunto, descripcion, rut_ejecutivo)
        VALUES (:rut, :fecha, :id_categoria, :id_subcategoria, :asunto, :descripcion, :rut_ejecutivo)
    ";

    $connexion->query($sql);
    $connexion->bind(':rut', $row['rut']);
    $connexion->bind(':fecha', $row['fecha']);
    $connexion->bind(':id_categoria', $row['id_categoria']);
    $connexion->bind(':id_subcategoria', $row['id_subcategoria']);
    $connexion->bind(':asunto', $row['asunto']);
    $connexion->bind(':descripcion', $row['descripcion']);
    $connexion->bind(':rut_ejecutivo', $row['rut_ejecutivo']);
    $connexion->execute();
}

function TraeIntendosAccesosFallidosIpProxy()
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $sql = "SELECT COUNT(id) as cuenta FROM tbl_login_intento_acceso WHERE ip_proxy = :ip_proxy AND fecha = :fecha";

    $connexion->query($sql);
    $connexion->bind(':ip_proxy', $_SERVER['HTTP_X_FORWARDED_FOR']);
    $connexion->bind(':fecha', $fecha);

    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function InsertaAccesoIntentoAdmin($rut, $error)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $sql = "INSERT INTO tbl_login_intento_acceso (rut, fecha, hora, ip_compartido, ip_proxy, ip_acceso, error)
            VALUES (:rut, :fecha, :hora, :ip_compartido, :ip_proxy, :ip_acceso, :error)";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':ip_compartido', $_SERVER['HTTP_CLIENT_IP']);
    $connexion->bind(':ip_proxy', $_SERVER['HTTP_X_FORWARDED_FOR']);
    $connexion->bind(':ip_acceso', $_SERVER['REMOTE_ADDR']);
    $connexion->bind(':error', $error);

    $connexion->execute();
}

function Tickets_BitacoraGroupbyMonthYear($id_empresa, $tipo, $rut, $perfil)
{
    $connexion = new DatabasePDO();

    if ($perfil == "ejecutivo_superadmin") {
        $JQuery_Ejecutivo = " ";
    } elseif ($perfil == "ejecutivo_derivado") {
        $JQuery_Ejecutivo = " AND (h.rut_derivado = :rut) ";
        $tipo = "derivado";
    } elseif ($perfil == "ejecutivo") {
        $JQuery_Ejecutivo = " AND (h.rut_ejecutivo = :rut OR h.rut_ejecutivo = '' OR h.rut_ejecutivo IS NULL) ";
    } else {
        $JQuery_Ejecutivo = " AND h.rut_ejecutivo = :rut ";
        $tipo = "todos";
    }

    $tipo = "registro";
    $Jquery_Tipo = " AND h.estado = :tipo ";

    $sql = "SELECT YEAR(h.fecha) as year, MONTH(h.fecha) as month
            FROM tbl_tickets h 
            WHERE h.id_empresa = :id_empresa 
            $Jquery_Tipo $JQuery_Ejecutivo 
            GROUP BY YEAR(h.fecha) DESC, MONTH(h.fecha) DESC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':tipo', $tipo);

    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_lista_preguntas_respuestas_2022_data($id_empresa, $tipo, $rut, $perfil, $fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*, 
            (SELECT COUNT(id) FROM tbl_tickets_respuestas_rating WHERE id_respuesta = h.id_respuesta AND rating = '1') AS CuentaSi,
            (SELECT COUNT(id) FROM tbl_tickets_respuestas_rating WHERE id_respuesta = h.id_respuesta AND rating = '2') AS CuentaNo
            FROM tbl_tickets_preguntas_2021 h 
            ORDER BY id ASC";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function LimpiaTextosTrim($texto){
    $texto = str_replace(";", ".", $texto);
    $texto = str_replace("<br>", "", $texto);
    $texto = str_replace("/\r|\n/", "", $texto);
    $texto = str_replace("/\r|\n/", "", $texto);
    $texto = str_replace("/\r|\n/", "", $texto);
    $texto = str_replace(array("\r", "\n"), '',  $texto);
    $texto = str_replace(array("\r\n", "\r", "\n"), "",  $texto);
    return $texto;
}

function UpdateTicketTiempos($id,$Hours,$Sla,$porcentaje_Sla_Hours){

    $connexion = new DatabasePDO();

    $hoy = date('Y-m-d');
    $sql="update tbl_tickets
		set 
		horas_transcurridas= :Hours,
		horas_sla= :Sla,
		porcentaje_sla= :porcentaje_Sla_Hours
		where id= :id";

    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->bind(':Hours', $Hours);
    $connexion->bind(':Sla', $Sla);
    $connexion->bind(':porcentaje_Sla_Hours', $porcentaje_Sla_Hours);
    $connexion->execute();


}

function Tickets_tbl_tickets_comentarios_data($rut, $id_ticket)
{
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(h.id) as cuenta FROM tbl_tickets_comentarios h
        WHERE h.rut = :rut AND h.id_ticket = :id_ticket";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_ticket', $id_ticket);

    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function Ticket_delete_pregunta_vacia_data($id_empresa)
{
    $connexion = new DatabasePDO();

    $sql2 = "DELETE FROM tbl_tickets_preguntas WHERE LENGTH(pregunta) < 3";

    $connexion->query($sql2);
    $connexion->execute();
}

function Tickets_Consultas_Usuarios_2020_csv()
{
    $connexion = new DatabasePDO();

    $sql = "SELECT h.* FROM tbl_tickets_preguntas_usuario h WHERE h.pregunta <> ''";

    $connexion->query($sql);
    $cod = $connexion->resultset();

    return $cod;
}

function Tickets_Consultas_Usuarios_2023_csv($fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    $qsd = "";
    $qed = "";
    if ($fecha_inicio !== "") {
        $qsd = " AND h.fecha >= :fecha_inicio";
    }
    if ($fecha_termino !== "") {
        $qed = " AND h.fecha <= :fecha_termino";
    }

    $sql = "SELECT h.* FROM tbl_tickets_preguntas_usuario h WHERE h.pregunta<>'' $qsd $qed";
    $connexion->query($sql);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $cod = $connexion->resultset();
    return $cod;
}

function TicketsPreguntas_2021_2020_csv() {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.* FROM tbl_tickets_preguntas_2021 h WHERE h.id_empresa='78'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function TicketsPreguntas_2023_csv($fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    $qsd = "";
    $qed = "";
    if ($fecha_inicio !== "") {
        $qsd = " AND h.fecha >= :fecha_inicio";
    }
    if ($fecha_termino !== "") {
        $qed = " AND h.fecha <= :fecha_termino";
    }

    $sql = "SELECT h.* FROM tbl_tickets_preguntas_2021 h WHERE h.id_empresa='78' $qsd $qed";
    $connexion->query($sql);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_Rating_Usuarios_Preguntas_2020_csv()
{
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*, 
        (SELECT pregunta1 FROM tbl_tickets_preguntas_2021 WHERE id_respuesta = h.id_respuesta LIMIT 1) AS pregunta2021
        FROM tbl_tickets_respuestas_rating h
        WHERE (SELECT pregunta1 FROM tbl_tickets_preguntas_2021 WHERE id_respuesta = h.id_respuesta LIMIT 1) <> ''";

    $connexion->query($sql);
    $cod = $connexion->listObjects();

    return $cod;
}

function Tickets_Rating_Usuarios_Preguntas_2023_csv($fecha_inicio, $fecha_termino)
{
    $connexion = new DatabasePDO();

    $qsd = $qed = "";

    if ($fecha_inicio !== "") {
        $qsd = "AND h.fecha >= :fecha_inicio";
    }

    if ($fecha_termino !== "") {
        $qed = "AND h.fecha <= :fecha_termino";
    }

    $sql = "
        SELECT h.*, 
        (SELECT pregunta1 FROM tbl_tickets_preguntas_2021 WHERE id_respuesta = h.id_respuesta LIMIT 1) AS pregunta2021
        FROM tbl_tickets_respuestas_rating h
        WHERE (SELECT pregunta1 FROM tbl_tickets_preguntas_2021 WHERE id_respuesta = h.id_respuesta LIMIT 1) <> ''
        $qsd $qed";

    $connexion->query($sql);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);

    $cod = $connexion->listObjects();

    return $cod;
}

function Tickets_Update_Preguntas_2020_csv($id_pregunta, $pregunta)
{
    $connexion = new DatabasePDO();

    $sql = "UPDATE tbl_tickets_preguntas SET pregunta = :pregunta WHERE id_pregunta = :id_pregunta";

    $connexion->query($sql);
    $connexion->bind(':pregunta', $pregunta);
    $connexion->bind(':id_pregunta', $id_pregunta);
    $connexion->execute();
}

function Tickets_Update_Respuestas_2020_csv($id_respuesta, $respuesta, $tip)
{
    $connexion = new DatabasePDO();

    $sql = "UPDATE tbl_tickets_preguntas SET respuesta = :respuesta, tip_ejecutivo = :tip WHERE id_respuesta = :id_respuesta";

    $connexion->query($sql);
    $connexion->bind(':respuesta', $respuesta);
    $connexion->bind(':tip', $tip);
    $connexion->bind(':id_respuesta', $id_respuesta);
    $connexion->execute();
}


function Ticket_Create_Insert_Respuestas($resp1, $resp2, $categoria, $subcategoria, $preguntas, $id_empresa)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $id_empresa = $_SESSION["id_empresa"]; // You might need to handle session data separately

    $sql_1 = "SELECT MAX(id_pregunta) as max FROM tbl_tickets_preguntas";
    $connexion->query($sql_1);
    $cod_1 = $connexion->resultset();

    $sql_2 = "SELECT MAX(id_respuesta) as max FROM tbl_tickets_respuestas";
    $connexion->query($sql_2);
    $cod_2 = $connexion->resultset();

    $id_respuesta = $cod_2[0]->max + 1;

    $resp1 = trim($resp1);
    $resp2 = trim($resp2);

    $resp1 = strip_tags($resp1);
    $resp2 = strip_tags($resp2);

    $sql_4 = "
    INSERT INTO tbl_tickets_respuestas (id_respuesta, respuesta, tip_ejecutivo, id_empresa)
    VALUES (:id_respuesta, :resp1, :resp2, :id_empresa)";
    $connexion->query($sql_4);
    $connexion->bind(':id_respuesta', $id_respuesta);
    $connexion->bind(':resp1', $resp1);
    $connexion->bind(':resp2', $resp2);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $id_pregunta = $cod_1[0]->max + 1;

    foreach ($preguntas as $pregunta) {
        if (!empty($pregunta)) {
            $sql_3 = "
            INSERT INTO tbl_tickets_preguntas (id_pregunta, pregunta, id_respuesta, id_empresa, fecha_actualizacion, estado, categoria, subcategoria)
            VALUES (:id_pregunta, :pregunta, :id_respuesta, :id_empresa, :fecha, 'PUBLICADA', :categoria, :subcategoria)";
            $connexion->query($sql_3);
            $connexion->bind(':id_pregunta', $id_pregunta);
            $connexion->bind(':pregunta', $pregunta);
            $connexion->bind(':id_respuesta', $id_respuesta);
            $connexion->bind(':id_empresa', $id_empresa);
            $connexion->bind(':fecha', $fecha);
            $connexion->bind(':categoria', $categoria);
            $connexion->bind(':subcategoria', $subcategoria);
            $connexion->execute();

            $id_pregunta++;
        }
    }
}

function Ticket_Download_Preg_respuestas_Tickets_data($id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "
        select h.*,

			(select id_categoria from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 1) as id_categoria,
			(select categoria from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 1) as categoria,

			(select id_subcategoria from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 1) as id_subcategoria,
			(select subcategoria from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 1) as subcategoria,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 0,1) as id_pregunta_1,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 0,1) as pregunta_1,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 1,1) as id_pregunta_2,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 1,1) as pregunta_2,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 2,1) as id_pregunta_3,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 2,1) as pregunta_3,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 3,1) as id_pregunta_4,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 3,1) as pregunta_4,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 4,1) as id_pregunta_5,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 4,1) as pregunta_5,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 5,1) as id_pregunta_6,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 5,1) as pregunta_6,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 6,1) as id_pregunta_7,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 6,1) as pregunta_7,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 7,1) as id_pregunta_8,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 7,1) as pregunta_8,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 8,1) as id_pregunta_9,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 8,1) as pregunta_9,

			(select id_pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 9,1) as id_pregunta_10,
			(select pregunta from tbl_tickets_preguntas where id_respuesta=h.id_respuesta limit 9,1) as pregunta_10

			from tbl_tickets_respuestas h

			where id_empresa='$id_empresa'
		
		 ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function Ticket_Crear_PreguntaRespuesta_Pendiente($rut, $id_empresa, $pregunta_add, $respuesta_add){


    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    //echo "<br>a $c_host, b $c_user, c $c_pass, d $c_db";

    $pregunta_add				= utf8_decode($pregunta_add);
    $respuesta_add			= utf8_decode($respuesta_add);

    $fecha 				= date("Y-m-d");

    $sql_1= " select max(id_pregunta) as max from tbl_tickets_preguntas";
    $database->setquery($sql_1);
    $database->query();
    $cod_1 = $database->listObjects();

    $sql_2= " select max(id_respuesta) as max from tbl_tickets_respuestas";
    $database->setquery($sql_2);
    $database->query();
    $cod_2 = $database->listObjects();

    $id_pregunta	=	$cod_1[0]->max+1;
    $id_respuesta	=	$cod_2[0]->max+1;

    $sql_3 = "
    INSERT INTO tbl_tickets_preguntas (id_pregunta, pregunta, id_respuesta, id_empresa, fecha_actualizacion, estado, rut_publicador)
    VALUES ('$id_pregunta','$pregunta_add','$id_respuesta','$id_empresa','$fecha','PENDIENTE_VALIDACION','$rut')";
    //echo "<br>sql Preguntas<br> $sql_3<br>";
    $database->setquery($sql_3);
    $database->query();

    $sql_4 = "
    INSERT INTO tbl_tickets_respuestas (id_respuesta, respuesta, id_empresa)
    VALUES ('$id_respuesta','$respuesta_add','$id_empresa')";
    //echo "<br>sql Respuesta<br> $sql_4<br>";
    $database->setquery($sql_4);
    $database->query();


    echo "<script>alert('Se ha registrado la pregunta y respuesta con estado Pendiente de Aprobacion');</script>";
    echo "<script type='text/javascript'>window.history.go(-1);</script>"; exit();
}

function Ticket_Renegocia($id, $horas)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql = "UPDATE tbl_tickets SET fecha_renegociacion = :fecha, hora_renegociacion = :hora, horas_renegociada = :horas WHERE id = :id";

    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':horas', $horas);
    $connexion->bind(':id', $id);

    $connexion->execute();
}


function Ticket_Reasigna_Categoria_Subcategoria($id, $categoria,$subcategoria){

    $connexion = new DatabasePDO();
    $sql = "update tbl_tickets 
                set id_categoria= :categoria, id_subcategoria= :subcategoria where id= :id";
    $connexion->query($sql);
    $connexion->bind(':categoria', $categoria);
    $connexion->bind(':subcategoria', $subcategoria);
    $connexion->bind(':id', $id);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;

}

function Ticket_Reasigna_Ejecutivo_Nivel($id, $rut_ejecutivo_nivel_2)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql = "UPDATE tbl_tickets SET rut_ejecutivo = :rut_ejecutivo_nivel_2 WHERE id = :id";

    $connexion->query($sql);
    $connexion->bind(':rut_ejecutivo_nivel_2', $rut_ejecutivo_nivel_2);
    $connexion->bind(':id', $id);

    $connexion->execute();
}

function Ticket_Deriva_Ejecutivo_Nivel($id, $rut_ejecutivo_nivel_3)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql = "UPDATE tbl_tickets SET rut_derivado = :rut_ejecutivo_nivel_3, fecha_derivacion = :fecha, hora_derivacion = :hora, estado = 'derivado' WHERE id = :id";

    $connexion->query($sql);
    $connexion->bind(':rut_ejecutivo_nivel_3', $rut_ejecutivo_nivel_3);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':id', $id);

    $connexion->execute();
}

function Ticket_Actualiza_Fecha_Respuesta_Derivada($id)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql = "UPDATE tbl_tickets SET fecha_derivacion_respuesta = :fecha, hora_derivacion_respuesta = :hora WHERE id = :id";

    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':id', $id);

    $connexion->execute();
}

function Tickets_Busca_Ejecutivos_Nivel2($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select * from tbl_admin where id_empresa='78' and go='2' ";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_Busca_Ejecutivos_Nivel3($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select * from tbl_admin where id_empresa='78' and go='3'   order by nombre";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_Dashboard_Graf_data($rut, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(id) AS cuenta, estado, cierre_descripcion 
        FROM tbl_tickets 
        WHERE estado <> 'registro' AND id_empresa = :id_empresa 
        GROUP BY estado, cierre_descripcion
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_Dashboard_Graf_Tiempos_data($rut, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(id) as cuenta, horas_transcurridas
        FROM tbl_tickets 
        WHERE estado <> 'registro' 
        AND horas_transcurridas < 100
        AND id_empresa = :id_empresa 
        GROUP BY horas_transcurridas
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_Dashboard_Graf_Tiempos_min_max_data($rut, $min, $max, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(id) as cuenta
        FROM tbl_tickets 
        WHERE estado <> 'registro' 
        AND horas_transcurridas < 100
        AND horas_transcurridas <= :max
        AND horas_transcurridas > :min
        AND id_empresa = :id_empresa
    ";

    $connexion->query($sql);
    $connexion->bind(':max', $max);
    $connexion->bind(':min', $min);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}


function Tickets_Dashboard_Graf_Tiempos_24_data($rut, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(id) as cuenta, horas_transcurridas
        FROM tbl_tickets 
        WHERE estado <> 'registro' 
        AND horas_transcurridas < 100
        AND id_empresa = :id_empresa
        GROUP BY horas_transcurridas
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_Dashboard_Graf_Tiempos_36_data($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(id) AS cuenta,
               horas_transcurridas
        FROM tbl_tickets
        WHERE estado <> 'registro' 
        AND horas_transcurridas < 100
        AND id_empresa = :id_empresa
        GROUP BY horas_transcurridas
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function Tickets_Dashboard_Graf_Tiempos_48_data($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(id) AS cuenta,
               horas_transcurridas
        FROM tbl_tickets
        WHERE estado <> 'registro' 
        AND horas_transcurridas < 100
        AND id_empresa = :id_empresa
        GROUP BY horas_transcurridas
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function Tickets_Dashboard_Graf_Tiempos_48omas_data($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "
        SELECT COUNT(id) AS cuenta,
               horas_transcurridas
        FROM tbl_tickets
        WHERE estado <> 'registro' 
        AND horas_transcurridas < 100
        AND id_empresa = :id_empresa
        GROUP BY horas_transcurridas
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function Tickets_dashboard_Tiempos_ejecutivo_lista($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT 
        h.rut_ejecutivo, 
        (SELECT nombre_completo FROM tbl_admin WHERE user = h.rut_ejecutivo) AS nombre
        FROM tbl_tickets h
        WHERE h.id > 0
        AND h.horas_transcurridas < 100
        AND h.rut_ejecutivo <> ''
        AND h.id_empresa = :id_empresa 
        GROUP BY h.rut_ejecutivo;
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_dashboard_Tiempos_ejecutivo_por_rut($id_empresa, $rut_ejecutivo, $fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    if ($fecha_inicio <> "") {
        $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
        $Q_fecha_inicio1 = " AND fecha >= :fecha_inicio ";
    } else {
        $Q_fecha_inicio = "";
        $Q_fecha_inicio1 = "";
    }

    if ($fecha_termino <> "") {
        $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
        $Q_fecha_termino1 = " AND fecha <= :fecha_termino ";
    } else {
        $Q_fecha_termino = "";
        $Q_fecha_termino1 = "";
    }

    $sql = "
        SELECT 
        ROUND(AVG(h.horas_transcurridas), 1) AS promedio_horas, 
        COUNT(h.horas_transcurridas) AS num_requerimientos, 
        h.rut_ejecutivo, 
        (SELECT COUNT(id) FROM tbl_tickets WHERE rut_ejecutivo = h.rut_ejecutivo $Q_fecha_inicio1 $Q_fecha_termino1) AS num_bitacora,
        (SELECT nombre_completo FROM tbl_admin WHERE user = h.rut_ejecutivo) AS nombre
        FROM tbl_tickets h
        WHERE h.id > 0
        $Q_fecha_inicio
        $Q_fecha_termino
        AND h.rut_ejecutivo = :rut_ejecutivo
        AND h.id_empresa = :id_empresa 
        GROUP BY h.rut_ejecutivo;
    ";

    // $connexion->query($sql);
    // $connexion->bind(':id_empresa', $id_empresa);
    // $connexion->bind(':rut_ejecutivo', $rut_ejecutivo);
    // $connexion->bind(':fecha_inicio', $fecha_inicio);
    // $connexion->bind(':fecha_termino', $fecha_termino);
    // $connexion->execute();

    //$cod = $connexion->resultset();
    //return $cod;
}


function Tickets_dashboard_Tiempos_ejecutivo($id_empresa, $fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    if ($fecha_inicio !== "") {
        $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
        $Q_fecha_inicio1 = " AND fecha >= :fecha_inicio ";
    } else {
        $Q_fecha_inicio = "";
        $Q_fecha_inicio1 = "";
    }

    if ($fecha_termino !== "") {
        $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
        $Q_fecha_termino1 = " AND fecha <= :fecha_termino ";
    } else {
        $Q_fecha_termino = "";
        $Q_fecha_termino1 = "";
    }

    $sql = "
        SELECT 
        ROUND(AVG(h.horas_transcurridas), 1) AS promedio_horas, 
        COUNT(h.horas_transcurridas) AS num_requerimientos, 
        h.rut_ejecutivo, 
        (SELECT COUNT(id) FROM tbl_tickets WHERE rut_ejecutivo = h.rut_ejecutivo $Q_fecha_inicio1 $Q_fecha_termino1) AS num_bitacora,
        (SELECT nombre_completo FROM tbl_admin WHERE user = h.rut_ejecutivo) AS nombre
        FROM tbl_tickets h
        WHERE h.id > 0
        $Q_fecha_inicio
        $Q_fecha_termino
        AND h.horas_transcurridas < 100
        AND h.rut_ejecutivo <> ''
        AND h.id_empresa = :id_empresa 
        GROUP BY h.rut_ejecutivo;
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_dashboard_Tiempos_ejecutivo_total($id_empresa, $fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    if ($fecha_inicio !== "") {
        $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
        $Q_fecha_inicio1 = " AND fecha >= :fecha_inicio ";
    } else {
        $Q_fecha_inicio = "";
        $Q_fecha_inicio1 = "";
    }

    if ($fecha_termino !== "") {
        $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
        $Q_fecha_termino1 = " AND fecha <= :fecha_termino ";
    } else {
        $Q_fecha_termino = "";
        $Q_fecha_termino1 = "";
    }

    $sql = "
        SELECT 
        ROUND(AVG(h.horas_transcurridas), 1) AS promedio_horas, 
        COUNT(h.horas_transcurridas) AS num_requerimientos, 
        h.rut_ejecutivo, 
        (SELECT COUNT(id) FROM tbl_tickets WHERE 1=1 $Q_fecha_inicio1 $Q_fecha_termino1) AS num_bitacora,
        (SELECT nombre_completo FROM tbl_admin WHERE user = h.rut_ejecutivo) AS nombre
        FROM tbl_tickets h
        WHERE h.id > 0
        $Q_fecha_inicio
        $Q_fecha_termino
        AND h.horas_transcurridas < 100
        AND h.rut_ejecutivo <> ''
        AND h.id_empresa = :id_empresa 
        GROUP BY h.rut_ejecutivo;
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_dashboard_Tiempos_Derivados_total($id_empresa, $fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    if ($fecha_inicio !== "") {
        $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
    } else {
        $Q_fecha_inicio = "";
    }

    if ($fecha_termino !== "") {
        $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
    } else {
        $Q_fecha_termino = "";
    }

    $sql = "
        SELECT 
        ROUND(AVG(h.horas_transcurridas), 1) AS promedio_horas, 
        COUNT(h.horas_transcurridas) AS num_requerimientos, 
        h.rut_ejecutivo, 
        (SELECT COUNT(id) FROM tbl_tickets WHERE rut_ejecutivo = h.rut_ejecutivo) AS num_bitacora,
        (SELECT nombre_completo FROM tbl_admin WHERE user = h.rut_ejecutivo) AS nombre,
        (SELECT nombre_completo FROM tbl_admin WHERE user = h.rut_derivado) AS Derivado
        FROM tbl_tickets h
        WHERE h.id > 0
        $Q_fecha_inicio
        $Q_fecha_termino
        AND h.rut_ejecutivo <> ''
        AND h.rut_derivado <> ''
        AND h.id_empresa = :id_empresa 
        GROUP BY h.rut_derivado;
    ";

    // $connexion->query($sql);
    // $connexion->bind(':id_empresa', $id_empresa);
    // $connexion->bind(':fecha_inicio', $fecha_inicio);
    // $connexion->bind(':fecha_termino', $fecha_termino);
    // $connexion->execute();

    // $cod = $connexion->resultset();
    // return $cod;
}



function Tickets_Dashboard_Graf_Categorias_data($rut, $tipo, $fecha_inicio, $fecha_termino, $id_empresa, $limite) {
    //$connexion = new DatabasePDO();

    //if ($tipo == "Requerimiento+Bitacora") {
    //    $query_estado = " AND h.estado <> '' ";
    // } elseif ($tipo == "Requerimiento") {
    //     $query_estado = " AND h.estado <> 'registro' ";
    // } elseif ($tipo == "Bitacora") {
    //     $query_estado = " AND h.estado = 'registro' ";
    // }

    // $Q_fecha_inicio = "";
    // if ($fecha_inicio <> "") {
    //     $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
    // }

    //$Q_fecha_termino = "";
    // if ($fecha_termino <> "") {
    //     $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
    // }

    // if ($limite == "sinlimite") {
    //     $limit = "";
    // } else {
    //     $limit = " LIMIT 15";
    // }

    // $sql = "
    //     SELECT COUNT(h.id) AS cuenta,
    //            (SELECT categoria FROM tbl_tickets_categoria WHERE id = h.id_categoria) AS categoria,
    //           h.id_categoria
    //       FROM tbl_tickets h
    //      WHERE h.id > 0
    //          $query_estado
    //        $Q_fecha_inicio
    //         $Q_fecha_termino
    //         AND h.id_empresa = :id_empresa
    //         AND (SELECT categoria FROM tbl_tickets_categoria WHERE id = h.id_categoria) <> ''
    //   GROUP BY (SELECT categoria FROM tbl_tickets_categoria WHERE id = h.id_categoria)
    //   ORDER BY COUNT(h.id) DESC
    //  $limit
    // ";

    //  $connexion->query($sql);
    //  $connexion->bind(':id_empresa', $id_empresa);
    //  $connexion->bind(':fecha_inicio', $fecha_inicio);
    //  $connexion->bind(':fecha_termino', $fecha_termino);
    //  $connexion->execute();

    // $cod = $connexion->resultset();
    //  return $cod;
}



function Tickets_Dashboard_Graf_SubCategorias_data($rut, $tipo, $fecha_inicio, $fecha_termino, $id_empresa, $limite) {
    $connexion = new DatabasePDO();

    if ($fecha_inicio <> "") {
        $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
    } else {
        $Q_fecha_inicio = "";
    }

    if ($fecha_termino <> "") {
        $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
    } else {
        $Q_fecha_termino = "";
    }

    if ($tipo == "Requerimiento+Bitacora") {
        $query_estado = " AND h.estado <> '' ";
    } elseif ($tipo == "Requerimiento") {
        $query_estado = " AND h.estado <> 'registro' ";
    } elseif ($tipo == "Bitacora") {
        $query_estado = " AND h.estado = 'registro' ";
    }

    if ($limite == "sinlimite") {
        $limit = "";
    } else {
        $limit = " LIMIT 15";
    }

    $sql = "
        SELECT COUNT(h.id) AS cuenta, 
               (SELECT subcategoria FROM tbl_tickets_subcategoria WHERE id = h.id_subcategoria) AS subcategoria,
               h.id_subcategoria
        FROM tbl_tickets h
        WHERE 
              h.id > 0
              $query_estado
              $Q_fecha_inicio
              $Q_fecha_termino
              AND h.id_empresa = :id_empresa 
              AND (SELECT subcategoria FROM tbl_tickets_subcategoria WHERE id = h.id_subcategoria) <> ''
        GROUP BY (SELECT subcategoria FROM tbl_tickets_subcategoria WHERE id = h.id_subcategoria)
        ORDER BY COUNT(h.id) DESC
        $limit
    ";

    //$connexion->query($sql);
    //$connexion->bind(':id_empresa', $id_empresa);
    // $connexion->bind(':fecha_inicio', $fecha_inicio);
    // $connexion->bind(':fecha_termino', $fecha_termino);
    // $connexion->execute();

    // $cod = $connexion->resultset();
    // return $cod;
}


function Tickets_Dashboard_Graf_Canal_Bitacora_data($rut, $tipo, $fecha_inicio, $fecha_termino, $id_empresa) {
    $connexion = new DatabasePDO();

    if ($fecha_inicio <> "") {
        $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
    } else {
        $Q_fecha_inicio = "";
    }

    if ($fecha_termino <> "") {
        $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
    } else {
        $Q_fecha_termino = "";
    }

    if ($tipo == "Requerimiento+Bitacora") {
        $query_estado = " AND h.estado <> '' ";
    } elseif ($tipo == "Requerimiento") {
        $query_estado = " AND h.estado <> 'registro' ";
    } elseif ($tipo == "Bitacora") {
        $query_estado = " AND h.estado = 'registro' ";
    }

    $sql = "
        SELECT h.asunto, COUNT(h.id) AS cuenta
        FROM tbl_tickets h
        WHERE 
              h.id > 0
              $query_estado
              $Q_fecha_inicio
              $Q_fecha_termino
              AND h.estado = 'registro'
              AND h.id_empresa = :id_empresa
        GROUP BY h.asunto;
    ";

    // $connexion->query($sql);
    // $connexion->bind(':fecha_inicio', $fecha_inicio);
    // $connexion->bind(':fecha_termino', $fecha_termino);
    // $connexion->bind(':id_empresa', $id_empresa);
    // $connexion->execute();

    //$cod = $connexion->resultset();
    // return $cod;
}


function Tickets_Dashboard_Graf_Canal_Bitacora_2_data($rut, $tipo, $fecha_inicio, $fecha_termino, $id_empresa) {
    $connexion = new DatabasePDO();

    if ($fecha_inicio <> "") {
        $Q_fecha_inicio = " AND h.fecha >= :fecha_inicio ";
    } else {
        $Q_fecha_inicio = "";
    }

    if ($fecha_termino <> "") {
        $Q_fecha_termino = " AND h.fecha <= :fecha_termino ";
    } else {
        $Q_fecha_termino = "";
    }

    if ($tipo == "Requerimiento+Bitacora") {
        $query_estado = " AND h.estado <> '' ";
    } elseif ($tipo == "Requerimiento") {
        $query_estado = " AND h.estado <> 'registro' ";
    } elseif ($tipo == "Bitacora") {
        $query_estado = " AND h.estado = 'registro' ";
    }

    $sql = "
        SELECT 'requerimiento' AS asunto, COUNT(h.id) AS cuenta 
        FROM tbl_tickets h
        WHERE 
              h.id > 0
              $query_estado
              $Q_fecha_inicio
              $Q_fecha_termino
              AND h.estado <> 'registro'
        ;
    ";

    $connexion->query($sql);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_Descarga_Excel_CSV_data($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*, 
        (SELECT categoria FROM tbl_tickets_categoria WHERE id = h.id_categoria) AS categoria,
        (SELECT subcategoria FROM tbl_tickets_subcategoria WHERE id = h.id_subcategoria) AS subcategoria 

        FROM tbl_tickets h WHERE h.id_empresa = :id_empresa AND h.estado <> 'registro'
        
        ORDER BY h.fecha DESC
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_Nombre_Admin_data($rut_ejecutivo) {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.nombre_completo FROM tbl_admin h WHERE h.user = :rut_ejecutivo";

    $connexion->query($sql);
    $connexion->bind(':rut_ejecutivo', $rut_ejecutivo);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod[0]->nombre_completo;
}

function Tickets_Descarga_Excel_Bitacora_CSV_data($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*, 
        (SELECT categoria FROM tbl_tickets_categoria WHERE id = h.id_categoria) AS categoria,
        (SELECT subcategoria FROM tbl_tickets_subcategoria WHERE id = h.id_subcategoria) AS subcategoria 

        FROM tbl_tickets h WHERE h.id_empresa = :id_empresa AND h.estado = 'registro'
        
        ORDER BY h.fecha DESC
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_Descarga_Excel_Bitacora_CSV_data_fechas($id_empresa, $fecha_inicio, $fecha_termino) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*, 
        (SELECT categoria FROM tbl_tickets_categoria WHERE id = h.id_categoria) AS categoria,
        (SELECT subcategoria FROM tbl_tickets_subcategoria WHERE id = h.id_subcategoria) AS subcategoria 

        FROM tbl_tickets h 
        WHERE h.id_empresa = :id_empresa
            AND h.estado = 'registro'
            AND h.fecha >= :fecha_inicio 
            AND h.fecha <= :fecha_termino

        ORDER BY h.fecha DESC
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}

function Ticket_Save_Visualizacion($rut, $id, $id_empresa){
    //echo "<br>Ticket_Save_Visualizacion $rut, $id, $id_empresa";
    $connexion = new DatabasePDO();
    $sql = "update tbl_tickets set visualizado='1', fecha_visualizacion='$fecha', 
                       hora_visualizacion='$hora',
                       rut_ejecutivo= :rut where id= :id and visualizado is null";
    $connexion->query($sql);
    $connexion->bind(':rut',    $rut);
    $connexion->bind(':id',     $id);
    $connexion->execute();
}

function Ticket_Save_Respondido($rut, $id, $id_empresa)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $sql = "UPDATE tbl_tickets 
            SET estado = 'respondido', fecha_estado = :fecha, hora_estado = :hora, rut_ejecutivo = :rut 
            WHERE id = :id";

    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id', $id);

    $connexion->execute();
}

function Ticket_Save_Respondido_Vuelve_a_Pendiente($rut, $id, $id_empresa)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql_2 = "SELECT * FROM tbl_tickets WHERE id = :id";
    $connexion->query($sql_2);
    $connexion->bind(':id', $id);
    $cod_2 = $connexion->resultset();

    $fecha_original = $cod_2[0]->fecha;
    $hora_original = $cod_2[0]->hora;

    if ($id_empresa == "61") {
        $sql = "UPDATE tbl_tickets SET estado = 'reabierto' WHERE id = :id";
    } else {
        $sql = "UPDATE tbl_tickets 
                SET estado = 'reabierto', fecha_visualizacion = NULL, hora_visualizacion = NULL, fecha_estado = NULL, hora_estado = NULL, fecha_reapertura_original = :fecha_original, hora_reapertura_original = :hora_original, fecha = :fecha, hora = :hora 
                WHERE id = :id";
    }

    $connexion->query($sql);
    $connexion->bind(':fecha_original', $fecha_original);
    $connexion->bind(':hora_original', $hora_original);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':id', $id);

    $connexion->execute();
}


function Tickets_Busca_Num_Resumen_Total($rut, $perfil, $id_empresa)
{
    $connexion = new DatabasePDO();

    if ($perfil == "ejecutivo") {
        $jquery = " and (h.rut_ejecutivo=:rut or h.rut_ejecutivo='' or h.rut_ejecutivo is null) ";
    } elseif ($perfil == "ejecutivo_derivado") {
        $jquery = " and (h.rut_derivado=:rut) ";
        $tipo = "derivado";
    }

    if ($perfil == "ejecutivo_superadmin") {
        $jquery = " ";
    }

    if ($perfil == "colaborador") {
        $jquery = " and h.rut=:rut ";
    }

    $sql = "SELECT count(h.id) AS cuenta, h.estado FROM tbl_tickets h WHERE h.id>0 AND h.id_empresa=:id_empresa $jquery GROUP BY h.estado";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function Tickets_Busca_datos_usuario_admin($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_usuario WHERE id_empresa = :id_empresa AND rut = :rut";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}


function Tickets_Busca_datos_admin($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_admin WHERE id_empresa = :id_empresa AND user = :rut";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}


function Tickets_Busca_datos_tbl_Usuario($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_usuario WHERE rut = :rut";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}


function Tickets_Busca_Ejecutivo($id_empresa, $categoria, $subcategoria) {
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_admin WHERE id_empresa = :id_empresa AND email <> '' AND go = '1' LIMIT 1";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_Insert_Interaccion($id, $interaccion, $archivo, $rut, $perfil, $id_empresa, $archivo2, $archivo3)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $interaccion = utf8_decode($interaccion);

    $sql = "
        INSERT INTO tbl_tickets_comentarios (id_ticket, rut, id_empresa, comentario, fecha, hora, archivo, perfil, archivo2, archivo3)
        VALUES (:id, :rut, :id_empresa, :interaccion, :fecha, :hora, :archivo, :perfil, :archivo2, :archivo3)
    ";

    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':interaccion', $interaccion);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':archivo', $archivo);
    $connexion->bind(':perfil', $perfil);
    $connexion->bind(':archivo2', $archivo2);
    $connexion->bind(':archivo3', $archivo3);

    $connexion->execute();
}

function Tickets_Delete_Ticket($id, $rut, $ticket_perfil, $id_empresa)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql = "
        UPDATE tbl_tickets 
        SET id_empresa = '99' 
        WHERE id = :id
    ";

    $connexion->query($sql);
    $connexion->bind(':id', $id);

    $connexion->execute();
}

function Tickets_Cerrar_Ticket($id, $rut, $ticket_perfil, $id_empresa)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    $sql = "
        UPDATE tbl_tickets 
        SET estado = 'cerrado', fecha_cierre = :fecha, hora_cierre = :hora, rut_cierre = :rut, cierre_descripcion = :ticket_perfil 
        WHERE id = :id
    ";

    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':ticket_perfil', $ticket_perfil);
    $connexion->bind(':id', $id);

    $connexion->execute();
}

function Tickets_Lista_Comentarios($id, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "select h.*, 
    (select nombre_completo from tbl_admin where user=h.rut) as nombre_completo
    
    from tbl_tickets_comentarios h 
    
    where h.id_empresa='78' and h.id_ticket= :id order by id ASC";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;

}

function Tickets_BuscaAdmin($rut)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT h.* FROM tbl_admin h WHERE h.user = :rut";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}

function Tickets_Detalle_id_Data($id, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_tickets h WHERE h.id_empresa = :id_empresa AND h.id = :id";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id', $id);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_Lista_Categoria($id_empresa) {
    // Create a new instance of the DatabasePDO class
    $connexion = new DatabasePDO($c_host, $c_user, $c_pass, $c_db);

    if ($id_empresa == "78") {
        $qCat = " and h.id > 300 ";
    } else {
        $qCat = "  ";
    }

    $sql = "SELECT h.* FROM tbl_tickets_categoria h WHERE h.id_empresa = :id_empresa $qCat ORDER BY orden ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $cod = $connexion->resultset();
    return $cod;
}


function Tickets_Lista_SubCategoria($id_categoria, $id_empresa) {
    if($id_categoria==""){
        $id_categoria="1";
    }
    // echo $id_categoria;
    $connexion = new DatabasePDO();
    $sql = "select h.* from tbl_tickets_subcategoria h
           where h.id_categoria= :id_categoria and  h.id_empresa='78' order by subcategoria ASC";
    //echo $sql;
    $connexion->query($sql);
    $connexion->bind(':id_categoria', $id_categoria);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_lista_tickets_data($id_empresa, $tipo, $rut, $perfil)
{
    //echo "<br>Tickets_lista_tickets_data($id_empresa, $tipo, $rut, $perfil";
    $connexion = new DatabasePDO();
    $Usu = Tickets_Busca_datos_admin($rut, $id_empresa);
    $id_empresa=78;
    $JQuery_Ejecutivo = "";
    $Jquery_Tipo = "";
    if ($tipo == "todos") {
        $Jquery_Tipo = "";
    }
    if ($perfil == "ejecutivo_superadmin") {
        $JQuery_Ejecutivo = " ";
    } elseif ($perfil == "ejecutivo_derivado") {
        $JQuery_Ejecutivo = " and (h.rut_derivado='$rut') ";
        if ($tipo == "") {
            $tipo = "derivado";
        }
        $Jquery_Tipo = " and h.estado='$tipo'";
        $Jquery_Tipo = " ";
    } elseif ($perfil == "ejecutivo") {
        $JQuery_Ejecutivo = " and (h.rut_ejecutivo='$rut' or h.rut_ejecutivo='' or h.rut_ejecutivo is null) ";
    } else {
        $JQuery_Ejecutivo = " and h.rut='$rut' ";
        $tipo = "todos";
    }

    if ($tipo == "") {
        $tipo = "pendiente";
    }
    $Jquery_Tipo = " and h.estado='$tipo' ";

    if ($tipo == "pendiente") {
        $Jquery_Tipo = " and (h.estado='pendiente' or h.estado='reabierto') ";
    }

    if ($perfil == "ejecutivo_superadmin") {
        $Jquery_Tipo = "  and h.estado<>'registro'  ";
    }

    if ($perfil == "colaborador") {
        $Jquery_Tipo = " ";
    }

    if ($perfil == "ejecutivo_derivado") {
        $Jquery_Tipo = " ";
    }

    $sql = "SELECT h.*, 
    	(SELECT sla FROM tbl_tickets_categoria WHERE id=h.id_categoria) AS sla_categoria
     FROM tbl_tickets h WHERE h.id_empresa='$id_empresa' $Jquery_Tipo $JQuery_Ejecutivo ORDER BY
     	estado='pendiente' DESC,
	    estado='derivado' DESC,
	    estado='respondido' DESC,
        estado='cerrado' DESC,
        fecha DESC, hora DESC";
    //echo "<h3>$sql</h3>";
    $connexion->query($sql);
    // $connexion->bind(':id_empresa', $id_empresa);
    // $connexion->bind(':rut', $rut);
    // $connexion->bind(':tipo', $tipo);
    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_lista_tickets_registro_data($id_empresa, $tipo, $rut, $perfil) {
    $connexion = new DatabasePDO();

    if ($perfil == "ejecutivo_superadmin") {
        $JQuery_Ejecutivo = " ";
    } elseif ($perfil == "ejecutivo_derivado") {
        $JQuery_Ejecutivo = " AND (h.rut_derivado = :rut) ";
        $tipo = "derivado";
    } elseif ($perfil == "ejecutivo") {
        $JQuery_Ejecutivo = " AND (h.rut_ejecutivo = :rut OR h.rut_ejecutivo = '' OR h.rut_ejecutivo IS NULL) ";
    } else {
        $JQuery_Ejecutivo = " AND h.rut_ejecutivo = :rut ";
        $tipo = "todos";
    }

    $tipo = "registro";
    $Jquery_Tipo = " AND h.estado = :tipo ";

    $sql = "SELECT h.*, 
                   (SELECT sla FROM tbl_tickets_categoria WHERE id = h.id_categoria) AS sla_categoria
            FROM tbl_tickets h 
            WHERE h.id_empresa = :id_empresa $Jquery_Tipo $JQuery_Ejecutivo 
            ORDER BY fecha DESC, hora DESC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':tipo', $tipo);

    $cod = $connexion->resultset();
    return $cod;
}

function Tickets_SaveNuevoTicket_data($asunto, $descripcion, $id_categoria, $id_subcategoria, $archivo, $rut, $id_empresa, $nombre_completo, $cargo, $email, $division, $empresa, $rut_col, $creado_admin) {
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $asunto = utf8_decode($asunto);
    $descripcion = utf8_decode($descripcion);
    $estado = "pendiente";

    $sql = "
    INSERT INTO tbl_tickets (rut,fecha,hora,id_categoria,id_subcategoria,asunto,descripcion,archivo,estado,fecha_estado,rut_ejecutivo,id_empresa, nombre_completo, cargo, email, division, empresa, creado_admin)
    VALUES (:rut_col, :fecha, :hora, :id_categoria, :id_subcategoria, :asunto, :descripcion, :archivo, :estado, '', '', :id_empresa, :nombre_completo, :cargo, :email, :division, :empresa, :creado_admin)";

    $connexion->query($sql);
    $connexion->bind(':rut_col', $rut_col);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':id_categoria', $id_categoria);
    $connexion->bind(':id_subcategoria', $id_subcategoria);
    $connexion->bind(':asunto', $asunto);
    $connexion->bind(':descripcion', $descripcion);
    $connexion->bind(':archivo', $archivo);
    $connexion->bind(':estado', $estado);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':nombre_completo', $nombre_completo);
    $connexion->bind(':cargo', $cargo);
    $connexion->bind(':email', $email);
    $connexion->bind(':division', $division);
    $connexion->bind(':empresa', $empresa);
    $connexion->bind(':creado_admin', $creado_admin);

    $connexion->execute();

    $sql = "SELECT id FROM tbl_tickets WHERE estado <> 'registro' ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();

    return $cod[0]->id;
}



function Tickets_SaveNuevoTicket_Registro_data($asunto, $descripcion, $id_categoria, $id_subcategoria, $archivo, $rut, $id_empresa, $nombre_completo, $cargo, $email, $division, $empresa) {
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $asunto = utf8_decode($asunto);
    $descripcion = utf8_decode($descripcion);
    $estado = "registro";

    $sql = "
        INSERT INTO tbl_tickets (rut, fecha, hora, id_categoria, id_subcategoria, asunto, descripcion, archivo, estado, fecha_estado, rut_ejecutivo, id_empresa, nombre_completo, cargo, email, division, empresa)
        VALUES (:rut, :fecha, :hora, :id_categoria, :id_subcategoria, :asunto, :descripcion, :archivo, :estado, '', :rut_ejecutivo, :id_empresa, :nombre_completo, :cargo, :email, :division, :empresa)
    ";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':id_categoria', $id_categoria);
    $connexion->bind(':id_subcategoria', $id_subcategoria);
    $connexion->bind(':asunto', $asunto);
    $connexion->bind(':descripcion', $descripcion);
    $connexion->bind(':archivo', $archivo);
    $connexion->bind(':estado', $estado);
    $connexion->bind(':rut_ejecutivo', $_SESSION["user_"]);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':nombre_completo', $nombre_completo);
    $connexion->bind(':cargo', $cargo);
    $connexion->bind(':email', $email);
    $connexion->bind(':division', $division);
    $connexion->bind(':empresa', $empresa);
    $connexion->execute();

    $sql = "
        SELECT id FROM tbl_tickets WHERE rut = :rut AND fecha = :fecha AND asunto = :asunto ORDER BY id DESC LIMIT 1
    ";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':asunto', $asunto);
    $connexion->execute();
    $cod = $connexion->resultset();

    return $cod[0]->id;
}

function Tickets_SaveNuevoTicket_Update_Registro_data($asunto, $descripcion, $id_categoria, $id_subcategoria, $archivo, $rut, $id_empresa, $nombre_completo, $cargo, $email, $division, $empresa, $id)
{
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $asunto = utf8_decode($asunto);
    $descripcion = utf8_decode($descripcion);
    $estado = "registro";

    $sql = "
        UPDATE tbl_tickets 
        SET rut = :rut, asunto = :asunto, descripcion = :descripcion, id_categoria = :id_categoria, id_subcategoria = :id_subcategoria 
        WHERE id = :id
    ";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':asunto', $asunto);
    $connexion->bind(':descripcion', $descripcion);
    $connexion->bind(':id_categoria', $id_categoria);
    $connexion->bind(':id_subcategoria', $id_subcategoria);
    $connexion->bind(':id', $id);

    $connexion->execute();

    $sql = "
        SELECT id 
        FROM tbl_tickets 
        WHERE rut = :rut 
        AND fecha = :fecha 
        AND asunto = :asunto 
        ORDER BY id DESC 
        LIMIT 1
    ";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':asunto', $asunto);

    $cod = $connexion->resultset();

    return $cod[0]->id;
}

function Tickets_IdCategoria_data($id_categoria, $id_empresa){

    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_tickets_categoria WHERE id = :id_categoria and id_empresa= :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_categoria', $id_categoria);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;

}

function Tickets_IdSubCategoria_data($id_subcategoria, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_tickets_subcategoria WHERE id = :id_subcategoria and id_empresa= :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_subcategoria', $id_subcategoria);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;


}
function TraeDatosUsuario($rut) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_usuario WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
