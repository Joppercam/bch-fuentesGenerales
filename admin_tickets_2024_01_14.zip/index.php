<?php
	session_start();error_reporting(0);
	ini_set('display_errors', 1);ini_set('display_startup_errors', 1);
    //error_reporting(E_ERROR | E_PARSE);
    //error_reporting(E_ALL);

    $seccion = $_GET["sw"];
	$seccion = str_replace("%", "", $seccion);
	$seccion = str_replace("'", "", $seccion);
	$seccion = str_replace('"', '', $seccion);
	$seccion = str_replace(' ', '', $seccion);
	$seccion = str_replace(" ", "", $seccion);
	$seccion = str_replace("'", "", $seccion);
	$seccion = str_replace('"', "", $seccion);
	$seccion = str_replace("+'", "", $seccion);
	$seccion = str_replace('--', "", $seccion);
	$seccion = str_replace('--', "", $seccion);
	$seccion = str_replace('--', "", $seccion);
	$seccion = str_replace('&', "", $seccion);
	$seccion = str_replace('.php', "", $seccion);
	$seccion = str_replace('.js', "", $seccion);
	$seccion = str_replace('%', "", $seccion);
	$seccion = str_replace('&', "", $seccion);
	$seccion = str_replace('&amp;', "", $seccion);
	$seccion = str_replace('<', "", $seccion); 
	$seccion = str_replace('&lt;', "", $seccion);
	$seccion = str_replace('>', "", $seccion);
	$seccion = str_replace('&gt;', "", $seccion);
	$seccion = str_replace('&quot;', "", $seccion);

if ($_SESSION["admin_"] == '' and $seccion != 'login' and $seccion != 'prevCa' and $seccion != 'entrada' and $seccion != 'entradaCap') {
	
				session_start();
				$_SESSION = array();
				if (ini_get("session.use_cookies")) {
			    $params = session_get_cookie_params();
			    setcookie(session_name(), '', time() - 42000,
			        $params["path"], $params["domain"],
			        $params["secure"], $params["httponly"]
			    );
				}
		// Finalmente, destruir la sesión.
		session_destroy();	
	
    echo "<script>location.href='https://www.masconectadosbch.cl/tickets/admin/?sw=login';</script>";
    
    
}

require_once "includes/include.php";
//echo Decodear3("enpGRVJPeTMvUGd3eWJkQ2ZldW9YZz09");exit;
  $arreglo_post = $_POST;
  $arreglo_get = $_GET;
  $_POST = VerificaArregloSQLInjectionV2($arreglo_post);
  $_GET = VerificaArregloSQLInjectionV2($arreglo_get);


  
  
$_SESSION['LAST_ACTIVITY'] = time();
if (!$seccion) {
    echo "<script>location.href='https://www.masconectadosbch.cl/tickets/admin/?sw=login';</script>";
} else if ($seccion == "login") {

    $PRINCIPAL = file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/login.html");
    $PRINCIPAL = str_replace("{HEAD}", file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/head.html"), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
} else if ($seccion == "loginu") {
    $PRINCIPAL = file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/login_user.html");
    $PRINCIPAL = str_replace("{HEAD}", file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/head.html"), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
} else if ($seccion == "login_id") {
    session_start();
// Destruir todas las variables de sesión.
    $_SESSION = array();
    session_destroy();
    $PRINCIPAL = file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/login_id.html");
    $PRINCIPAL = str_replace("{HEAD}", file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/head.html"), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
} 

if ($seccion == "entrada") {

	$id_empresa_desde_login = Decodear3($_POST["iem"]);
	$rut = ($_POST["userid"]);
	$rut=$_POST["userid"]; 
	//echo "<br>rut $rut, clave $clave ";
	
	$total_intentos=3;
	$rut = htmlentities(trim($rut));
	//echo "<br>2rut $rut, clave $clave ";

	$clave = (($_POST["password"]));
	$clave = htmlentities(trim($clave));
	
	//echo "<br>3rut $rut, clave $clave";
	
	$word = trim($_GET["word"]);
	$tema = Decodear3(trim(($_POST["tema"])));
	$rutcontodo = str_replace(" ", "", $rut);
	$rut = str_replace(".", "", $rut);
	$rut = str_replace(" ", "", $rut);
	$arreglo_rut = explode("-", $rut);
	$rut = $arreglo_rut[0];
	
	$existe_base = UsuarioAdminRutEmpresa($rut);
	
	if ($existe_base) {
			$rut = $existe_base[0]->user;
			if ($existe_base[0]->vigencia == 1) {
				echo "<script>    window.location='?sw=login'    </script>";	exit;
				InsertaAccesoIntentoAdmin($rut, "Bloqueo Admin por Intentos IpProxy");				
			}
		//echo "hol";
		$verifica_clave = VerificaClaveAccesoAdmin_v2($rut, $clave);
		//print_r($verifica_clave);
		//exit();
	
		
		//$clave=Encriptar("bch_innova_2019");
		//echo "<br>rut $rut, bch_innova_2019 clave $clave";
		if ($verifica_clave) {
				session_start();
				$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
				$_SESSION["user_"] = $rut;
        $_SESSION["admin_"] = $rut;
        $home_admin = $arrayEmpresa[0]->home_admin;
				$_SESSION["user_"] = $rut;
				$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
        $arrayEmpresa = BuscaEmpresaUserRut($rut);
        $home_admin = $arrayEmpresa[0]->home_admin;

				if($_SESSION["user_"]==""){
					InsertaAccesoIntentoAdmin($rut, "Bloqueo Admin por Intentos IpProxy");							
					echo "<script>location.href='?sw=login';</script>";
					exit;				
				}
				echo "
					<script>location.href='?sw=Tickets';</script>";
				exit;
		 
		}
		else {
			//echo "hola 2";
			// CLAVE INCORRECTA
			//echo "aca";
				InsertaAccesoIntentoAdmin($rut, "Bloqueo Admin por Intentos IpProxy");		
			session_start();
			$_SESSION["toku"] = Encodear3($rut);
			$_SESSION["tokc"] = Encodear3($clave);
			$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;

				echo " <script>alert('Ups, las credenciales no son correctas'); location.href='?sw=login';    </script>";exit;
			
		}
	} else {
				InsertaAccesoIntentoAdmin($rut, "Bloqueo Admin por Intentos IpProxy");		
		
			echo "<script>location.href='?sw=login';</script>";
			exit;	
	}
	
							InsertaAccesoIntentoAdmin($rut, "Bloqueo Admin por Intentos IpProxy");		

			echo "<script>location.href='?sw=login';</script>";
			exit;		
}
else if ($seccion == "prevCa") {
    $PRINCIPAL = file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/login_captcha.html");
    $PRINCIPAL = str_replace("{HEAD}", file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/head.html"), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
		exit();
}
else if ($seccion == "actualizacion_preguntas_respuestas") {
    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/usuarios_gestion/entorno.html"));
    $id_empresa = $_SESSION["id_empresa"];

		$descargar_xls = $_GET["descargar_xls"];
 		if($descargar_xls==1){	
 		    header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=SubirBitacoraMasiva.csv');
        echo "rut_de;fecha_recibida(dd/mm/yyyy);id_categoria;id_subcategorias;canal;descripcion;rut_ejecutivo\r\n";
        /*$Total_Rows_full = Lista_ausentismo_data($id_empresa);
	        foreach ($Total_Rows_full as $Unico) {
							echo $Unico->rut 
								. ";"  . $Unico->dv
								. ";"  . $Unico->tipo_ausentismo
								. ";"  . $Unico->nro_dias
								. ";"  . $Unico->fecha_desde
								. ";"  . $Unico->fecha_hasta
								. ";"  . $Unico->description
								. "\r\n";
					}*/
				exit();		
 		}

    $PRINCIPAL = str_replace("{ENTORNO}", lista_subida_bitacora(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/usuarios_gestion/entorno_usuarios_licencias.html")), $id_empresa, $temporal_actualizar, $procesar), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "actualizacion_bitacoras") {
    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/usuarios_gestion/entorno.html"));
    $id_empresa = $_SESSION["id_empresa"];

		$descargar_xls = $_GET["descargar_xls"];
 		if($descargar_xls==1){	
 		    header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=SubirBitacoraMasiva.csv');
        echo "rut_de;fecha_recibida(dd/mm/yyyy);id_categoria;id_subcategorias;canal;descripcion;rut_ejecutivo\r\n";
        /*$Total_Rows_full = Lista_ausentismo_data($id_empresa);
	        foreach ($Total_Rows_full as $Unico) {
							echo $Unico->rut 
								. ";"  . $Unico->dv
								. ";"  . $Unico->tipo_ausentismo
								. ";"  . $Unico->nro_dias
								. ";"  . $Unico->fecha_desde
								. ";"  . $Unico->fecha_hasta
								. ";"  . $Unico->description
								. "\r\n";
					}*/
				exit();		
 		}

    $PRINCIPAL = str_replace("{ENTORNO}", lista_subida_bitacora(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/usuarios_gestion/entorno_usuarios_licencias.html")), $id_empresa, $temporal_actualizar, $procesar), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);;
}
else if ($seccion == "bitacora_insert") {
    $id_empresa = $_SESSION["id_empresa"];
    //echo "<br /><br />"; print_r($_POST); echo "<br /><br />";print_r($_FILES); echo "<br /><br />";
    VerificaExtensionFilesAdmin($_FILES["file"]["name"]);
    if ( isset($_POST["action"]) ) {
			   if ( isset($_FILES["file"])) {
                   if ($_FILES["file"]["error"] > 0) {	exit();	}
			        else {
			             		//echo "Upload: " . $_FILES["file"]["name"] . "<br />";			             echo "Type: " . $_FILES["file"]["type"] . "<br />";
			             		//echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";			             echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
			             if (file_exists("upload/" . $_FILES["file"]["name"])) {
			             }
			             else {
			            $storagename = "uploaded_file.txt";
			            move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $storagename);
			            }
			        }
			     } else {
			             echo "No file selected <br />";
			     }
			     
			     if ( isset($storagename) && $file = fopen( "upload/" . $storagename , r ) ) {
			     	
			     	
						    //echo "File opened.<br />";
						    $firstline = fgets ($file, 10096 );
						        //Gets the number of fields, in CSV-files the names of the fields are mostly given in the first line
						    $num = strlen($firstline) - strlen(str_replace(";", "", $firstline));
						        //save the different fields of the firstline in an array called fields
						    $fields = array();
						    $fields = explode( ";", $firstline, ($num+1) );
						    $line = array();
						    $i = 0;

						    while ( $line[$i] = fgets ($file, 10096) ) {
						        $dsatz[$i] = array();
						        $dsatz[$i] = explode( ";", $line[$i], ($num+1) );
						        $i++;
						    }
						        //echo "<table>";						        //echo "<tr>";
						         $cuentaK=0;
						    for ( $k = 0; $k != ($num+1); $k++ ) {
						        //echo "<td>AA " . $fields[$k] . "</td>";
						       $cuentaK++;
						    }
						       // echo "</tr>";
						    foreach ($dsatz as $key => $number) {
						       // echo "<tr>";
						       $row_csv="";
						       $cuenta=0;
						        foreach ($number as $k => $content) {
						             		$cuenta++;
						             		$content = str_replace(' ', '', $content);
						            		
						            		if($cuenta=="2"){
						            			$array = explode("/", $content);
						            				$row_csv.="'".$array[2]."-".$array[1]."-".$array[0]."'";
						            			
						            			} else {
						            				$row_csv.="'".trim(strip_tags($content))."'";
						            			}
						            		
						            		if($cuenta<7){$row_csv.=",";}
						        }
						        Insert_Bitacora_data($row_csv);
						    }
						  // echo "</table>";
						}
			}
      
    unlink("upload/" . $storagename);

    echo "<script> alert('bitacora actualizada correctamente'); location.href='?sw=actualizacion_bitacoras';</script>";

    exit;
}
else if ($seccion == "Tickets_actualizacion_preguntas_respuestas") {

    $id_empresa = $_SESSION["id_empresa"];

		$descargar_xls = $_GET["descargar_xls"];
 		if($descargar_xls==1){	
 		    header('Content-type: application/csv');
        header('Content-Disposition: attachment; filename=Requerimientos_Preguntas_Respuestas_Actualizar.csv');
        echo "id_respuesta;respuesta;tip_ejecutivo;id_categoria;categoria;id_subcategoria;subcategoria;id_pregunta_1;pregunta_1;id_pregunta_2;pregunta_2;id_pregunta_3;pregunta_3;id_pregunta_4;pregunta_4;id_pregunta_5;pregunta_5;id_pregunta_6;pregunta_6;id_pregunta_7;pregunta_7;id_pregunta_8;pregunta_8;id_pregunta_9;pregunta_9;id_pregunta_10;pregunta_10\r\n";
        $Total_Rows_full = Ticket_Download_Preg_respuestas_Tickets_data($id_empresa);
	        foreach ($Total_Rows_full as $Unico) {
							echo $Unico->id_respuesta.";".$Unico->respuesta.";".$Unico->tip_ejecutivo.";".$Unico->id_categoria.";".$Unico->categoria.";".$Unico->id_subcategoria.";".$Unico->subcategoria.";".$Unico->id_pregunta_1.";".$Unico->pregunta_1.";".$Unico->id_pregunta_2.";".$Unico->pregunta_2.";".$Unico->id_pregunta_3.";".$Unico->pregunta_3.";".$Unico->id_pregunta_4.";".$Unico->pregunta_4.";".$Unico->id_pregunta_5.";".$Unico->pregunta_5.";".$Unico->id_pregunta_6.";".$Unico->pregunta_6.";".$Unico->id_pregunta_7.";".$Unico->pregunta_7.";".$Unico->id_pregunta_8.";".$Unico->pregunta_8.";".$Unico->id_pregunta_9.";".$Unico->pregunta_9.";".$Unico->id_pregunta_10.";".$Unico->pregunta_10. "\r\n";
					}
				exit();		
 		}

		$descargar_template_xls = $_GET["descargar_template_xls"];
 		if($descargar_template_xls==1){	
 		    header('Content-type: application/csv');
        header('Content-Disposition: attachment; filename=Requerimientos_Crear_Preguntas_Respuestas.csv');
        echo "respuesta;tip_ejecutivo;categoria;subcategoria;pregunta_1;pregunta_2;pregunta_3;pregunta_4;pregunta_5;pregunta_6;pregunta_7;pregunta_8;pregunta_9;pregunta_10\r\n";
				exit();		
 		}

    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", lista_gestion_usuarios_licencias(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_preguntas_respuestas_actualizacion.html")), $id_empresa, $temporal_actualizar, $procesar), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Descargas_Consultas_Rating") {
        $id_empresa = $_SESSION["id_empresa"];
		$tipo				= $_REQUEST["tipo"];
 		if($tipo=="consultas"){
 		    header('Content-type: application/csv');
            header('Content-Disposition: attachment; filename=Requerimientos_Consultas_Personas.csv');
            echo "rut;nombre_completo;pregunta;fecha;hora\r\n";
                $Total_Rows_full = Tickets_Consultas_Usuarios_2023_csv($_POST["fecha_inicio"], $_POST["fecha_termino"]);
	            foreach ($Total_Rows_full as $Unico) {
	        		    $Usu=TraeDatosUsuario($Unico->rut);
	        			$Unico->pregunta=LimpiaTextosTrim($Unico->pregunta);
	        			if($Usu[0]->nombre_completo==""){$Usu[0]->nombre_completo="Usuario No Vigente";}
							echo $Unico->rut.";".$Usu[0]->nombre_completo.";".$Unico->pregunta.";".$Unico->fecha.";".$Unico->hora."\r\n";
					}
				exit();		
 		}

 		if($tipo=="preguntas"){
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=Requerimientos_Consultas_Personas.csv');
                echo "IdPregunta;Pregunta;IdRespuesta;Respuesta;Categoria;SubCategoria;Topten;Pregunta2;Pregunta3;Pregunta4;Pregunta5;Pregunta6;Pregunta7;Pregunta8;Pregunta9;Pregunta10\r\n";
                $Total_Rows_full = TicketsPreguntas_2021_2020_csv();
	        foreach ($Total_Rows_full as $Unico) {
	        		    //$Usu=TraeDatosUsuario($Unico->rut);
	        			$Unico->pregunta1=LimpiaTextosTrim($Unico->pregunta1);
	        			$Unico->pregunta2=LimpiaTextosTrim($Unico->pregunta2);
	        			$Unico->pregunta3=LimpiaTextosTrim($Unico->pregunta3);
                        $Unico->pregunta4=LimpiaTextosTrim($Unico->pregunta4);
                        $Unico->pregunta5=LimpiaTextosTrim($Unico->pregunta5);
                        $Unico->pregunta6=LimpiaTextosTrim($Unico->pregunta6);
                        $Unico->pregunta7=LimpiaTextosTrim($Unico->pregunta7);
                        $Unico->pregunta8=LimpiaTextosTrim($Unico->pregunta8);
                        $Unico->pregunta9       =LimpiaTextosTrim($Unico->pregunta9);
                        $Unico->pregunta10      =LimpiaTextosTrim($Unico->pregunta10);
                        $Unico->respuesta       =LimpiaTextosTrim($Unico->respuesta);
                        $Unico->categoria       =LimpiaTextosTrim($Unico->categoria);
                        $Unico->subcategoria    =LimpiaTextosTrim($Unico->subcategoria);

                        echo $Unico->id.";".$Unico->pregunta1.";".$Unico->id_respuesta.";".$Unico->respuesta.
                        ";".$Unico->categoria.";".$Unico->subcategoria.";".$Unico->top_ten.";".$Unico->pregunta2.";".$Unico->pregunta3.
                        ";".$Unico->pregunta4.";".$Unico->pregunta5.";".$Unico->pregunta6.";".$Unico->pregunta7.";".$Unico->pregunta8.
                        ";".$Unico->pregunta9.";".$Unico->pregunta10."\r\n";

					}
				exit();
 		}

 		if($tipo=="rating"){

	    header('Content-type: application/csv');
        header('Content-Disposition: attachment; filename=Requerimientos_Rating_Preguntas_Cargadas.csv');
        echo "rut;nombre_completo;pregunta;rating;fecha;hora;comentario\r\n";
        $Total_Rows_full = Tickets_Rating_Usuarios_Preguntas_2023_csv($_POST["fecha_inicio"], $_POST["fecha_termino"]);
	        foreach ($Total_Rows_full as $Unico) {

	        			$Usu=TraeDatosUsuario($Unico->rut);

	        			$Unico->pregunta=LimpiaTextosTrim($Unico->pregunta);
	        			if($Usu[0]->nombre_completo==""){$Usu[0]->nombre_completo="Usuario No Vigente";}

                                if($Unico->pregunta2021==""){
                                    $Unico->pregunta2021=$Unico->pregunta;
                                }
	        	
	        	if($Unico->rating=="1"){$rating="RESPUESTA UTIL";}
	        	if($Unico->rating=="2"){$rating="RESPUESTA NO UTIL";}


                $Unico->pregunta2021=LimpiaTextosTrim($Unico->pregunta2021);
                $Unico->comentario=LimpiaTextosTrim($Unico->comentario);

							echo $Unico->rut.";".$Usu[0]->nombre_completo.";".$Unico->pregunta2021.";".$rating.";".$Unico->fecha.";".$Unico->hora.";".$Unico->comentario."\r\n";
					}
				exit();		
 		}

    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", lista_gestion_usuarios_licencias(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_preguntas_respuestas_actualizacion.html")), $id_empresa, $temporal_actualizar, $procesar), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_insert_tbl_preguntas_respuestas") {
 	
    $id_empresa = $_SESSION["id_empresa"];
    		
    /*echo "<br /><br />Tickets_insert_tbl_preguntas_respuestas<br>"; 
    	print_r($_POST); echo "<br /><br />";print_r($_FILES); 
    echo "<br /><br />";	*/
    
    if ( isset($_POST["action"]) ) {
			   if ( isset($_FILES["file"])) {
                   if ($_FILES["file"]["error"] > 0) {	exit();	}
			        else {
			             		//echo "Upload: " . $_FILES["file"]["name"] . "<br />";			             echo "Type: " . $_FILES["file"]["type"] . "<br />";
			             		//echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";			             echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
			             if (file_exists("upload/" . $_FILES["file"]["name"])) {
					            //	echo $_FILES["file"]["name"] . " already exists. ";
			             }
			             else {
			                    //Store file in directory "upload" with the name of "uploaded_file.txt"
			            $storagename = "uploaded_file.txt";
			            move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $storagename);
			            					//echo "Stored in: " . "upload/" . $_FILES["file"]["name"] . "<br />";
			            }
			        }
			     } else {
			             echo "No file selected <br />";
			     }
			     
			     if ( isset($storagename) && $file = fopen( "upload/" . $storagename , r ) ) {
			     	
						    //echo "File opened.<br />";
						    $firstline = fgets ($file, 10096 );
						        //Gets the number of fields, in CSV-files the names of the fields are mostly given in the first line
						    $num = strlen($firstline) - strlen(str_replace(";", "", $firstline));
						        //save the different fields of the firstline in an array called fields
						    $fields = array();
						    $fields = explode( ";", $firstline, ($num+1) );
						    $line = array();
						    $i = 0;

						    while ( $line[$i] = fgets ($file, 10096) ) {
						        $dsatz[$i] = array();
						        $dsatz[$i] = explode( ";", $line[$i], ($num+1) );
						        $i++;
						    }
						        //echo "<table>";						        //echo "<tr>";
						         $cuentaK=0;
						    for ( $k = 0; $k != ($num+1); $k++ ) {
						        //echo "<td>AA " . $fields[$k] . "</td>";
						       $cuentaK++;
						    }
						       // echo "</tr>";
						    foreach ($dsatz as $key => $number) {
						       // echo "<tr>";
						       $row_csv="";
						       $cuenta=0;
						        foreach ($number as $k => $content) {
						             		$cuenta++;						            
						            	// echo "<br> number ".$number." k ".$k." content ".$content;						            
						            	if($k=="0"){$id_respuesta		=$content;}					            	
						            	if($k=="1"){$respuesta			=$content;}
						            	if($k=="2"){$tip						=$content;}						            
						            	if($k=="7"){$id_pregunta1		=$content;}
						            	if($k=="8"){$pregunta1			=$content;}
						            	if($k=="9"){$id_pregunta2		=$content;}
						            	if($k=="10"){$pregunta2			=$content;}
						            	if($k=="11"){$id_pregunta3	=$content;}
						            	if($k=="12"){$pregunta3			=$content;}
						            	if($k=="13"){$id_pregunta4	=$content;}
						            	if($k=="14"){$pregunta4			=$content;}
						            	if($k=="15"){$id_pregunta5	=$content;}
						            	if($k=="16"){$pregunta5			=$content;}
						            	if($k=="17"){$id_pregunta6	=$content;}
						            	if($k=="18"){$pregunta6			=$content;}
						            	if($k=="19"){$id_pregunta7	=$content;}
						            	if($k=="20"){$pregunta7			=$content;}
						            	if($k=="21"){$id_pregunta8	=$content;}
						            	if($k=="22"){$pregunta8			=$content;}
						            	if($k=="23"){$id_pregunta9	=$content;}
						            	if($k=="24"){$pregunta9			=$content;}
						            	if($k=="25"){$id_pregunta10	=$content;}
						            	if($k=="26"){$pregunta10		=$content;}
						        }

								Tickets_Update_Respuestas_2020_csv($id_respuesta, $respuesta, $tip);
								Tickets_Update_Preguntas_2020_csv($id_pregunta1, $pregunta1);
								Tickets_Update_Preguntas_2020_csv($id_pregunta2, $pregunta2);
								Tickets_Update_Preguntas_2020_csv($id_pregunta3, $pregunta3);
								Tickets_Update_Preguntas_2020_csv($id_pregunta4, $pregunta4);
								Tickets_Update_Preguntas_2020_csv($id_pregunta5, $pregunta5);
								Tickets_Update_Preguntas_2020_csv($id_pregunta6, $pregunta6);
								Tickets_Update_Preguntas_2020_csv($id_pregunta7, $pregunta7);
								Tickets_Update_Preguntas_2020_csv($id_pregunta8, $pregunta8);
								Tickets_Update_Preguntas_2020_csv($id_pregunta9, $pregunta9);
								Tickets_Update_Preguntas_2020_csv($id_pregunta10, $pregunta10);
					    }
						  // echo "</table>";
						}
			}

    echo "<script> alert('base actualizada correctamente'); location.href='?sw=Tickets_actualizacion_preguntas_respuestas';</script>";
    exit;
}
else if ($seccion == "Tickets_insert_Create_tbl_preguntas_respuestas") {

    $id_empresa = $_SESSION["id_empresa"];
    //echo "<br>_POST<br>";		    print_r($_POST);    //echo "<br>_FILES<br>";	    print_r($_FILES);	    echo "<br>";
    if ( isset($_POST["action"]) ) {
			   if ( isset($_FILES["file"])) {
                   if ($_FILES["file"]["error"] > 0) {	exit();	}
			        else {
			             		//echo "Upload: " . $_FILES["file"]["name"] . "<br />";			             echo "Type: " . $_FILES["file"]["type"] . "<br />";
			             		//echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";			             echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
			             if (file_exists("upload/" . $_FILES["file"]["name"])) {
					            //	echo $_FILES["file"]["name"] . " already exists. ";
			             }
			             else {
			                    //Store file in directory "upload" with the name of "uploaded_file.txt"
			            $storagename = "uploaded_file.txt";
			            move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $storagename);
			            					//echo "Stored in: " . "upload/" . $_FILES["file"]["name"] . "<br />";
			            }
			        }
			     } else {
			             echo "No file selected <br />";
			     }
			     	//echo "<h1>a</h1>";
			     if ( isset($storagename) && $file = fopen( "upload/" . $storagename , r ) ) {
						//echo "<h1>b</h1>";
						    $firstline = fgets ($file, 10096 );
						        //Gets the number of fields, in CSV-files the names of the fields are mostly given in the first line
						    $num = strlen($firstline) - strlen(str_replace(";", "", $firstline));
						        //save the different fields of the firstline in an array called fields
						    $fields = array();
						    $fields = explode( ";", $firstline, ($num+1) );
						    $line = array();
						    $i = 0;

						    while ( $line[$i] = fgets ($file, 10096) ) {
						        $dsatz[$i] = array();
						        $dsatz[$i] = explode( ";", $line[$i], ($num+1) );
						        $i++;
						    }
						        //echo "<table>";						        //echo "<tr>";
						         $cuentaK=0;
						    for ( $k = 0; $k != ($num+1); $k++ ) {
						        //echo "<td>AA " . $fields[$k] . "</td>";
						       $cuentaK++;
						    }
						    foreach ($dsatz as $key => $number) {
						       $row_csv="";
						       $cuenta=0;
						        foreach ($number as $k => $content) {
														//echo "<br>K ".$k;	echo "<br>Content ".$content;													
													if($k=="0") 	{ $resp[0]=$content;}
													if($k=="1") 	{ $resp[1]=$content;}													
													if($k=="2") 	{ $categoria=$content;}
													if($k=="3") 	{ $subcategoria=$content;}													
													if($k=="4") 	{ 	$preg[1]=$content;	}
													if($k=="5") 	{ 	$preg[2]=$content;	}
													if($k=="6") 	{ 	$preg[3]=$content;	}
													if($k=="7") 	{ 	$preg[4]=$content;	}
													if($k=="8") 	{ 	$preg[5]=$content;	}
													if($k=="9") 	{ 	$preg[6]=$content;	}
													if($k=="10") 	{ 	$preg[7]=$content;	}
													if($k=="11") 	{ 	$preg[8]=$content;	}
													if($k=="12") 	{ 	$preg[9]=$content;	}
													if($k=="13") 	{		$preg[10]=$content;	}
	
						        }
	
													//echo "<br>Respuesta<br>";			print_r($resp);													//echo "<br>categoria<br>"; 		echo ($categoria);
													//echo "<br>subcategoria<br>"; 	echo ($subcategoria);										//echo "<br>Pregunta<br>"; 			print_r($preg);
													Ticket_Create_Insert_Respuestas($resp[0], $resp[1], $categoria, $subcategoria, $preg[1], $preg[2], $preg[3], $preg[4], $preg[5], $preg[6], $preg[7], $preg[8], $preg[9], $preg[10], $id_empresa);
						       
						    }
						}
			}
   	
   	Ticket_delete_pregunta_vacia_data($id_empresa);
   	
    echo "<script> alert('base actualizada correctamente'); location.href='?sw=Tickets_actualizacion_preguntas_respuestas';</script>";
    exit;
}
else if($seccion=="ColocaSubCategoriaDadaCategoria"){
 	$id_empresa = $_SESSION["id_empresa"];
	$id_categoria=$_POST["categoria"];

    $lista_subcategoria	=	Tickets_Lista_SubCategoria($id_categoria, $id_empresa);
    foreach($lista_subcategoria as $unicosubcat){
        $option_subcat.="<option value='".($unicosubcat->id)."'>".($unicosubcat->subcategoria)."</option>";
    }    
	echo  $option_subcat;
}
else if ($seccion == "Tickets") {
    $PRINCIPAL 				= FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 							= $_SESSION["user_"];
    $tipo = isset($_GET["tipo"]) ? $_GET["tipo"] : "";
    $vista = isset($_GET["vista"]) ? $_GET["vista"] : "";
    $id_categoria = "";
    
    CheckSesionActiva($_SESSION["user_"]);

    $tipoUsuarioAdmin	=	Tickets_Busca_datos_admin($rut, $id_empresa);
    //print_r($tipoUsuarioAdmin[0]);
    //echo "nombre $nombre;";
    //vista Derivados
		//cho "<br>TICKETS<br>start $start end $end , total horas $go ";    
    
		if($tipoUsuarioAdmin[0]->go=="3"){
			$PRINCIPAL 				= str_replace("{ENTORNO_MEDICIONES}", Tickets_lista(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_tickets_derivados.html")), $id_empresa, $id_categoria, $tipo, $rut, "especialista"), $PRINCIPAL);	
		} else {
			$PRINCIPAL 				= str_replace("{ENTORNO_MEDICIONES}", Tickets_lista(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_tickets.html")), $id_empresa, $id_categoria, $tipo, $rut, $vista), $PRINCIPAL);	
		}
    
     $PRINCIPAL = str_replace("{NOMBRE_USUARIO_TICKET}", 	($tipoUsuarioAdmin[0]->nombre_completo), $PRINCIPAL);
     $PRINCIPAL = str_replace("{EMPRESA_TICKET}", 				$tipoUsuarioAdmin[0]->empresa, $PRINCIPAL);
    //print_r($_GET);

    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Dashboard") {
	
    $PRINCIPAL 				    = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa 			    = $_SESSION["id_empresa"];
    $rut 						= $_SESSION["user_"];
    $tipo 						= $_GET["tipo"];
    $vista 						= $_GET["vista"];

    $year_default=date("Y");
    $month_default=date("m");

    if($_POST["month"]<>"") {$month_default =   $_POST["month"];}
    if($_POST["year"]<>"")  {$year_default  =   $_POST["year"];}
    $YearMonth=Tickets_MonthYear();
    //print_r($YearMonth);
    //echo "<br>year_default $year_default month_default $month_default<br>";

    foreach($YearMonth[0] as $y){
        //echo "<br>->".$y->year;

        if($y->year==$year_default){
            $row_y.="<option value='".$y->year."' selected>".$y->year."</option>";
        } else {
            $row_y.="<option value='".$y->year."'>".$y->year."</option>";
        }

    }

    foreach($YearMonth[1] as $m){
        //echo "<br>->".$m->month;
        if($m->month==$month_default){
            $row_m.="<option value='".$m->month."' selected>".$m->month."</option>";
        } else {
            $row_m.="<option value='".$m->month."'>".$m->month."</option>";
            }
    }



    CheckSesionActiva($_SESSION["user_"]);

        $Tickets_Array		= Tickets_Dashboard_Graf_data($rut, $id_empresa);
		$cerrado_por_colaborador=0;
		$cerrado_por_ejecutivo=0;
		$cerrado_por_tiempo=0;
		$respondido=0;
		$abierto=0;
		
	foreach ($Tickets_Array as $unico){
			//echo "<br>";	print_r($unico);
			if($unico->cierre_descripcion=="Cerrado por Colaborador" and $unico->estado=="cerrado"){
				$cerrado_por_colaborador=$unico->cuenta;
			}
			if($unico->cierre_descripcion=="Cerrado por Ejecutivo" and $unico->estado=="cerrado"){
				$cerrado_por_ejecutivo=$unico->cuenta;
			}
			if($unico->cierre_descripcion=="Cierre Requerimiento Respondido por Tiempo" and $unico->estado=="cerrado"){
				$cerrado_por_tiempo=$unico->cuenta;
			}
			if($unico->estado=="respondido"){
				$respondido=$unico->cuenta;
			}
			if($unico->estado=="abierto"){
				$abierto=$unico->cuenta;
			}
		}
		
	$PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", 				            FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_tickets_dashboard.html")), $PRINCIPAL);
 	$PRINCIPAL = str_replace("{CERRADO_COLABORADOR}", 				            $cerrado_por_colaborador, $PRINCIPAL);
    $PRINCIPAL = str_replace("{CERRADO_EJECUTIVO}", 					        $cerrado_por_ejecutivo, $PRINCIPAL);
    $PRINCIPAL = str_replace("{CERRADO_TIEMPO}", 							    $cerrado_por_tiempo, $PRINCIPAL);
    $PRINCIPAL = str_replace("{RESPONDIDO}", 									$respondido, $PRINCIPAL);
    $PRINCIPAL = str_replace("{ABIERTO}", 										$abierto, $PRINCIPAL);


    if($month_default=="1") {$month_default_txt="Enero";}
    if($month_default=="2") {$month_default_txt="Febrero";}
    if($month_default=="3") {$month_default_txt="Marzo";}
    if($month_default=="4") {$month_default_txt="Abril";}
    if($month_default=="5") {$month_default_txt="Mayo";}
    if($month_default=="6") {$month_default_txt="Junio";}
    if($month_default=="7") {$month_default_txt="Julio";}
    if($month_default=="8") {$month_default_txt="Agosto";}
    if($month_default=="9") {$month_default_txt="Septiembre";}
    if($month_default=="10") {$month_default_txt="Octubre";}
    if($month_default=="11") {$month_default_txt="Noviembre";}
    if($month_default=="12") {$month_default_txt="Diciembre";}


    $PRINCIPAL = str_replace("{MES_SELECCIONADO_TXT}", 										    $month_default_txt, $PRINCIPAL);
    $PRINCIPAL = str_replace("{YEAR_SELECCIONADO_TXT}", 										$year_default, $PRINCIPAL);
    $PRINCIPAL = str_replace("{OPTIONS_MONTH_SELECTED}", 										$row_m, $PRINCIPAL);
    $PRINCIPAL = str_replace("{OPTIONS_YEAR_SELECTED}", 										$row_y, $PRINCIPAL);

  	$Tickets_Tiempos_Array		= Tickets_Dashboard_Graf_Tiempos_data($rut, $id_empresa);
		foreach ($Tickets_Tiempos_Array as $unico){
				if($unico->horas_transcurridas>0 and $unico->horas_transcurridas<=12){
					$cuenta_A=$cuenta_A+$unico->cuenta;
				}
		}
		
											$min="-1"; $max="12";
$Arreglo_cuenta[1]	=	Tickets_Dashboard_Graf_Tiempos_min_max_data($rut, $min, $max, $id_empresa);
											$min="12"; $max="24";
$Arreglo_cuenta[2]	=	Tickets_Dashboard_Graf_Tiempos_min_max_data($rut, $min, $max, $id_empresa);
											$min="24"; $max="36";
$Arreglo_cuenta[3]	=	Tickets_Dashboard_Graf_Tiempos_min_max_data($rut, $min, $max, $id_empresa);
											$min="36"; $max="48";
$Arreglo_cuenta[4]	=	Tickets_Dashboard_Graf_Tiempos_min_max_data($rut, $min, $max, $id_empresa);
											$min="48"; $max="100";
$Arreglo_cuenta[5]	=	Tickets_Dashboard_Graf_Tiempos_min_max_data($rut, $min, $max, $id_empresa);

        $Arreglo_total_cuentas=
		$Arreglo_cuenta[1]+
		$Arreglo_cuenta[2]+
		$Arreglo_cuenta[3]+
		$Arreglo_cuenta[4]+
		$Arreglo_cuenta[5];
		$row_graf_tiempos.="['0 a 12 hrs',    	".$Arreglo_cuenta[1]."],";
		$row_graf_tiempos.="['12 a 24 hrs',    	".$Arreglo_cuenta[2]."],";
		$row_graf_tiempos.="['24 a 36 hrs',    	".$Arreglo_cuenta[3]."],";
		$row_graf_tiempos.="['36 a 48 hrs',    	".$Arreglo_cuenta[4]."],";
		$row_graf_tiempos.="['48+ hrs',    			".$Arreglo_cuenta[5]."],";

    $PRINCIPAL = str_replace("{TIEMPOS_RESPUESTA_CANTIDAD}", 	$row_graf_tiempos, $PRINCIPAL);
    
    $tipo="requerimiento";
		// dashboard por categoria / numero
  	$Tickets_Categoria_Array		= Tickets_Dashboard_Graf_Categorias_data($rut, $tipo, $id_empresa);
	  //print_r($Tickets_Tiempos_Array);
		foreach ($Tickets_Categoria_Array as $unico){
				$row_graf_catg.="['".($unico->categoria)."',    ".$unico->cuenta."],";
		}

    $PRINCIPAL = str_replace("{TICKETS_POR_CATEGORIA_CANTIDAD}", 	$row_graf_catg, $PRINCIPAL);    
  	$Tickets_SubCategoria_Array		= Tickets_Dashboard_Graf_SubCategorias_data($rut, $tipo, $id_empresa);
	  //print_r($Tickets_Tiempos_Array);
		foreach ($Tickets_SubCategoria_Array as $unico){
				$row_graf_subcatg.="['".($unico->subcategoria)."',    ".$unico->cuenta."],";
		}

    $PRINCIPAL = str_replace("{TICKETS_POR_SUBCATEGORIA_CANTIDAD}", 	$row_graf_catg, $PRINCIPAL);
    $Tickets_Canal_Array			    = Tickets_Dashboard_Graf_Canal_Bitacora_data($rut, $tipo, $fecha_inicio, $fecha_termino, $id_empresa);$Tickets_Canal_2_Array		    = Tickets_Dashboard_Graf_Canal_Bitacora_2_data($rut, $tipo, $fecha_inicio, $fecha_termino, $id_empresa);
    $row_graf_cat_canal_cantidad.="['Presencial ',    	    ".$Tickets_Canal_Array[0]->cuenta."],";
    $row_graf_cat_canal_cantidad.="['Telefono',    			".$Tickets_Canal_Array[1]->cuenta."],";
    $row_graf_cat_canal_cantidad.="['Requerimiento',        ".$Tickets_Canal_2_Array[0]->cuenta."],";
    $PRINCIPAL = str_replace("{CANAL_ATENCION_CANTIDAD}", 	$row_graf_cat_canal_cantidad, $PRINCIPAL);
    $PRINCIPAL = str_replace("{NOMBRE_USUARIO_TICKET}", 	($tipoUsuarioAdmin[0]->nombre_completo), $PRINCIPAL);
    $PRINCIPAL = str_replace("{EMPRESA_TICKET}", 			$tipoUsuarioAdmin[0]->empresa, $PRINCIPAL);
    //print_r($_GET);

    $Estadisticas_Visitas=Tickets_Estadisticas_Vistas_Home_Cap_2022($id_empresa, $year_default);
        foreach ($Estadisticas_Visitas as $unico){
			$row_estadisticas_visitas.="['".$unico->fecha_year."-".$unico->fecha_month."', ".$unico->cuenta."],";
		}
       // echo "<br>-> ".$row_estadisticas_visitas;
    $PRINCIPAL = str_replace("{FECHA_VISITAS_TICKETS_2020}", 			$row_estadisticas_visitas, $PRINCIPAL);



$Estadisticas_Visitas_diario=Tickets_Estadisticas_Vistas_Home_Diario_Cap_2022($id_empresa,$month_default,$year_default);
        foreach ($Estadisticas_Visitas_diario as $unico){
			$row_estadisticas_visitas_diario.="['".$unico->fecha."', ".$unico->cuenta."],";
		}
       // echo "<br>-> ".$row_estadisticas_visitas;
    $PRINCIPAL = str_replace("{FECHA_VISITAS_DIARIAS_TICKETS_2020}", 			$row_estadisticas_visitas_diario, $PRINCIPAL);

    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Dashboard_Bitacora") {
		//	print_r($_POST);
		 CheckSesionActiva($_SESSION["user_"]);
		$fecha_inicio				=$_POST["fecha_inicio"];
		$fecha_termino			=$_POST["fecha_termino"];
		$tipo_requerimiento	=$_POST["tipo_requerimiento"];
	
	
    $PRINCIPAL 				= FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 							= $_SESSION["user_"];
    $tipo 						= $_GET["tipo"];
    $vista 						= $_GET["vista"];
    $tipo="todos";
		$PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_tickets_dashboard_bitacora.html")), $PRINCIPAL);	
 		$PRINCIPAL = str_replace("{CERRADO_COLABORADOR}", 				$cerrado_por_colaborador, $PRINCIPAL);
    $PRINCIPAL = str_replace("{CERRADO_EJECUTIVO}", 					$cerrado_por_ejecutivo, $PRINCIPAL);
    $PRINCIPAL = str_replace("{CERRADO_TIEMPO}", 						$cerrado_por_tiempo, $PRINCIPAL);
    $PRINCIPAL = str_replace("{RESPONDIDO}", 								$respondido, $PRINCIPAL);
    $PRINCIPAL = str_replace("{ABIERTO}", 										$abierto, $PRINCIPAL);

    $PRINCIPAL = str_replace("{FECHA_INICIO}", 										$_POST["fecha_inicio"], $PRINCIPAL);
    $PRINCIPAL = str_replace("{FECHA_TERMINO}", 									$_POST["fecha_termino"], $PRINCIPAL);
    $PRINCIPAL = str_replace("{TIPO_REQUERIMIENTO}", 							$_POST["tipo_requerimiento"], $PRINCIPAL);

		$fecha_inicio				=$_POST["fecha_inicio"];
		$fecha_termino			=$_POST["fecha_termino"];
		$tipo_requerimiento	=$_POST["tipo_requerimiento"];
	
	
	
  	$Cat		= Tickets_Dashboard_Graf_Categorias_data($rut, $tipo_requerimiento, $fecha_inicio, $fecha_termino, $id_empresa, "sinlimite");
  	//print_r($Cat);
  	//exit();

	  
		$total_cuenta=0;
		foreach ($Cat as $unico){

				$total_cuenta=$unico->cuenta+$total_cuenta;
		}

		
  	$Cat		= Tickets_Dashboard_Graf_Categorias_data($rut, $tipo_requerimiento, $fecha_inicio, $fecha_termino, $id_empresa);
		foreach ($Cat as $unico){
				//$row_graf_catg.="['".($unico->categoria)."',    ".$unico->cuenta."],";
				$porcentaje=round(100*$unico->cuenta/$total_cuenta);
				$suma_cuenta=$unico->cuenta+$suma_cuenta;
				$row_graf_catg.="
						<tr>
							<td>".($unico->categoria)."</td>
							<td>".($unico->cuenta)."</td>
							<td>".($porcentaje)."%</td>
							<td>
								<div class='progress'>
								  <div class='progress-bar progress-bar-info' role='progressbar' 
									  aria-valuenow='".$porcentaje."' aria-valuemin='0' aria-valuemax='100' style='width: ".$porcentaje."%'>
								    <span class='sr-only'>".$porcentaje."% Complete</span>
								  </div>
								</div>
							</td>							
						</tr>
						";
		}
		
		$row_graf_catg.="
						<tr>
							<td>Todos</td>
							<td>".$total_cuenta."</td>
							<td></td>
							<td>
								
							</td>							
						</tr>
						";
		

    $PRINCIPAL = str_replace("{Tickets_Dashboard_Bitacora}", 	$row_graf_catg, $PRINCIPAL);    


		// dashboard por categoria / numero
  	$Tickets_SubCategoria_Array		= Tickets_Dashboard_Graf_SubCategorias_data($rut, $tipo_requerimiento, $fecha_inicio, $fecha_termino, $id_empresa, "sinlimite");
	  //print_r($Tickets_Tiempos_Array);

		$total_cuenta=0;
		foreach ($Tickets_SubCategoria_Array as $unico){

				$total_cuenta=$unico->cuenta+$total_cuenta;
		}

  	$Tickets_SubCategoria_Array		= Tickets_Dashboard_Graf_SubCategorias_data($rut, $tipo_requerimiento, $fecha_inicio, $fecha_termino, $id_empresa);
		
		foreach ($Tickets_SubCategoria_Array as $unico){
				//$row_graf_catg.="['".($unico->categoria)."',    ".$unico->cuenta."],";
				$porcentaje=round(100*$unico->cuenta/$total_cuenta);
				
				$suma_subcuenta=$unico->cuenta+$suma_subcuenta;
				$row_graf_subcatg.="
						<tr>
							<td>".($unico->subcategoria)."</td>
							<td>".($unico->cuenta)."</td>
							<td>".($porcentaje)."%</td>
							<td>
								<div class='progress'>
								  <div class='progress-bar progress-bar-info' role='progressbar' 
									  aria-valuenow='".$porcentaje."' aria-valuemin='0' aria-valuemax='100' style='width: ".$porcentaje."%'>
								    <span class='sr-only'>".$porcentaje."% Complete</span>
								  </div>
								</div>
							</td>							
						</tr>
						";
		}


		$row_graf_subcatg.="
						<tr>
							<td>Todos</td>
							<td>".$total_cuenta."</td>
							<td></td>
							<td>
								
							</td>							
						</tr>
						";

    $PRINCIPAL = str_replace("{TICKETS_POR_SUBCATEGORIA_CANTIDAD}", 	$row_graf_subcatg, $PRINCIPAL);    

		$Lista_Ejecutivo=Tickets_dashboard_Tiempos_ejecutivo_lista($id_empresa);
		foreach ($Lista_Ejecutivo as $unico){
			
			$ListaDatos=Tickets_dashboard_Tiempos_ejecutivo_por_rut($id_empresa, $unico->rut_ejecutivo, $fecha_inicio, $fecha_termino);
			//print_r($ListaDatos);
			
			if($ListaDatos[0]->num_bitacora==""){$ListaDatos[0]->num_bitacora=0;}
			if($ListaDatos[0]->num_requerimientos==""){$ListaDatos[0]->num_requerimientos=0;}
			if($ListaDatos[0]->promedio_horas==""){$ListaDatos[0]->promedio_horas=0;}
			
				$row_graf_ejecu.="
						<tr>
							<td>".($unico->nombre)."</td>
							<td>".($ListaDatos[0]->num_bitacora)."</td>
							<td>".($ListaDatos[0]->num_requerimientos)."</td>
							<td>".($ListaDatos[0]->promedio_horas)." hrs</td>
						</tr>
						";			
			
			$suma_num_bitacora=$suma_num_bitacora+$ListaDatos[0]->num_bitacora;
			$suma_num_req=$suma_num_req+$ListaDatos[0]->num_requerimientos;
			$suma_num_prom=$suma_num_prom+$ListaDatos[0]->promedio_horas;
		}

 $PRINCIPAL = str_replace("{TICKETS_POR_EJECUTIVO_CANTIDAD}", 	$row_graf_ejecu, $PRINCIPAL);   

	$Tickets_Ejecutivo_Array	= Tickets_dashboard_Tiempos_ejecutivo($id_empresa, $fecha_inicio, $fecha_termino);
 		foreach ($Tickets_Ejecutivo_Array as $unico){
				//$row_graf_catg.="['".($unico->categoria)."',    ".$unico->cuenta."],";
				//$porcentaje=round(100*$unico->cuenta/$total_cuenta);
				/*$row_graf_ejecu.="
						<tr>
							<td>".($unico->nombre)."</td>
							<td>".($unico->num_bitacora)."</td>
							<td>".($unico->num_requerimientos)."</td>
							<td>".($unico->promedio_horas)." hrs</td>
						</tr>
						";*/
		}   
      


	$Tickets_Ejecutivo_Total_Array	= Tickets_dashboard_Tiempos_ejecutivo_total($id_empresa, $fecha_inicio, $fecha_termino);
 		foreach ($Tickets_Ejecutivo_Total_Array as $unico){
				//$row_graf_catg.="['".($unico->categoria)."',    ".$unico->cuenta."],";
				//$porcentaje=round(100*$unico->cuenta/$total_cuenta);
				$row_graf_ejecut.="
						<tr>
							<td>Total Ejecutivos</td>
							<td>".($suma_num_bitacora)."</td>
							<td>".($suma_num_req)."</td>
							<td>".($suma_num_prom)." hrs</td>
						</tr>
						";
		}   
      $PRINCIPAL = str_replace("{TICKETS_POR_EJECUTIVO_TOTAL_CANTIDAD}", 	$row_graf_ejecut, $PRINCIPAL);  

//echo $_POST["tipo_requerimiento"];

if($_POST["tipo_requerimiento"]=="Bitacora"){
	
} else {
	$Tickets_Derivado_Array	= Tickets_dashboard_Tiempos_Derivados_total($id_empresa, $fecha_inicio, $fecha_termino);
}

	
 		foreach ($Tickets_Derivado_Array as $unico){
				//$row_graf_catg.="['".($unico->categoria)."',    ".$unico->cuenta."],";
				//$porcentaje=round(100*$unico->cuenta/$total_cuenta);
				$row_graf_derivado.="
						<tr>
							<td>".($unico->Derivado)."</td>
							<td>".($unico->num_requerimientos)."</td>
							<td>".($unico->promedio_horas)." hrs</td>
						</tr>
						";
		}   
      $PRINCIPAL = str_replace("{TICKETS_POR_DERIVADO_CANTIDAD}", 	$row_graf_derivado, $PRINCIPAL);    

  
    $PRINCIPAL = str_replace("{NOMBRE_USUARIO_TICKET}", 	($tipoUsuarioAdmin[0]->nombre_completo), $PRINCIPAL);
    $PRINCIPAL = str_replace("{EMPRESA_TICKET}", 				$tipoUsuarioAdmin[0]->empresa, $PRINCIPAL);
    //print_r($_GET);

    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Dashboard_Preguntas") {
	 CheckSesionActiva($_SESSION["user_"]);
	$fecha_inicio				=$_POST["fecha_inicio"];
	$fecha_termino			=$_POST["fecha_termino"];
	$tipo_requerimiento	=$_POST["tipo_requerimiento"];
    $PRINCIPAL 				= FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 							= $_SESSION["user_"];
    $tipo 						= $_GET["tipo"];
    $vista 						= $_GET["vista"];
    $tipo="todos";
	$PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_tickets_dashboard_pregunta.html")), $PRINCIPAL);
    $PRINCIPAL = str_replace("{NOMBRE_USUARIO_TICKET}", 	($tipoUsuarioAdmin[0]->nombre_completo), $PRINCIPAL);
    $PRINCIPAL = str_replace("{EMPRESA_TICKET}", 				$tipoUsuarioAdmin[0]->empresa, $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Dashboard_Bitacora_01_CSV") {
	 CheckSesionActiva($_SESSION["user_"]);
				$hoy=date("Y-m-d");
				$id_empresa = $_SESSION["id_empresa"];
				//print_r($_GET);exit();
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_Dashboard_Categorias.csv');
        echo "CATEGORIA;CANTIDAD;PORCENTAJE\r\n";
        
       $Cat		= Tickets_Dashboard_Graf_Categorias_data($rut, $_GET["tipo_requerimiento"], $_GET["fecha_inicio"], $_GET["fecha_termino"], $id_empresa, "sinlimite");

		$total_cuenta=0;
		foreach ($Cat as $unico){
				$total_cuenta=$unico->cuenta+$total_cuenta;
		}





        foreach ($Cat as $Un) {
        	$porcentaje=round(100*$Un->cuenta/$total_cuenta);
            echo $Un->categoria.";".$Un->cuenta.";".$porcentaje.";\r\n";
        }
        exit();
}
else if ($seccion == "Tickets_Dashboard_Bitacora_02_CSV") {
	 CheckSesionActiva($_SESSION["user_"]);
				$hoy=date("Y-m-d");
				$id_empresa = $_SESSION["id_empresa"];
				//print_r($_GET);exit();
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_Dashboard_SubCategorias.csv');
        echo "SUBCATEGORIA;CANTIDAD;PORCENTAJE\r\n";
        
       $Cat		= Tickets_Dashboard_Graf_SubCategorias_data($rut, $_GET["tipo_requerimiento"], $_GET["fecha_inicio"], $_GET["fecha_termino"], $id_empresa, "sinlimite");

		$total_cuenta=0;
		foreach ($Cat as $Un){
				$total_cuenta=$Un->cuenta+$total_cuenta;
		}





        foreach ($Cat as $Un) {
        	$porcentaje=round(100*$Un->cuenta/$total_cuenta);
            echo $Un->subcategoria.";".$Un->cuenta.";".$porcentaje.";\r\n";
        }
        exit();
}
else if ($seccion == "Tickets_Dashboard_Bitacora_03_CSV") {
	 CheckSesionActiva($_SESSION["user_"]);
				$hoy=date("Y-m-d");
				$id_empresa = $_SESSION["id_empresa"];
				//print_r($_GET);exit();
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_Dashboard_SubCategorias.csv');
        echo "EJECUTIVO;BITACORA+REQUERIMIENTOS;REQUERIMIENTOS;PROMEDIO_ATENCION\r\n";
        
    //   $Cat		= Tickets_Dashboard_Graf_SubCategorias_data($rut, $_GET["tipo_requerimiento"], $_GET["fecha_inicio"], $_GET["fecha_termino"], $id_empresa, "sinlimite");

		$Lista_Ejecutivo=Tickets_dashboard_Tiempos_ejecutivo_lista($id_empresa);
		foreach ($Lista_Ejecutivo as $unico){
			
			$ListaDatos=Tickets_dashboard_Tiempos_ejecutivo_por_rut($id_empresa, $unico->rut_ejecutivo, $_GET["fecha_inicio"], $_GET["fecha_termino"]);
			//print_r($ListaDatos);
			
			if($ListaDatos[0]->num_bitacora==""){$ListaDatos[0]->num_bitacora=0;}
			if($ListaDatos[0]->num_requerimientos==""){$ListaDatos[0]->num_requerimientos=0;}
			if($ListaDatos[0]->promedio_horas==""){$ListaDatos[0]->promedio_horas=0;}
			
			echo $unico->nombre.";".$ListaDatos[0]->num_bitacora.";".$ListaDatos[0]->num_requerimientos.";".$ListaDatos[0]->promedio_horas.";\r\n";
			
			
			
			
		}





        foreach ($Cat as $Un) {
        	$porcentaje=round(100*$Un->cuenta/$total_cuenta);
            echo $Un->subcategoria.";".$Un->cuenta.";".$porcentaje.";\r\n";
        }
        exit();
}
else if ($seccion == "Tickets_Dashboard_Bitacora_04_CSV") {
	 CheckSesionActiva($_SESSION["user_"]);
				$hoy=date("Y-m-d");
				$id_empresa = $_SESSION["id_empresa"];
				//print_r($_GET);exit();
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_Dashboard_SubCategorias.csv');
        echo "DERIVADO_A;REQUERIMIENTOS;PROMEDIO_ATENCION\r\n";
        
    //   $Cat		= Tickets_Dashboard_Graf_SubCategorias_data($rut, $_GET["tipo_requerimiento"], $_GET["fecha_inicio"], $_GET["fecha_termino"], $id_empresa, "sinlimite");


if($_GET["tipo_requerimiento"]=="Bitacora"){
	
} else {
	$Tickets_Derivado_Array	= Tickets_dashboard_Tiempos_Derivados_total($id_empresa, $_GET["fecha_inicio"], $_GET["fecha_termino"]);
}

	
 		foreach ($Tickets_Derivado_Array as $unico){
			
			echo $unico->Derivado.";".$unico->num_requerimientos.";".$unico->promedio_horas.";\r\n";
			
		}





        foreach ($Cat as $Un) {
        	$porcentaje=round(100*$Un->cuenta/$total_cuenta);
            echo $Un->subcategoria.";".$Un->cuenta.";".$porcentaje.";\r\n";
        }
        exit();
}
else if ($seccion == "Tickets_actualizacion_preguntas_respuestas_2022") {
	CheckSesionActiva($_SESSION["user_"]);



    if($_GET["ad"]=="1"){
        //print_r($_POST);

        UpdateInsertPregRespuestas2022_data("", $_POST["pregunta1"],$_POST["pregunta2"],$_POST["pregunta3"],
                            $_POST["pregunta4"],$_POST["pregunta5"],$_POST["pregunta6"],$_POST["pregunta7"],
                            $_POST["pregunta8"],$_POST["pregunta9"],$_POST["pregunta10"],
                            $_POST["respuesta"],$_POST["categoria"],$_POST["subcategoria"],"");
       echo "<script>alert('Pregunta agregada exitosamente')</script>";

    }
    if($_GET["ed"]=="1"){
            $id_pregunta_edicion=Decodear3($_POST["IDP"]);
            
       UpdateInsertPregRespuestas2022_data($id_pregunta_edicion, $_POST["pregunta1"],$_POST["pregunta2"],$_POST["pregunta3"],
                            $_POST["pregunta4"],$_POST["pregunta5"],$_POST["pregunta6"],$_POST["pregunta7"],
                            $_POST["pregunta8"],$_POST["pregunta9"],$_POST["pregunta10"],
                            $_POST["respuesta"],$_POST["categoria"],$_POST["subcategoria"],"");
       echo "<script>alert('Pregunta editada exitosamente')</script>";
    }
    if($_GET["dl"]=="1"){
            $ide=Decodear3($_GET["ide"]);

       UpdateInsertPregRespuestas2022_data($id_pregunta_edicion, $_POST["pregunta1"],$_POST["pregunta2"],$_POST["pregunta3"],
                            $_POST["pregunta4"],$_POST["pregunta5"],$_POST["pregunta6"],$_POST["pregunta7"],
                            $_POST["pregunta8"],$_POST["pregunta9"],$_POST["pregunta10"],
                            $_POST["respuesta"],$_POST["categoria"],$_POST["subcategoria"],$ide);
       echo "<script>alert('Pregunta eliminada exitosamente')</script>";
    }


    $PRINCIPAL 				= FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 					= $_SESSION["user_"];
    $tipo 					= $_GET["tipo"];
    $vista 					= $_GET["vista"];
    $MonthActual			= date("m");
    $YearActual				= date("Y");
    if($_GET["Y"]>0){
    	$YearActual				= $_GET["Y"];
    }
    if($_GET["M"]>0){
     	$MonthActual			= $_GET["M"];
    }
    $fecha_inicio		    =	$_POST["fecha_inicio"];
    $fecha_termino	        =	$_POST["fecha_termino"];
    $vista					=	$_POST["tipo_vista"];
    if($vista=="Excel"){

				$hoy=date("Y-m-d");
				$id_empresa = $_SESSION["id_empresa"];
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_Bitacora__'.$fecha_inicio.'__'.$fecha_termino.'.csv');
        echo "ID_TICKET;ESTADO;FECHA_CREACION;HORA_CREACION;ASUNTO;DESCRIPCION;CATEGORIA;SUBCATEGORIA;RUT;NOMBRE;CARGO;EMAIL;DIVISION;ID_EJECUTIVO;EJECUTIVO\r\n";
        $tick = Tickets_Descarga_Excel_Bitacora_CSV_data_fechas($id_empresa,$fecha_inicio,$fecha_termino);

        foreach ($tick as $Un) {
        	$data_rut=TraeDatosUsuario(LimpiaRut($Un->rut));
        		$categoria="";
        		$categoria = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->categoria);
						$categoria = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->categoria);

        		$subcategoria="";
        		$subcategoria = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->subcategoria);
						$subcategoria = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->subcategoria);

        		$descripcion="";
        		$descripcion = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->descripcion);
						$descripcion = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->descripcion);

        $EJECUTIVO=Tickets_Busca_datos_admin($Un->rut_ejecutivo, $id_empresa);
        $nombre_ejecutivo=$EJECUTIVO[0]->nombre_completo;

            echo $Un->id.";".$Un->estado.";".$Un->fecha.";".$Un->hora.";".$Un->asunto.";".$descripcion.";".$categoria.";".$subcategoria.";".$Un->rut.";".$data_rut[0]->nombre_completo.";".$data_rut[0]->cargo.";".$data_rut[0]->email.";".$data_rut[0]->division.";".$Un->rut_ejecutivo.";".$nombre_ejecutivo.";\r\n";
        }
        exit();


    }
    $tipoUsuarioAdmin	    = Tickets_Busca_datos_admin($rut,$MonthActual,$YearActual, $id_empresa);
	$PRINCIPAL 				= str_replace("{ENTORNO_MEDICIONES}",       Tickets_Registro_Gestion_Preguntas_Respuestas_FN(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_tickets_preguntas_respuestas_2022.html")), $id_empresa, $id_categoria, $tipo, $rut, $vista, $fecha_inicio,$fecha_termino), $PRINCIPAL);
    $PRINCIPAL 				= str_replace("{NOMBRE_USUARIO_TICKET}", 	$tipoUsuarioAdmin[0]->nombre_completo, $PRINCIPAL);
    $PRINCIPAL 				= str_replace("{EMPRESA_TICKET}", 			$tipoUsuarioAdmin[0]->empresa, $PRINCIPAL);

    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Registros") {
	  CheckSesionActiva($_SESSION["user_"]);
    $PRINCIPAL 				= FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 							= $_SESSION["user_"];
    $tipo 						= $_GET["tipo"];
    $vista 						= $_GET["vista"];
    
    $MonthActual			= date("m");
    $YearActual				= date("Y");
    
    if($_GET["Y"]>0){
    	$YearActual				= $_GET["Y"];
    }
    if($_GET["M"]>0){
     	$MonthActual			= $_GET["M"];
    }
    //print_r($_POST);
    $fecha_inicio		=	$_POST["fecha_inicio"];
    $fecha_termino	=	$_POST["fecha_termino"];
    $vista					=	$_POST["tipo_vista"];
    
    //echo "<br>fecha_inicio $fecha_inicio, fecha_termino $fecha_termino, vista $vista<br>";
    if($vista=="Excel"){

				$hoy=date("Y-m-d");
				$id_empresa = $_SESSION["id_empresa"];
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_Bitacora__'.$fecha_inicio.'__'.$fecha_termino.'.csv');
        echo "ID_TICKET;ESTADO;FECHA_CREACION;HORA_CREACION;ASUNTO;DESCRIPCION;CATEGORIA;SUBCATEGORIA;RUT;NOMBRE;CARGO;EMAIL;DIVISION;ID_EJECUTIVO;EJECUTIVO\r\n";
        $tick = Tickets_Descarga_Excel_Bitacora_CSV_data_fechas($id_empresa,$fecha_inicio,$fecha_termino);
				
        foreach ($tick as $Un) {
        	$data_rut=TraeDatosUsuario(LimpiaRut($Un->rut));
        		$categoria="";
        		$categoria = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->categoria);
						$categoria = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->categoria);

        		$subcategoria="";
        		$subcategoria = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->subcategoria);
						$subcategoria = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->subcategoria);

        		$descripcion="";
        		$descripcion = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->descripcion);
						$descripcion = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->descripcion);
						
        $EJECUTIVO=Tickets_Busca_datos_admin($Un->rut_ejecutivo, $id_empresa);
        $nombre_ejecutivo=$EJECUTIVO[0]->nombre_completo;
						
            echo $Un->id.";".$Un->estado.";".$Un->fecha.";".$Un->hora.";".$Un->asunto.";".$descripcion.";".$categoria.";".$subcategoria.";".$Un->rut.";".$data_rut[0]->nombre_completo.";".$data_rut[0]->cargo.";".$data_rut[0]->email.";".$data_rut[0]->division.";".$Un->rut_ejecutivo.";".$nombre_ejecutivo.";\r\n";
        }
        exit();

    	
    } 
    
    $tipoUsuarioAdmin	=	Tickets_Busca_datos_admin($rut,$MonthActual,$YearActual, $id_empresa);
    
		$PRINCIPAL 				= str_replace("{ENTORNO_MEDICIONES}", Tickets_Registro_Bitacora_lista(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno_tickets_registros.html")), $id_empresa, $id_categoria, $tipo, $rut, $vista, $fecha_inicio,$fecha_termino), $PRINCIPAL);	
    $PRINCIPAL 				= str_replace("{NOMBRE_USUARIO_TICKET}", 	$tipoUsuarioAdmin[0]->nombre_completo, $PRINCIPAL);
    $PRINCIPAL 				= str_replace("{EMPRESA_TICKET}", 				$tipoUsuarioAdmin[0]->empresa, $PRINCIPAL);

    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Descarga_Excel_CSV") {
    
	    CheckSesionActiva($_SESSION["user_"]);
		$hoy=date("Y-m-d");
		$id_empresa = $_SESSION["id_empresa"];
        
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_'.$hoy.'.csv');
        echo "ID_TICKET;ESTADO;FECHA_CREACION;HORA_CREACION;ASUNTO;DESCRIPCION;CATEGORIA;SUBCATEGORIA;RUT;NOMBRE;CARGO;EMAIL;DIVISION;EMPRESA;FECHA_VISUALIZACION;HORA_VISUALIZACION;RUT_EJECUTIVO;NOMBRE_EJECUTIVO;FECHA_RESPUESTA;HORA_RESPUESTA;FECHA_CIERRE;HORA_CIERRE;RUT_CIERRE;DESCRIPCION_CIERRE;HORAS_ESPERA;HORAS_MAXIMA;PORCENTAJE_AVANCE;DERIVADO;USUARIO_DERIVADO;FECHA_DERIVACION;CREACION_EJECUTIVO\r\n";        $tick = Tickets_Descarga_Excel_CSV_data($id_empresa);
				//print_r($tick);

        foreach ($tick as $Un) {
									$Un->descripcion = str_replace(";", "", 	    	$Un->descripcion);
									$Un->descripcion = str_replace("<br>", "", 	    	$Un->descripcion);
									$Un->descripcion = str_replace("/\r|\n/", "", 		$Un->descripcion); 
									$Un->descripcion = str_replace("/\r|\n/", "", 		$Un->descripcion); 
									$Un->descripcion = str_replace("/\r|\n/", "", 		$Un->descripcion); 
									$Un->descripcion = str_replace(array("\r", "\n"), '',  	$Un->descripcion);
									$Un->descripcion = str_replace(array("\r\n", "\r", "\n"), "",  $Un->descripcion);
									$Un->asunto = str_replace("<br>", "", 	    	$Un->asunto);
									$Un->asunto = str_replace(";", "", 	    	$Un->asunto);
									$Un->asunto = str_replace("/\r|\n/", "", 		$Un->asunto); 
									$Un->asunto = str_replace("/\r|\n/", "", 		$Un->asunto); 
									$Un->asunto = str_replace("/\r|\n/", "", 		$Un->asunto); 
									$Un->asunto = str_replace(array("\r", "\n"), '',  	$Un->asunto);
									$Un->asunto = str_replace(array("\r\n", "\r", "\n"), "",  $Un->asunto);

									$Un->categoria = str_replace("<br>", "", 		    $Un->categoria);
									$Un->categoria = str_replace("/\r|\n/", "", 		$Un->categoria); 
									$Un->categoria = str_replace("/\r|\n/", "", 		$Un->categoria); 
									$Un->categoria = str_replace("/\r|\n/", "", 		$Un->categoria); 
									$Un->categoria = str_replace(array("\r", "\n"), '',  	$Un->categoria);
									$Un->categoria = str_replace(array("\r\n", "\r", "\n"), "",  $Un->categoria);

									$Un->subcategoria = str_replace("<br>", "", 		$Un->subcategoria); 
									$Un->subcategoria = str_replace("/\r|\n/", "", 		$Un->subcategoria); 
									$Un->subcategoria = str_replace("/\r|\n/", "", 		$Un->subcategoria); 
									$Un->subcategoria = str_replace("/\r|\n/", "", 		$Un->subcategoria); 
									$Un->subcategoria = str_replace(array("\r", "\n"), '',  	$Un->subcategoria);
									$Un->subcategoria = str_replace(array("\r\n", "\r", "\n"), "",  $Un->subcategoria);        	
        	
        					$nombre_admin=Tickets_Nombre_Admin_data($Un->rut_ejecutivo);
        	
				if($Un->fecha_estado<>"" and $Un->hora_estado<>""){
					$fecha_comparacion=$Un->fecha_estado." ".$Un->hora_estado;
				} else {
					$fecha_comparacion=$hoy_ahora;
				}
				$ticket_creado	=	$Un->fecha." ".$Un->hora;
				$Hours=biss_hours($ticket_creado,$fecha_comparacion)-1;
				if($Un->sla_categoria==""){
					$Sla="24";
				} else {
					$Sla=$Un->sla_categoria;
				}
				if($Hours=="-0"){$Hours=0;}
				if($Hours=="-1"){$Hours=0;}
				$estado_renegociada="";
				if($Un->horas_renegociada>0){
					$Sla=$Sla+$unico->horas_renegociada;
					$estado_renegociada="<div class='badge badge-info'>Renegociado por ".$Un->horas_renegociada." horas </div>";
				}
				if($Un->fecha_reapertura_original<>""){
					$reapertura="";
				} else {
					$reapertura="";
				}
				$porcentaje_Sla_Hours=round(100*$Hours/$Sla);

                if($Un->rut_derivado<>"")
                    {
                        $derivado="SI";
                        $usuario_derivado   = $Un->rut_derivado;
                        $fecha_derivado     = $Un->fecha_derivacion_respuesta;
                    } else {
                        $derivado="NO";
                        $usuario_derivado   = "";
                        $fecha_derivado     = "";
                    }
        if($Un->creado_admin=="1"){
            $creado_admin="SI";
        } else {
            $creado_admin="NO";
        }

            echo $Un->id.";".$Un->estado.";".$Un->fecha.";".$Un->hora.";".$Un->asunto.";".$Un->descripcion.";".$Un->categoria.";".$Un->subcategoria.";".$Un->rut.";".$Un->nombre_completo.";".$Un->cargo.";".$Un->email.";".$Un->division.";".$Un->empresa.";".$Un->fecha_visualizacion.";".$Un->hora_visualizacion.";".$Un->rut_ejecutivo.";".$nombre_admin.";".$Un->fecha_estado.";".$Un->hora_estado.";".$Un->fecha_cierre.";".$Un->hora_cierre.";".$Un->rut_cierre.";".$Un->cierre_descripcion.";".$Hours.";".$Sla.";".$porcentaje_Sla_Hours.";".$derivado.";".$usuario_derivado.";".$fecha_derivado.";".$creado_admin."\r\n";
        }
        exit();
}
else if ($seccion == "Tickets_Descarga_Bitacora_Excel_CSV") {
				 CheckSesionActiva($_SESSION["user_"]);
				$hoy=date("Y-m-d");
				$id_empresa = $_SESSION["id_empresa"];
        header('Content-type: text/plain');
        header('Content-Disposition: attachment; filename=Tickets_'.$hoy.'.csv');
        echo "ID_TICKET;ESTADO;FECHA_CREACION;HORA_CREACION;ASUNTO;DESCRIPCION;CATEGORIA;SUBCATEGORIA;RUT;NOMBRE;CARGO;EMAIL;DIVISION;ID_EJECUTIVO;EJECUTIVO\r\n";
        $tick = Tickets_Descarga_Excel_Bitacora_CSV_data($id_empresa);

				//print_r($tick);
				
				
        foreach ($tick as $Un) {
        	$data_rut=TraeDatosUsuario(LimpiaRut($Un->rut));
        		$categoria="";
        		$categoria = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->categoria);
						$categoria = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->categoria);

        		$subcategoria="";
        		$subcategoria = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->subcategoria);
						$subcategoria = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->subcategoria);

        		$descripcion="";
        		$descripcion = preg_replace("/[\r\n|\n|\r]+/", PHP_EOL, $Un->descripcion);
						$descripcion = preg_replace("/[\r\n|\n|\r]+/", " ", $Un->descripcion);
						
        $EJECUTIVO=Tickets_Busca_datos_admin($Un->rut_ejecutivo, $id_empresa);
        $nombre_ejecutivo=$EJECUTIVO[0]->nombre_completo;
						
            echo $Un->id.";".$Un->estado.";".$Un->fecha.";".$Un->hora.";".$Un->asunto.";".$descripcion.";".$categoria.";".$subcategoria.";".$Un->rut.";".$data_rut[0]->nombre_completo.";".$data_rut[0]->cargo.";".$data_rut[0]->email.";".$data_rut[0]->division.";".$Un->rut_ejecutivo.";".$nombre_ejecutivo.";\r\n";
        }
        exit();
}
else if ($seccion == "Tickets_Detalle") {
	 CheckSesionActiva($_SESSION["user_"]);
	  $id_empresa 			= $_SESSION["id_empresa"];
    $rut 							= $_SESSION["user_"];
	
    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa = $_SESSION["id_empresa"];
    $id					= Decodear3($_GET["id"]);
    $reasignacion										= ($_POST["reasignacion"]);
    $derivacion											= ($_POST["derivacion"]);
    $rut_ejecutivo_nivel_2					= ($_POST["rut_ejecutivo_nivel_2"]);
    $rut_ejecutivo_nivel_3					= ($_POST["rut_ejecutivo_nivel_3"]);

    $pregunta_publica								= ($_POST["pregunta_publica"]);

		if($pregunta_publica=="1"){
			$pregunta_add									= ($_POST["pregunta_add"]);
			$respuesta_add								= ($_POST["respuesta_add"]);
			Ticket_Crear_PreguntaRespuesta_Pendiente($rut, $id_empresa, $pregunta_add, $respuesta_add);
		}
	

		if($reasignacion==1 and $rut_ejecutivo_nivel_2<>""){
			Ticket_Reasigna_Ejecutivo_Nivel($id, $rut_ejecutivo_nivel_2);
			$Ejecutivo_nivel_2	=Tickets_Busca_datos_admin($rut_ejecutivo_nivel_2, $id_empresa);
			//print_r($Ejecutivo_nivel_2);
					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					$to				= $Ejecutivo_nivel_2[0]->email;				
					$nombreto	= $Ejecutivo_nivel_2[0]->email;	
					$subject	= "[Requerimiento $id Reasignado]";
					$titulo1	= "<br><br> El Requerimiento $id: <strong>".$asunto."</strong> te ha sido Reasignado. <br><br>";			
					//echo "<br>$to ";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
		}

		if($derivacion==1 and $rut_ejecutivo_nivel_3<>""){
			
					//print_r($_POST);
			
					Ticket_Deriva_Ejecutivo_Nivel($id, $rut_ejecutivo_nivel_3);
					$Ejecutivo_nivel_3	=Tickets_Busca_datos_admin($rut_ejecutivo_nivel_3, $id_empresa);
					//print_r($Ejecutivo_nivel_3);
					
					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					$to				= $Ejecutivo_nivel_3[0]->email;				
					$nombreto	= $Ejecutivo_nivel_3[0]->email;	
					$subject	= "[Requerimiento $id Derivado]";
					$titulo1	= "<br><br> El Requerimiento $id: <strong>".$asunto."</strong> 
                ha sido Derivado por necesidad de una Respuesta Técnica. <br><br>".$_POST["comentario_derivacion"];
					//echo "<br>$to ";
					//$to="esteban@gop.cl";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
					
					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					$to				= $Ejecutivo_nivel_3[0]->email_backup;				
					$nombreto	= $Ejecutivo_nivel_3[0]->email_backup;	
					$subject	= "[Requerimiento $id Derivado]";
					$titulo1	= "<br><br> El Requerimiento $id: <strong>".$asunto."</strong> ha sido Derivado por necesidad de una Respuesta Técnica. <br><br>".$_POST["comentario_derivacion"];			
					//echo "<br>$to ";
					//$to="esteban@gop.cl";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);

					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					$to				= $Ejecutivo_nivel_3[0]->email_backup2;				
					$nombreto	= $Ejecutivo_nivel_3[0]->email_backup2;	
					$subject	= "[Requerimiento $id Derivado]";
					$titulo1	= "<br><br> El Requerimiento $id: <strong>".$asunto."</strong> ha sido Derivado por necesidad de una Respuesta Técnica. <br><br>".$_POST["comentario_derivacion"];			
					//echo "<br>$to ";
					//$to="esteban@gop.cl";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
								
								
					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					$to				= $Ejecutivo_nivel_3[0]->email_backup3;				
					$nombreto	= $Ejecutivo_nivel_3[0]->email_backup3;	
					$subject	= "[Requerimiento $id Derivado]";
					$titulo1	= "<br><br> El Requerimiento $id: <strong>".$asunto."</strong> 
                      ha sido Derivado por necesidad de una Respuesta Técnica. <br><br>".$_POST["comentario_derivacion"];
					//echo "<br>$to ";
					//$to="esteban@gop.cl";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
								
								
					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					$to				= $Ejecutivo_nivel_3[0]->email_backup4;				
					$nombreto	= $Ejecutivo_nivel_3[0]->email_backup4;	
					$subject	= "[Requerimiento $id Derivado]";
					$titulo1	= "<br><br> El Requerimiento $id: <strong>".$asunto."</strong> ha sido Derivado por necesidad de una Respuesta Técnica. <br><br>".$_POST["comentario_derivacion"];			
					//echo "<br>$to ";
					//$to="esteban@gop.cl";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
								
								
					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					$to				= $Ejecutivo_nivel_3[0]->email_backup5;				
					$nombreto	= $Ejecutivo_nivel_3[0]->email_backup5;	
					$subject	= "[Requerimiento $id Derivado]";
					$titulo1	= "<br><br> El Requerimiento $id: <strong>".$asunto."</strong> ha sido Derivado por necesidad de una Respuesta Técnica. <br><br>".$_POST["comentario_derivacion"];			
					//echo "<br>$to ";
					//$to="esteban@gop.cl";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
																																
								
					
					//exit();
					$UsuCol	=Tickets_Busca_datos_tbl_Usuario($Ticket[0]->rut, $id_empresa);
					//print_r($UsuCol);
					$to				= $UsuCol[0]->email;				
					$nombreto	= $UsuCol[0]->email;	
					$subject	= "[Requerimiento $id Derivado]";
					$titulo1	= "<br><br>
			
					Estimado(a) ".$UsuCol[0]->nombre_completo.", informamos que dado lo específico de tu Requerimiento $id: <strong>".$Ticket[0]->asunto."</strong>, hemos derivado la consulta al especialista del proceso, 
					lo cual implica extender el tiempo de respuesta en 72  horas, una vez obtenido los antecedentes, entregaremos la respuesta por este medio.
					<br>Que tengas un excelente día!.
					<br><br>Para revisar el estado o la respuesta de tu requerimiento, debes ingresar a Más Conectados > Atención Personas
                    <br><br>				
									Te saluda atentamente,
									<br><br>
									Centro de Atención Personas  
									<br> 
									División Personas y Organización
									<br><br><br><br><center><small>[ POR FAVOR NO RESPONDAS ESTE EMAIL ]</small></center><br><br>
					";			
					//echo "<br>$to ";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
					
					
					
		}

    $reasignacion_categoria					= ($_POST["reasignacion_categoria"]);
    $bloque_categoria								= ($_POST["bloque_categoria"]);
    $bloque_subcategoria						= ($_POST["bloque_subcategoria"]);

		if($reasignacion_categoria==1 and $bloque_categoria<>"" and $bloque_subcategoria<>""){
			Ticket_Reasigna_Categoria_Subcategoria($id, $bloque_categoria,$bloque_subcategoria);	
		}
    $renegociar						= ($_POST["renegociar"]);
		if($renegociar==1){
			Ticket_Renegocia($id, $_POST["horas_renegociada"]);
					//print_r($Ejecutivo_nivel_2);
					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					//print_r($Ticket);
					$UsuCol	=Tickets_Busca_datos_tbl_Usuario($Ticket[0]->rut, $id_empresa);
					//print_r($UsuCol);
					$to				= $UsuCol[0]->email;				
					$nombreto	= $UsuCol[0]->email;	
					$subject	= "[Requerimiento $id ]";
					$titulo1	= "<br><br>
					
					
					Estimado(a) ".$UsuCol[0]->nombre_completo.",					
					informamos que dado lo específico de tu requerimiento, hemos derivado la consulta al especialista del proceso, lo cual implica extender el tiempo de respuesta en ".$_POST["horas_renegociada"]." horas, una vez obtenido los antecedentes, entregaremos la respuesta por este medio.
					
									<br><br>				
									Te saluda atentamente,
									<br><br>
									Centro de Atención Personas  
									<br> 
									División Personas y Organización
									<br><br><br><br><center><small>[ POR FAVOR NO RESPONDAS ESTE EMAIL ]</small></center><br><br>					
					
					";			
					//echo "<br>$to ";
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
					
					//exit();

		}

    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 							= $_SESSION["user_"];

		if($_GET["del"]==1){

		    Tickets_Delete_Ticket($id,	$rut,	$ticket_perfil, $id_empresa);
		    echo "<script>alert('Requerimiento Eliminado');</script>";
            echo "<script>location.href='?sw=Tickets';    </script>";
		}

    if($_GET["close"]){
    	
    	if($_GET["close"]==2){
					// rut ejecutivo 
					$ticket_perfil="Cerrado por Ejecutivo";
					Tickets_Cerrar_Ticket($id,	$rut,	$ticket_perfil, $id_empresa);
  				$array_ejecutivo=Tickets_Busca_Ejecutivo($id_empresa, $categoria, $subcategoria, $id_empresa);
  				$email_ejecutivo=$array_ejecutivo[0]->email;

					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					
					$to				= $email_ejecutivo;				
					$nombreto	= $email_ejecutivo;	
					$subject	= "[Requerimiento $id] Cerrado ";
					$titulo1	= "
						<br><br>
						El Requerimiento <strong>$id</strong>, <strong>asunto: ".$asunto."</strong> ha sido cerrado exitosamente.
					<br><br>
					Muchas Gracias.";			
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
 					
 		 			$to				= $Ticket[0]->email;				
					$nombreto	= $Ticket[0]->email;		
					$subject	= "[Requerimiento $id] Cerrado";
					$titulo1	= "

                                    <br><br>
                                    ".$Ticket[0]->nombre_completo.", informamos que tu requerimiento <strong>".$Ticket[0]->id."</strong>, 
                                    descripción :<strong> ".$asunto."</strong>, fue cerrado definitivamente. 
                                    Para revisar respuesta y/o documentos adjuntos debes ingresar a Más conectados - Atención Personas.
                                    <br><br> Esperamos haber respondido tu consulta acorde a tus expectativas y quedamos disponibles para futuros requerimientos

					                <br><br>
									Te saluda atentamente,
									<br><br>
									Centro de Atención Personas  
									<br> 
									División Personas y Organización
									<br><br><br><br><center><small>[ POR FAVOR NO RESPONDAS ESTE EMAIL ]</small></center><br><br>

					
					";			
													
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
					
					echo "<script>alert('Requerimiento cerrado exitosamente');location.href='?sw=Tickets';</script>";
          exit; 		
			}
    	if($_GET["close"]==1){
					// rut colaborador 
					$ticket_perfil="Cerrado por Colaborador";
   				Tickets_Cerrar_Ticket($id,	$rut,	$ticket_perfil, $id_empresa);
  				$array_ejecutivo=Tickets_Busca_Ejecutivo($id_empresa, $categoria, $subcategoria, $id_empresa);
  				$email_ejecutivo=$array_ejecutivo[0]->email;

					$Ticket=Tickets_Detalle_id_Data($id, $id_empresa);
					$asunto=($Ticket[0]->asunto);
					
					$to				= $email_ejecutivo;				
					$nombreto	= $email_ejecutivo;	
					$subject	= "[Requerimiento $id] Cerrado ";
					$titulo1	= "
					<br><br>
						El Requerimiento <strong>$id</strong>.<br><br> <strong>Asunto: ".$asunto."</strong> ha sido cerrado exitosamente.
					<br><br>
					Muchas Gracias.";			
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
 					
 					$to				= $Ticket[0]->email;				
					$nombreto	= $Ticket[0]->email;		
					$subject	= "[Requerimiento $id] Cerrado";
					$titulo1	= "
					<br><br>
					".$Ticket[0]->nombre_completo.", hemos recibido exitosamente el cierre del Requerimiento $id.<br><br><strong>".$asunto."</strong>.
					<br><br>
					Muchas Gracias.
					";			
													
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
					
					echo "<script>alert('Requerimiento cerrado exitosamente');location.href='?sw=Tickets';</script>";
          exit;
      }
    }
    
    $PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", Tickets_Detalle(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/ticket_detalle.html")), $id_empresa, $id), $PRINCIPAL);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Tickets_Detalle_Agregar_Interaccion"){
	    CheckSesionActiva($_SESSION["user_"]);
        $id_empresa 			= $_SESSION["id_empresa"];
        $rut 							= $_SESSION["user_"];
		$id								=	Decodear3($_POST["id"]);
		$interaccion			=	($_POST["interaccion"]);

    $tamano_archivo = $_FILES["archivo"]['size'];
    $tipo_archivo = $_FILES["archivo"]['type'];
    $archivo_archivo = $_FILES["archivo"]['name'];
    
        if($_FILES["archivo"]["name"]<>""){
       		 VerificaExtensionFiles($_FILES["archivo"]["name"]);	
        }
    $arreglo_archivo = explode(".", $archivo_archivo);
    $extension_archivo = $arreglo_archivo[1];
    $rutaarchivo = "tickets";
    $randomString = hash('sha256', random_bytes(16)); $prefijo = $id . "_" . $rut . "_" . substr($randomString, 0, 6);
    if ($arreglo_archivo != "") {
        $nombre_archivo = $id_empresa . "_" . $prefijo;
        $datos_subida_archivo = Tickets_SubirArchivosTickets($_FILES, $extension_archivo, $nombre_archivo, $rutaarchivo, 1, $camp->campo);
        $nombre_archivo = $datos_subida_archivo[1];
    }  

	$tamano_archivo2 = $_FILES["archivo2"]['size'];
    $tipo_archivo2 = $_FILES["archivo2"]['type'];
    $archivo_archivo2 = $_FILES["archivo2"]['name'];
    
        if($_FILES["archivo2"]["name"]<>""){
       		 VerificaExtensionFiles($_FILES["archivo2"]["name"]);	
        }
    $arreglo_archivo2 = explode(".", $archivo_archivo2);
    $extension_archivo2 = $arreglo_archivo2[1];
    $rutaarchivo2 = "tickets";
    $randomString2 = hash('sha256', random_bytes(16)); $prefijo2 = $id . "_" . $rut . "_" . substr($randomString2, 0, 6);
    if ($arreglo_archivo2 != "") {
        $nombre_archivo2 = $id_empresa . "_" . $prefijo2;
        $datos_subida_archivo2 = Tickets_SubirArchivos2Tickets($_FILES, $extension_archivo2, $nombre_archivo2, $rutaarchivo2, 1, $camp->campo);
        $nombre_archivo2 = $datos_subida_archivo2[1];
    }  

    $tamano_archivo3 = $_FILES["archivo3"]['size'];
    $tipo_archivo3 = $_FILES["archivo3"]['type'];
    $archivo_archivo3 = $_FILES["archivo3"]['name'];

        if($_FILES["archivo3"]["name"]<>""){
       		 VerificaExtensionFiles($_FILES["archivo3"]["name"]);
        }
    $arreglo_archivo3 = explode(".", $archivo_archivo3);
    $extension_archivo3 = $arreglo_archivo3[1];
    $rutaarchivo3 = "tickets";
    $randomString3 = hash('sha256', random_bytes(16)); $prefijo3 = $id . "_" . $rut . "_" . substr($randomString3, 0, 6);
    if ($arreglo_archivo3 != "") {
        $nombre_archivo3 = $id_empresa . "_" . $prefijo3;
        $datos_subida_archivo3 = Tickets_SubirArchivos3Tickets($_FILES, $extension_archivo3, $nombre_archivo3, $rutaarchivo3, 1, $camp->campo);
        $nombre_archivo3 = $datos_subida_archivo3[1];
    }
    //print_r($_FILES);    exit();
		$Usu		=	Tickets_Busca_datos_admin($rut, $id_empresa);
		
		Tickets_Insert_Interaccion($id, $interaccion, $nombre_archivo, $rut, $Usu[0]->go, $id_empresa, $nombre_archivo2,$nombre_archivo3);
		//print_r($_POST);	exit();

 
 if($Usu[0]->go=="1" or $Usu[0]->go=="2")		{
 	//Se me reasigna a mi
 	Ticket_Reasigna_Ejecutivo_Nivel($id, $rut);
 }
		
		$Ticket	=	Tickets_Detalle_id_Data($id, $id_empresa);
		
		//print-
		$rut_col	= $Ticket[0]->rut;
		$rut_ejecutivo	= $Ticket[0]->rut_ejecutivo;
		
		$UsuCol	=	Tickets_Busca_datos_admin($rut_col, $id_empresa);
		$UsuEje	=	Tickets_Busca_datos_admin($rut_ejecutivo, $id_empresa);

  	$email_ejecutivo	=	$UsuEje[0]->email;

if($email_ejecutivo==""){
	//asigna uno 
	$Usu_Ejecutivo_Uno=Tickets_Busca_Ejecutivo($id_empresa, $categoria, $subcategoria, $id_empresa);
	$email_ejecutivo=$Usu_Ejecutivo_Uno[0]->email;
}

$rut 								= $_SESSION["user_"];
$rut_ejecutivo			= $Ticket[0]->rut_ejecutivo;
 

 if($Usu[0]->go=="3"){
 	        //Derivado
		 	//solo respuesta a Ejecutivo del Ticket
 			$to				= $email_ejecutivo;				
			$nombreto	= $email_ejecutivo;	
			$subject	= "[Requerimiento ".$Ticket[0]->id." Respuesta de Experto]";
			$titulo1	= "
			<br><br>[Ticket $id]: <strong>".$asunto."</strong><br><br>
			Respuesta: ".$interaccion."";			
		  SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);

			//Save Update fecha_derivacion_respuesta	/ hora_derivacion_respuesta
			Ticket_Actualiza_Fecha_Respuesta_Derivada($id);
 	
 } else {
					// NO DERIVADO 	
					//echo "rut $rut, rut ejefcutivo $rut_ejecutivo  $id"; 
					
					 if($rut==$rut_ejecutivo){
					 	Ticket_Save_Respondido($rut, $id, $id_empresa);
					 } else {
					 	Ticket_Save_Respondido_Vuelve_a_Pendiente($rut, $id, $id_empresa);
					 }
				//echo "<br>Tickets_Detalle_Agregar_Interaccion<br>rut $rut, email_ejecutivo $email_ejecutivo, usu email ".$Usu[0]->email; exit();
				$asunto						= ($Ticket[0]->asunto);
				
				if($Ticket[0]->id_empresa=="78") {
					$nombre_empresa=" Centro de Atención Personas     <br>   División Personas y Organización ";
				} else {
					$nombre_empresa=" Equipo GO ";
				}
				if($Usu[0]->email==$email_ejecutivo)  	{


									$to				= $Ticket[0]->email;
									$nombreto	= $Ticket[0]->email;


									$subject	= "[Requerimiento ".$Ticket[0]->id." Respuesta]";
									$titulo1	= "
									<br><br>".$Ticket[0]->nombre_completo.", a continuación respuesta a requerimiento [".$Ticket[0]->id."].
									
									<br><strong>Descripción</strong>: ".$asunto." 
									<br><br>
									<br><strong>Respuesta</strong>: ".$interaccion."
									<br><br>
									Para revisar respuesta y/o documentos adjuntos debes ingresar a Más conectados - Atención Personas.
									<br><br>Esperamos haber respondido tu consulta acorde a tus expectativas y quedamos disponibles para futuros requerimientos.


									<br><br>
									Agradecemos entrar al portal para responder el requerimiento o bien para cerrar el proceso, de lo contrario en el transcurso de 3 días hábiles, este se cerrará de manera automática, entendiendo que quedo aclarada su inquietud.
									<br><br>				
									Te saluda atentamente,
									<br><br>
									Centro de Atención Personas  
									<br> 
									División Personas y Organización
									<br><br><br><br><center><small>[ POR FAVOR NO RESPONDAS ESTE EMAIL ]</small></center><br><br>

 									
									";			
									SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
									
									$to			= $email_ejecutivo;
									$nombreto	= $email_ejecutivo;	
									$subject	= "[Requerimiento ".$Ticket[0]->id." Respuesta]";
									$titulo1	= "
									<br><br>[Requerimiento $id]: <strong>".$asunto."</strong><br><br>
									Se ha respondido tu Requerimiento, Comentario: ".$interaccion."
									<br><br>";	
									//SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
				
				} else {
									$to				= $email_ejecutivo;				
									$nombreto	= $email_ejecutivo;	
									$subject	= "[Requerimiento  ".$Ticket[0]->id." Respuesta]";
									$titulo1	= "
									<br><br>[Requerimiento $id]: <strong>".$asunto."</strong><br><br>Respuesta de ".$Ticket[0]->nombre.": ".$interaccion."<br><br>";			
									SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
									$to				= $Ticket[0]->email;
									$nombreto	= $Ticket[0]->email;
									$subject	= "[Requerimiento ".$Ticket[0]->id." Respuesta]";
									$titulo1	= "
									<br><br>[Requerimiento $id]: <strong>".$asunto."</strong><br><br>
									Hemos recibido tu Respuesta: ".$interaccion."
									<br><br>";	
									SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
				}
 }
		      echo "<script>alert('Respuesta enviada exitosamente');location.href='?sw=Tickets';</script>";
          exit;
}
else if ($seccion == "Tickets_Agregar_Nuevo") {
    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa = $_SESSION["id_empresa"];
    if($id_empresa=="78"){
    $PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", Tickets_Agregar_nuevo_fn(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/agregar_ticket_sin_categorias.html")), $id_empresa, $id_categoria), $PRINCIPAL);	
    } else {
		$PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", Tickets_Agregar_nuevo_fn(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/agregar_ticket.html")), $id_empresa, $id_categoria), $PRINCIPAL);    	
    }
    echo CleanHTMLWhiteList($PRINCIPAL);
} 
else if ($seccion == "Tickets_Agregar_Nuevo_Registro") {
    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/entorno.html"));
    $id_empresa = $_SESSION["id_empresa"];
		$PRINCIPAL = str_replace("{ENTORNO_MEDICIONES}", Tickets_Agregar_nuevo_Registro_fn(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/tickets/agregar_ticket_registro.html")), $id_empresa, $id_categoria), $PRINCIPAL);    	
    echo CleanHTMLWhiteList($PRINCIPAL);
} 
else if ($seccion == "Tickets_SaveNuevoTicket") {
		/*echo "<br>POST<br>"; print_r($_POST); echo "<br>FILE<br>"; print_r($_FILES);	echo "<br>"; exit();*/
    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 							= $_SESSION["user_"];
    $asunto 					= ($_POST['asunto']);
    $descripcion 			= ($_POST['descripcion']);
    $categoria 				= ($_POST['categoria']);
    $subcategoria 		= ($_POST['bloque_subcategoria']);
    $archivo 					= ($_POST['archivo']);
     CheckSesionActiva($_SESSION["user_"]);

   	$data_rut=TraeDatosUsuario($_POST["rut_col"]);
   	if($data_rut[0]->rut<>""){
   		
   	} else {
   		echo "<script>alert('Rut no existe en Base de datos');location.href='?sw=Tickets_Agregar_Nuevo';</script>";exit();
   	}
   		//print_r($_POST);   	print_r($_FILES);   	print_r($data_rut);   	//exit();
	   	//print_r($UsuAdmin);   	//exit();
	   	
   	if($_FILES["archivo"]['name']<>""){
 		 $tamano_archivo = $_FILES["archivo"]['size'];
    	$tipo_archivo = $_FILES["archivo"]['type'];
    	$archivo_archivo = $_FILES["archivo"]['name'];
    VerificaExtensionFiles($archivo_archivo);
    
    $arreglo_archivo = explode(".", $archivo_archivo);
    $extension_archivo = $arreglo_archivo[1];
    $rutaarchivo = "tickets";
    $randomString = hash('sha256', random_bytes(16)); $prefijo = $id . "_" . $rut . "_" . substr($randomString, 0, 6);

        if ($arreglo_archivo != "") {
        $nombre_archivo = $id_empresa . "_" . $prefijo;
        $datos_subida_archivo = Tickets_SubirArchivosTickets($_FILES, $extension_archivo, $nombre_archivo, $rutaarchivo, 1, $camp->campo);
        $nombre_archivo = $datos_subida_archivo[1];
    }   		
   	}
   	   
      
        $Usu_admin=TraeDatosUsuario($_POST["rut_col"], $id_empresa);
		$nombre_completo	=	$Usu_admin[0]->nombre_completo;
		$cargo						=	$Usu_admin[0]->cargo;
		$email						=	$Usu_admin[0]->email;
		$division					=	$Usu_admin[0]->division;
		$empresa					=	$Usu_admin[0]->empresa;
    
        $last_id=Tickets_SaveNuevoTicket_data($asunto, $descripcion, $categoria, $subcategoria, $nombre_archivo, $rut , $id_empresa, $nombre_completo, $cargo, $email, $division, $empresa, $_POST["rut_col"],"1");
		//echo "last id $last_id";
		
		//print_r($last_id);
	
		//print_r($Usu_admin);		exit();
    //$array_ejecutivo	= Tickets_Busca_Ejecutivo($id_empresa, $categoria, $subcategoria, $id_empresa);
    
        $UsuAdminEjecutivo					= Tickets_Busca_datos_admin($rut, $id_empresa);
  	    $email_ejecutivo=$UsuAdminEjecutivo[0]->email;

		$Ticket	=	Tickets_Detalle_id_Data($last_id, $id_empresa);
		
		//print_r($Ticket);
					$to 			= $email_ejecutivo;	
					$to				= $email_ejecutivo;				
					
					
					//echo "<br>to UsuAdminEjecutivo email_ejecutivo $to";
					
					$nombreto	= $email_ejecutivo;	
					$subject	= "[Requerimiento ".$last_id."] ";
					$titulo1	= "Nuevo Requerimiento de ".$Ticket[0]->nombre_completo.", ".$Ticket[0]->empresa." 
					<br><br>[Requerimiento ".$last_id."]<br><br>
					<strong>Asunto</strong>: ".$asunto."<br><br>
					<strong>Descripción</strong>:".$descripcion."
					<br><br>";			
													
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);
					//sleep(1);
 					$to				= $Ticket[0]->email;				
					$nombreto	= $Ticket[0]->email;		
					//$to 			= "rod@gop.cl";
					
					//echo "<br>to $to";
					
					$subject	= "[Requerimiento $last_id]";
					$titulo1	= "Hemos recibido satisfactoriamente el siguiente requerimiento.
					
					<br><br>[Requerimiento ".$last_id."]<br><br>
					<strong>Asunto</strong>: ".$asunto."<br><br>
					<strong>Descripción</strong>:".$descripcion."
					
					<br><br>Te informamos que responderemos tu consulta dentro de las siguientes 48 hrs.
                    <br><br>Para revisar el estado o la respuesta de tu requerimiento, debes ingresar a Más Conectados > Atención Personas
					<br><br>Te saluda atentamente,
					<br><br>
 							".$nombre_empresa."
					";					
													
					SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $otro_template);

				if($Ticket[0]->id_empresa=="78") {
					$nombre_empresa=" Centro de Atención Personas <br> División Personas y Organización ";
				} else {
					$nombre_empresa=" Equipo GO ";
				}   
   
   	
    echo "<script>      location.href='?sw=Tickets';     </script>";exit();
} 
else if ($seccion == "Tickets_SaveNuevoTicketRegistro") {
		//echo "<br>POST<br>"; print_r($_POST);  exit();
    $id_empresa 			= $_SESSION["id_empresa"];
    $rut 						= $_SESSION["user_"];
    $rut_solicitante 			= trim($_POST['rut']);
    $descripcion 			    = ($_POST['descripcion']);
    $categoria 				    = ($_POST['categoria']);
    $subcategoria 		        = ($_POST['bloque_subcategoria']);
    $archivo 					= ($_POST['archivo']);
    $asunto 					= ($_POST['asunto']);

		
		if($_POST["id"]>0){
		$last_id=Tickets_SaveNuevoTicket_Update_Registro_data($asunto, $descripcion, $categoria, $subcategoria, $nombre_archivo, $rut_solicitante , $id_empresa, $nombre_completo, $cargo, $email, $division, $empresa, $_POST["id"]);	
		} else {
		$last_id=Tickets_SaveNuevoTicket_Registro_data($asunto, $descripcion, $categoria, $subcategoria, $nombre_archivo, $rut_solicitante , $id_empresa, $nombre_completo, $cargo, $email, $division, $empresa);	
		}
    //$asunto						= "Bitácora";
    
 
		//print_r($Usu_admin);		exit();
    $array_ejecutivo	= Tickets_Busca_Ejecutivo($id_empresa, $categoria, $subcategoria, $id_empresa);
  	$email_ejecutivo=$array_ejecutivo[0]->email;


    echo "<script>      location.href='?sw=Tickets_Registros';     </script>";
} 
else if ($seccion == "als") {
	
    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno.html"));
    $id_empresa = $_SESSION["id_empresa"];
    $PRINCIPAL = str_replace("{ENTORNO}", file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_previa.html"), $PRINCIPAL);
    $datos_empresa = DatosEmpresa($id_empresa);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Usuario_Manual") {
	
	  $id_empresa = $_SESSION["id_empresa"];

	  
	  if($_POST["rut"]){
	  	
	  $porciones = explode("-", $_POST["rut"]);
	  if($porciones[1]==""){
	  	echo "<script>alert('Alerta: Recuerda que el RUT debe venir con guion y digito verificador');
	  						location.href='?sw=Usuario_Manual';  
	  	 			</script>";exit();
	  }	  	
	  	
	  	$rut			=		LimpiaRut($_POST["rut"]);
	  	$nombre		=		($_POST["nombre"]);
	  	$email		=		($_POST["email"]);
	  	$tipo			=		"USUARIO_MANUAL";
	  	
	  	$existe=Usuario_Manual_Busca_Existe($rut);
	  	if($existe>0){
	  			  	echo "<script>alert('Alerta: RUT ingresado ya existe en la Base de Personas');
	  						location.href='?sw=Usuario_Manual';  
	  	 			</script>";exit();
	  	}
	  	
	  	Usuario_Manual_InsertManual($rut, $_POST["rut"], $nombre, $email, $tipo, $id_empresa);
	
		  $existe=Usuario_Manual_Busca_Existe($rut);
	  	if($existe>0){

	  	}  	
	  	
	  }
	  
    $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/usuario_manual/entorno.html"));
    $PRINCIPAL = str_replace("{ENTORNO}", Usuario_Manual_fn(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/usuario_manual/entorno_creacion_usuario_manual.html")), $id_empresa, $id_categoria), $PRINCIPAL);
    $datos_empresa = DatosEmpresa($id_empresa);
    echo CleanHTMLWhiteList($PRINCIPAL);
	
}
else if ($seccion == "alslist") {
	if($_GET["ex"]=="1"){
		$PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_excel.html"));
	}else{
		$PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno.html"));
	}
    
    $id_empresa = $_SESSION["id_empresa"];
	if($_GET["ex"]=="1"){
	$fechahoy = date("Y-m-d") . " " . date("H:i:s");
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Denuncias_" .  $fechahoy . ".xls");
    header("Pragma: no-cache");
    header("Expires: 0");
	
    $PRINCIPAL = str_replace("{ENTORNO}", utf8_decode(ListadoAcosoLaboralSexual(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_notificaciones_excel.html")), $id_empresa, $id_categoria)), $PRINCIPAL);
	}else{
		
    $PRINCIPAL = str_replace("{ENTORNO}", ListadoAcosoLaboralSexual(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_notificaciones.html")), $id_empresa, $id_categoria), $PRINCIPAL);
	}
	$PRINCIPAL = str_replace("{URL_EXPORTAR_EXCEL}", "?sw=alslist&ex=1", $PRINCIPAL);
	
    $datos_empresa = DatosEmpresa($id_empresa);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if($seccion=="desDen"){
	
	$id=Decodear3($_GET["i"]);
	$detalle_denuncia=DetalleDenuncia($id);
	
	$root = "../front/denuncias/";
        $file = $detalle_denuncia[0]->archivo_evidencia;
        $path = $root.$file;
        $type = '';
		
        
        $titulo_archivo=$detalle_denuncia[0]->archivo_evidencia;
        $nombre_Archivo_a_descargar=$detalle_denuncia[0]->archivo_evidencia;
        $size = filesize($path);
        if (function_exists('mime_content_type')) {
        $type = mime_content_type($path);
        } else if (function_exists('finfo_file')) {
        $info = finfo_open(FILEINFO_MIME);
        $type = finfo_file($info, $path);
        finfo_close($info);
        }
        if ($type == '') {
        $type = "application/force-download";
        }
        // Definir headers
        header("Content-Type: $type");
        header("Content-Disposition: attachment; filename=$nombre_Archivo_a_descargar");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: " . $size);
        // Descargar archivo
        //readfile($path);
        readfile("../front/denuncias/".$file);
		
		
		
		
		
	
}
else if ($seccion == "valD") {
	
     $PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno.html"));
    $id_empresa = $_SESSION["id_empresa"];
    $PRINCIPAL = str_replace("{ENTORNO}", file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_previa.html"), $PRINCIPAL);
	
	
    $datos_empresa = DatosEmpresa($id_empresa);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "valDList") {
	if($_GET["ex"]=="1"){
		$PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_excel.html"));
	}else{
		$PRINCIPAL = FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno.html"));
	}
    $id_empresa = $_SESSION["id_empresa"];
	
	if($_GET["ex"]=="1"){
			
			$fechahoy = date("Y-m-d") . " " . date("H:i:s");
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Denuncias_" .  $fechahoy . ".xls");
    header("Pragma: no-cache");
    header("Expires: 0");
	
	
    $PRINCIPAL = str_replace("{ENTORNO}", utf8_decode(ListadoDenunciaValores(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_notificaciones_excel.html")), $id_empresa, $id_categoria)), $PRINCIPAL);
		
	}else{
		
		$PRINCIPAL = str_replace("{ENTORNO}", ListadoDenunciaValores(FuncionesTransversalesAdmin(file_get_contents("https://www.goptest.cl/bch_masco/tickets/admin/views/denuncias/entorno_notificaciones.html")), $id_empresa, $id_categoria), $PRINCIPAL);
		
	}
	
	
    $PRINCIPAL = str_replace("{URL_EXPORTAR_EXCEL}", "?sw=valDList&ex=1", $PRINCIPAL);
    $datos_empresa = DatosEmpresa($id_empresa);
    echo CleanHTMLWhiteList($PRINCIPAL);
}
else if ($seccion == "Descarga_Base_Usuarios_2019") {

    $id_empresa = $_SESSION["id_empresa"];
    $version = $_GET["version"];
    
    
    require_once 'clases/PHPExcel.php';
    $objPHPExcel = new PHPExcel();
    $objPHPExcel = new PHPExcel();
    $styleArray = array('font' => array('bold' => true, 'color' => array('rgb' => '000000'), 'size' => 12, 'name' => 'Calibri'));
    $objPHPExcel->getProperties()
        ->setCreator("GO Partners")
        ->setLastModifiedBy("GO Partners")
        ->setTitle("Reconocimiento")
        ->setSubject("Reconocimiento")
        ->setDescription("Reconocimiento")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Plantilla usuarios");

if($id_empresa=="61" and $version=="1") {

    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A1", "Rut");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("B1", "Nombre");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("C1", "Sexo");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("D1", "Nacionalidad");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("E1", "Correo-E");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("F1", "Cargo");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("G1", "Empresa");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("H1", "Descr Empr");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("I1", "Clasificacion Emp.");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("J1", "Clasificacion");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("K1", "Region");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("L1", "Comuna");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("M1", "Desc.Ubicacion");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("N1", "Jornada");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("O1", "Fecha de Ingreso");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("P1", "Contrato");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("Q1", "Rut Jefatura Directa");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("R1", "Nombre Jefatura Directa");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("S1", "Cargo Jefatura");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("T1", "Gerencia");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("U1", "Segundo Nivel de Gerencia");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("V1", "GRF Jefe Ventas Seguros");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("W1", "Gerente Zona Jefe Zonal Seguros");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("X1", "Gerente 1 Linea");
		
		
}

if($id_empresa=="61" and $version=="2") {

    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A1", "Rut");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("B1", "Nombre");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("C1", "Sexo");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("D1", "Nacionalidad");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("E1", "ISAPRE");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("F1", "AFP");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("G1", "Pensionado");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("H1", "Art.22");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("I1", "Alt. Fisica");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("J1", "Alt. Geo.");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("K1", "Dueno");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("L1", "Profesion");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("M1", "Tipo de Contrato");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("N1", "Fecha Inscripcion");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("O1", "Fecha Contrato");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("P1", "Ingreso Faena");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("Q1", "Estado");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("R1", "Rut Contratista");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("S1", "Contratista");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("T1", "Faena");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("U1", "Mandante");
}

if($id_empresa=="61" and $version=="3") {

    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A1", "RUT S/DV");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("B1", "DV");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("C1", "USUARIO AS400");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("D1", "ESTADO AS400");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("E1", "LOGIN");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("F1", "NOMBRES");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("G1", "APELLIDO PATERNO");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("H1", "APELLIDO MATERNO");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("I1", "COMUNA");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("J1", "PAIS");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("K1", "SEXO");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("L1", "FECHA NACIMIENTO");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("M1", "ESTADO CIVIL");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("N1", "HIJOS");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("O1", "N° Hijos");
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("P1", "NACIONALIDAD");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("Q1", "EMPRESA");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("R1", "CAMPANA");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("S1", "SUPERVISOR");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("T1", "FECHA INGRESO EMPRESA");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("U1", "FECHA INGRESO CAMPANA");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("V1", "CARGO");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("W1", "TIPO CONTRATO");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("X1", "JORNADA");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("Y1", "ESTADO CONTRACTUAL");
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue("Z1", "ESTADO"); 


}
    $i = 2;
    $Arreglo = Busca_Usuarios_Completo($id_empresa, $version);
   //print_r($Arreglo);

    foreach ($Arreglo as $usu) {

        $usu_jefe     = TraeDatosUsuario($usu->jefe);
        $usu_lider     = TraeDatosUsuario($usu->lider);
        $jk++;
	
				$fecha_espanol=FechaEspanol($usu->fecha);

if($id_empresa=="61" and $version=="1") {
	$nombre_archivo="CENCOSUD_SCOTIABANK";
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A" . $i, $usu->rut_completo);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("B" . $i, ($usu->nombre));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("C" . $i, ($usu->genero));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("D" . $i, ($usu->pais));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("E" . $i, ($usu->email));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("F" . $i, ($usu->cargo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("G" . $i, ($usu->empresa_holding));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("H" . $i, ($usu->nombre_empresa_holding));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("I" . $i, ($usu->division));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("J" . $i, ($usu->mundo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("K" . $i, ($usu->regional));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("L" . $i, ($usu->zonal));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("M" . $i, ($usu->area));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("N" . $i, ($usu->tipo_contrato));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("O" . $i, ($usu->fecha_ingreso));
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue("P" . $i, ($usu->tipo_servicio));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("Q" . $i, ($usu->jefe));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("R" . $i, ($usu_jefe[0]->nombre_completo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("S" . $i, ($usu_jefe[0]->cargo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("T" . $i, ($usu->gerencia));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("U" . $i, ($usu->gerenciaR2));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("V" . $i, ($usu->operador));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("W" . $i, ($usu->organica));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("X" . $i, ($usu->vicepresidencia));
        
}

if($id_empresa=="61" and $version=="2") {
	$nombre_archivo="EXTERNO";
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A" . $i, $usu->rut_completo);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("B" . $i, ($usu->nombre));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("C" . $i, ($usu->genero));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("D" . $i, ($usu->pais));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("E" . $i, ($usu->operador));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("F" . $i, ($usu->organica));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("G" . $i, ($usu->userid_moodle));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("H" . $i, ($usu->codigo_sap));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("I" . $i, ($usu->tramosence));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("J" . $i, ($usu->tallergrupo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("K" . $i, ($usu->telefono_jefatura));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("L" . $i, ($usu->cargo)); 
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("M" . $i, ($usu->tipo_cargo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("N" . $i, ($usu->fecha_ingreso));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("O" . $i, ($usu->fecha_nacimiento));
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue("P" . $i, ($usu->direccion_particular));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("Q" . $i, ($usu->codigo_escolaridad));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("R" . $i, ($usu->jefe));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("S" . $i, ($usu->nombre_jefatura));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("T" . $i, ($usu->gerencia));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("U" . $i, ($usu->empresa_holding));

}

if($id_empresa=="61" and $version=="3") {
	$nombre_archivo="EXTERNO_CALLCENTER";
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A" . $i, $usu->rut);

				$rut_full = explode("-", $usu->rut_completo);
				$dv=$rut_full[1];
				
				
        //echo "dv $dv"; exit();
        
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("B" . $i, ($dv));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("C" . $i, ($usu->userid_moodle));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("D" . $i, ($usu->codigo_sap));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("E" . $i, ($usu->email_jefatura));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("F" . $i, ($usu->nombre));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("G" . $i, ($usu->apaterno));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("H" . $i, ($usu->amaterno));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("I" . $i, ($usu->comuna));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("J" . $i, ($usu->pais));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("K" . $i, ($usu->genero));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("L" . $i, ($usu->fecha_nacimiento));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("M" . $i, ($usu->estadocivil));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("N" . $i, ($usu->tallergrupo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("O" . $i, ($usu->tramosence));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("P" . $i, ($usu->nacionalidad));       

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("Q" . $i, ($usu->empresa_holding));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("R" . $i, ($usu->codigo_escolaridad));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("S" . $i, ($usu->nombre_jefatura));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("T" . $i, ($usu->fecha_ingreso));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("U" . $i, ($usu->fecha_antiguedad));  
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("V" . $i, ($usu->cargo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("W" . $i, ($usu->tipo_cargo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("X" . $i, ($usu->servicio));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("Y" . $i, ($usu->familia_cargo));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue("Z" . $i, ($usu->organica));          

}

     
        $i++;
        
    }
    $sheet = $objPHPExcel->getActiveSheet();
    $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
    $cellIterator->setIterateOnlyExistingCells(true);
    /** @var PHPExcel_Cell $cell */
    foreach ($cellIterator as $cell) {
        $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
    }
    

    
    $objPHPExcel->getActiveSheet()->setTitle('Usuarios');
    $objPHPExcel->setActiveSheetIndex(0);
    $fechahoy = date("Y-m-d") . "_" . date("H:i:s");
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="Base_Usuarios_' . $nombre_archivo . '.xlsx"');
    header('Cache-Control: max-age=0');
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
    
      //  echo "3";exit();
    
    exit;
}
else if($seccion=="entradaCap"){

        session_start();
       // print_r($_SESSION);
		
		
				$valor=$_POST["captcha"];

				
				//GOOGLE CAPTCHA
					class ReCaptchaResponse
					{
						public $success;
						public $errorCodes;
					}
					class ReCaptcha
					{
						private static $_signupUrl = "https://www.google.com/recaptcha/admin";
						private static $_siteVerifyUrl =
							"https://www.google.com/recaptcha/api/siteverify?";
						private $_secret;
						private static $_version = "php_1.0";
						/**
						 * Constructor.
						 *
						 * @param string $secret shared secret between site and ReCAPTCHA server.
						 */
						function ReCaptcha($secret)
						{
							if ($secret == null || $secret == "") {
								die("To use reCAPTCHA you must get an API key from <a href='"
									. self::$_signupUrl . "'>" . self::$_signupUrl . "</a>");
							}
							$this->_secret=$secret;
						}
						/**
						 * Encodes the given data into a query string format.
						 *
						 * @param array $data array of string elements to be encoded.
						 *
						 * @return string - encoded request.
						 */
						private function _encodeQS($data)

						{
							$req = "";
							foreach ($data as $key => $value) {
								$req .= $key . '=' . urlencode(stripslashes($value)) . '&';
							}
							// Cut the last '&'
							$req=substr($req, 0, strlen($req)-1);
							return $req;
						}
						/**
						 * Submits an HTTP GET to a reCAPTCHA server.
						 *
						 * @param string $path url path to recaptcha server.
						 * @param array  $data array of parameters to be sent.
						 *
						 * @return array response
						 */
						private function _submitHTTPGet($path, $data)
						{
							$req = $this->_encodeQS($data);
							$response = file_get_contents($path . $req);
							return $response;
						}
						/**
						 * Calls the reCAPTCHA siteverify API to verify whether the user passes
						 * CAPTCHA test.
						 *
						 * @param string $remoteIp   IP address of end user.
						 * @param string $response   response string from recaptcha verification.
						 *
						 * @return ReCaptchaResponse
						 */
						public function verifyResponse($remoteIp, $response)
						{
							// Discard empty solution submissions
							if ($response == null || strlen($response) == 0) {
								$recaptchaResponse = new ReCaptchaResponse();
								$recaptchaResponse->success = false;
								$recaptchaResponse->errorCodes = 'missing-input';
								return $recaptchaResponse;
							}
							$getResponse = $this->_submitHttpGet(
								self::$_siteVerifyUrl,
								array (
									'secret' => $this->_secret,
									'remoteip' => $remoteIp,
									'v' => self::$_version,
									'response' => $response
								)
							);
							$answers = json_decode($getResponse, true);
							$recaptchaResponse = new ReCaptchaResponse();
							if (trim($answers ['success']) == true) {
								$recaptchaResponse->success = true;
							} else {
								$recaptchaResponse->success = false;
								$recaptchaResponse->errorCodes = $answers [error-codes];
							}
							return $recaptchaResponse;
						}
					} 
					// Get a key from https://www.google.com/recaptcha/admin/create
					 if ($_POST["g-recaptcha-response"]) {
						 //ini_set('display_errors', 1);ini_set('display_startup_errors', 1);error_reporting(E_ALL);
						  $secret = "";
						  $response = null;
						 // comprueba la clave secreta
						 $reCaptcha = new ReCaptcha($secret);
						 $response = $reCaptcha->verifyResponse(
						 $_SERVER["REMOTE_ADDR"],
						 $_POST["g-recaptcha-response"]
						 );
						 if ($response != null && $response->success) {
						// Si el c&oacute;digo es correcto, seguimos procesando el formulario como siempre
						//exit("si");
$rut	=Decodear3($_SESSION["toku"]);
$clave	=Decodear3($_SESSION["tokc"]);

/*
echo "hola";

echo "rut $rut, clave $clave"; 
*/

	$existe_base = UsuarioAdminRutEmpresa($rut);
//print_r($existe_base);
	if ($existe_base) {
		//$rut = $existe_base[0]->rut;

		$total_intentos = 3;
		$verifica_clave = VerificaClaveAccesoAdmin($rut, $clave);
		
//print_r($verifica_clave); 
		if ($verifica_clave) {
		session_start();
			// INGRESO CORRECTO
			
			//echo "hola";
        $_SESSION["user_"] = $rut;
        $_SESSION["admin_"] = $rut;
	        $home_admin = $arrayEmpresa[0]->home_admin;
		
			//InsertTblAnalitica($rut, $existe_base[0]->id_empresa, "LOGIN", "LoginRut");
//echo "hola OK";				
				$_SESSION["user_"] = $rut;
				$_SESSION["id_empresa"] = $existe_base[0]->id_empresa;
        $arrayEmpresa = BuscaEmpresaUserRut($rut);
        $home_admin = $arrayEmpresa[0]->home_admin;
//echo "$home_admin rut $rut";exit();
				
        echo "
                            <script>
                                location.href='?sw=" . $home_admin . "';
                            </script>";
        exit;
				
			
		}
		else {
			// CLAVE INCORRECTA
			session_start();
						echo " <script>alert('Ups, las credenciales no son correctas'); location.href='?sw=logout';    </script>";exit;
				echo "<script>location.href='https://www.masconectadosbch.cl/admin/?sw=login';</script>";
				exit;
			
		}
	}
				else   
					{
						echo " <script>alert('Ups, las credenciales no son correctas'); location.href='?sw=logout';    </script>";exit;
					}
		}		
	} else {
	echo " <script>alert('Ups, las credenciales no son correctas'); location.href='?sw=logout';    </script>";exit;

				echo "<script>location.href='https://www.masconectadosbch.cl/admin/?sw=login';</script>";
				exit;	
		
	}
}
if ($seccion == "UpdateClave") {
	UpdateClavedata();
}
else if($seccion=="logout"){    
	session_start();
	$_SESSION = array();
	if (ini_get("session.use_cookies")) {
    		$params = session_get_cookie_params();
   		 setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
	}
	session_destroy();
 	echo "    <script>         location.href='https://www.masconectadosbch.cl';     </script>"; exit;
}
else if ($seccion == "checkUserAdmin") {
    session_start();

    $nombre_completo = $_GET["fullName"];
    $nombre = $_GET["GivenName"];
    $apellido = $_GET["FamilyName"];
    $imagenUrl = $_GET["imageUrl"];
    $email = $_GET["email"];
    $user_content_key = $_GET["user_content_key"];
    $arreglo_email = $arreglo_archivo = explode("@", $email);

    if ($arreglo_email[1] == "bci.cl" or $arreglo_email[1] == "gop.cl" or $arreglo_email[1] == "cajalosandes.cl" or $arreglo_email[1] == "externos.bci.cl") {
        $key = $email;
        $arrayEmpresa = BuscaEmpresaUserRut($rut);
        //print_r($arrayEmpresa);
        $id_empresa = $arrayEmpresa[0]->id_empresa;
        $_SESSION["id_empresa"] = $id_empresa;
        $acceso = $arrayEmpresa[0]->acceso;
        $home_admin = $arrayEmpresa[0]->home_admin;
        $_SESSION["user_"] = $key;
        $_SESSION["admin_"] = $key;

        $verifica_clave_Google = VerificoAccesoAdminGoogle($key);

        //exit();
        if ($verifica_clave_Google) {
            $_SESSION["prefijo"] = $verifica_clave_Google[0]->prefijo;
            $_SESSION["nombre"] = $verifica_clave_Google[0]->nombre;
            $_SESSION["perfil"] = $verifica_clave_Google[0]->acceso;
            $_SESSION["id_empresa"] = $verifica_clave_Google[0]->id_empresa;
        }

        if (count($verifica_clave_Google) == 0) {
            echo "
                            <script>
                                location.href='?sw=login_id';
                            </script>";
            exit;
        }

        if ($key == "") {
            echo "
                                    <script>
                                        location.href='?sw=login_id';
                                    </script>";
            exit;
        }

        echo "
                            <script>
                                location.href='?sw=" . $home_admin . "';
                            </script>";
        exit;
    } else {

        echo "
                            <script>
                                location.href='?sw=login_id';
                            </script>";
        exit;
    }
}
?>