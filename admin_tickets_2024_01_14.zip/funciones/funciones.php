<?php

function CleanHTMLWhiteList($html)
{
    if ($html === null) {
        return '';
    }
    $listaBlanca = [
        'a', 'abbr', 'acronym', 'address', 'applet', 'area', 'article', 'aside', 'audio', 'b', 'base',
        'basefont', 'bdi', 'bdo', 'bgsound', 'big', 'blink', 'blockquote', 'body', 'br', 'button', 'canvas',
        'caption', 'center', 'cite', 'code', 'col', 'colgroup', 'command', 'content', 'data', 'datalist', 'dd',
        'del', 'details', 'dfn', 'dialog', 'dir', 'div', 'dl', 'dt', 'element', 'em', 'embed', 'fieldset',
        'figcaption', 'figure', 'font', 'footer', 'form', 'frame', 'frameset', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'head', 'header', 'hgroup', 'hr', 'html', 'i', 'iframe', 'img', 'input', 'ins', 'isindex', 'kbd', 'label',
        'legend', 'li', 'link', 'listing', 'main', 'map', 'mark', 'marquee', 'menu', 'menuitem', 'meta', 'meter',
        'nav', 'nobr', 'noembed', 'noframes', 'noscript', 'object', 'ol', 'optgroup', 'option', 'output', 'p',
        'param', 'picture', 'plaintext', 'pre', 'progress', 'q', 'rb', 'rp', 'rt', 'rtc', 'ruby', 's', 'samp',
        'script', 'section', 'select', 'shadow', 'slot', 'small', 'source', 'spacer', 'span', 'strike', 'strong',
        'style', 'sub', 'summary', 'sup', 'table', 'tbody', 'td', 'template', 'textarea', 'tfoot', 'th', 'thead',
        'time', 'title', 'tr', 'track', 'tt', 'u', 'ul', 'var', 'video', 'wbr', 'xmp'
    ];
    $doc = new DOMDocument();
    libxml_use_internal_errors(true); // Suprimir errores de an�lisis

    // Cargar el HTML en el documento DOM
    $doc->loadHTML($html);
    // Recorrer todos los elementos del documento
    $elements = $doc->getElementsByTagName('*');
    foreach ($elements as $element) {
        // Obtener el nombre del tag
        $tagName = $element->tagName;

        // Si el tag no est� en la lista blanca, eliminarlo
        if (!in_array($tagName, $listaBlanca, true)) {
            $parent = $element->parentNode;
            $parent->removeChild($element);
        }
    }
    // Obtener el HTML modificado
    return $doc->saveHTML();
}
function VerificaArregloSQLInjectionV2($arreglo)
{
$total_arreglo = count($arreglo);

foreach ($arreglo as $clave => $valor) {

if (strtoupper(trim($valor)) == "") {
continue;
}

$valor = str_replace("'", "", $valor);
$valor = str_replace('"', "", $valor);
$valor = str_replace("+'", "", $valor);
$valor = str_replace('--', "", $valor);
$valor = str_replace('--', "", $valor);
$valor = str_replace('--', "", $valor);
$valor = str_replace('&', "", $valor);
$valor = str_replace('.php', "", $valor);
$valor = str_replace('.js', "", $valor);
$valor = str_replace('.vbs', "", $valor);
$valor = str_replace('%', "", $valor);
$valor = str_replace('&', "", $valor);
$valor = str_replace('&amp;', "", $valor);
$valor = str_replace('&#38;', "", $valor);
$valor = str_replace('<', "", $valor);
$valor = str_replace('&lt;', "", $valor);
$valor = str_replace('&#60;', "", $valor);
$valor = str_replace('>', "", $valor);
$valor = str_replace('&gt;', "", $valor);
$valor = str_replace('&#62;', "", $valor);
$valor = str_replace('&quot;', "", $valor);
$valor = str_replace('&#34;', "", $valor);
$valor = str_replace('&#39;', "", $valor);
$valor = str_replace('select', "", $valor);
$valor = str_replace('tables', "", $valor);
$valor = str_replace('union', "", $valor);
$valor = str_replace('information_schema', "", $valor);
//$valor = str_replace('', "", $valor);
$valor = str_replace('delete', "", $valor);
$valor = str_replace('update', "", $valor);
$valor = str_replace('show', "", $valor);
$valor = str_replace('|', "", $valor);
$arreglo[$clave]= $valor;
}
return ($arreglo);
}

function VerificaArregloSQLInjectionDecodear($arreglo)
{
$total_arreglo = is_array($arreglo) ? count($arreglo) : 0;
$arreglo = str_replace('"', "", $arreglo);
$arreglo = str_replace("+'", "", $arreglo);
$arreglo = str_replace('--', "", $arreglo);
$arreglo = str_replace('--', "", $arreglo);
$arreglo = str_replace('--', "", $arreglo);
$arreglo = str_replace('&', "", $arreglo);
$arreglo = str_replace('.php', "", $arreglo);
$arreglo = str_replace('.js', "", $arreglo);
$arreglo = str_replace('.vbs', "", $arreglo);
$arreglo = str_replace('%', "", $arreglo);
$arreglo = str_replace('&', "", $arreglo);
$arreglo = str_replace('&amp;', "", $arreglo);
$arreglo = str_replace('&#38;', "", $arreglo);
$arreglo = str_replace('&lt;', "", $arreglo);
$arreglo = str_replace('&#60;', "", $arreglo);
$arreglo = str_replace('&gt;', "", $arreglo);
$arreglo = str_replace('&#62;', "", $arreglo);
$arreglo = str_replace('&quot;', "", $arreglo);
$arreglo = str_replace('&#34;', "", $arreglo);
$arreglo = str_replace('&#39;', "", $arreglo);
$arreglo = str_replace('select', "", $arreglo);
$arreglo = str_replace('tables', "", $arreglo);
$arreglo = str_replace('union', "", $arreglo);
$arreglo = str_replace('information_schema', "", $arreglo);
$arreglo = str_replace('delete', "", $arreglo);
$arreglo = str_replace('update', "", $arreglo);
$arreglo = str_replace('show', "", $arreglo);
$arreglo = str_replace('|', "", $arreglo);
$arreglo = str_replace('user()', "", $arreglo);
return ($arreglo);
}

function VerificaArregloSQLInjectionLight($arreglo)
{
$total_arreglo = count($arreglo);

foreach ($arreglo as $clave => $valor) {

if (strtoupper(trim($valor)) == "") {
continue;
}
$valor = str_replace('--', "", $valor);
$valor = str_replace('.php', "", $valor);
$valor = str_replace('.js', "", $valor);
$valor = str_replace('.vbs', "", $valor);
$valor = str_replace('&#38;', "", $valor);
$valor = str_replace('&lt;', "", $valor);
$valor = str_replace('&#60;', "", $valor);
$valor = str_replace('&gt;', "", $valor);
$valor = str_replace('&#62;', "", $valor);
$valor = str_replace('&quot;', "", $valor);
$valor = str_replace('&#34;', "", $valor);
$valor = str_replace('&#39;', "", $valor);
$valor = str_replace('select', "", $valor);
$valor = str_replace('delete', "", $valor);
$valor = str_replace('update', "", $valor);
$valor = str_replace('show', "", $valor);
$valor = str_replace('|', "", $valor);
$arreglo[$clave]= $valor;
}
return ($arreglo);
}

function Decodear3($valor)
{
    //$valor=Decodear(Decodear(Decodear($valor)));
    //print_r($valor);
    $valor = my_simple_crypt_decodear($valor, 'd');
    $valor      = VerificaArregloSQLInjectionDecodear($valor);
    return ($valor);
}

function my_simple_crypt_decodear($string)
{
    // you may change these values to your own
    $secret_key     = getenv('SECRET_KEYTICK1');
    $secret_iv      = getenv('SECRET_IVTICK1');
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv), 0, 16);
    $output         = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    return $output;
}
function my_simple_crypt_encodear($string)
{
    // you may change these values to your own
    $secret_key     = getenv('SECRET_KEYTICK1');
    $secret_iv      = getenv('SECRET_IVTICK1');
    $output         = false;
    $encrypt_method = "AES-256-CBC";
    $key            = hash('sha256', $secret_key);
    $iv             = substr(hash('sha256', $secret_iv), 0, 16);
    $output         = base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
    return $output;
}
function Encodear3($valor)
{
    //$valor=Encodear(Encodear(Encodear($valor)));
    $valor = my_simple_crypt_encodear($valor, 'e');
    return ($valor);
}
function FuncionesTransversalesAdmin($html){
    $id_empresa=$_SESSION["id_empresa"];
    $perfil="";
    if(isset($_SESSION["perfil"]) && $_SESSION["perfil"] !== ""){
        $perfil = PerfilAdmin($_SESSION["perfil"]);
    }
    $acceso_admin_perfil=VerificaTipoDePerfilAdminAcceso($_SESSION["user_"]);
    $html = str_replace("{MENU_IZQUIERDO}",file_get_contents("views/menu_izquierdo/".$acceso_admin_perfil[0]->template.""),$html);
    $html = str_replace("{HEAD}",file_get_contents("views/head.html"),$html);
    $html = str_replace("{HEADER}",file_get_contents("views/header.html"),$html);
    $html = str_replace("{NAVEGACION}",file_get_contents("views/navegacion.html"),$html);
    $html = str_replace("{FOOTER_ADMIN}",file_get_contents("views/footer.html"),$html);
    $AdminData=UsuarioAdminRutEmpresa($_SESSION["user_"]);
    $html = str_replace("{USER_TEMPLATE}","<div style='    padding: 15px;'>".$AdminData[0]->nombre_completo."</div>",$html);
    if (isset($perfil) && !empty($perfil)) {
        $perfilArray = str_split($perfil); // Convert $perfil to an array of characters
        if (isset($perfilArray[0])) {
            $html = str_replace("{HOME_INICIAL}", $perfilArray[0]->home, $html);
        } else {
        }
    }    $html = str_replace("{TITTLE}","Administracion",$html);
    if (isset($_SESSION["nombre"])) {
        $html = str_replace("{NOMBRE_USUARIO}", utf8_encode($_SESSION["nombre"]), $html);
    } else {
    }
    if (isset($perfil[0]) && isset($perfil[0]->nombre_perfil)) {
        $html = str_replace("{PERFIL_ADMIN}", utf8_encode($perfil[0]->nombre_perfil), $html);
    } else {
    }    return($html);
}

function VerificaFotoPersonalDesdeAdmin($rut){
    $imagen="../front/img/foto_perfil.jpg";
    return($imagen);
}

function CheckSesionActiva($rut){
    //echo "<br>--> CheckSesionActiva rut $rut ";
    $existe_base = UsuarioAdminRutEmpresa($rut);
    //print_r($existe_base);

    if($existe_base[0]->id>0){

    }
    else {
        session_start();
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        echo "<script>alert('Usuario no Registrado'); location.href='?sw=logout';</script>";exit();
    }


    if($rut==""){
        session_start();
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        echo "<script>alert('Usuario no Registrado'); location.href='?sw=logout';</script>";exit();
    }


}
function Tickets_Registro_Gestion_Preguntas_Respuestas_FN($html,  $id_empresa, $idcategoria, $tipo, $rut, $vista,  $fecha_inicio, $fecha_termino){

    //echo "<br>Function Tickets_Registro_Gestion_Preguntas_Respuestas_FN<br>$id_empresa, $idcategoria, $tipo, $rut, vista $vista, month $month, year $year<br>";
    $row=file_get_contents("views/tickets/entorno_tickets_preguntas_respuestas_2022.html");

    $Lista_Tickets=Tickets_lista_preguntas_respuestas_2022_data($id_empresa,$tipo, $rut, $perfil, $fecha_inicio, $fecha_termino);
    $tipo_demora_cerrado=0;
    $tipo_demora_cerrado_con_demora=0;
    $tipo_demora_abierto=0;
    $tipo_demora_abierto_con_demora=0;

    //print_r($Lista_Tickets);
    foreach($Lista_Tickets as $unico){
        $row	=	file_get_contents("views/tickets/row_tickets_preguntas_2022.html");
        $row 	= str_replace("{ID_PREGUNTA}",      							utf8_encode($unico->id),$row);
        $row 	= str_replace("{ID_PREGUNTA_ENC}",      						Encodear3($unico->id),$row);


        if($unico->id_empresa=="99"){
            $unico->pregunta1=$unico->pregunta1." <em>[DESPUBLICADA]</em>";
        }        else {
            $unico->pregunta1=$unico->pregunta1;
        }
        $row 	= str_replace("{PREGUNTA}",      								utf8_encode($unico->pregunta1),$row);
        $row 	= str_replace("{PREGUNTA2}",      								utf8_encode($unico->pregunta2),$row);
        $row 	= str_replace("{PREGUNTA3}",      								utf8_encode($unico->pregunta3),$row);
        $row 	= str_replace("{PREGUNTA4}",      								utf8_encode($unico->pregunta4),$row);
        $row 	= str_replace("{PREGUNTA5}",      								utf8_encode($unico->pregunta5),$row);
        $row 	= str_replace("{PREGUNTA6}",      								utf8_encode($unico->pregunta6),$row);
        $row 	= str_replace("{PREGUNTA7}",      								utf8_encode($unico->pregunta7),$row);
        $row 	= str_replace("{PREGUNTA8}",      								utf8_encode($unico->pregunta8),$row);
        $row 	= str_replace("{PREGUNTA9}",      								utf8_encode($unico->pregunta9),$row);
        $row 	= str_replace("{PREGUNTA10}",      								utf8_encode($unico->pregunta10),$row);
        $row 	= str_replace("{ID_RESPUESTA}",      							utf8_encode($unico->id_respuesta),$row);
        $row 	= str_replace("{RESPUESTA}",      								utf8_encode($unico->respuesta),$row);
        $row 	= str_replace("{CATEGORIA}",      								utf8_encode($unico->categoria),$row);
        $row 	= str_replace("{SUBCATEGORIA}",      							utf8_encode($unico->subcategoria),$row);
        $row 	= str_replace("{RATING_SI}",      								utf8_encode($unico->CuentaSi),$row);
        $row 	= str_replace("{RATING_NO}",      								utf8_encode($unico->CuentaNo),$row);
        $row 	= str_replace("{EDITAR}",      								    utf8_encode($editar),$row);
        $row 	= str_replace("{BORRAR}",      								    utf8_encode($borrar),$row);
        $total_html.=$row;
    }
    $total_html 	= str_replace("{NIVEL}","2",$total_html);
    $total_html 	= str_replace("{SUB_CAT}","",$total_html);
    $total_html 	= str_replace("{NSUB}","",$total_html);
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{VISTA}",$vista ,$html);

    $form_filtro=
        "
					
					<div class='row'>
					<div class='col-lg-3'>
					<form name='rango' id='rango' action='?sw=Tickets_Registros' method='post'>
						<label>Fecha Inicio</label>
						<br>
						<input type='date' name='fecha_inicio' id='fecha_inicio' value='".$fecha_inicio."' class='form form-control' required> 
					</div>	
					<div class='col-lg-3'>
						<label>Fecha T&eacute;rmino</label>
						<br>
						<input type='date' name='fecha_termino' id='fecha_inicio' value='".$fecha_termino."' class='form form-control' required> 
					</div>	
					<div class='col-lg-3'>
						<label>Vista</label>
						<select name='tipo_vista' class='form form-control' required>
							<option value=''></option>
							<option value='Web'>Web</option>
							<option value='Excel'>Excel</option>
						</select>
					</div>
					<div class='col-lg-3'>
					<label><br><br></label>
							<input type='submit' value='Filtrar' class='btn btn-info'>
							</form>
					</div>
				</div>
				";
    $html = str_replace("{VISTA_YEAR_MONTH}",$form_filtro ,$html);
    return($html);
}

function VerificaExtensionFilesAdmin($file){
    //echo "<br>file $file";
    $arreglo_archivo = explode(".", $file);
    $extension_archivo = $arreglo_archivo[1];
    //echo "<br>cuenta ".count($arreglo_archivo);		//print_r($arreglo_archivo);		//echo "<br>ex $extension_archivo";

    if(count($arreglo_archivo)<>2){
        echo "<br>archivo invalido con mas de una extension";	 echo "    <script>alert('Formato de Archivo Incompatible'); 			location.href='?sw=home_landing';    </script>";exit();
    }

    if($extension_archivo=="pdf" or $extension_archivo=="PDF" or $extension_archivo=="ppt" or $extension_archivo=="PPT"
        or $extension_archivo=="pptx" or $extension_archivo=="PPTX" or $extension_archivo=="doc" or $extension_archivo=="DOC"
        or $extension_archivo=="docx" or $extension_archivo=="DOCX" or $extension_archivo=="xls" or $extension_archivo=="XLS"
        or $extension_archivo=="csv" or $extension_archivo=="CSV"
        or $extension_archivo=="xlsx" or $extension_archivo=="XLSX" or $extension_archivo=="jpg" or $extension_archivo=="JPG"
        or $extension_archivo=="jpeg" or $extension_archivo=="JPEG" or $extension_archivo=="zip" or $extension_archivo=="ZIP"
        or $extension_archivo=="png" or $extension_archivo=="PNG" or $extension_archivo=="CSV"  or $extension_archivo=="csv")	{
        //echo "<br>archivo valido";
    } else {
        echo "<br>archivo invalido";	 echo "    <script>alert('Formato de Archivo Incompatible'); 			location.href='?sw=home_landing';    </script>";exit();
    }
}

function VerificaExtensionFiles($file){
    $arreglo_archivo = explode(".", $file);
    $extension_archivo = $arreglo_archivo[1];
    if(count($arreglo_archivo)<>2){
        //rechaza archivos sin extension o con mas de una
        session_start();
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        // Finalmente, destruir la sesi�n.
        session_destroy();
        echo "<script>alert('Formato de Archivo Incompatible'); location.href='?sw=logout';</script>";exit();
    }
    //rechaza archivos diferentes a la siguiente lista blanca
    if($extension_archivo=="pdf" or $extension_archivo=="PDF" or $extension_archivo=="ppt" or $extension_archivo=="PPT"
        or $extension_archivo=="pptx" or $extension_archivo=="PPTX" or $extension_archivo=="doc" or $extension_archivo=="DOC"
        or $extension_archivo=="docx" or $extension_archivo=="DOCX" or $extension_archivo=="xls" or $extension_archivo=="XLS"
        or $extension_archivo=="xlsx" or $extension_archivo=="XLSX" or $extension_archivo=="jpg" or $extension_archivo=="JPG"
        or $extension_archivo=="jpeg" or $extension_archivo=="JPEG" or $extension_archivo=="zip" or $extension_archivo=="ZIP"
        or $extension_archivo=="gif" or $extension_archivo=="GIF" or $extension_archivo=="png" or $extension_archivo=="PNG"
        or $extension_archivo=="msg")
    {
        //echo "<br>archivo valido";
    } else {
        session_start();
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        // Finalmente, destruir la sesi�n.
        session_destroy();

        echo "<br>archivo invalido";	 echo "    <script>alert('Formato de Archivo Incompatible'); 			location.href='?sw=logout';    </script>";exit();
    }
}

function lista_gestion_usuarios_licencias($html,  $id_empresa, $temporal_actualizar, $procesar){
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);
    $html = str_replace("{PROCESAR}",$btn_procesar,$html);
    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);
    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_subida_bitacora($html,  $id_empresa, $temporal_actualizar, $procesar){
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);
    $html = str_replace("{PROCESAR}",$btn_procesar,$html);
    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);
    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function biss_hours($start, $end){
    $startDate = new DateTime($start);
    $endDate = new DateTime($end);
    $periodInterval = new DateInterval( "PT1H" );
    $period = new DatePeriod( $startDate, $periodInterval, $endDate );
    $count = 0;
    foreach($period as $date){
        $startofday = clone $date;
        $startofday->setTime(9,01);
        $endofday = clone $date;
        $endofday->setTime(17,59);
        if($date > $startofday && $date <= $endofday && !in_array($date->format('l'), array('Sunday','Saturday'))){
            $count++;
        }
    }
    return $count;
}

function getWorkingHoursInSeconds(DateTime $start, DateTime $end, array $working_hours)
{
    $seconds = 0; // Total working seconds
    // Calculate the Start Date (Midnight) and Time (Seconds into day) as Integers.
    $start_date = clone $start;
    $start_date = $start_date->setTime(0, 0, 0)->getTimestamp();
    $start_time = $start->getTimestamp() - $start_date;
    // Calculate the Finish Date (Midnight) and Time (Seconds into day) as Integers.
    $end_date = clone $end;
    $end_date = $end_date->setTime(0, 0, 0)->getTimestamp();
    $end_time = $end->getTimestamp() - $end_date;
    // For each Day
    for ($today = $start_date; $today <= $end_date; $today += 86400) {
        // Get the current Weekday.
        $today_weekday = date('w', $today);
        // Skip to next day if no hours set for weekday.
        if (!isset($working_hours[$today_weekday][0]) || !isset($working_hours[$today_weekday][1])) continue;
        // Set the office hours start/finish.
        $today_start = $working_hours[$today_weekday][0];
        $today_end = $working_hours[$today_weekday][1];
        // Adjust Start/Finish times on Start/Finish Day.
        if ($today === $start_date) $today_start = min($today_end, max($today_start, $start_time));
        if ($today === $end_date) $today_end = max($today_start, min($today_end, $end_time));
        // Add to total seconds.
        $seconds += $today_end - $today_start;
    }
    return $seconds;
}

function Tickets_get_working_hours($from,$to)
{

    //echo "<br>Tickets_get_working_hours($from,$to)<br>";
    // timestamps
    $from_timestamp = strtotime($from);
    $to_timestamp = strtotime($to);

    // work day seconds
    $workday_start_hour = 9;
    $workday_end_hour = 18;
    $workday_seconds = ($workday_end_hour - $workday_start_hour)*3600;

    // work days beetwen dates, minus 1 day
    $from_date = date('Y-m-d',$from_timestamp);
    $to_date = date('Y-m-d',$to_timestamp);
    $workdays_number = count(get_workdays($from_date,$to_date))-1;
    $workdays_number = $workdays_number<0 ? 0 : $workdays_number;

    // start and end time
    $start_time_in_seconds = date("H",$from_timestamp)*3600+date("i",$from_timestamp)*60;
    $end_time_in_seconds = date("H",$to_timestamp)*3600+date("i",$to_timestamp)*60;

    // final calculations
    $working_hours = ($workdays_number * $workday_seconds + $end_time_in_seconds - $start_time_in_seconds) / 86400 * 24;

    return round($working_hours);
}

function get_workdays($from,$to)
{
    // arrays
    $days_array = array();
    $skipdays = array("Saturday", "Sunday");
    $skipdates = get_holidays();

    // other variables
    $i = 0;
    $current = $from;

    if($current == $to) // same dates
    {
        $timestamp = strtotime($from);
        if (!in_array(date("l", $timestamp), $skipdays)&&!in_array(date("Y-m-d", $timestamp), $skipdates)) {
            $days_array[] = date("Y-m-d",$timestamp);
        }
    }
    elseif($current < $to) // different dates
    {
        while ($current < $to) {
            $timestamp = strtotime($from." +".$i." day");
            if (!in_array(date("l", $timestamp), $skipdays)&&!in_array(date("Y-m-d", $timestamp), $skipdates)) {
                $days_array[] = date("Y-m-d",$timestamp);
            }
            $current = date("Y-m-d",$timestamp);
            $i++;
        }
    }

    return $days_array;
}


function get_holidays()
{
    // arrays
    $days_array = array();

    // You have to put there your source of holidays and make them as array...
    // For example, database in Codeigniter:
    // $days_array = $this->my_model->get_holidays_array();

    return $days_array;
}


function Tickets_SubirArchivosTickets($FILES, $prefijo, $ruta)
{
    $allowedExtensions = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'zip', 'gif', 'png', 'msg'];

    // Check if the file is uploaded successfully
    if (!isset($FILES["archivo"]["error"]) || is_array($FILES["archivo"]["error"])) {
        return false; // Return false for invalid file upload
    }

    // Check for upload errors
    switch ($FILES["archivo"]["error"]) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            return false; // Return false for no file uploaded
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return false; // Return false for file size exceeded
        default:
            return false; // Return false for other upload errors
    }

    // Get the file extension
    $fileExtension = pathinfo($FILES["archivo"]["name"], PATHINFO_EXTENSION);

    // Check if the file extension is in the allowed list
    if (!in_array(strtolower($fileExtension), $allowedExtensions)) {
        return false; // Return false for invalid file extension
    }

    $ruta = rtrim($ruta, '/'); // Remove trailing slash from the ruta
    $ruta_con_archivo = $ruta . "/" . $prefijo . "." . $fileExtension;

    if (move_uploaded_file($FILES["archivo"]["tmp_name"], $ruta_con_archivo)) {
        $nombre_imagen_video = $prefijo . "." . $fileExtension;
        $arreglo[0] = $ruta_con_archivo; // Ruta Completa
        $arreglo[1] = $nombre_imagen_video; // Nombre del Archivo
        $arreglo[2] = $ruta . "/" . $prefijo; // Ruta del Objeto sin el index
    } else {
        return false; // Return false to indicate file copying failure
    }

    return $arreglo;
}

function Tickets_SubirArchivos2Tickets($FILES, $extension_doc, $prefijo, $ruta, $numero, $nombre_file)
{
    $allowedExtensions = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'zip', 'gif', 'png', 'msg'];

    // Check if the file is uploaded successfully
    if (!isset($FILES["archivo2"]["error"]) || is_array($FILES["archivo2"]["error"])) {
        return false; // Return false for invalid file upload
    }

    // Check for upload errors
    switch ($FILES["archivo2"]["error"]) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            return false; // Return false for no file uploaded
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return false; // Return false for file size exceeded
        default:
            return false; // Return false for other upload errors
    }

    // Get the file extension
    $fileExtension = pathinfo($FILES["archivo2"]["name"], PATHINFO_EXTENSION);

    // Check if the file extension is in the allowed list
    if (!in_array(strtolower($fileExtension), $allowedExtensions)) {
        return false; // Return false for invalid file extension
    }

    $ruta = rtrim($ruta, '/'); // Remove trailing slash from the ruta
    $ruta_con_archivo = $ruta . "/" . $prefijo . "." . $fileExtension;

    if (move_uploaded_file($FILES["archivo2"]["tmp_name"], $ruta_con_archivo)) {
        $nombre_imagen_video = $prefijo . "." . $fileExtension;
        $arreglo[0] = $ruta_con_archivo; // Ruta Completa
        $arreglo[1] = $nombre_imagen_video; // Nombre del Archivo
        $arreglo[2] = $ruta . "/" . $prefijo; // Ruta del Objeto sin el index
    } else {
        return false; // Return false to indicate file copying failure
    }

    return $arreglo;
}

function Tickets_SubirArchivos3Tickets($FILES, $extension_doc, $prefijo, $ruta, $numero, $nombre_file)
{
    $allowedExtensions = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'zip', 'gif', 'png', 'msg'];

    // Check if the file is uploaded successfully
    if (!isset($FILES["archivo3"]["error"]) || is_array($FILES["archivo3"]["error"])) {
        return false; // Return false for invalid file upload
    }

    // Check for upload errors
    switch ($FILES["archivo3"]["error"]) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            return false; // Return false for no file uploaded
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return false; // Return false for file size exceeded
        default:
            return false; // Return false for other upload errors
    }

    // Get the file extension
    $fileExtension = pathinfo($FILES["archivo3"]["name"], PATHINFO_EXTENSION);

    // Check if the file extension is in the allowed list
    if (!in_array(strtolower($fileExtension), $allowedExtensions)) {
        return false; // Return false for invalid file extension
    }

    $ruta = rtrim($ruta, '/'); // Remove trailing slash from the ruta
    $ruta_con_archivo = $ruta . "/" . $prefijo . "." . $fileExtension;

    if (move_uploaded_file($FILES["archivo3"]["tmp_name"], $ruta_con_archivo)) {
        $nombre_imagen_video = $prefijo . "." . $fileExtension;
        $arreglo[0] = $ruta_con_archivo; // Ruta Completa
        $arreglo[1] = $nombre_imagen_video; // Nombre del Archivo
        $arreglo[2] = $ruta . "/" . $prefijo; // Ruta del Objeto sin el index
    } else {
        return false; // Return false to indicate file copying failure
    }

    return $arreglo;
}

function Tickets_lista($html,  $id_empresa, $idcategoria, $tipo, $rut, $vista){
    //echo "<br>Function Tickets Lista<br>$id_empresa, $idcategoria, $tipo, $rut, vista $vista<br>";
    $row=file_get_contents("views/tickets/entorno_tickets.html");
    $Ejecutivo=Tickets_Busca_datos_admin($rut, $id_empresa);
    $total_html = '';
    //print_r($Ejecutivo);
    if($Ejecutivo[0]->go=="2"){
        $perfil="ejecutivo";
    } elseif ($Ejecutivo[0]->go=="1"){
        $perfil="ejecutivo_superadmin";
    }
    elseif ($Ejecutivo[0]->go=="3"){
        $perfil="ejecutivo_derivado";

    } else{
        $perfil="colaborador";
    }
    if($vista=="1"){
        $perfil="ejecutivo_superadmin";
    }

    $Lista_Tickets=Tickets_lista_tickets_data($id_empresa,$tipo, $rut, $perfil);
    $tipo_demora_cerrado=0;
    $tipo_demora_cerrado_con_demora=0;
    $tipo_demora_abierto=0;
    $tipo_demora_abierto_con_demora=0;
    if (count(isset($Lista_Tickets) ? $Lista_Tickets : []) > 0) {

        foreach($Lista_Tickets as $unico){
        $row=file_get_contents("views/tickets/row_tickets.html");
        $row = str_replace("{ID}",      				utf8_encode($unico->id),$row);
        $row = str_replace("{SOLICITANTE}",     		utf8_encode($unico->rut),$row);
        $row = str_replace("{NOMBRE_SOLICITANTE}",     	utf8_encode($unico->nombre_completo),$row);
        $row = str_replace("{CARGO_SOLICITANTE}",     	utf8_encode($unico->cargo),$row);
        $row = str_replace("{DIVISION_SOLICITANTE}",    utf8_encode($unico->division),$row);
        if($unico->creado_admin=="1"){
            $row = str_replace("{TIPO_CREADO_ADMIN}",   "<div class='badge badge-danger badge-full'  style=' background-color: #8da1ab;'>Creaci&oacute;n Ejecutivo</div>",$row);
        } else {
            $row = str_replace("{TIPO_CREADO_ADMIN}",   "",$row);
        }

        $hoy_ahora= date("Y-m-d")." ".date("H:i:s");


        if($unico->fecha_estado<>"" and $unico->hora_estado<>""){
            $fecha_comparacion=$unico->fecha_estado." ".$unico->hora_estado;
        } else {
            $fecha_comparacion=$hoy_ahora;
        }
        $ticket_creado	=	$unico->fecha." ".$unico->hora;
        $Hours=biss_hours($ticket_creado,$fecha_comparacion)-1;
        if($unico->sla_categoria==""){
            $Sla="24";
        } else {
            $Sla=$unico->sla_categoria;
        }
        if($Hours=="-0"){$Hours=0;}
        if($Hours=="-1"){$Hours=0;}
        $estado_renegociada="";
        if($unico->horas_renegociada>0){
            $Sla=$Sla+$unico->horas_renegociada;
            $estado_renegociada="<div class='badge badge-info'>Renegociado por ".$unico->horas_renegociada." horas </div>";
        }
        if($unico->fecha_reapertura_original<>""){
            $reapertura="";
        } else {
            $reapertura="";
        }
        $porcentaje_Sla_Hours=round(100*$Hours/$Sla);
        $row = str_replace("{HORAS_TRANSCURRIDAS}",										utf8_encode($Hours),$row);
        $row = str_replace("{TOTAL_HORAS_SLA}",												utf8_encode($Sla),$row);
        $row = str_replace("{PORCENTAJE_DESCENDENTE}",								utf8_encode($porcentaje_Sla_Hours),$row);



        $row = str_replace("{HORAS_RENEGOCIADA}",											utf8_encode($estado_renegociada),$row);

        $row = str_replace("{REAPERTURA}",														($reapertura),$row);

        //echo "<br>Id ".$unico->id." Hours ".$Hours." SLA ".$Sla." Porcentaje SLA ".$porcentaje_Sla_Hours;
        UpdateTicketTiempos($unico->id,$Hours,$Sla,$porcentaje_Sla_Hours);

        $demora=0;
        if($porcentaje_Sla_Hours>100){
            $demora	=	1;
        } else {
            $demora	=	0;
        }
        if($unico->estado=="cerrado" or $unico->estado=="respondido"){
            $fecha_ticket_stamp	=	$unico->fecha." ".$unico->hora;
            $fecha_ticket_cierre= $unico->fecha_cierre." ".$unico->hora_cierre;
            $fecha_cierre				= date($fecha_ticket_cierre, time() - 3600);
            $fecha_ticket				= date($fecha_ticket_stamp, time() - 3600);
            $fecha_ticket = strtotime($fecha_ticket).'<br/>';
            $fecha_cierre = strtotime($fecha_cierre);
            $fecha_diferencia = $fecha_cierre - $fecha_ticket;
            if($porcentaje_Sla_Hours>100){
                $demora	=	1;
                $tipo_demora="Cerrado con Demora";
                $tipo_demora_cerrado_con_demora++;
            } else {
                $demora	=	0;
                $tipo_demora="Cerrado";
                $tipo_demora_cerrado++;
            }
        }  else {
            $fecha_ticket_stamp	=	$unico->fecha." ".$unico->hora;
            $fecha_actual				= date("Y-m-d H:i:s", time() - 3600);
            $fecha_ticket				= date($fecha_ticket_stamp, time() - 3600);
            //echo "<br>fecha_actual $fecha_actual<br>fecha_ticket $fecha_ticket
            //<br>Fecha Ticket $fecha_ticket_stamp actual $fecha_actual";
            $fecha_ticket = strtotime($fecha_ticket).'<br/>';
            $fecha_actual = strtotime($fecha_actual);
            $fecha_diferencia = $fecha_actual - $fecha_ticket;
            if($porcentaje_Sla_Hours>100){
                $demora	=	1;
                $tipo_demora="Abierto con Demora";
                $tipo_demora_abierto_con_demora++;
            } else {
                $demora	=	0;
                $tipo_demora="Abierto";
                $tipo_demora_abierto++;
            }
        }
        //echo "<br>ID Ticket ".$unico->id." <br> horas ".$Hours." SLA ".$Sla." <br>estado ".$unico->estado." demora $demora, tipo demora $tipo_demora";
        $row = str_replace("{ASUNTO}",  					utf8_encode($unico->asunto),$row);
        $row = str_replace("{FECHA}",  						($unico->fecha),$row);
        $row = str_replace("{HORA}",  						($unico->hora),$row);
        $Ticket_Categoria			=	Tickets_IdCategoria_data($unico->id_categoria, $id_empresa);
        $Ticket_SubCategoria	=	Tickets_IdSubCategoria_data($unico->id_subcategoria, $id_empresa);
        if($unico->estado=="pendiente"){
            $estado		=	"<div class='badge badge-danger badge-full'>Abierto</div>";
            if($demora==1){
                $semaforo	= " <i class='fa fa-circle badge_color_demora'></i> ";
            } else {
                if($unico->visualizado=="1"){
                    $semaforo	= " <i class='fa fa-circle' style='color: #32c5d2;'></i> ";
                } else {
                    $semaforo	= " <i class='fa fa-circle' style='color: #bbbbbb;'></i> ";
                }
            }
        }
        elseif($unico->estado=="reabierto"){
            $estado		=	"<div class='badge badge-danger badge-full'>Reabierto</div>";
            if($demora==1){
                $semaforo	= " <i class='fa fa-circle badge_color_demora'></i> ";
            } else {
                if($unico->visualizado=="1"){
                    $semaforo	= " <i class='fa fa-circle' style='color: #32c5d2;'></i> ";
                } else {
                    $semaforo	= " <i class='fa fa-circle' style='color: #bbbbbb;'></i> ";
                }
            }
        }
        elseif($unico->estado=="respondido"){
            $estado		=	"<div class='badge badge-warning badge-full'>Respondido</div>";
            if($demora==1){
                $semaforo	= " <i class='fa fa-circle badge_color_demora'></i> ";
            } else {
                $semaforo	= " <i class='fa fa-circle badge_color_sin_demora' ></i> ";
            }

        } elseif($unico->estado=="derivado"){
            $estado		=	"<div class='badge badge-info badge-full'>Derivado</div>";

            if($vista=="especialista"){

                // Respondido o no

                $Respuesta_Unica_Derivado=Tickets_tbl_tickets_comentarios_data($rut,$unico->id);

                if($Respuesta_Unica_Derivado>0){
                    $semaforo	= " <i class='fa fa-circle badge_color_demora' style='    color: #36c6d3;'></i> Respondido";
                } else {
                    $semaforo	= " <i class='fa fa-circle badge_color_demora'></i> Pendiente";
                }


            } else {

                if($demora==1){
                    $semaforo	= " <i class='fa fa-circle badge_color_demora'></i> ";
                } else {
                    $semaforo	= " <i class='fa fa-circle badge_color_sin_demora'></i> ";
                }



            }


        } elseif($unico->estado=="cerrado"){
            $estado		=	"<div class='badge badge-success badge-full'>Cerrado</div>";
            if($demora==1){
                $semaforo	= " <i class='fa fa-circle badge_color_demora'></i> ";
            } else {
                $semaforo	= " <i class='fa fa-circle badge_color_sin_demora'></i> ";
            }

        }  else {

        }

        $accion 			= "<a href='?sw=Tickets_Detalle&id=".Encodear3($unico->id)."' class='btn btn-link'>Ver</a>";
        $url 					= "?sw=Tickets_Detalle&id=".Encodear3($unico->id)."'";
        if (isset($Ticket_Categoria[0])) {
            $categoria = $Ticket_Categoria[0]->categoria;
        } else {
            // Handle the case when $Ticket_Categoria doesn't have an element at index 0
            // You can set a default value or display an error message
        }

        if (isset($Ticket_SubCategoria[0])) {
            $subcategoria = $Ticket_SubCategoria[0]->subcategoria;
        } else {
            // Handle the case when $Ticket_SubCategoria doesn't have an element at index 0
            // You can set a default value or display an error message
        }

        $row = str_replace("{ESTADO}",  					utf8_encode($estado),$row);
        $row = str_replace("{SEMAFORO}",  				utf8_encode($semaforo),$row);

        if($unico->rut_ejecutivo==""){
            $ejecutivo= "[ SIN ASIGNAR ]";
        } else{
            $ejecutivo= $unico->rut_ejecutivo."";
            $Ejecutivo_ticket=Tickets_Busca_datos_admin($unico->rut_ejecutivo, $id_empresa);
        }

        $row = str_replace("{EJECUTIVO}",								utf8_encode($ejecutivo),$row);
        if (isset($Ejecutivo_ticket[0])) {
            $row = str_replace("{NOMBRE_EJECUTIVO}", utf8_encode($Ejecutivo_ticket[0]->nombre_completo), $row);
        } else {
            // Handle the case when $Ejecutivo_ticket is not defined or doesn't have an element at index 0
            // You can set a default value or display an error message
        }

        if($unico->fecha_derivacion=="" and $unico->fecha_derivacion_respuesta==""){
            $row = str_replace("{Derivado_a_NOMBRE_DERIVADO}", "",$row);
        } elseif($unico->fecha_derivacion<>"" and $unico->fecha_derivacion_respuesta==""){
            $Derivado_ticket=Tickets_Busca_datos_admin($unico->rut_derivado, $id_empresa);
            $row = str_replace("{Derivado_a_NOMBRE_DERIVADO}", "<br><div style=' color: #31708f !important;    padding: 5px;background-color: #f5f3f3;'>Derivado a ".utf8_encode($Derivado_ticket[0]->nombre_completo)." el ".$unico->fecha_derivacion." ".$unico->hora_derivacion."</div>",$row);
        } elseif($unico->fecha_derivacion<>"" and $unico->fecha_derivacion_respuesta<>""){
            $Derivado_ticket=Tickets_Busca_datos_admin($unico->rut_derivado, $id_empresa);
            $row = str_replace("{Derivado_a_NOMBRE_DERIVADO}", "<br><div style=' color: #31708f !important;    padding: 5px;background-color: #f5f3f3;'>Derivado y Respondido por Especialista.<Br>Derivado a ".utf8_encode($Derivado_ticket[0]->nombre_completo)." el ".$unico->fecha_derivacion." ".$unico->hora_derivacion." <br> <br> Respondido por especialista el ".$unico->fecha_derivacion_respuesta." ".$unico->hora_derivacion_respuesta."</div>",$row);
        }
        if (isset($categoria)) {
            $row = str_replace("{CATEGORIA}", utf8_encode($categoria), $row);
        } else {
            // Handle the case when $categoria is not defined
            // You can set a default value or display an error message
        }

        if (isset($subcategoria)) {
            $row = str_replace("{SUBCATEGORIA}", utf8_encode($subcategoria), $row);
        } else {
            // Handle the case when $subcategoria is not defined
            // You can set a default value or display an error message
        }
        $row = str_replace("{ACCION}",  												$accion,$row);
        $row = str_replace("{URL}",  														$url,$row);
        $row = str_replace("{FECHA}",  													($unico->fecha),$row);
        $row = str_replace("{FECHA}",  													($unico->fecha),$row);
        if($unico->fecha_visualizacion	=="0000-00-00")					{$unico->fecha_visualizacion="";}
        if($unico->hora_visualizacion		=="00:00:00")						{$unico->hora_visualizacion="";}
        if($unico->fecha_estado					=="0000-00-00")					{$unico->fecha_estado="";}
        if($unico->hora_estado					=="00:00:00")						{$unico->hora_estado="";}
        if($unico->fecha_cierre					=="0000-00-00")					{$unico->fecha_cierre="";}
        if($unico->hora_cierre					=="00:00:00")						{$unico->hora_cierre="";}
        $row = str_replace("{FECHA_VISUALIZACION}",  						($unico->fecha_visualizacion),$row);
        $row = str_replace("{HORA_VISUALIZACION}",  						($unico->hora_visualizacion),$row);
        $row = str_replace("{FECHA_RESPUESTA}",  								($unico->fecha_estado),$row);
        $row = str_replace("{HORA_RESPUESTA}",  								($unico->hora_estado),$row);
        $row = str_replace("{FECHA_CIERRE}",  									($unico->fecha_cierre),$row);
        $row = str_replace("{HORA_CIERRE}",  										($unico->hora_cierre),$row);
        $total_html.=$row;
    }
    }
    $total_html 	= str_replace("{NIVEL}","2",$total_html);
    $total_html 	= str_replace("{SUB_CAT}","",$total_html);
    $total_html 	= str_replace("{NSUB}","",$total_html);
    // BuscaNumresum
    $arreglo["pendiente"]=0;
    $arreglo["respondido"]=0;
    $arreglo["derivado"]=0;
    $arreglo["cerrado"]=0;

    $Ticket_Resumen=Tickets_Busca_Num_Resumen_Total($rut, $perfil,$id_empresa);
    foreach ($Ticket_Resumen as $unico){
        $arreglo[$unico->estado]=$unico->cuenta;
    }
    if (isset($arreglo["reabierto"])) {

    } else {
        $arreglo["reabierto"]=0;
    }
//print_r($arreglo);
    $html = str_replace("{NUM_TICKETS_PENDIENTES}",		$arreglo["pendiente"]+$arreglo["reabierto"],$html);
    $html = str_replace("{NUM_TICKETS_RESPONDIDOS}",	$arreglo["respondido"],$html);
    $html = str_replace("{NUM_TICKETS_DERIVADOS}",		$arreglo["derivado"],$html);
    $html = str_replace("{NUM_TICKETS_CERRADOS}",			$arreglo["cerrado"],$html);


    $html 	= str_replace("{SEMAFORO_CERRADO}",									$tipo_demora_cerrado,								$html);
    $html 	= str_replace("{SEMAFORO_CERRADO_CON_DEMORA}",			$tipo_demora_cerrado_con_demora,		$html);
    $html 	= str_replace("{SEMAFORO_ABIERTA}",									$tipo_demora_abierto,								$html);
    $html 	= str_replace("{SEMAFORO_ABIERTA_CON_DEMORA}",			$tipo_demora_abierto_con_demora,		$html);

    $html = str_replace("{META_REFRESH_ABIERTO}",			"<meta http-equiv='refresh' content='60'/>",$html);


    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{VISTA}",$vista ,$html);

    return($html);
}

function Tickets_Registro_Bitacora_lista($html,  $id_empresa, $idcategoria, $tipo, $rut, $vista,  $fecha_inicio, $fecha_termino){

    //echo "<br>Function Tickets Lista<br>$id_empresa, $idcategoria, $tipo, $rut, vista $vista, month $month, year $year<br>";
    $row=file_get_contents("views/tickets/entorno_tickets.html");

    $Lista_Tickets=Tickets_lista_tickets_registro_month_year_data($id_empresa,$tipo, $rut, $perfil, $fecha_inicio, $fecha_termino);
    $tipo_demora_cerrado=0;
    $tipo_demora_cerrado_con_demora=0;
    $tipo_demora_abierto=0;
    $tipo_demora_abierto_con_demora=0;

    //print_r($Lista_Tickets);
    foreach($Lista_Tickets as $unico){
        $Ticket_Categoria			=	Tickets_IdCategoria_data($unico->id_categoria, $id_empresa);
        $Ticket_SubCategoria	=	Tickets_IdSubCategoria_data($unico->id_subcategoria, $id_empresa);
        $categoria		=	$Ticket_Categoria[0]->categoria;
        $subcategoria	= $Ticket_SubCategoria[0]->subcategoria;
        //echo "<br>Ticket ".$Ticket_Categoria;

        $row	=	file_get_contents("views/tickets/row_tickets_registro.html");
        // intenta traer nfo de tbl usuario
        $Usu_R=Tickets_Busca_datos_usuario_admin(LimpiaRut($unico->rut), $id_empresa);

        if($Usu_R[0]->nombre_completo<>""){
            $rut_nombre_solicitante=$unico->rut."<br>".$Usu_R[0]->nombre_completo;
        } else {
            $rut_nombre_solicitante=$unico->rut;
        }



        $row 	= str_replace("{ID}",      								utf8_encode($unico->id),$row);
        $row 	= str_replace("{DESCRIPCION}",     				utf8_encode($unico->descripcion),$row);
        $row	= str_replace("{SOLICITANTE}",     				utf8_encode($rut_nombre_solicitante),$row);
        $row 	= str_replace("{CANAL}",     							utf8_encode($unico->asunto),$row);
        $row 	= str_replace("{NOMBRE_SOLICITANTE}",     	utf8_encode($unico->nombre_completo),$row);
        $row 	= str_replace("{CARGO_SOLICITANTE}",     	utf8_encode($unico->cargo),$row);
        $row 	= str_replace("{DIVISION_SOLICITANTE}",    utf8_encode($unico->division),$row);

        $row = str_replace("{FECHA}",  						($unico->fecha),$row);
        $row = str_replace("{HORA}",  						($unico->hora),$row);
        $row = str_replace("{SEMAFORO}",  						(""),$row);

        $Ejecutivo_ticket=Tickets_Busca_datos_admin($unico->rut_ejecutivo, $id_empresa);
        $row = str_replace("{EJECUTIVO}",								utf8_encode($unico->rut_ejecutivo),$row);
        $row = str_replace("{NOMBRE_EJECUTIVO}",				utf8_encode($Ejecutivo_ticket[0]->nombre_completo),$row);

        $row = str_replace("{CATEGORIA}",  							utf8_encode($categoria),$row);
        $row = str_replace("{SUBCATEGORIA}",  					utf8_encode($subcategoria),$row);

        $total_html.=$row;
    }

    $total_html 	= str_replace("{NIVEL}","2",$total_html);
    $total_html 	= str_replace("{SUB_CAT}","",$total_html);
    $total_html 	= str_replace("{NSUB}","",$total_html);

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{VISTA}",$vista ,$html);

    //$groupbyYearhMonth=Tickets_BitacoraGroupbyMonthYear($id_empresa, $tipo, $rut, $perfil);
    //print_r($groupbyYearhMonth);
    //foreach ($groupbyYearhMonth as $unicoMY){
    /*$row_ahref_YM.="
    <div class='col-lg-1'>
        <a href='?sw=Tickets_Registros&Y=".$unicoMY->year."&M=".$unicoMY->month."'>
            ".$unicoMY->month." - ".$unicoMY->year."
        </a>
        </div>";


//}
    */
    $form_filtro=
        "
					
					<div class='row'>
					<div class='col-lg-3'>
					<form name='rango' id='rango' action='?sw=Tickets_Registros' method='post'>
						<label>Fecha Inicio</label>
						<br>
						<input type='date' name='fecha_inicio' id='fecha_inicio' value='".$fecha_inicio."' class='form form-control' required> 
					</div>	
					<div class='col-lg-3'>
						<label>Fecha T&eacute;rmino</label>
						<br>
						<input type='date' name='fecha_termino' id='fecha_inicio' value='".$fecha_termino."' class='form form-control' required> 
					</div>	
					<div class='col-lg-3'>
						<label>Vista</label>
						<select name='tipo_vista' class='form form-control' required>
							<option value=''></option>
							<option value='Web'>Web</option>
							<option value='Excel'>Excel</option>
						</select>
					</div>
					<div class='col-lg-3'>
					<label><br><br></label>
							<input type='submit' value='Filtrar' class='btn btn-info'>
							</form>
					</div>
				</div>
				";

    $html = str_replace("{VISTA_YEAR_MONTH}",$form_filtro ,$html);

    return($html);
}

function Tickets_Registro_lista($html,  $id_empresa, $idcategoria, $tipo, $rut, $vista){
    //echo "<br>Function Tickets Lista<br>$id_empresa, $idcategoria, $tipo, $rut, vista $vista<br>";
    $row=file_get_contents("views/tickets/entorno_tickets.html");


    $Lista_Tickets=Tickets_lista_tickets_registro_data($id_empresa,$tipo, $rut, $perfil);
    $tipo_demora_cerrado=0;
    $tipo_demora_cerrado_con_demora=0;
    $tipo_demora_abierto=0;
    $tipo_demora_abierto_con_demora=0;


    //print_r($Lista_Tickets);

    foreach($Lista_Tickets as $unico){

        $Ticket_Categoria			=	Tickets_IdCategoria_data($unico->id_categoria, $id_empresa);
        $Ticket_SubCategoria	=	Tickets_IdSubCategoria_data($unico->id_subcategoria, $id_empresa);

        $categoria		=	$Ticket_Categoria[0]->categoria;
        $subcategoria	= $Ticket_SubCategoria[0]->subcategoria;

//echo "<br>Ticket ".$Ticket_Categoria;

        $row	=	file_get_contents("views/tickets/row_tickets_registro.html");

        // intenta traer nfo de tbl usuario
        $Usu_R=Tickets_Busca_datos_usuario_admin(LimpiaRut($unico->rut), $id_empresa);

        if($Usu_R[0]->nombre_completo<>""){
            $rut_nombre_solicitante=$unico->rut."<br>".$Usu_R[0]->nombre_completo;
        } else {
            $rut_nombre_solicitante=$unico->rut;
        }



        $row 	= str_replace("{ID}",      								utf8_encode($unico->id),$row);
        $row 	= str_replace("{DESCRIPCION}",     				utf8_encode($unico->descripcion),$row);
        $row	= str_replace("{SOLICITANTE}",     				utf8_encode($rut_nombre_solicitante),$row);
        $row 	= str_replace("{CANAL}",     							utf8_encode($unico->asunto),$row);
        $row 	= str_replace("{NOMBRE_SOLICITANTE}",     	utf8_encode($unico->nombre_completo),$row);
        $row 	= str_replace("{CARGO_SOLICITANTE}",     	utf8_encode($unico->cargo),$row);
        $row 	= str_replace("{DIVISION_SOLICITANTE}",    utf8_encode($unico->division),$row);

        $row = str_replace("{FECHA}",  						($unico->fecha),$row);
        $row = str_replace("{HORA}",  						($unico->hora),$row);
        $row = str_replace("{SEMAFORO}",  						(""),$row);

        $Ejecutivo_ticket=Tickets_Busca_datos_admin($unico->rut_ejecutivo, $id_empresa);
        $row = str_replace("{EJECUTIVO}",								utf8_encode($unico->rut_ejecutivo),$row);
        $row = str_replace("{NOMBRE_EJECUTIVO}",				utf8_encode($Ejecutivo_ticket[0]->nombre_completo),$row);

        $row = str_replace("{CATEGORIA}",  							utf8_encode($categoria),$row);
        $row = str_replace("{SUBCATEGORIA}",  					utf8_encode($subcategoria),$row);

        $total_html.=$row;
    }

    $total_html 	= str_replace("{NIVEL}","2",$total_html);
    $total_html 	= str_replace("{SUB_CAT}","",$total_html);
    $total_html 	= str_replace("{NSUB}","",$total_html);

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{VISTA}",$vista ,$html);

    return($html);
}

function Tickets_Agregar_nuevo_Registro_fn($html,  $id_empresa, $idcategoria){



    if($_GET["id"]<>""){
        $Tik= $ticket_detalle				=	Tickets_Detalle_id_Data($_GET["id"], $id_empresa);
        //print_r($Tik);
    }

    $row=file_get_contents("views/tickets/agregar_ticket_registro.html");

    $lista_categoria	=	Tickets_Lista_Categoria($id_empresa);
    foreach($lista_categoria as $unicocat){
        $option_cat.="<option value='".($unicocat->id)."'>".($unicocat->categoria)."</option>";
    }

    $html = str_replace("{CANAL}",utf8_encode($Tik[0]->asunto),$html);
    $html = str_replace("{ID}",$_GET["id"],$html);
    $html = str_replace("{DESCRIPCION}",utf8_encode($Tik[0]->descripcion),$html);
    $html = str_replace("{RUT}",$Tik[0]->rut,$html);


    $html = str_replace("{OPTIONS_LISTA_CATEGORIA}",		utf8_encode($option_cat),$html);
    $html = str_replace("{OPTIONS_LISTA_SUBCATEGORIA}",	utf8_encode($option_subcat),$html);


    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function Tickets_Agregar_nuevo_fn($html,  $id_empresa, $idcategoria){
    $row=file_get_contents("views/tickets/agregar_ticket.html");

    $lista_categoria	=	Tickets_Lista_Categoria($id_empresa);
    foreach($lista_categoria as $unicocat){
        $option_cat.="<option value='".($unicocat->id)."'>".($unicocat->categoria)."</option>";
    }


    $html = str_replace("{OPTIONS_LISTA_CATEGORIA}",		utf8_encode($option_cat),$html);
    $html = str_replace("{OPTIONS_LISTA_SUBCATEGORIA}",	utf8_encode($option_subcat),$html);


    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function Tickets_Detalle($html,  $id_empresa, $id){
    $row=file_get_contents("views/tickets/ticket_detalle.html");
    $ticket_detalle				=	Tickets_Detalle_id_Data($id, $id_empresa);
    //print_r($ticket_detalle);

    if($ticket_detalle[0]->id_categoria>0 and $ticket_detalle[0]->id_subcategoria>0){
        $display_none="";
    } else {
        $display_none="display:none;";
    }

    //echo "<br>display_none $display_none<br>";

    $Ticket_Categoria			=	Tickets_IdCategoria_data($ticket_detalle[0]->id_categoria, $id_empresa);
    $Ticket_SubCategoria	=	Tickets_IdSubCategoria_data($ticket_detalle[0]->id_subcategoria, $id_empresa);
    $Ejecutivo						= Tickets_Busca_datos_admin($ticket_detalle[0]->rut_ejecutivo, $id_empresa);
    $Usuario							= Tickets_Busca_datos_admin($ticket_detalle[0]->rut, $id_empresa);
// verifica nivel del rut como sesion
    $Usuario_Ses					=	Tickets_Busca_datos_admin($_SESSION["user_"], $id_empresa);
//print_r($Usuario_Ses);
    if($Usuario_Ses[0]->go>0 and $Usuario_Ses[0]->go<3){
        //echo "Soy Ejecutivo y veo botones de reasignacion";
        $html = str_replace("{BOTON_REASIGNAR_EJECUTIVO}",	"<button type='button' class='btn btn-link pull-right' 	data-bs-toggle='modal' data-bs-target='#exampleModal'><i class='fa fa-edit'></i> Reasignar Ejecutivo Atenci�n</button>",$html);
        $html = str_replace("{BOTON_DERIVAR_EJECUTIVO}",		"<button type='button' class='btn btn-link pull-right' 	data-bs-toggle='modal' data-bs-target='#exampleModalDerivar'><i class='fa fa-edit'></i> Derivar Experto</button>",$html);
        $html = str_replace("{BOTON_REASIGNAR_CATEGORIA}",	"<button type='button' class='btn btn-link pull-right' 	data-bs-toggle='modal' data-bs-target='#exampleModalCategoria'><i class='fa fa-edit'></i> Editar Categor�a</button>",$html);
        $html = str_replace("{BOTON_CONVERTIR_PUBLICA}",	"<button type='button' class='btn btn-link pull-right' 		data-bs-toggle='modal' data-bs-target='#exampleModalPublica'><i class='fa fa-edit'></i> Convertir en P�blica</button>",$html);
        if($ticket_detalle[0]->horas_renegociada>0){
            $html = str_replace("{BOTON_RENEGOCIAR}",	"",$html);
        }else {
            $html = str_replace("{BOTON_RENEGOCIAR}",						"<button type='button' class='btn btn-link pull-right' data-bs-toggle='modal' data-bs-target='#exampleModalRenegociar'><i class='fa fa-edit'></i> Renegociar</button>",$html);
        }

    } else {
        //echo "Soy Ejecutivo y veo botones de reasignacion";
        $html = str_replace("{BOTON_REASIGNAR_EJECUTIVO}",	"",$html);
        $html = str_replace("{BOTON_DERIVAR_EJECUTIVO}",		"",$html);
        $html = str_replace("{BOTON_REASIGNAR_CATEGORIA}",	"",$html);
        $html = str_replace("{BOTON_RENEGOCIAR}",	"",$html);
        $html = str_replace("{BOTON_CONVERTIR_PUBLICA}",	"",$html);
    }

    $html = str_replace("{ID}",								utf8_encode($ticket_detalle[0]->id),$html);
    $html = str_replace("{FECHA_INICIO}",			utf8_encode($ticket_detalle[0]->fecha),$html);
    $html = str_replace("{NOMBRE_SOLICITANTE}",			utf8_encode($ticket_detalle[0]->nombre_completo),$html);

    if($Ticket_Categoria[0]->categoria<>"" and $Ticket_SubCategoria[0]->subcategoria<>""){
        $categoria_subcategoria="".$Ticket_Categoria[0]->categoria." | ".$Ticket_SubCategoria[0]->subcategoria;
    } else {
        $categoria_subcategoria="[ CATEGORIA SIN ASIGNAR ]";
    }

    $html = str_replace("{RUT_EJECUTIVO}",								utf8_encode($ticket_detalle[0]->rut_ejecutivo),$html);
    $html = str_replace("{NOMBRE_EJECUTIVO}",	utf8_encode($Ejecutivo[0]->nombre_completo),$html);
    $html = str_replace("{HORA_INICIO}",			utf8_encode($ticket_detalle[0]->hora),$html);
    $html = str_replace("{CATEGORIA_SUBCATEGORIA}",				utf8_encode($categoria_subcategoria),$html);
    $html = str_replace("{SUBCATEGORIA}",			utf8_encode($Ticket_SubCategoria[0]->subcategoria),$html);
    $html = str_replace("{ASUNTO}",						utf8_encode($ticket_detalle[0]->asunto),$html);
    $html = str_replace("{DESCRIPCION}",			utf8_encode($ticket_detalle[0]->descripcion),$html);
    $html = str_replace("{RUT}",							utf8_encode($ticket_detalle[0]->rut),$html);
    $html = str_replace("{ID_ENC}",								Encodear3($ticket_detalle[0]->id),$html);
    $html = str_replace("{display_none}",								($display_none),$html);

    $Array_Ejecutivos_Nivel_2	=	Tickets_Busca_Ejecutivos_Nivel2($id_empresa);
    //print_r($Array_Ejecutivos_Nivel_2);
    foreach ($Array_Ejecutivos_Nivel_2 as $unicoN2){
        $row_ejecutivo_nivel_2.="<option value='".$unicoN2->user."'>".utf8_encode($unicoN2->nombre_completo)."</option>";
    }
    $html = str_replace("{TICKET_REASIGNAR_OPTION_NIVEL_2}",	$row_ejecutivo_nivel_2,$html);

    $Array_Ejecutivos_Nivel_3	=	Tickets_Busca_Ejecutivos_Nivel3($id_empresa);
    //print_r($Array_Ejecutivos_Nivel_2);
    foreach ($Array_Ejecutivos_Nivel_3 as $unicoN3){
        $row_ejecutivo_nivel_3.="<option value='".$unicoN3->user."'>".utf8_encode($unicoN3->nombre_completo)."</option>";
    }
    $html = str_replace("{TICKET_REASIGNAR_OPTION_NIVEL_3}",	$row_ejecutivo_nivel_3,$html);




    if (file_exists("tickets/".$ticket_detalle[0]->archivo) and $ticket_detalle[0]->archivo<>"") {
        $ve_archivo=1;
    } else {
        $ve_archivo=0;
    }

    if($ve_archivo=="1"){
        $archivo="
    	
    		<center><a href='tickets/".$ticket_detalle[0]->archivo."' target='_blank' class='btn btn-link' style='    text-decoration: underline;'>
    		<span class='negro' style='    color: #192857;'>Ver archivo adjunto</span></a></center>
    	<br>";
    } else {
        $archivo="<br>";
    }
    $html = str_replace("{ARCHIVO}",					utf8_encode($archivo),$html);


    if (file_exists("tickets/".$ticket_detalle[0]->archivo2) and $ticket_detalle[0]->archivo2<>"") {
        $ve_archivo2=1;
    } else {
        $ve_archivo2=0;
    }

    if($ve_archivo2=="1"){
        $archivo2="
    	
    		<center><a href='tickets/".$ticket_detalle[0]->archivo2."' target='_blank' class='btn btn-link' style='    text-decoration: underline;'>
    		<span class='negro' style='    color: #192857;'>Ver archivo 2 adjunto</span></a></center>
    	<br>";
    } else {
        $archivo2="<br>";
    }
    $html = str_replace("{ARCHIVO2}",					utf8_encode($archivo2),$html);

    if (file_exists("tickets/".$ticket_detalle[0]->archivo3) and $ticket_detalle[0]->archivo3<>"") {
        $ve_archivo3=1;
    } else {
        $ve_archivo3=0;
    }

    if($ve_archivo3=="1"){
        $archivo3="
    	
    		<center><a href='tickets/".$ticket_detalle[0]->archivo3."' target='_blank' class='btn btn-link' style='    text-decoration: underline;'>
    		<span class='negro' style='    color: #192857;'>Ver archivo 3 adjunto</span></a></center>
    	<br>";
    } else {
        $archivo3="<br>";
    }
    $html = str_replace("{ARCHIVO3}",					utf8_encode($archivo3),$html);

//{TICKET_ROWS_INTERACCIONES}
    $total_comentarios=Tickets_Lista_Comentarios($id, $id_empresa);
    //print_r($total_comentarios);

    foreach($total_comentarios as $tot){

        if($tot->perfil=="3" and $_SESSION["user_"]==$ticket_detalle[0]->rut){
            continue;
        } else {
            $row_c.=file_get_contents("views/tickets/row_comentario_ticket.html");

        }
        if($ticket_detalle[0]->rut==$tot->rut){
            $clase_comentario="alert alert-warning pull-right";
            $nombre_completo="";
            $nombre_completo=$tot->nombre_completo;
        } else {
            $clase_comentario="alert alert-success pull-left";
            $nombre_completo=$tot->nombre_completo;
        }
        if($tot->archivo<>""){
            $archivo_comentario="<br> <a href='tickets/".$tot->archivo."' class='btn btn-link' target='_blank' style='color:#444;padding-left: 0px;'>Ver Documento Adjunto 1</a>";
        } else {
            $archivo_comentario="";
        }
        if($tot->archivo2<>""){
            $archivo_comentario2="<br> <a href='tickets/".$tot->archivo2."' class='btn btn-link' target='_blank' style='color:#444;padding-left: 0px;'>Ver Documento Adjunto 2</a>";
        } else {
            $archivo_comentario2="";
        }
        if($tot->archivo3<>""){
            echo "WI";
            $archivo_comentario3="<br> <a href='tickets/".$tot->archivo3."' class='btn btn-link' target='_blank' style='color:#444;padding-left: 0px;'>Ver Documento Adjunto 3</a>";
        } else {
            $archivo_comentario3="";
        }
        //echo "<br>-> archivo3 ".$tot->archivo3;
        $row_c= str_replace("{COMENTARIO}", 	$tot->comentario,$row_c);
        $row_c= str_replace("{ALERT}", 				$clase_comentario,$row_c);
        $row_c= str_replace("{RUT}", 					$tot->rut,$row_c);
        $row_c= str_replace("{NOMBRE_COMPLETO}", 	$nombre_completo ,$row_c);
        $row_c= str_replace("{ARCHIVO}", 		$archivo_comentario ,$row_c);
        $row_c= str_replace("{ARCHIVO2}", 		$archivo_comentario2 ,$row_c);
        $row_c= str_replace("{ARCHIVO3}", 		$archivo_comentario3 ,$row_c);
        $row_c= str_replace("{FECHA}", 				$tot->fecha,$row_c);
        $row_c= str_replace("{HORA}", 				$tot->hora,$row_c);

    }
    $rut 							= $_SESSION["user_"];
    $data_admin_session=Tickets_Busca_datos_admin($rut, $id_empresa);

    //print_r($data_admin_session);
    if($data_admin_session[0]->go=="1" or $data_admin_session[0]->go=="2"){
        Ticket_Save_Visualizacion($rut, $id, $id_empresa);
    }

    if($ticket_detalle[0]->estado<>"cerrado"){
        $boton_agregar_interaccion="
		<span><small style='font-size: 13px;color: #31709c;font-weight: 700; style='float: left;'>Agrega una nueva Respuesta </small></span>
			<br><br><form name='interaccion' id='interaccion' action='?sw=Tickets_Detalle_Agregar_Interaccion' method='post' enctype='multipart/form-data'>	
				
				<span class='label bg-blue' style='float: left;'>Respuesta </span><br>
				<textarea class='form form-control' row='10' name='interaccion' id='interaccion' style='font-family: Open Sans;float: left;margin-bottom: 7px;min-height: 270px;'></textarea>
				
				<br><br>
				<span class='label bg-blue' style=' text-align: left;'>Subir Archivo 1 </span>
				<input type='file' id='archivo' name='archivo' style='    text-align: left;'>	
				<br>
				<span class='label bg-blue' style=' text-align: left;'>Subir Archivo 2</span>
				<input type='file' id='archivo2' name='archivo2' style='     text-align: left;'>	
				<br>
				<span class='label bg-blue' style=' text-align: left;'>Subir Archivo 3</span>
				<input type='file' id='archivo3' name='archivo3' style='     text-align: left;'>	
				<br>						
				<input type='hidden' name='id' id='id' value='".Encodear3($id)."'>
				<br>
					<input type='submit' name='grabar' id='grabar' value='Enviar Respuesta' class='btn btn-success' style='float: left; margin-top: 5px;'>
				
			</form>
			";

//$refresh	= 	"<meta http-equiv='refresh' content='300'/>";
//echo "rut $rut ".$ticket_detalle[0]->rut;

        if($rut==$ticket_detalle[0]->rut){
            $boton_cerrar="<center><br><a href='?sw=Tickets_Detalle&id=".Encodear3($ticket_detalle[0]->id)."&close=1' class='btn btn-success'>Cerrar Requerimiento</a></center>";
        } else {
            $boton_cerrar="<center><br><a href='?sw=Tickets_Detalle&id=".Encodear3($ticket_detalle[0]->id)."&close=2' class='btn btn-success'>Cerrar Requerimiento</a></center>";
        }

        $boton_cerrar="";

        if($rut=="bchticket1" or $rut=="15371061"){
            $boton_cerrar.="<center><br>
			
			<div class='col col-lg-6'>
				<a href='?sw=Tickets_Detalle&id=".Encodear3($ticket_detalle[0]->id)."&close=2' class='btn btn-success'>Cerrar Requerimiento</a>
			</div>
				
				";
            $boton_cerrar.="
			<div class='col col-lg-6'>
			
			 	<a href='?sw=Tickets_Detalle&id=".Encodear3($ticket_detalle[0]->id)."&del=1' class='btn btn-danger'>Eliminar Requerimiento</a>
			</div>
			 	<br><br><br>
			 	</center>";

        }

        //echo "boton_cerrar $rut";

    } elseif($ticket_detalle[0]->estado=="cerrado"){
        $refresh	= 	"";
        $boton_cerrar="";
        $boton_agregar_interaccion="";
    }

    if($ticket_detalle[0]->estado=="pendiente"){
        $estado		=	"<div class='badge badge-danger'>Abierto</div>";
    } elseif($ticket_detalle[0]->estado=="respondido"){
        $estado		=	"<div class='badge badge-warning'>Respondido</div>";
    } elseif($ticket_detalle[0]->estado=="derivado"){
        $estado		=	"<div class='badge badge-info'>Derivado</div>";
    } elseif($ticket_detalle[0]->estado=="cerrado"){
        $estado		=	"<div class='badge badge-success'>Cerrado</div>";
    }  else {

    }

    $lista_categoria	=	Tickets_Lista_Categoria($id_empresa);
    foreach($lista_categoria as $unicocat){
        $option_cat.="<option value='".($unicocat->id)."'>".($unicocat->categoria)."</option>";
    }

    $html = str_replace("{OPTIONS_LISTA_CATEGORIA}",		utf8_encode($option_cat),$html);
    $html = str_replace("{OPTIONS_LISTA_SUBCATEGORIA}",	utf8_encode($option_subcat),$html);
    $html = str_replace("{ESTADO_TICKET}",		utf8_encode($estado),$html);
    $html = str_replace("{TICKET_ROWS_INTERACCIONES}",		utf8_encode($row_c),$html);
    $html = str_replace("{AGREGAR_INTERACCION}",		utf8_encode($boton_agregar_interaccion),$html);
    $html = str_replace("{META_REFRESH_ABIERTO}",		($refresh),$html);
    $html = str_replace("{CERRAR_TICKET}",		utf8_encode($boton_cerrar),$html);
    $html = str_replace("{OPTIONS_LISTA_CATEGORIA}",		utf8_encode($option_cat),$html);
    $html = str_replace("{META_REFRESH_ABIERTO}",	utf8_encode($option_subcat),$html);
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    if($categoria_subcategoria=="[ CATEGORIA SIN ASIGNAR ]"){
        $DISPLAY_BOTON_DERIVAR_NONE=" display:none; ";
        $DISPLAY_TEXTO_DERIVAR_NONE=" <center>Antes de derivar debes seleccionar Categoria / SubCategoria</center>";
    } else {
        $DISPLAY_BOTON_DERIVAR_NONE="";
        $DISPLAY_TEXTO_DERIVAR_NONE="";
    }
    //echo "categoria_subcategoria<br><h1>".$categoria_subcategoria."</h1>";
    $html = str_replace("{DISPLAY_BOTON_DERIVAR_NONE}",		($DISPLAY_BOTON_DERIVAR_NONE),$html);
    $html = str_replace("{DISPLAY_TEXTO_DERIVAR_NONE}",		($DISPLAY_TEXTO_DERIVAR_NONE),$html);


    return($html);
}
function SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url,
$texto_url, $texto2, $texto3, $texto4, $logo, $id_empresa, $url2, $tipomensaje, $rut, $key, $otro_template)
{
$id_empresa="78";


$from="notificaciones@masconectadosbch.cl";
$nombrefrom="notificaciones@masconectadosbch.cl";


 if($tipo==""){$tipo="text/html";}

 if($id_empresa==""){
        $id_empresa = $_SESSION["id_empresa"];
    }

		//echo "<br>otro template ".$otro_template;

    if($otro_template){
        $message = file_get_contents("views/emails_notificaciones/" . $id_empresa . "_" . $otro_template . ".html");
		//echo "otro template";
        //echo "<br>views/emails_notificaciones/" . $id_empresa . "_" . $otro_template . ".html";

    }else{
        $message = file_get_contents("views/emails_notificaciones/" . $id_empresa . "_template_notificacion.html");
      //echo " template normal ";
      //  echo "<br>https://" . $_SERVER['SERVER_NAME'] . "/bch_beneficios/front/views/emails_notificaciones/" . $id_empresa . "_template_notificacion.html";

    }


	/*	echo "
		<br><h2>SendGrid_Email</h2><br>
    <br>to $to,
    <br>nombreto $nombreto,
    <br>from $from, <br>nombrefrom $nombrefrom,
    <br> tipo $tipo,<br>
    subject $subject,<br> titulo1 $titulo1,
    <br> subtitulo1 $subtitulo1,<br>texto1 $texto1,<br>url $url,<br>txto url $texto_url,
    <br>texto2 $texto2, <br>texto3 $texto3, <br>texto4 $texto4, <br>logo $logo, <br>id_empresa $id_empresa, <br>url $url, <br>tipomensaje $tipomensaje,<br>    rut $rut,
    <br>key $key,<br>otro_template $otro_template";
		*/

  	$message = str_replace("{TITULO1}", $titulo1, $message);
    $message = str_replace("{SUBTITULO1}", $subtitulo1, $message);
    $message = str_replace("{TEXTO1}", $texto1, $message);
    $message = str_replace("{URL}", $url, $message);
    $message = str_replace("{TEXTO_URL}", $texto_url, $message);
    $message = str_replace("{TEXTO2}", $texto2, $message);
    $message = str_replace("{TEXTO3}", $texto3, $message);
    $message = str_replace("{TEXTO4}", $texto4, $message);
    $message = str_replace("{LOGO}", $logo, $message);

    require("script/sendgrid-php/sendgrid-php.php");

    global $from_2022,$nombrefrom_2022,$api_key_2022;
    $from       = new SendGrid\Email($nombrefrom_2022, $from_2022);
    $to         = new SendGrid\Email($nombreto, $to);
    $content    = new SendGrid\Content($tipo, $message);
    $mail       = new SendGrid\Mail($from, $subject, $to, $content);
   $apiKey     = $api_key_2022;
    $sg         = new \SendGrid($apiKey);
    $response   = $sg->client->mail()->send()->post($mail);

		//echo "<br>mensaje<br><br>$message";*/

    $statuscode = $response->statusCode();
    $headers    = $response->headers();
    $body       = $response->body();
    $fecha      = date("Y-m-d");

	/*	echo "<br><br>statuscode_";    print_r($statuscode);
		echo "<br><br>headers_";        print_r($headers);
		echo "<br><br>body_";       print_r($body);
	exit();*/
//SaveLogEmails($id_empresa, $tipo, $subject, $to, $nombreto, $fecha, $statuscode, $headers, $body, $tipomensaje, $rut, $key);
}
function LimpiaRut($rut){

    $id_empresa = $_SESSION["id_empresa"];

    if($id_empresa<>'75'){
        $rut = str_replace(".","",$rut);
        $arreglo_rut=explode("-", $rut);
        return($arreglo_rut[0]);
    } else {
        return  $rut;
    }

}


