let basicToast = document.querySelector('.basic-toast'),
    showBasicToast = new bootstrap.Toast(basicToast);
$(document).ready(function () {
    $("#generarReporte").on('click', function () {
        let desdeInput = $("#filterDesde").val();
        let hastaInput = $("#filterHasta").val();
        let audiencias = $("#select_audiencia").val();
        let reporte = $("#selReporte").val();
        $.ajax({
            url: './' + reporte,
            type: "post",
            responseType: 'blob',
            data: {
                desde: desdeInput,
                hasta: hastaInput,
                audiencias: audiencias
            },
            headers: {'X-CSRF-Token': csrf},
            beforeSend: function () {
                $(".contenedorReportes").LoadingOverlay('show', loading);
            },
            success: function (result, status, xhr) {

                let disposition = xhr.getResponseHeader('content-disposition');
                let matches = /"([^"]*)"/.exec(disposition);
                let filename = (matches != null && matches[1] ? matches[1] : reporte + '.csv');

                let csvContent = '\uFEFF' + result;
                let blob = new Blob([csvContent], {
                    type: 'text/csv; charset=utf-8'
                });
                let filenameClean = convertHtmlToJQueryObject(filename, true, false);
                $("#linkDownload").attr('href', window.URL.createObjectURL(blob));
                $("#linkDownload").attr('download', filenameClean);
                document.getElementById("linkDownload").click()
            },
            complete: function () {
                $(".contenedorReportes").LoadingOverlay('hide', true);
            },
            error: (response) => {
                console.log(response);
                $(".toast-body").text(response.responseJSON);
                showBasicToast.show();
            }
        });
    })

    $("#selReporte").on("change", function () {
        let nameReport = $(this).val();
        $(".containerDates").removeClass('d-none');
        $(".containerAudiencias").addClass('d-none');
        if (nameReport === "ListAudienciaDetail" || nameReport === "ListAudiencias") {
            $(".containerDates").addClass('d-none');
            $(".containerAudiencias").removeClass('d-none');
        }
    });
    obtenerAudiencias();
});

function obtenerAudiencias() {

    $.ajax({
        url: './listarAudienciasSinUsuarios',
        dataType: "json",
        method: "get",
        data: {
            "_token": csrf
        },
        success: function (data) {
            data['data'].forEach(element => {
                let creador = element.nombre_creador.nombre_completo
                let optionClean = convertHtmlToJQueryObject("<option value=" + element.id + "><p class='text-muted fw-b'>(" + creador + ")</p> " + element.nombre + "</option>", true, false);
                $('#select_audiencia').append(optionClean);
            });
        },
        error: function (xhr, status, error) {

        },
        beforeSend: function () {


        },
        complete: function () {
            $('#select_audiencia').select2({
                placeholder: "Selecciona las audiencias",
                multiple: true,
                search: true
            });

        }
    });
}
