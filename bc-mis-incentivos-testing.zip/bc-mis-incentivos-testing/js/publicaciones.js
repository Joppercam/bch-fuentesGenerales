let basicToast = document.querySelector('.basic-toast'),
    showBasicToast = new bootstrap.Toast(basicToast),
    lista_publicaciones = $('.lista_publicaciones'),
    assetPath = 'public/app-assets/',
    tempIdDocumento = null,
    lista_audiencias_usuarios_table_ = $('.lista_audiencias_usuarios'),
    lista_audiencias_usuarios = null,
    tempIdAudiencia = null,
    tempIdPublicacion = null,
    buttonsDatatable = [],
    minDate, maxDate,
    dt_basic,
    publicationSelected = [];
$.fn.dataTable.ext.search.push(
    function (settings, data, dataIndex) {
        let min = minDate.val();
        let max = maxDate.val();
        let date = new Date(data[14]);

        if (
            (min === null && max === null) ||
            (min === null && date <= max) ||
            (min <= date && max === null) ||
            (min <= date && date <= max)
        ) {
            return true;
        }
        return false;
    }
);
$(document).ready(function () {
    moment.locale('es');
    obtenerAudiencias();
    obtenerDocumentos();
    obtenerPublicacionOpciones();
    if (idAudiencia || idDocumento) {
        $('#modal-publicacion').modal('show');
        $('#select_documento').val(idDocumento).trigger('change');
        $('#select_audiencia').val(idAudiencia).trigger('change');
    }
    /**Se incluyen filtros por fecha en tabla de audiencias**/
    minDate = new DateTime($('#min'), {});
    maxDate = new DateTime($('#max'), {});
    if (perfilMi == 'admin') {
        buttonsDatatable.push(
            {
                text: feather.icons['trash'].toSvg({class: 'me-50 font-small-4'}) + 'Eliminar publicaciones',
                className: 'button error small btnDeleteRecords d-none',
                attr: {
                    'onclick': 'deleteMultiplesRecords()'
                },
            },
            {
                text: feather.icons['plus'].toSvg({class: 'me-50 font-small-4'}) + 'Nueva Publicacion',
                className: 'create-new button default small',
                attr: {
                    'data-bs-toggle': 'modal',
                    'data-bs-target': '#modal-publicacion',
                    'onclick': ''
                },
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');

                }
            },
            {
                extend: 'collection',
                className: 'create-new button default small me-2 report-button',
                text: feather.icons['share'].toSvg({class: 'font-small-4 me-50'}) + 'Descargar reporte de publicaciones',
                buttons: [
                    {
                        extend: 'csv',
                        text: feather.icons['file-text'].toSvg({class: 'font-small-4 me-50 mr-2'}) + '.csv',
                        charset: 'utf-8',
                        title: 'Publicaciones',
                        bom: true,
                        fieldSeparator: ';',
                        className: 'dropdown-item',
                        exportOptions: {columns: [1, 2, 3, 4, 5, 6, 7, 8, 16, 10, 9, 11, 12, 13, 14, 15]}
                    }
                ],
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');
                    $(node).parent().removeClass('btn-group');
                    setTimeout(function () {
                        $(node).closest('.dt-buttons').removeClass('btn-group').addClass('d-inline-flex');
                    }, 50);
                }
            });
    } else {
        buttonsDatatable.push({
            extend: 'collection',
            className: 'create-new button default small me-2 report-button',
            text: feather.icons['share'].toSvg({class: 'font-small-4 me-50'}) + 'Descargar reporte de publicaciones',
            buttons: [
                {
                    extend: 'csv',
                    text: feather.icons['file-text'].toSvg({class: 'font-small-4 me-50 mr-2'}) + '.csv',
                    charset: 'utf-8',
                    title: 'Publicaciones',
                    bom: true,
                    fieldSeparator: ';',
                    className: 'dropdown-item',
                    exportOptions: {columns: [1, 2, 3, 4, 5, 6, 7, 8, 16, 10, 9, 11, 12, 13, 14, 15]}
                }
            ],
            init: function (api, node, config) {
                $(node).removeClass('btn-secondary');
                $(node).parent().removeClass('btn-group');
                setTimeout(function () {
                    $(node).closest('.dt-buttons').removeClass('btn-group').addClass('d-inline-flex');
                }, 50);
            }
        });
    }

    dt_basic = lista_publicaciones.DataTable({
        ajax: listPublicaciones,
        scrollX: true,
        columns: [
            {
                data: 'id',
                name: 'check',
                visible: true,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = '';
                    return txt.value;
                }
            }, {
                data: 'id',
                name: 'Código',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre',
                name: 'nombre',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre_audiencia.id',
                name: 'nombre_audiencia.id',
                visible: false,
                exportable: true,
                render: function (data, type, row) {

                    // Agrega el botón al valor devuelto
                    let buttonHtml = data;
                    return buttonHtml;
                }
            },
            {
                data: 'nombre_audiencia.id',
                name: 'nombre_audiencia.id',
                render: function (data, type, row) {

                    // Agrega el botón al valor devuelto
                    let buttonHtml = '<label>' + row.nombre_audiencia.nombre + '</label><a  data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdopAudiencia" aria-controls="offcanvasBackdopAudiencia" class="' + data + ' visualizarAudiencia link ml-2"><span class="link__wrapper"><span class="link__text fw-b">Ver</span></span></a>';
                    return buttonHtml;
                }
            },
            {
                data: 'nombre_documento.id',
                name: 'nombre_documento.id',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    // Agrega el botón al valor devuelto
                    let buttonHtml = data;
                    return buttonHtml;

                }
            },
            {
                data: 'nombre_documento.id',
                name: 'nombre_documento.id',
                render: function (data, type, row) {
                    // Agrega el botón al valor devuelto
                    let buttonHtml = '<label>' + row.nombre_documento.nombre + '</label><a  data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropFormulario" aria-controls="offcanvasBackdropFormulario" class="' + data + ' visualizarDocumento link ml-2"><span class="link__wrapper"><span class="link__text fw-b">Ver</span></span></a>';
                    return buttonHtml;

                }
            },

            {
                data: 'fecha_inicio',
                name: 'fecha_inicio',
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'fecha_termino',
                name: 'fecha_termino',
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'clasificacion.nombre_item',
                name: 'clasificacion.nombre_item',
                visible: false,
                exportable: true,
                searchable: true,
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'negocio.nombre_item',
                name: 'negocio.nombre_item',
                visible: false,
                exportable: true,
                searchable: true,
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'periodicidad.nombre_item',
                name: 'Trimestre publicación',
                visible: false,
                exportable: true,
                searchable: true,
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data
                    return txt.value;
                }
            },
            {
                data: 'categoria.nombre_item',
                name: 'Categoría',
                visible: false,
                exportable: true,
                searchable: true,
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data
                    return txt.value;
                }
            },
            {
                data: 'nombre_autor.rut',
                name: 'rut Creador',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre_autor.nombre_completo',
                name: 'nombre_autor.nombre_completo',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'fecha',
                name: 'fecha',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'id_perfil',
                name: 'Perfil',
                visible: false,
                exportable: true,
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data
                    return txt.value;
                }
            }

        ],
        order: [],
        columnDefs: [
            {
                targets: 17,
                title: 'Acciones',
                data: null,
                //orderable: false,
                render: function (data, type, full, meta) {

                    let html = '';
                    html += '<div class="btn-group"> ';
                    html += '    <a class="link dropdown-toggle" type="button" id="dropdownMenuAcciones" ';
                    html += '        data-bs-toggle="dropdown" aria-expanded="false"><i data-feather="chevron-down" ';
                    html += '                                                            class="mr-2"></i>Acciones ';
                    html += '    </a> ';
                    html += '    <div class="dropdown-menu" aria-labelledby="dropdownMenuAcciones"> ';
                    html += '        <a data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropPublicacion" aria-controls="offcanvasBackdropPublicacion" class="dropdown-item ver-publicacion pr-5" data-toggle="tooltip" data-pacement="top" ';
                    html += '            title="Editar"><i data-feather="users"></i> Ver</a> ';
                    if (perfilMi == 'admin') {
                        html += '        <a data-bs-toggle="modal" data-bs-target="#modal-publicacion" class="dropdown-item editar-publicacion pr-5" data-toggle="tooltip" ';
                        html += '            data-pacement="top" title="Editar"><i data-feather="edit-3"></i> Editar</a> ';
                        html += '        <a data-bs-toggle="modal" data-bs-target="#modal-publicacion" class=" dropdown-item duplicar-publicacion pr-5" data-toggle="tooltip" ';
                        html += '            data-pacement="top" title="Duplicar"> <i data-feather="copy"></i> Duplicar</a> ';
                    }
                    html += '    </div> ';
                    html += '</div> ';
                    return html;
                }
            },
            {
                orderable: false,
                className: 'select-checkbox',
                targets: 0,
                checkboxes: {
                    selectRow: true
                }
            }
        ],
        select: {
            style: 'multi',
            selector: 'td:first-child'
        },
        initComplete: function () {
            let cardHeader = $("#tdFilterCreator");
            let htmlClean = DOMPurify.sanitize('<label for="am_aplicacion_id">Creadores</label><select class="form-control input-sm"  id="am_aplicacion_id"><option value="">Todos</option></select>', {IN_PLACE: true});
            cardHeader.append(htmlClean);
            $("#tdFilterClasif").append(DOMPurify.sanitize('<label for="am_aplicacion_clasif">Clasificaciones</label><select class="form-control input-sm"  id="am_aplicacion_clasif"><option value="">Todos</option></select>', {IN_PLACE: true}));
            $("#tdFilterNegocio").append(DOMPurify.sanitize('<label for="am_aplicacion_negocio">Negocios</label><select class="form-control input-sm"  id="am_aplicacion_negocio"><option value="">Todos</option></select>', {IN_PLACE: true}));
            $("#tdFilterTrimestre").append(DOMPurify.sanitize('<label for="am_aplicacion_trimestre">Periodos</label><select class="form-control input-sm"  id="am_aplicacion_trimestre"><option value="">Todos</option></select>', {IN_PLACE: true}));
            $("#tdFilterPeriod").append(DOMPurify.sanitize('<label for="am_aplicacion_period">Periodicidad</label><select class="form-control input-sm"  id="am_aplicacion_period"><option value="">Todos</option></select>', {IN_PLACE: true}));
            this.api()
                .columns([9, 10, 11, 12, 14])
                .every(function () {
                    let column = this;
                    let select = "";
                    if (column.index() == 14) {
                        select = $("#tdFilterCreator").find('#am_aplicacion_id')
                            .on('change', function () {
                                let val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });
                    }
                    if (column.index() == 9) {
                        select = $("#tdFilterClasif").find('#am_aplicacion_clasif')
                            .on('change', function () {
                                let val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });
                    }
                    if (column.index() == 10) {
                        select = $("#tdFilterNegocio").find('#am_aplicacion_negocio')
                            .on('change', function () {
                                let val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });
                    }
                    if (column.index() == 12) {
                        select = $("#tdFilterTrimestre").find('#am_aplicacion_trimestre')
                            .on('change', function () {
                                let val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });
                    }
                    if (column.index() == 11) {
                        select = $("#tdFilterPeriod").find('#am_aplicacion_period')
                            .on('change', function () {
                                let val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });
                    }
                    column
                        .data()
                        .unique()
                        .sort()
                        .each(function (d, j) {
                            select.append('<option value="' + d + '">' + d + '</option>');
                        });
                });
        },
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: buttonsDatatable
    });
    setTimeout(function () {
        let filter = $("#tdFilterCreator").find('#am_aplicacion_id');
        filter.val(nombreUsuario);
        filter.change();
    }, 1000);

    $('#min, #max').on('change', function () {
        dt_basic.draw();
    });
    dt_basic.on('select', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas > 0) {
                $(".btnDeleteRecords").removeClass("d-none");
            }
            if (filasSeleccionadas === dt.rows({search: 'applied'}).count()) {
                $('#select-all').prop('checked', true);
            } else {
                $('#select-all').prop('checked', false);
            }
        }
    });
    dt_basic.on('deselect', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas === 0) {
                $(".btnDeleteRecords").addClass("d-none");
            }
        }
    });
    $("#btnRefresh").on("click", function () {
        $('#min, #max').val('');
        minDate.val('');
        maxDate.val('');
        $("#am_aplicacion_id").val('');
        $("#am_aplicacion_clasif").val('');
        $("#am_aplicacion_negocio").val('');
        $("#am_aplicacion_trimestre").val('');
        $("#am_aplicacion_period").val('');
        dt_basic.search('').columns().search('').draw();
    });
    $("#visualizarUsuarios").on("click", function () {
        cargarAudienciaUsuarios(tempIdAudiencia);
    });
    $("#btnViewUser").on("click", function () {
        let rut = $("#rutUser").val();
        verifyUser(rut);
    });
    /* A click event handler for the delete-user class. */
    $('.lista_publicaciones tbody').on('click', 'a.visualizarDocumento', function () {
        visualizarDocumento($(this));

    });
    /* A click event handler for the delete-user class. */
    /*$('#ver_documento_publicacion').on('click', function () {
        visualizarDocumento(tempIdDocumento, true);
    });*/

    /* A click event handler for the delete-user class. */
    $('.lista_publicaciones tbody').on('click', 'a.visualizarAudiencia', function () {
        verAudiencia($(this));
    });

    $("#frmPublicacion").on("submit", function () {
        if (tempIdPublicacion != null) {
            editarPublicacion(tempIdPublicacion);
        } else {
            guardarPublicacion();
        }
    });

    /* A click event handler for the delete-user class. */
    $('.lista_publicaciones tbody').on('click', 'a.duplicar-publicacion', function () {
        // Encuentra la fila correcta y obtén los datos
        let rowNode = $(this).closest('tr');
        if (dt_basic.responsive.hasHidden()) {
            rowNode = $(this).closest('tr').prev();
        }
        let data = dt_basic.row(rowNode).data();

        $('#nombre_publicacion').val(data.nombre);
        $('#fecha_inicio').val(data.fecha_inicio);
        $('#fecha_termino').val(data.fecha_termino);
        $('#select_audiencia').val(data.id_audiencia).trigger('change');
        $('#select_documento').val(data.id_documento).trigger('change');
        $('#select_clasificacion').val(data.id_clasificacion);
        $('#select_periodicidad').val(data.id_periodicidad);
        $('#select_negocio').val(data.id_negocio);
        $('#select_categoria').val(data.id_categoria);
        $('#select_perfil').val(data.id_perfil);
    });
    /* A click event handler for the delete-user class. */
    $('.lista_publicaciones tbody').on('click', 'a.eliminar-publicacion', function () {
        let data = dt_basic.row($(this).parents('tr')).data();
        eliminarPublicacion(data.id);
    });

    /* A click event handler for the delete-user class. */
    $('.lista_publicaciones tbody').on('click', 'a.editar-publicacion', function () {
        // Encuentra la fila correcta y obtén los datos
        let rowNode = $(this).closest('tr');
        if (dt_basic.responsive.hasHidden()) {
            rowNode = $(this).closest('tr').prev();
        }
        let data = dt_basic.row(rowNode).data();

        $('#nombre_publicacion').val(data.nombre);
        $('#fecha_inicio').val(data.fecha_inicio);
        $('#fecha_termino').val(data.fecha_termino);
        $('#select_audiencia').val(data.id_audiencia).trigger('change');
        $('#select_documento').val(data.id_documento).trigger('change');
        $('#select_clasificacion').val(data.id_clasificacion);
        $('#select_periodicidad').val(data.id_periodicidad);
        $('#select_negocio').val(data.id_negocio);
        $('#select_categoria').val(data.id_categoria);
        $('#select_perfil').val(data.id_perfil);

        tempIdPublicacion = data.id;

    });

    /* A click event handler for the delete-user class. */
    $('.lista_publicaciones tbody').on('click', 'a.ver-publicacion', function () {

        // Encuentra la fila correcta y obtén los datos
        let rowNode = $(this).closest('tr');
        if (dt_basic.responsive.hasHidden()) {
            rowNode = $(this).closest('tr').prev();
        }

        let data = dt_basic.row(rowNode).data();
        tempIdDocumento = data.id_documento;


        $('#ver_nombre_publicacion').html(data.nombre);

        let fechaInicio = moment(data.fecha_inicio);
        let fechaFin = moment(data.fecha_termino);
        $('#ver_nombre_rol').html(data.negocio.nombre_item);
        $('#ver_nombre_clasificacion').html(data.clasificacion.nombre_item);
        $('#ver_nombre_categoria').html(data.categoria.nombre_item);
        $('#ver_nombre_periodicidad').html(data.periodicidad.nombre_item);
        let fechaInicioEnLetras = fechaInicio.format('dddd, D [de] MMMM [de] YYYY');
        let fechaFinEnLetras = fechaFin.format('dddd, D [de] MMMM [de] YYYY');
        $('#ver_fecha_inicio').html(fechaInicioEnLetras);
        $('#ver_fecha_termino').html(fechaFinEnLetras);


        verAudiencia(data.id_audiencia, true);
        $.ajax({
            url: './cargarDocumento/' + tempIdDocumento,
            dataType: "json",
            method: "get",
            success: function (dataDoc) {
                let pdf = 'data:application/pdf;base64,' + dataDoc['data'].documento_base_64 + '#toolbar=0';
                let pdfClean = convertHtmlToJQueryObject(pdf, true, false);
                $("#visualizarDocumentoVer").attr('src', pdfClean);
            },
            error: function (xhr, status, error) {
                $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
                showBasicToast.show();
            },
            beforeSend: function () {
                $('#containerVisualizarDocumentoVer').LoadingOverlay('show', loading);
                $("#visualizarDocumentoVer").attr('src', '');

            },
            complete: function (data) {
                $('#containerVisualizarDocumentoVer').LoadingOverlay('hide', true);
            }
        });

    });

    $('#select_documento').select2({
        placeholder: "Selecciona el documento",
        dropdownParent: $("#modal-publicacion")
    });

    $('#selectDivision').select2({
        placeholder: "Divisiones",
        dropdownParent: $("#moffcanvasBackdopAudiencia")
    });

    $('#selectCargo').select2({
        placeholder: "Cargos",
        dropdownParent: $("#offcanvasBackdopAudiencia")
    });

    $('#selectUnidad').select2({
        placeholder: "Unidades",
        dropdownParent: $("#offcanvasBackdopAudiencia")
    });
    $('#select-all').on('change', function () {
        if ($(this).is(':checked')) {
            dt_basic.rows({search: 'applied'}).select();
        } else {
            dt_basic.rows({search: 'applied'}).deselect();
        }
    });
})

function deleteMultiplesRecords() {
    let textoAlerta = "A continuación se procesara la eliminación de los siguientes publicaciones:";
    dt_basic.rows({selected: true}).data().toArray().map(function (item) {
        publicationSelected.push(item.id);
        textoAlerta += " </br>*" + item.nombre;
    });
    Swal.fire({
        title: '¿Deseas eliminar las publicaciones seleccionadas?',
        html: textoAlerta,
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            EliminarPublicacionesMiltiples();
        }
    })
}

function EliminarPublicacionesMiltiples() {

    $.ajax({
        url: './eliminarPublicacionMultiple',
        dataType: "json",
        method: "post",
        data: {
            "_token": csrf,
            "datos": publicationSelected

        },
        success: function (data) {
            tempIdPublicacion = data['data'];
            $(".toast-body").html('Se ha eliminado correctamente.');
            dt_basic.ajax.reload();
            showBasicToast.show();
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#lista_publicaciones_wrapper').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#lista_publicaciones_wrapper').LoadingOverlay('hide', true);

        }
    });
}

function initTableAudiencia(idAudiencia) {
    if (lista_audiencias_usuarios != null) {
        lista_audiencias_usuarios.destroy();
    }
    lista_audiencias_usuarios = lista_audiencias_usuarios_table_.DataTable({
        ajax: './getAudienciaUsuarios/' + idAudiencia,
        serverSide: false,
        processing: true,
        responsive: true,
        columns: [{
            data: 'rut', name: 'Rut', visible: true, render: function (data, type, row) {
                let txt = document.createElement("textarea");
                txt.innerHTML = data;
                return txt.value;
            }
        }, {
            data: 'nombre_completo', name: 'Nombre completo', render: function (data, type, row) {
                let txt = document.createElement("textarea");
                txt.innerHTML = data;
                return txt.value;
            }
        },
            {
                data: 'silla_division', name: 'División', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_unidad', name: 'Unidad', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_cargo', name: 'Cargo', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }],
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [{
            extend: 'excelHtml5',
            text: 'Descargar usuarios',
            className: 'create-new button default small',
            exportOptions: {
                columns: ':visible'
            }
        }]


    });
}

function cargarAudienciaUsuarios(tempIdAudiencia) {
    initTableAudiencia(tempIdAudiencia);
}

function obtenerAudiencias() {

    $.ajax({
        url: './listarAudienciasSinUsuarios',
        dataType: "json",
        method: "get",
        data: {
            "_token": csrf
        },
        success: function (data) {
            data['data'].forEach(element => {
                let option;
                let creador = element.nombre_creador.nombre_completo
                option = DOMPurify.sanitize("<option value=" + element.id + "><p class='text-muted fw-b'>(" + creador + ")</p> " + element.nombre + "</option>", {IN_PLACE: true})
                let optionClean = convertHtmlToJQueryObject(option, true, false);
                $('#select_audiencia').append(optionClean);
                $('#select_audiencia').select2({
                    placeholder: "Selecciona la audiencia",
                    dropdownParent: $("#modal-publicacion")
                });
            });
            if (idAudiencia) {
                $('#select_audiencia').val(idAudiencia).trigger('change');
            }
        },
        error: function (xhr, status, error) {

        },
        beforeSend: function () {


        },
        complete: function () {


        }
    });
}

function obtenerDocumentos() {

    $.ajax({
        url: './listarDocumentosSimple',
        dataType: "json",
        method: "get",
        data: {
            "_token": csrf
        },
        success: function (data) {

            data['data'].forEach(element => {
                let option;
                let creador = element.nombre_autor.nombre_completo;
                option = DOMPurify.sanitize("<option value=" + element.id + ">(" + creador + ") " + element.nombre + "</option>", {IN_PLACE: true})
                let optionClean = convertHtmlToJQueryObject(option, true, false);
                $('#select_documento').append(optionClean);
            });
            if (idDocumento) {
                $('#select_documento').val(idDocumento).trigger('change');
            }
        },
        error: function (xhr, status, error) {

        },
        beforeSend: function () {


        },
        complete: function () {

        }
    });
}

function obtenerPublicacionOpciones() {

    $.ajax({
        url: './listarOpciones',
        dataType: "json",
        method: "get",
        data: {
            "_token": csrf
        },
        success: function (data) {

            data['data'].forEach(element => {
                /*select_clasificacion
                select_periodicidad
                select_negocio
                select_categoria
                select_perfil*/
                if (element.tipo == 'clasificacion') {
                    let option;
                    option = DOMPurify.sanitize("<option value=" + element.id_item + ">" + element.nombre_item + "</option>", {IN_PLACE: true})
                    let optionClean = convertHtmlToJQueryObject(option, true, false);
                    $('#select_clasificacion').append(optionClean);
                }

                if (element.tipo == 'periodicidad') {
                    let option;
                    option = DOMPurify.sanitize("<option value=" + element.id_item + ">" + element.nombre_item + "</option>", {IN_PLACE: true})
                    let optionClean = convertHtmlToJQueryObject(option, true, false);
                    $('#select_periodicidad').append(optionClean);
                }

                if (element.tipo == 'negocio') {
                    let option;
                    option = DOMPurify.sanitize("<option value=" + element.id_item + ">" + element.nombre_item + "</option>", {IN_PLACE: true})
                    let optionClean = convertHtmlToJQueryObject(option, true, false);
                    $('#select_negocio').append(optionClean);
                }

                if (element.tipo == 'categoria') {
                    let option;
                    option = DOMPurify.sanitize("<option value=" + element.id_item + ">" + element.nombre_item + "</option>", {IN_PLACE: true})
                    let optionClean = convertHtmlToJQueryObject(option, true, false);
                    $('#select_categoria').append(optionClean);
                }

                if (element.tipo == 'perfil') {
                    let option;
                    option = DOMPurify.sanitize("<option value=" + element.id_item + ">" + element.nombre_item + "</option>", {IN_PLACE: true})
                    let optionClean = convertHtmlToJQueryObject(option, true, false);
                    $('#select_perfil').append(optionClean);
                }


            });

        },
        error: function (xhr, status, error) {

        },
        beforeSend: function () {


        },
        complete: function () {

        }
    });
}

function guardarPublicacion() {

    let form = new FormData();
    form.append('nombre_publicacion', $('#nombre_publicacion').val());
    form.append('fecha_inicio', $('#fecha_inicio').val());
    form.append('fecha_termino', $('#fecha_termino').val());
    form.append('select_audiencia', $('#select_audiencia').val());
    form.append('select_documento', $('#select_documento').val());
    form.append('select_clasificacion', $('#select_clasificacion').val());
    form.append('select_negocio', $('#select_negocio').val());
    form.append('select_perfil', $('#select_perfil').val());
    form.append("_token", csrf);


    $.ajax({
        url: './savePublicacion',
        dataType: "json",
        method: "POST",
        data: form,
        processData: false,
        contentType: false,
        success: function (data) {
            if (data.code === 200) {
                tempIdPublicacion = data['data'];
                $(".toast-body").text('Se ha registrado correctamente.');
                dt_basic.ajax.reload();
                $('#modal-publicacion').modal('hide');
                limpiarCampos();
            } else {
                $(".toast-body").text(data);
            }
        },
        error: function (xhr, status, error) {
            let message = "";
            let obj = jQuery.parseJSON(xhr.responseJSON.message);
            $.map(obj, function (i) {
                message += "\n" + i
            });
            $(".toast-body").text(message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#modal-publicacion').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#modal-publicacion').LoadingOverlay('hide', true);
            showBasicToast.show();
        }
    });
}

function editarPublicacion(id) {

    let form = new FormData();
    form.append('id', id);
    form.append('nombre_publicacion_editar', $('#nombre_publicacion').val());
    form.append('fecha_inicio_editar', $('#fecha_inicio').val());
    form.append('fecha_termino_editar', $('#fecha_termino').val());
    form.append('select_audiencia_editar', $('#select_audiencia').val());
    form.append('select_documento_editar', $('#select_documento').val());
    form.append('select_clasificacion_editar', $('#select_clasificacion').val());
    form.append('select_negocio_editar', $('#select_negocio').val());
    form.append('select_perfil_editar', $('#select_perfil').val());
    form.append("_token", csrf);


    $.ajax({
        url: './editarPublicacion',
        dataType: "json",
        method: "POST",
        data: form,
        processData: false,
        contentType: false,
        success: function (data) {
            if (data.code === 200) {
                tempIdPublicacion = data['data'];
                $(".toast-body").html('Se ha registrado correctamente.');
                dt_basic.ajax.reload();
                limpiarCampos();
                $('#modal-publicacion').modal('hide');
            } else {
                $(".toast-body").text(data);
            }
        },
        error: function (xhr, status, error) {
            let message = "";
            let obj = jQuery.parseJSON(xhr.responseJSON.message);
            $.map(obj, function (i) {
                message += "\n" + i
            });
            $(".toast-body").text(message);
        },
        beforeSend: function () {
            $('#modal-publicacion').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#modal-publicacion').LoadingOverlay('hide', true);
            showBasicToast.show();
        }
    });
}

function duplicarPublicacion(id) {

    let form = new FormData();
    form.append('id', id);
    form.append("_token", csrf);


    $.ajax({
        url: './duplicarPublicacion',
        dataType: "json",
        method: "POST",
        data: form,
        processData: false,
        contentType: false,
        success: function (data) {
            tempIdPublicacion = data['data'];
            $(".toast-body").html('Se ha registrado correctamente.');
            dt_basic.ajax.reload();
            showBasicToast.show();
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#lista_publicaciones_wrapper').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#lista_publicaciones_wrapper').LoadingOverlay('hide', true);
        }
    });
}

function verifyUser(rut) {
    $.ajax({
        url: './usuarioByRut/' + rut,
        dataType: "json",
        method: "get",
        success: function (response) {
            let datos = response.usuario;
            if (datos.rut != "") {
                $("#nameUser").text(datos.nombre_completo);
                $("#cargoUser").text(datos.silla_cargo);
                let urlRedirect = 'https://www.goptest.cl/bch_masco/front/?sw=home_misincentivos&tk=' + datos.rutToken;
                window.open(urlRedirect);
            } else {
                $("#nameUser").text("Usuario inválido");
            }
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#viewUser').LoadingOverlay('show', loading);

        },
        complete: function () {
            $('#viewUser').LoadingOverlay('hide', true);
        }
    });
}

function eliminarPublicacion(id) {

    let form = new FormData();
    form.append('id', id);
    form.append("_token", csrf);

    Swal.fire({
        title: '¿Deseas eliminar esta publicación?',
        text: "A continuación se procesara la eliminación.",
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: './eliminarPublicacion',
                dataType: "json",
                method: "POST",
                data: form,
                processData: false,
                contentType: false,
                success: function (data) {
                    tempIdPublicacion = data['data'];
                    $(".toast-body").html('Se ha eliminado correctamente.');
                    dt_basic.ajax.reload();
                    showBasicToast.show();
                },
                error: function (xhr, status, error) {
                    $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
                    showBasicToast.show();
                },
                beforeSend: function () {
                    $('#lista_publicaciones_wrapper').LoadingOverlay('show', loading);
                },
                complete: function (data) {
                    $('#lista_publicaciones_wrapper').LoadingOverlay('hide', true);

                }
            });
        }
    });


}

function limpiarCampos() {
    $("#frmPublicacion")[0].reset();
    $('#select_audiencia').val(null).trigger('change');
    $('#select_documento').val(null).trigger('change');
}

function visualizarDocumento(id, fromPublicacion = false) {
    let id_documento = id;
    let visualizarDocumento = $('#visualizarDocumento');

    if (!fromPublicacion) {
        var button = $(id);
        var firstClass = button.attr('class').split(' ')[0];

        id_documento = firstClass;
    }


    $.ajax({
        url: './cargarDocumento/' + id_documento,
        dataType: "json",
        method: "get",
        success: function (data) {
            let pdf = 'data:application/pdf;base64,' + data['data'].documento_base_64 + '#toolbar=0';
            let pdfClean = convertHtmlToJQueryObject(pdf, true, false);
            visualizarDocumento.attr('src', pdfClean);
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#offcanvasBackdropFormulario').LoadingOverlay('show', loading);
            visualizarDocumento.attr('src', '');

        },
        complete: function (data) {
            $('#offcanvasBackdropFormulario').LoadingOverlay('hide', true);
        }
    });


}

function verAudiencia(id, fromVerPublicacion = false) {
    let id_audiencia = id;

    if (!fromVerPublicacion) {
        let button = $(id);
        let firstClass = button.attr('class').split(' ')[0];
        id_audiencia = firstClass;
    }

    tempIdAudiencia = id_audiencia;

    $.ajax({
        url: './verAudiencia/' + id_audiencia,
        dataType: "json",
        method: "get",
        success: function (data) {

            if (!fromVerPublicacion) {

                data['data'].cargos.forEach(element => {
                    // Reemplaza estos valores de ejemplo con los datos que deseas agregar
                    var optionValue = element.id;
                    var optionText = element.nombre_cargo.silla_cargo;

                    // Crea una nueva opción y la agrega al elemento Select2
                    var newOption = new Option(optionText, optionValue, true, true);
                    $("#selectCargo").append(newOption).trigger("change");

                });

                data['data'].unidades.forEach(element => {
                    // Reemplaza estos valores de ejemplo con los datos que deseas agregar
                    var optionValue = element.id;
                    var optionText = element.nombre_unidad.unidad;

                    // Crea una nueva opción y la agrega al elemento Select2
                    var newOption = new Option(optionText, optionValue, true, true);
                    $("#selectUnidades").append(newOption).trigger("change");

                });

                data['data'].divisiones.forEach(element => {
                    // Reemplaza estos valores de ejemplo con los datos que deseas agregar
                    var optionValue = element.id;
                    var optionText = element.nombre_division.silla_division;

                    // Crea una nueva opción y la agrega al elemento Select2
                    var newOption = new Option(optionText, optionValue, true, true);
                    $("#selectDivision").append(newOption).trigger("change");

                });
                $('#nombre_audiencia').val(data['data'].nombre);


            } else {
                let nombreClean = convertHtmlToJQueryObject(data['data'].usuarios.nombre_completo, true, false);
                let cargoClean = convertHtmlToJQueryObject(data['data'].usuarios.silla_cargo, true, false);
                let divisionClean = convertHtmlToJQueryObject(data['data'].usuarios.silla_division, true, false);
                $('#ver_nombre_usuario').html(nombreClean);
                $('#ver_nombre_cargo').html(cargoClean);
                $('#ver_nombre_division').html(divisionClean);
            }


        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#offcanvasBackdopAudiencia').LoadingOverlay('show', loading);
            $("#selectDivision").empty().trigger("change");
            $("#selectCargo").empty().trigger("change");
            $("#selectUnidad").empty().trigger("change");
            $('#nombre_audiencia').val('');

        },
        complete: function (data) {
            $('#offcanvasBackdopAudiencia').LoadingOverlay('hide', true);
            $("#selectDivision").prop("disabled", true).trigger("change");
            $("#selectCargo").prop("disabled", true).trigger("change");
            $("#selectUnidad").prop("disabled", true).trigger("change");

        }
    });
}
