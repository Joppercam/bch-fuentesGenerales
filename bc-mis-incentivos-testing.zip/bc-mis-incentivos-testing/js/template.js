let dt_basic_table = $('.lista_template'),
    dt_basic = null,
    tempIdTemplate = null,
    editor = null,
    basicToast = document.querySelector('.basic-toast'),
    assetPath = 'public/app-assets/',
    showBasicToast = new bootstrap.Toast(basicToast),
    modalControl = $('#modalTemplate');
$(document).ready(function () {
    initEditor();
    dt_basic = dt_basic_table.DataTable({
        ajax: './getTemplates',
        responsive: true,
        columns: [
            {
                data: 'nottem_codigo',
                name: 'codigo',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nottem_titulo',
                name: 'Título',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nottem_asunto',
                name: 'Asunto',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }
        ],
        order: [],
        columnDefs: [
            {
                targets: 3,
                title: 'Acciones',
                data: null,
                //orderable: false,
                render: function (data, type, full, meta) {

                    let html = '';
                    html += '<div class="btn-group"> ';
                    html += '    <a class="link dropdown-toggle" type="button" id="dropdownMenuAcciones" ';
                    html += '        data-bs-toggle="dropdown" aria-expanded="false"><i data-feather="chevron-down" ';
                    html += '                                                            class="mr-2"></i>Acciones ';
                    html += '    </a> ';
                    html += '    <div class="dropdown-menu" aria-labelledby="dropdownMenu"> ';
                    html += '        <a href="javascript:void(0);" class=" dropdown-item pr-5 item-edit" data-bs-toggle="modal" data-bs-target="#modalTemplate" data-toggle="tooltip" data-pacement="top" title="Editar"><i data-feather="edit-3"></i> Editar</a>';
                    html += '        <a href="javascript:void(0);" class=" dropdown-item pr-5 item-delete" title="Eliminar"><i data-feather="edit-3"></i> Eliminar</a>';
                    html += '        <a href="javascript:void(0);" class=" dropdown-item pr-5 item-preview" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropPreview" aria-controls="offcanvasBackdropPreview" data-toggle="tooltip" data-placement="top"><i data-feather="eye"></i> Previsualizar</a>';
                    html += '    </div> ';
                    html += '</div> ';
                    return html;
                }
            }
        ],
        select: {
            style: 'multi',
            selector: 'td:first-child'
        },
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [
            {
                text: feather.icons['plus'].toSvg({class: 'me-50 font-small-4'}) + 'Nuevo template',
                className: 'create-new button default small',
                attr: {
                    'data-bs-toggle': 'modal',
                    'data-bs-target': '#modalTemplate',
                },
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');
                }
            },
            {
                extend: 'collection',
                className: 'create-new button default small me-2 report-button',
                text: feather.icons['share'].toSvg({class: 'font-small-4 me-50'}) + 'Descargar templates',
                buttons: [
                    {
                        extend: 'csv',
                        text: feather.icons['file-text'].toSvg({class: 'font-small-4 me-50 mr-2'}) + '.csv',
                        charset: 'utf-8',
                        title: 'Templates',
                        bom: true,
                        fieldSeparator: ';',
                        className: 'dropdown-item',
                        exportOptions: {columns: [0, 1, 2]}
                    }
                ],
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');
                    $(node).parent().removeClass('btn-group');
                    setTimeout(function () {
                        $(node).closest('.dt-buttons').removeClass('btn-group').addClass('d-inline-flex');
                    }, 50);
                }
            }]
    });
    $("#frmTemplate").on("submit", function () {
        if (tempIdTemplate == null) {
            saveTemplate();
        } else {
            editTemplatea(tempIdTemplate);
        }
    });
    modalControl.on('hidden.bs.modal', function () {
        editor.setData('');
        tempIdTemplate = null;
        $("#nottem_titulo").val('');
        $("#nottem_asunto").val('');
    })
    dt_basic_table.on("click", ".item-edit", function () {
        let textoEnriquecido = "";
        let data = dt_basic.row($(this).parents('tr')).data();
        if (data.nottem_contenido != null) {
            textoEnriquecido = data.nottem_contenido
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&#039;/g, "'")
                .replace(/&quot;/g, '"');
        }
        editor.setData(textoEnriquecido);
        tempIdTemplate = data.nottem_codigo;
        $("#nottem_titulo").val(data.nottem_titulo);
        $("#nottem_asunto").val(data.nottem_asunto);
    });
    dt_basic_table.on("click", ".item-delete", function () {
        let data = dt_basic.row($(this).parents('tr')).data();
        let id = data.nottem_codigo;
        Swal.fire({
            title: '¿Deseas eliminar este template?',
            text: "A continuación se procesara la eliminación.",
            icon: 'info',
            showCancelButton: true,
            confirmButtonText: 'Si, continuar!',
            cancelButtonText: 'Cancelar',
            customClass: {
                confirmButton: 'button btn-primary  small mr-4',
                cancelButton: 'button btn-danger small'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.value) {
                $.ajax({
                    url: './eliminarTemplate/' + id,
                    method: "get",
                    success: function (data) {
                        $(".toast-body").html('Se ha eliminado correctamente.');
                        dt_basic.ajax.reload();
                        showBasicToast.show();
                    },
                    error: function (xhr, status, error) {
                        $(".toast-body").text(xhr.responseJSON.message);
                        showBasicToast.show();
                    },
                    beforeSend: function () {
                        $('.contenedorListarTemplate').LoadingOverlay('show', loading);
                    },
                    complete: function (data) {
                        $('.contenedorListarTemplate').LoadingOverlay('hide', true);

                    }
                });
            }
        });
    });

    dt_basic_table.on("click", ".item-preview", function () {
        let data = dt_basic.row($(this).parents('tr')).data();
        cargarNotificacionTemplate(data.nottem_codigo);
    });
});

function cargarNotificacionTemplate(idTemplate) {

    $.ajax({
        url: './cargarTemplate/' + idTemplate,
        dataType: "json",
        method: "get",
        processData: false,
        contentType: false,
        success: function (datos) {
            let data = datos.data
            let textoEnriquecido = data
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&#039;/g, "'")
                .replace(/&quot;/g, '"');
            let textoEnriquecidoClean = convertHtmlToJQueryObject(textoEnriquecido, true, false);
            $("#containerNotificacionPreview").html(textoEnriquecidoClean);
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#offcanvasBackdropPreview').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#offcanvasBackdropPreview').LoadingOverlay('hide', true);
        }
    });
}

function saveTemplate() {
    const editorData = editor.getData();
    let form = $("#frmTemplate");
    let formData = new FormData(form[0]);
    formData.append('nottem_contenido', editorData);
    $.ajax({
        url: './saveTemplate',
        type: 'POST',
        cache: false,
        contentType: false,
        headers: {'X-CSRF-Token': csrf},
        processData: false,
        data: formData,
        success: function (data) {
            modalControl.modal('hide');
            $(".toast-body").html('Se ha registrado correctamente.');
            dt_basic.ajax.reload();
            form[0].reset();
        },
        error: function (xhr, status, error) {
            let message = DOMPurify.sanitize(xhr.responseJSON.message, {IN_PLACE: true});
            if (typeof message === 'string') {
                message = message.replace(/[[\]"]/g, "");
                $(".toast-body").text(message);
            }
        },
        beforeSend: function () {
            modalControl.LoadingOverlay('show', loading);
        },
        complete: function (data) {
            modalControl.LoadingOverlay('hide', true);
            showBasicToast.show();
        }
    });
}

function editTemplatea(nottem_codigo) {
    let form = $("#frmTemplate");
    let editorData = editor.getData();
    let formData = new FormData(form[0]);
    formData.append('nottem_codigo', nottem_codigo);
    formData.append('nottem_contenido', editorData);
    formData.append("_token", csrf);
    $.ajax({
        url: './updateTemplate',
        dataType: "json",
        method: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            modalControl.modal('hide');
            $(".toast-body").html('Se ha editado correctamente.');
            dt_basic.ajax.reload();
            form[0].reset();
            tempIdTemplate = null;
        },
        error: function (xhr, status, error) {
            let message = DOMPurify.sanitize(xhr.responseJSON.message, {IN_PLACE: true});
            if (typeof message === 'string') {
                message = message.replace(/[[\]"]/g, "");
                $(".toast-body").text(message);
            }
            showBasicToast.show();
        },
        beforeSend: function () {
            modalControl.LoadingOverlay('show', loading);
        },
        complete: function (data) {
            modalControl.LoadingOverlay('hide', true);
        }
    });
}

function initEditor() {
    CKEDITOR.editorConfig = function (config) {
        // misc options
        config.height = '500px';
    };
    editor = CKEDITOR.replace('nottem_contenido', {
        extraPlugins: ['mentions', 'pagebreak', 'justify', 'copyformatting', 'lineheight', 'tabletools', 'tableresize', 'panelbutton', 'colordialog', 'colorbutton'],
        baseFloatZIndex: 20000,
        allowedContent: true,
        removeButtons: 'About,Link,Styles,Format,Image,font',
        delayIfDetached: true,
        lineheight: ['0.5px', '1px', '1.1px', '1.2px', '1.3px', '1.4px', '1.5px'],
    });
}
