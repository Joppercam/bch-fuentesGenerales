let listNotificaciones_table = $('.listNotificaciones'),
    listaNotificacionesAsign_table = $('.lista_notificaciones_asign'),
    lista_usuariosNotif_table = $('.lista_usuariosNotif'),
    dt_basic,
    lista_usuariosNotif,
    listaNotificacionesAsign,
    basicToast = document.querySelector('.basic-toast'),
    lista_audiencias_usuarios_table_ver = $('.lista_audiencias_usuarios_ver'),
    showBasicToast = new bootstrap.Toast(basicToast),
    assetPath = 'public/app-assets/',
    lista_audiencias_usuarios_ver,
    publicationSelected = [],
    modalControl = $('#modal-audiencia');
;
/**Se incluyen filtros por fecha en tabla de audiencias**/
let minDate, maxDate;
$.fn.dataTable.ext.search.push(
    function (settings, data, dataIndex) {
        let min = minDate.val();
        let max = maxDate.val();
        let date = new Date(data[4]);

        if (
            (min === null && max === null) ||
            (min === null && date <= max) ||
            (min <= date && max === null) ||
            (min <= date && date <= max)
        ) {
            return true;
        }
        return false;
    }
);
$(document).ready(function () {
    /**Se incluyen filtros por fecha en tabla de audiencias**/
    minDate = new DateTime($('#min'), {});
    maxDate = new DateTime($('#max'), {});
    listarTemplates();
    dt_basic = listNotificaciones_table.DataTable({
        ajax: listNotificaciones,
        scrollX: true,
        columns: [
            {
                data: 'id',
                name: 'id',
                visible: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = '';
                    return txt.value;
                }
            }, {
                data: 'id_audiencia',
                name: 'id_audiencia',
                visible: false,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre',
                name: 'nombre',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre_autor.nombre_completo',
                name: 'nombre_autor.nombre_completo',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },

            {
                data: 'fecha_inicio',
                name: 'fecha_inicio',
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'fecha_termino',
                name: 'fecha_termino',
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'notificaciones_count',
                name: 'Notificaciones agendadas',
                searchable: true,
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    let element = '<span class="badge bg-success">' + data + '</span>'
                    if (data == null || data == "") {
                        element = '<span class="badge bg-warning">No establecida</span>'
                    }
                    txt.innerHTML = element
                    return txt.value;
                }
            },
            {
                data: 'negocio.nombre_item',
                name: 'negocio.nombre_item',
                visible: false,
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }

        ],
        order: [],
        columnDefs: [
            {
                targets: 8,
                title: 'Acciones',
                data: null,
                //orderable: false,
                render: function (data, type, full, meta) {

                    let html = '';
                    html += '<div class="btn-group"> ';
                    html += '    <a class="link dropdown-toggle" type="button" id="dropdownMenuAcciones" ';
                    html += '        data-bs-toggle="dropdown" aria-expanded="false"><i data-feather="chevron-down" ';
                    html += '                                                            class="mr-2"></i>Acciones ';
                    html += '    </a> ';
                    html += '    <div class="dropdown-menu" aria-labelledby="dropdownMenuAcciones"> ';
                    html += '        <a href="javascript:void(0);" class=" dropdown-item ver-notificaciones pr-5" title="Editar" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropNotif" aria-controls="offcanvasBackdropNotif" data-toggle="tooltip" data-placement="top">' + feather.icons['align-justify'].toSvg({class: 'me-50 font-small-4'}) + ' Ver notificaciones</a> ';
                    html += '        <a href="javascript:void(0);" class="dropdown-item ver-audiencia pr-5" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdrop" aria-controls="offcanvasBackdrop" data-toggle="tooltip" data-placement="top" ';
                    html += '            title="Ver audiencia">' + feather.icons['eye'].toSvg({class: 'me-50 font-small-4'}) + ' Ver audiencia</a> ';
                    html += '    </div> ';
                    html += '</div> ';
                    return html;
                }
            },
            {
                orderable: false,
                className: 'select-checkbox',
                targets: 0,
                checkboxes: {
                    selectRow: true
                }
            }
        ],
        select: {
            style: 'multi',
            selector: 'td:first-child'
        },
        initComplete: function () {
            let cardHeader = $("#tdFilterCreator");
            let filterNegocio = $("#tdFilterNegocio");
            let htmlClean = DOMPurify.sanitize('<label class="mb-0" for="am_aplicacion_id">Creadores</label><select class="form-control input-sm"  id="am_aplicacion_id"><option value="">Todos</option></select>', {IN_PLACE: true});
            let htmlCleanNegocio = DOMPurify.sanitize('<label class="mb-0" for="am_negocio_id">Negocio</label><select class="form-control input-sm"  id="am_negocio_id"><option value="">Todos</option></select>', {IN_PLACE: true});
            cardHeader.append(htmlClean);
            filterNegocio.append(htmlCleanNegocio);
            this.api()
                .columns([3, 7])
                .every(function () {
                    let column = this;
                    let select = "";
                    if (column.index() == 3) {
                        select = $("#tdFilterCreator").find('#am_aplicacion_id')
                            .on('change', function () {
                                let val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });
                    }
                    if (column.index() == 7) {
                        select = $("#tdFilterNegocio").find('#am_negocio_id')
                            .on('change', function () {
                                let val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });
                    }
                    column
                        .data()
                        .unique()
                        .sort()
                        .each(function (d, j) {
                            select.append('<option value="' + d + '">' + d + '</option>');
                        });
                });
        },
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [
            {
                text: feather.icons['plus'].toSvg({class: 'me-50 font-small-4'}) + 'Asignar notificación',
                className: 'button error small btnAsignNotification d-none',
                attr: {
                    'onclick': 'saveDatesNotification()'
                },
            }, {
                text: feather.icons['trash'].toSvg({class: 'me-50 font-small-4'}) + 'Eliminar notificaciónes',
                className: 'button error small btnDeleteNotification d-none',
                attr: {
                    'onclick': 'deleteNotificationPublicacion()'
                },
            }]


    });
    setTimeout(function () {
        let filter = $("#tdFilterCreator").find('#am_aplicacion_id');
        filter.val(nombreUsuario);
        filter.change();
    }, 4000);
    lista_audiencias_usuarios_ver = lista_audiencias_usuarios_table_ver.DataTable({
        scrollX: true,
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [{
            extend: 'excelHtml5',
            text: 'Descargar usuarios',
            className: 'create-new button default small',
            exportOptions: {
                columns: ':visible'
            }
        }]


    });
    listaNotificacionesAsign = listaNotificacionesAsign_table.DataTable({
        scrollX: true,
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        columnDefs: [
            {
                targets: 0,
                visible: false
            },
            {
                targets: 5,
                title: 'Acciones',
                data: null,
                //orderable: false,
                render: function (data, type, full, meta) {

                    let html = '';
                    html += '<div class="btn-group"> ';
                    html += '    <a class="link dropdown-toggle" type="button" id="dropdownMenuAcciones" ';
                    html += '        data-bs-toggle="dropdown" aria-expanded="false"><i data-feather="chevron-down" ';
                    html += '                                                            class="mr-2"></i>Acciones ';
                    html += '    </a> ';
                    html += '    <div class="dropdown-menu" aria-labelledby="dropdownMenuAcciones"> ';
                    html += '        <a href="javascript:void(0);" class="dropdown-item ver-notifUser pr-5" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropNotifUser" aria-controls="offcanvasBackdropNotifUser" data-toggle="tooltip" data-placement="top" title="Ver usuarios">' + feather.icons['eye'].toSvg({class: 'me-50 font-small-4'}) + ' Ver usuarios</a> ';
                    html += '        <a href="javascript:void(0);" class=" dropdown-item preview-notificacion pr-5" title="Previsualizar" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropPreview" aria-controls="offcanvasBackdropPreview" data-toggle="tooltip" data-placement="top">' + feather.icons['airplay'].toSvg({class: 'me-50 font-small-4'}) + ' Previsualizar</a> ';
                    html += '        <a href="javascript:void(0);" class="dropdown-item deleteNotif pr-5" title="Eliminar notificación">' + feather.icons['trash'].toSvg({class: 'me-50 font-small-4'}) + ' Eliminar</a> ';
                    html += '    </div> ';
                    html += '</div> ';
                    return html;
                }
            }
        ],
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [{
            extend: 'excelHtml5',
            text: 'Descargar notificaciones',
            className: 'create-new button default small',
            exportOptions: {
                columns: ':visible'
            }
        }]


    });
    lista_usuariosNotif = lista_usuariosNotif_table.DataTable({
        scrollX: true,
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [{
            extend: 'excelHtml5',
            text: 'Descargar Usuarios',
            className: 'create-new button default small',
            exportOptions: {
                columns: ':visible'
            }
        }]


    });
    $('#min, #max').on('change', function () {
        dt_basic.draw();
    });
    dt_basic.on('select', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas > 0) {
                $(".btnAsignNotification").removeClass("d-none");
                $(".btnDeleteNotification").removeClass("d-none");
            }
            if (filasSeleccionadas === dt.rows({search: 'applied'}).count()) {
                $('#select-all').prop('checked', true);
            } else {
                $('#select-all').prop('checked', false);
            }
        }
    });
    dt_basic.on('deselect', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas === 0) {
                $(".btnAsignNotification").addClass("d-none");
                $(".btnDeleteNotification").addClass("d-none");
            }
        }
    });

    $("#btnRefresh").on("click", function () {
        $('#min, #max').val('');
        minDate.val('');
        maxDate.val('');
        $("#am_aplicacion_id").val('');
        $("#am_negocio_id").val('');
        dt_basic.search('').columns().search('').draw();
    });
    $("#btnRefreshTemplate").on("click", function () {
        $("#fechaPubliacion").val('');
        $("#selHoraPublicacion").val('');
        $("#selTemplate").val('');

    });
    modalControl.modal({
        backdrop: 'static',
        keyboard: false
    });
    $('#select-all').on('change', function () {
        if ($(this).is(':checked')) {
            dt_basic.rows({search: 'applied'}).select();
        } else {
            dt_basic.rows({search: 'applied'}).deselect();
        }
    });
});

listNotificaciones_table.on('click', '.ver-audiencia', function () {
    let data = dt_basic.row($(this).parents('tr')).data();
    cargarAudienciaUsuarios(data.id_audiencia, true);
});
listNotificaciones_table.on('click', '.ver-notificaciones', function () {
    let data = dt_basic.row($(this).parents('tr')).data();
    tempIdPublicacion = data.id;
    cargarNotificaciones(tempIdPublicacion, true);
});

listaNotificacionesAsign_table.on('click', '.preview-notificacion', function () {
    let data = listaNotificacionesAsign.row($(this).parents('tr')).data();
    cargarNotificacionTemplate(data[0]);
});
listaNotificacionesAsign_table.on('click', '.ver-notifUser', function () {
    let data = listaNotificacionesAsign.row($(this).parents('tr')).data();
    cargarUsuariosNotif(data[0], true);
});
listaNotificacionesAsign_table.on('click', '.deleteNotif ', function () {
    let data = listaNotificacionesAsign.row($(this).parents('tr')).data();
    eliminarNotificacion(data[0]);
});

function eliminarNotificacion(id) {
    Swal.fire({
        title: '¿Deseas eliminar esta notificación?',
        text: "A continuación se procesara la eliminación.",
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: './eliminarNotificacion/' + id,
                method: "get",
                success: function (data) {
                    $(".toast-body").html('Se ha eliminado correctamente.');
                    cargarNotificaciones(tempIdPublicacion);
                    dt_basic.ajax.reload();
                    showBasicToast.show();
                },
                error: function (xhr, status, error) {
                    $(".toast-body").text(xhr.responseJSON.message);
                    showBasicToast.show();
                },
                beforeSend: function () {
                    $('#containerNotificacionesAsignadas').LoadingOverlay('show', loading);
                },
                complete: function (data) {
                    $('#containerNotificacionesAsignadas').LoadingOverlay('hide', true);

                }
            });
        }
    });


}

function cargarAudienciaUsuarios(tempIdAudiencia) {

    $.ajax({
        url: './cargarAudienciaUsuarios/' + tempIdAudiencia,
        dataType: "json",
        method: "get",
        processData: false,
        contentType: false,
        success: function (data) {
            data.forEach(usuario => {
                let row = [
                    usuario.rut,
                    usuario.nombre_completo,
                    usuario.silla_division,
                    usuario.silla_unidad,
                    usuario.silla_cargo,
                ];
                lista_audiencias_usuarios_ver.row.add(row).draw();
            });
        },
        error: function (xhr, status, error) {
            $(".toast-body").text(xhr.responseJSON.message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#offcanvasBackdrop').LoadingOverlay('show', loading);
            lista_audiencias_usuarios_ver.clear().draw();
        },
        complete: function (data) {
            $('#offcanvasBackdrop').LoadingOverlay('hide', true);
        }
    });
}

function cargarNotificaciones(idPublicacion) {

    $.ajax({
        url: './cargarNotificacionesByPublicacion/' + idPublicacion,
        dataType: "json",
        method: "get",
        processData: false,
        contentType: false,
        success: function (datos) {
            let data = datos.data
            data.forEach(data => {
                let row = [
                    data.notif_codigo,
                    data.notif_fecha,
                    data.notif_hour,
                    data.template.nottem_titulo,
                    data.cantidad_notificaciones_enviadas_count
                ];
                listaNotificacionesAsign.row.add(row).draw();
            });
        },
        error: function (xhr, status, error) {
            $(".toast-body").text(xhr.responseJSON.message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#offcanvasBackdropNotif').LoadingOverlay('show', loading);
            listaNotificacionesAsign.clear().draw();
        },
        complete: function (data) {
            $('#offcanvasBackdropNotif').LoadingOverlay('hide', true);
        }
    });
}

function cargarNotificacionTemplate(idNotificacion) {

    $.ajax({
        url: './cargarNotificacionTemplate/' + idNotificacion,
        dataType: "json",
        method: "get",
        processData: false,
        contentType: false,
        success: function (datos) {
            let data = datos.data
            let textoEnriquecido = data
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&#039;/g, "'")
                .replace(/&quot;/g, '"');
            let textoEnriquecidoClean = convertHtmlToJQueryObject(textoEnriquecido, true, false);
            $("#containerNotificacionPreview").html(textoEnriquecidoClean);
        },
        error: function (xhr, status, error) {
            $(".toast-body").text(xhr.responseJSON.message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#offcanvasBackdropPreview').LoadingOverlay('show', loading);
            listaNotificacionesAsign.clear().draw();
        },
        complete: function (data) {
            $('#offcanvasBackdropPreview').LoadingOverlay('hide', true);
        }
    });
}

function cargarUsuariosNotif(idNotificacion) {

    $.ajax({
        url: './cargarUsuariosNotificadosById/' + idNotificacion,
        dataType: "json",
        method: "get",
        processData: false,
        contentType: false,
        success: function (datos) {
            datos.data.forEach(usuarios => {
                let row = [
                    usuarios.notifdet_rut,
                    usuarios.usuarios.nombre_completo,
                    usuarios.usuarios.silla_division,
                    usuarios.usuarios.silla_unidad,
                    usuarios.usuarios.silla_cargo,
                    'Sí'
                ];
                lista_usuariosNotif.row.add(row).draw();
            });
        },
        error: function (xhr, status, error) {
            $(".toast-body").text(xhr.responseJSON.message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#offcanvasBackdropNotif').LoadingOverlay('show', loading);
            lista_usuariosNotif.clear().draw();
        },
        complete: function (data) {
            $('#offcanvasBackdropNotif').LoadingOverlay('hide', true);
        }
    });
}

function saveDatesNotification() {
    let textoAlerta = "Se asignará fecha y hora de notificación para las siguientes publicaciones:";
    dt_basic.rows({selected: true}).data().toArray().map(function (item) {
        publicationSelected.push(item.id);
        textoAlerta += " </br>*" + item.nombre;
    });
    Swal.fire({
        title: '¿Deseas asignar esta fecha y hora a las publicaciones seleccionadas?',
        html: textoAlerta,
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            AsignarFechaHoraPublicacion();
        }
    })
}

function deleteNotificationPublicacion() {
    let textoAlerta = "Se limpiaran las notificaciones para las siguientes publicaciones:";
    dt_basic.rows({selected: true}).data().toArray().map(function (item) {
        publicationSelected.push(item.id);
        textoAlerta += " </br>*" + item.nombre;
    });
    Swal.fire({
        title: '¿Deseas eliminar las noificaciones a las publicaciones seleccionadas?',
        html: textoAlerta,
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            EliminarNotificacionesPublicacion();
        }
    })
}

function AsignarFechaHoraPublicacion() {
    let fechaPublication = $("#fechaPubliacion").val();
    let horaPublication = $("#selHoraPublicacion").val();
    let idTemplate = $("#selTemplate").val();
    $.ajax({
        url: './AsignarFechaHoraPublicacion',
        dataType: "json",
        method: "post",
        data: {
            "_token": csrf,
            "datos": publicationSelected,
            "fecha_publicacion": fechaPublication,
            "hora_publicacion": horaPublication,
            "template": idTemplate
        },
        success: function (data) {
            tempIdPublicacion = data['data'];
            if (data.code == 201) {
                $(".toast-body").text('Se ha asignado correctamente.');
            } else {
                $(".toast-body").text(data.status);
            }
            dt_basic.ajax.reload();
            showBasicToast.show();
        },
        error: function (xhr, status, error) {
            $(".toast-body").text(xhr.responseJSON.message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#lista_publicaciones_wrapper').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#lista_publicaciones_wrapper').LoadingOverlay('hide', true);
            publicationSelected = [];
        }
    });
}

function EliminarNotificacionesPublicacion() {
    $.ajax({
        url: './eliminarNotificacionesPublicacion',
        dataType: "json",
        method: "post",
        data: {
            "_token": csrf,
            "datos": publicationSelected,
        },
        success: function (data) {
            tempIdPublicacion = data['data'];
            if (data.code == 200) {
                $(".toast-body").text('Se han eliminado correctamente.');
            } else {
                $(".toast-body").text(data.status);
            }
            dt_basic.ajax.reload();
            showBasicToast.show();
        },
        error: function (xhr, status, error) {
            $(".toast-body").text(xhr.responseJSON.message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#lista_publicaciones_wrapper').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#lista_publicaciones_wrapper').LoadingOverlay('hide', true);
            publicationSelected = [];
        }
    });
}

function listarTemplates() {
    $.ajax({
        url: './listTemplate',
        dataType: "json",
        async: false,
        method: "get",
        data: {
            "_token": csrf,
        },
        success: function (datos) {
            $.map(datos.data, function (v) {
                let optionClean = convertHtmlToJQueryObject('<option value="' + v.nottem_codigo + '">' + v.nottem_titulo + '</option>', true, false);
                $("#selTemplate").append(optionClean);
            })
        },
        error: function (xhr, status, error) {
            $(".toast-body").text(xhr.responseJSON.message);
            showBasicToast.show();
        },
        beforeSend: function () {
        },
        complete: function (data) {

        }
    });
}

