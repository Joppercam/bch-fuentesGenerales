let dt_basic_table = $('.lista_audiencias'),
    dt_basic_,
    lista_audiencias_usuarios_table_ = $('.lista_audiencias_usuarios'),
    lista_audiencias_usuarios_table_ver = $('.lista_audiencias_usuarios_ver'),
    lista_audiencias_usuarios = null,
    lista_audiencias_usuarios_ver = null,
    basicToast = document.querySelector('.basic-toast'),
    dropFileDocument = $('#dpz-single-file-publicacion'),
    dropFileAudiencia = $('#multimediaFiles'),
    assetPath = 'public/app-assets/',
    showBasicToast = new bootstrap.Toast(basicToast),
    modalContainerAsignacionUsuarios = $('#offcanvasBackdrop'),
    modoEditar_ = false,
    tempIdAudiencia = false,
    tempDuplicate = false,
    AudienciaSelected = [],
    textoAlertaRestricDelete = "",
    modalControl = $('#modal-audiencia');
;
/**Se incluyen filtros por fecha en tabla de audiencias**/
let minDate, maxDate;
$.fn.dataTable.ext.search.push(
    function (settings, data, dataIndex) {
        let min = minDate.val();
        let max = maxDate.val();
        let date = new Date(data[3]);

        if (
            (min === null && max === null) ||
            (min === null && date <= max) ||
            (min <= date && max === null) ||
            (min <= date && date <= max)
        ) {
            return true;
        }
        return false;
    }
);
$(document).ready(function () {

    dropFileAudiencia.fileinput({
        showCancel: false,
        showRemove: true,
        showUpload: false,
        browseLabel: 'Seleccionar elementos',
        allowedFileExtensions: ['xlsx'],
        initialPreviewShowDelete: false,
    });
    /**Se incluyen filtros por fecha en tabla de audiencias**/
    minDate = new DateTime($('#min'), {});
    maxDate = new DateTime($('#max'), {});
    dt_basic = dt_basic_table.DataTable({
        ajax: {
            url: listAudiencias,
            data: function (d) {
                return $.extend({}, d, {
                    "desde": $("#min").val(),
                    "hasta": $("#max").val(),
                    "creador": $("#am_aplicacion_id").val()
                })
            }
        },
        serverSide: true,
        responsive: true,
        columns: [
            {
                data: 'id',
                name: 'check',
                visible: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = '';
                    return txt.value;
                }
            }, {
                data: 'id',
                name: 'id_audiencia',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre',
                name: 'nombre',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'fecha',
                name: 'fecha',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'created_at',
                name: 'fecha_creacion',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre_creador.rut',
                name: 'Rut Autor',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'nombre_creador.nombre_completo',
                name: 'Creador',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'updated_at',
                name: 'Fecha edición',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'cargos',
                name: 'cargos',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = row.usuarios;
                    return txt.value;
                }
            },
            {
                data: 'num_incluidos_count',
                name: 'Num Incluidos',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = "<span class='badge bg-success'>" + data + "</span>";
                    return txt.value;
                }
            },
            {
                data: 'num_excluidos_count',
                name: 'Num Excluidos',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = "<span class='badge bg-danger'>" + data + "</span>";
                    return txt.value;
                }
            },
            {
                data: 'cargos',
                name: 'Cargos',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = JSON.stringify(data);
                    return txt.value;
                }
            }

        ],
        order: [],
        columnDefs: [
            {
                targets: 12,
                title: 'Acciones',
                data: null,
                //orderable: false,
                render: function (data, type, full, meta) {

                    let html = '';
                    html += '<div class="btn-group"> ';
                    html += '    <a class="link dropdown-toggle" type="button" id="dropdownMenuAcciones" ';
                    html += '        data-bs-toggle="dropdown" aria-expanded="false"><i data-feather="chevron-down" ';
                    html += '                                                            class="mr-2"></i>Acciones ';
                    html += '    </a> ';
                    html += '    <div class="dropdown-menu" aria-labelledby="dropdownMenuAcciones"> ';
                    html += '        <a href="javascript:;" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropFormulario" aria-controls="offcanvasBackdropFormulario" class="dropdown-item ver-audiencia pr-5" data-toggle="tooltip" data-pacement="top" ';
                    html += '            title="Editar"><i data-feather="users"></i> Ver</a> ';
                    html += '        <a href="javascript:;" class=" dropdown-item editar-audiencia pr-5" data-toggle="tooltip" ';
                    html += '            data-pacement="top" title="Editar"><i data-feather="edit-3"></i> Editar</a> ';
                    if (full.num_incluidos_count === 0 && full.num_excluidos_count === 0) {
                        html += '        <a href="javascript:;" class=" dropdown-item duplicar-audiencia pr-5" data-toggle="tooltip" ';
                        html += '            data-pacement="top" title="Duplicar"> <i data-feather="copy"></i> Duplicar</a> ';
                    }
                    html += '    </div> ';
                    html += '</div> ';
                    return html;
                }
            },
            {
                orderable: false,
                className: 'select-checkbox',
                targets: 0,
                checkboxes: {
                    selectRow: true
                }
            }
        ],
        select: {
            style: 'multi',
            selector: 'td:first-child'
        },
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [
            {
                text: feather.icons['trash'].toSvg({class: 'me-50 font-small-4'}) + 'Eliminar audiencias',
                className: 'button error small btnDeleteRecords d-none',
                attr: {
                    'onclick': 'deleteMultiplesRecords()'
                },
            },
            {
                text: feather.icons['plus'].toSvg({class: 'me-50 font-small-4'}) + 'Nueva Audiencia',
                className: 'create-new button default small',
                attr: {
                    'data-bs-toggle': 'modal',
                    'data-bs-target': '#modal-audiencia',
                    'onclick': 'getEstructuraInit(divisiones = "", unidades = "",cargos = "",modoEditar_ = false,init = false); modoEditar(modoEditar_);'
                },
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');
                }
            },
            {
                extend: 'collection',
                className: 'create-new button default small me-2 report-button',
                text: feather.icons['share'].toSvg({class: 'font-small-4 me-50'}) + 'Descargar reporte de audiencias',
                buttons: [
                    {
                        extend: 'csv',
                        text: feather.icons['file-text'].toSvg({class: 'font-small-4 me-50 mr-2'}) + '.csv',
                        charset: 'utf-8',
                        title: 'Audiencias',
                        bom: true,
                        fieldSeparator: ';',
                        className: 'dropdown-item',
                        exportOptions: {columns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]}
                    }
                ],
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');
                    $(node).parent().removeClass('btn-group');
                    setTimeout(function () {
                        $(node).closest('.dt-buttons').removeClass('btn-group').addClass('d-inline-flex');
                    }, 50);
                }
            }]


    });
    $('#min, #max,#am_aplicacion_id').on('change', function () {
        dt_basic.draw();
    });
    dt_basic.on('select', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas > 0) {
                $(".btnDeleteRecords").removeClass("d-none");
            }
            if (filasSeleccionadas === dt.rows().count()) {
                $('#select-all').prop('checked', true);
            } else {
                $('#select-all').prop('checked', false);
            }
        }
    });
    dt_basic.on('deselect', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas === 0) {
                $(".btnDeleteRecords").addClass("d-none");
            }
        }
    });

    $("#selectDivision").on("change", function () {
        let divisiones = $(this).val();
        getUnidades(divisiones, [], [], modoEditar_, true);
    });
    $("#selectUnidad").on("change", function () {
        let divisiones = $("#selectDivision").val();
        let unidades = $(this).val();

        getCargos(divisiones, unidades, [], modoEditar_);
    });

    $("#frmAudiencia").on("submit", function () {
        if (!modoEditar_) {
            saveAudiencia();
        } else {
            editarAudiencia(tempIdAudiencia);
        }

    });
    $("#btnRefresh").on("click", function () {
        $('#min, #max').val('');
        minDate.val('');
        maxDate.val('');
        dt_basic.draw();
    });
    $("#visualizarUsuarios").on("click", function () {
        initTableAudiencia(tempIdAudiencia);
    });
    $("#visualizarUsuariosExInc").on("click", function () {
        initTableAudienciaIncExc(tempIdAudiencia);
    });
    $(".btn-close-modal").on("click", function () {
        $("#selectDivision").empty();
        $("#selectCargo").empty();
        $("#selectUnidad").empty();
        tempIdAudiencia = false;
    });

    /* A click event handler for the delete-user class. */
    $('.lista_audiencias tbody').on('click', 'a.eliminar-audiencia', function () {
        var data = dt_basic.row($(this).parents('tr')).data();
        eliminarAudiencia(data.id);
    });

    /* A click event handler for the delete-user class. */
    $('.lista_audiencias tbody').on('click', 'a.ver-audiencia', function () {
        var data = dt_basic.row($(this).parents('tr')).data();
        initTableVerAudiencia(data.id);
    });
    /* A click event handler for the delete-user class. */
    $('.lista_audiencias tbody').on('click', 'a.duplicar-audiencia', function () {
        tempIdAudiencia = false;
        modoEditar_ = false;
        let data = dt_basic.row($(this).parents('tr')).data();
        tempDuplicate = data.id;
        /* MODO EDiTAR*/
        $('#modal-audiencia').modal('show');
        $("#nombre_audiencia").val(data.nombre);
        getEstructuraInit(data.divisiones, data.unidades, data.cargos, true);
    });
    $('#lista_audiencias_usuarios').on('click', '.deleteColExIn', function () {
        let data = lista_audiencias_usuarios.row($(this).parents('tr')).data();
        Swal.fire({
            title: '¿Desea eliminar este usuario?',
            icon: 'info',
            showCancelButton: true,
            confirmButtonText: 'Si, continuar!',
            cancelButtonText: 'Cancelar',
            customClass: {
                confirmButton: 'button btn-primary  small mr-4',
                cancelButton: 'button btn-danger small'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.value) {
                deleteUserExInc(data.rut);
            }
        })
    });

    /* A click event handler for the delete-user class. */
    $('.lista_audiencias tbody').on('click', 'a.editar-audiencia', function () {
        let data = dt_basic.row($(this).parents('tr')).data();
        if (data.publicaciones_count > 0) {
            Swal.fire({
                title: '¿Esta audiencia esta siendo utilizada seguro deseas editarla?',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Si, continuar!',
                cancelButtonText: 'Cancelar',
                customClass: {
                    confirmButton: 'button btn-primary  small mr-4',
                    cancelButton: 'button btn-danger small'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.value) {
                    /* MODO EDiTAR*/
                    $('#modal-audiencia').modal('show');
                    $("#nombre_audiencia").val(data.nombre);
                    modoEditar(true);
                    modoEditar_ = true;
                    tempIdAudiencia = data.id;
                    getEstructuraInit(data.divisiones, data.unidades, data.cargos, modoEditar_);
                }
            })
        } else {
            /* MODO EDiTAR*/
            $('#modal-audiencia').modal('show');
            $("#nombre_audiencia").val(data.nombre);
            modoEditar(true);
            modoEditar_ = true;
            tempIdAudiencia = data.id;
            console.log(tempIdAudiencia);
            getEstructuraInit(data.divisiones, data.unidades, data.cargos, modoEditar_);
        }
    });

    modalControl.modal({
        backdrop: 'static',
        keyboard: false
    });
    $('#select-all').on('change', function () {
        if ($(this).is(':checked')) {
            dt_basic.rows().select(); // Solo selecciona las filas filtradas
        } else {
            dt_basic.rows().deselect(); // Solo deselecciona las filas filtradas
        }
    });

});

function deleteMultiplesRecords() {
    let textoAlerta = "A continuación se procesara la eliminación de las siguientes audiencias:";
    dt_basic.rows({selected: true}).data().toArray().map(function (item) {
        if (item.publicaciones_count == 0) {
            AudienciaSelected.push(item.id);
            textoAlerta += " </br>*" + item.nombre;
        } else {
            textoAlertaRestricDelete += " </br>*" + item.nombre;
        }
    });
    if (AudienciaSelected.length == 0) {
        textoAlerta = "Las audiencias seleccionadas no pueden ser eliminadas";
    }
    Swal.fire({
        title: '¿Deseas eliminar las audiencias seleccionadas?',
        html: textoAlerta,
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            if (AudienciaSelected.length > 0) {
                EliminarAudienciasMiltiples();
            }
        }
    })
}

function EliminarAudienciasMiltiples() {

    $.ajax({
        url: './deleteAudienciaMultiple',
        dataType: "json",
        method: "post",
        data: {
            "_token": csrf,
            "datos": AudienciaSelected
        },
        success: function (data) {
            tempIdPublicacion = data['data'];
            $(".toast-body").html('Se ha eliminado correctamente.');
            dt_basic.ajax.reload();
            showBasicToast.show();
            if (textoAlertaRestricDelete != "") {
                Swal.fire({
                    title: '¡Algunas audiencias no fueron eliminadas ya que se encuentran en uso!',
                    html: textoAlertaRestricDelete,
                    icon: 'info',
                    customClass: {
                        confirmButton: 'button btn-primary  small mr-4',
                    },
                    buttonsStyling: false
                })
            }
            textoAlertaRestricDelete = "";
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('.contenedorListarAudiencias').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('.contenedorListarAudiencias').LoadingOverlay('hide', true);
        }
    });
}

function getEstructuraInit(divisiones = '', unidades = '', cargos = '', modoEditar_ = false, init = false) {
    getDivisiones(divisiones, unidades, cargos, modoEditar_, init);
}

function getDivisiones(divisiones, unidades, cargos, modoEditar_, init) {

    $.ajax({
        url: './listDivisiones',
        dataType: "json",
        method: "get",
        data: {
            "_token": csrf
        },
        success: function (data) {
            data['data'].forEach(element => {
                if (modoEditar_) {

                    divisiones.forEach(division => {
                        let option;
                        if (division.id_division == element.silla_id_division) {
                            option = DOMPurify.sanitize("<option selected value=" + element.silla_id_division + ">" + element.silla_division + "</option>", {IN_PLACE: true})

                        } else {
                            option = DOMPurify.sanitize("<option value=" + element.silla_id_division + ">" + element.silla_division + "</option>", {IN_PLACE: true})
                        }
                        let optionClean = convertHtmlToJQueryObject(option, true, false);
                        $('#selectDivision').append(optionClean);
                    });
                } else {
                    let option;

                    option = DOMPurify.sanitize("<option value=" + element.silla_id_division + ">" + element.silla_division + "</option>", {IN_PLACE: true})
                    let optionClean = convertHtmlToJQueryObject(option, true, false);
                    $('#selectDivision').append(optionClean);

                }

            });
            $('#selectDivision').select2();
            $('#selectUnidad').select2();
            getUnidades(divisiones, unidades, cargos, modoEditar_);
        },
        error: function (xhr, status, error) {
        },
        beforeSend: function () {
            $('#modal-audiencia').LoadingOverlay('show', loading);
        },
        complete: function () {
        }
    });
}

function getUnidades(divisiones, unidades, cargos, modoEditar_, fromSelect = false) {

    $.ajax({
        url: './listUnidades',
        dataType: "json",
        method: "post",
        data: {
            "_token": csrf,
            "data": divisiones
        },
        success: function (data) {
            let unidades_array = [];
            data['data'].forEach(element => {

                if (modoEditar_) {

                    unidades.forEach(unidad => {
                        let option;

                        if (unidad.id_unidad == element.silla_id_unidad && unidades != '') {

                            if (!unidades_array.includes(element.silla_id_unidad)) {
                                option = DOMPurify.sanitize("<option selected value=" + element.silla_id_unidad + ">" + element.silla_unidad + "</option>", {IN_PLACE: true})
                            }
                            unidades_array.push(unidad.id_unidad);

                        } else {

                            option = DOMPurify.sanitize("<option value=" + element.silla_id_unidad + ">" + element.silla_unidad + "</option>", {IN_PLACE: true})

                        }

                        let optionClean = convertHtmlToJQueryObject(option, true, false);
                        $('#selectUnidad').append(optionClean);
                    });
                } else {
                    let option;
                    option = DOMPurify.sanitize("<option value=" + element.silla_id_unidad + ">" + element.silla_unidad + "</option>", {IN_PLACE: true})
                    let optionClean = convertHtmlToJQueryObject(option, true, false);
                    $('#selectUnidad').append(optionClean);
                }

            });
            getCargos(divisiones, unidades, cargos, modoEditar_);
        },
        error: function (xhr, status, error) {
        },
        beforeSend: function () {
            if (fromSelect) {
                $("#selectCargo").empty().trigger('change');
                $("#selectUnidad").empty().trigger('change');
            }
        },
        complete: function () {
        }
    });
}

function getCargos(divisiones, unidades, cargos, modoEditar_) {
    $("#selectCargo").empty().trigger('change');
    $.ajax({
        url: './listCargos',
        dataType: "json",
        async: false,
        method: "post",
        data: {
            "_token": csrf,
            "data": {
                'divisiones': divisiones,
                'unidades': unidades,
            }
        },
        success: function (data) {
            $("#selectCargo").select2({
                data: data['data']
            })
            var cargos_seleccionados = [];
            if (cargos != '') {
                data['data'].forEach(select2 => {
                    if (modoEditar_) {
                        cargos.forEach(cargo => {
                            if (select2.id == cargo.id_cargo) {
                                cargos_seleccionados.push(select2.id);
                            }
                        });
                    } else {
                        cargos_seleccionados.push(select2.id);
                    }
                });
            }
            if (modoEditar_) {
                $('#selectCargo').val(cargos_seleccionados);
                $('#selectCargo').trigger('change.select2');
            }
        },
        error: function (xhr, status, error) {
        },
        beforeSend: function () {
        },
        complete: function () {
            $('#modal-audiencia').LoadingOverlay('hide', true);
        }
    });
}

function saveAudiencia() {
    let form = $("#frmAudiencia");
    let formData = new FormData(form[0]);
    if (tempDuplicate) {
        formData.append("idDuplicated", tempDuplicate);
    }
    $.ajax({
        url: './saveAudiencia',
        type: 'POST',
        cache: false,
        contentType: false,
        headers: {'X-CSRF-Token': csrf},
        processData: false,
        data: formData,
        success: function (data) {
            let idAudiencia = data['data'];
            modalControl.modal('hide');
            $(".toast-body").html('Se ha registrado correctamente.');
            Swal.fire({
                title: '¿Desea generar un documento asociado?',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Si, continuar!',
                cancelButtonText: 'Cancelar',
                customClass: {
                    confirmButton: 'button btn-primary  small mr-4',
                    cancelButton: 'button btn-danger small'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.value) {
                    $.ajax({
                        url: './generarSesiones/idaudiencia/' + idAudiencia,
                        dataType: "json",
                        async: false,
                        method: "get",
                        data: {
                            "_token": csrf
                        },
                        success: function (data) {
                            window.location.href = './documentos';
                        },
                        error: function (xhr, status, error) {
                        },
                        beforeSend: function () {
                        },
                        complete: function () {

                        }
                    });
                }
            })
            dt_basic.ajax.reload();
            form[0].reset();
            $("#selectDivision").val(null).trigger('change');
            $("#selectUnidad").val(null).trigger('change');
            $("#selectCargo").val(null).trigger('change');
            tempIdAudiencia = false;
        },
        error: function (xhr, status, error) {
            let message = DOMPurify.sanitize(xhr.responseJSON.message, {IN_PLACE: true});
            if (typeof message === 'string') {
                message = message.replace(/[[\]"]/g, "");
                $(".toast-body").text(message);
            }
        },
        beforeSend: function () {
            $('#modal-audiencia-body').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#modal-audiencia-body').LoadingOverlay('hide', true);
            showBasicToast.show();
        }
    });
}

function initTableAudiencia(idAudiencia) {
    if (lista_audiencias_usuarios != null) {
        lista_audiencias_usuarios.destroy();
    }
    lista_audiencias_usuarios = lista_audiencias_usuarios_table_.DataTable({
        ajax: './getAudienciaUsuarios/' + idAudiencia,
        serverSide: false,
        processing: true,
        responsive: true,
        columns: [{
            data: 'rut', name: 'Rut', visible: true, render: function (data, type, row) {
                let txt = document.createElement("textarea");
                txt.innerHTML = data;
                return txt.value;
            }
        }, {
            data: 'nombre_completo', name: 'Nombre completo', render: function (data, type, row) {
                let txt = document.createElement("textarea");
                txt.innerHTML = data;
                return txt.value;
            }
        },
            {
                data: 'silla_division', name: 'División', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_unidad', name: 'Unidad', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_cargo', name: 'Cargo', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }],
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [{
            extend: 'excelHtml5',
            text: 'Descargar usuarios',
            className: 'create-new button default small',
            exportOptions: {
                columns: ':visible'
            }
        }]


    });
}

function initTableAudienciaIncExc(idAudiencia) {
    if (lista_audiencias_usuarios != null) {
        lista_audiencias_usuarios.destroy();
    }
    lista_audiencias_usuarios = lista_audiencias_usuarios_table_.DataTable({
        ajax: './getAudienciaUsuariosExInc/' + idAudiencia,
        serverSide: false,
        processing: true,
        responsive: true,
        columns: [{
            data: 'rut', name: 'Rut', visible: true, render: function (data, type, row) {
                let tipoText = "Incluido";
                let tipoClass = "badge bg-success";
                let txt = document.createElement("textarea");
                if (row.tipo == 1) {
                    tipoText = "Excluido";
                    tipoClass = "badge bg-warning";
                }
                txt.innerHTML = '<a href="javascript:void(0)" class="deleteColExIn c-warning">' + feather.icons['trash'].toSvg({class: 'me-50 font-small-5'}) + '</a>' + data + '<span class="' + tipoClass + '">' + tipoText + '</span>';
                return txt.value;
            }
        }, {
            data: 'nombre_completo', name: 'Nombre completo', render: function (data, type, row) {
                let txt = document.createElement("textarea");
                txt.innerHTML = data;
                return txt.value;
            }
        },
            {
                data: 'silla_division', name: 'División', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_unidad', name: 'Unidad', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_cargo', name: 'Cargo', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }],
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [{
            extend: 'excelHtml5',
            text: 'Descargar usuarios',
            className: 'create-new button default small',
            exportOptions: {
                columns: ':visible'
            }
        }]


    });
}

function initTableVerAudiencia(idAudiencia) {
    if (lista_audiencias_usuarios_ver != null) {
        lista_audiencias_usuarios_ver.destroy();
    }
    lista_audiencias_usuarios_ver = lista_audiencias_usuarios_table_ver.DataTable({
        ajax: './getAudienciaUsuarios/' + idAudiencia,
        serverSide: false,
        processing: true,
        responsive: true,
        columns: [{
            data: 'rut', name: 'Rut', visible: true, render: function (data, type, row) {
                let txt = document.createElement("textarea");
                txt.innerHTML = data;
                return txt.value;
            }
        }, {
            data: 'nombre_completo', name: 'Nombre completo', render: function (data, type, row) {
                let txt = document.createElement("textarea");
                txt.innerHTML = data;
                return txt.value;
            }
        },
            {
                data: 'silla_division', name: 'División', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_unidad', name: 'Unidad', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'silla_cargo', name: 'Cargo', render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }],
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [{
            extend: 'excelHtml5',
            text: 'Descargar usuarios',
            className: 'create-new button default small',
            exportOptions: {
                columns: ':visible'
            }
        }]


    });
}

function editarAudiencia(id) {
    let form = $("#frmAudiencia");
    let formData = new FormData(form[0]);
    formData.append("id", id);
    formData.append("_token", csrf);
    $.ajax({
        url: './updateAudiencia',
        dataType: "json",
        method: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            modalControl.modal('hide');
            $(".toast-body").html('Se ha editado correctamente.');
            dt_basic.ajax.reload();
            form[0].reset();
            tempIdAudiencia = false;
            $("#selectDivision").val(null).trigger('change');
            $("#selectUnidad").val(null).trigger('change');
            $("#selectCargo").val(null).trigger('change');
        },
        error: function (xhr, status, error) {
            let message = DOMPurify.sanitize(xhr.responseJSON.message, {IN_PLACE: true});
            if (typeof message === 'string') {
                message = message.replace(/[[\]"]/g, "");
                $(".toast-body").text(message);
            }
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#modal-audiencia-body').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#modal-audiencia-body').LoadingOverlay('hide', true);
        }
    });
}

function eliminarAudiencia(id) {

    let newdataform = new FormData();
    newdataform.append("id", id);
    newdataform.append("_token", csrf);

    Swal.fire({
        title: '¿Deseas eliminar esta audiencia?',
        text: "A continuación se procesara la eliminación.",
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: './deleteAudiencia',
                dataType: "json",
                method: "POST",
                data: newdataform,
                processData: false,
                contentType: false,
                success: function (data) {
                    dt_basic.ajax.reload(function () {
                    }, false);
                    $(".toast-body").html('Se ha eliminado correctamente.');
                },
                error: function (xhr, status, error) {
                    $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
                },
                beforeSend: function () {
                    $('.contenedorListarAudiencias').LoadingOverlay('show', loading);
                },
                complete: function (data) {
                    $('.contenedorListarAudiencias').LoadingOverlay('hide', true);
                    showBasicToast.show();
                }
            });
        }
    });


}

function modoEditar(editar) {

    if (editar) {
        modoEditar_ = true;
        $('.editar').hide();
        $('.editar-title').html('Audiencias');
        $('.editar-button').html('Guardar');
        $('#visualizarUsuarios').show();

    } else {
        modoEditar_ = false;
        $('#visualizarUsuarios').hide();
        $('.editar').show();
        $('.editar-title').html('Audiencias');
        $('.editar-button').html('Guardar');
        $("#nombre_audiencia").val("");
        $("#selectDivision").val("");
        $("#selectUnidad").val("");
        $("#selectCargo").val("");
        $('#selectCargo').trigger('change.select2');
        $('#selectUnidad').trigger('change.select2');
        $('#selectDivision').trigger('change.select2');
    }

}

function deleteUserExInc(rut) {
    $.ajax({
        url: './deleteUsuarioExcInc',
        dataType: "json",
        method: "POST",
        data: {
            "_token": csrf,
            "rut": rut,
            "idAudiencia": tempIdAudiencia
        },
        success: function (data) {
            lista_audiencias_usuarios.ajax.reload();
            $(".toast-body").html('Se ha eliminado correctamente.');
            dt_basic.ajax.reload();
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
        },
        beforeSend: function () {
            $('#containerDocumentosUsuariosAsignados').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#containerDocumentosUsuariosAsignados').LoadingOverlay('hide', true);
            showBasicToast.show();
        }
    });
}
