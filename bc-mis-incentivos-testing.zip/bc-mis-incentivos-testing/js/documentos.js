var dt_basic_table = $('.lista_documentos'),
    assetPath = 'public/app-assets/',
    dropFileDocumento = $('#multimediaFiles'),
    basicToast = document.querySelector('.basic-toast'),
    showBasicToast = new bootstrap.Toast(basicToast),
    tempIdDocumento = null,
    tempDuplicate = false,
    tempIdDocumentoVisualizar = null,
    DocumentoSelected = [],
    minDate, maxDate,
    textoAlertaRestricDelete = "",
    modalControl = $('#modal-documento');
$.fn.dataTable.ext.search.push(
    function (settings, data, dataIndex) {
        let min = minDate.val();
        let max = maxDate.val();
        let date = new Date(data[7]);

        if (
            (min === null && max === null) ||
            (min === null && date <= max) ||
            (min <= date && max === null) ||
            (min <= date && date <= max)
        ) {
            return true;
        }
        return false;
    }
);
$(document).ready(function () {
    if (idAudiencia) {
        $('#modal-documento').modal('show');
    }
    // Limit File Size and No. Of Files
    dropFileDocumento.fileinput({
        showCancel: false,
        showRemove: true,
        showUpload: false,
        browseLabel: 'Seleccionar elementos',
        allowedFileExtensions: ['pdf'],
        initialPreviewShowDelete: false,
    });

    /**Se incluyen filtros por fecha en tabla de audiencias**/
    minDate = new DateTime($('#min'), {});
    maxDate = new DateTime($('#max'), {});
    dt_basic = dt_basic_table.DataTable({
        ajax: listDocumentos,
        responsive: true,
        columns: [
            {
                data: 'id',
                name: 'id',
                visible: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = '';
                    return txt.value;
                }
            }, {
                data: 'id',
                name: 'id_documento',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre',
                name: 'nombre',
                exportable: false,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data + '<br><span class="text-muted">' + row.descripcion + '</span>';
                    return txt.value;
                }
            },
            {
                data: 'nombre',
                name: 'Nombre documento',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }, {
                data: 'descripcion',
                name: 'Descripcion',
                visible: false,
                exportable: true,
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre_documento_mascara',
                name: 'Documento',
                render: function (data, type, row) {

                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'nombre_autor.nombre_completo',
                name: 'nombre_autor.nombre_completo',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            },
            {
                data: 'fecha',
                name: 'fecha',
                render: function (data, type, row) {
                    let txt = document.createElement("textarea");
                    txt.innerHTML = data;
                    return txt.value;
                }
            }

        ],
        order: [],
        columnDefs: [
            {
                targets: 8,
                title: 'Acciones',
                data: null,
                //orderable: false,
                render: function (data, type, full, meta) {

                    let html = '';
                    html += '<div class="btn-group"> ';
                    html += '    <a class="link dropdown-toggle" type="button" id="dropdownMenuAcciones" ';
                    html += '        data-bs-toggle="dropdown" aria-expanded="false"><i data-feather="chevron-down" ';
                    html += '                                                            class="mr-2"></i>Acciones ';
                    html += '    </a> ';
                    html += '    <div class="dropdown-menu" aria-labelledby="dropdownMenuAcciones"> ';
                    html += '        <a data-bs-toggle="offcanvas" data-bs-target="#offcanvasBackdropFormulario" aria-controls="offcanvasBackdropFormulario" class="dropdown-item ver-documento pr-5" data-toggle="tooltip" data-pacement="top" ';
                    html += '            title="Editar"><i data-feather="users"></i> Ver</a> ';
                    html += '        <a data-bs-toggle="modal" class="dropdown-item editar-documento pr-5" data-toggle="tooltip" ';
                    html += '            data-pacement="top" title="Editar"><i data-feather="edit-3"></i> Editar</a> ';
                    html += '        <a class=" dropdown-item duplicar-documento pr-5" data-toggle="tooltip" ';
                    html += '            data-pacement="top" title="Duplicar"> <i data-feather="copy"></i> Duplicar</a> ';
                    html += '    </div> ';
                    html += '</div> ';
                    return html;
                }
            },
            {
                orderable: false,
                className: 'select-checkbox',
                targets: 0,
                checkboxes: {
                    selectRow: true
                }
            }
        ],
        select: {
            style: 'multi',
            selector: 'td:first-child'
        },
        initComplete: function () {
            let cardHeader = $("#tdFilterCreator");
            let htmlClean = DOMPurify.sanitize('<label for="am_aplicacion_id">Filtrar por creador</label><select class="form-control input-sm"  id="am_aplicacion_id"><option value="">Todos</option></select>', {IN_PLACE: true});
            cardHeader.append(htmlClean);
            this.api()
                .columns([6])
                .every(function () {
                    let column = this;
                    let select = $("#tdFilterCreator").find('#am_aplicacion_id')
                        .on('change', function () {
                            let val = $.fn.dataTable.util.escapeRegex($(this).val());
                            column.search(val ? '^' + val + '$' : '', true, false).draw();
                            column.search(val ? '^' + val + '$' : '', true, false).draw();
                        });
                    column
                        .data()
                        .unique()
                        .sort()
                        .each(function (d, j) {
                            select.append('<option value="' + d + '">' + d + '</option>');
                        });
                });
        },

        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        language: {
            "url": assetPath + "data/locales/es.json",
            paginate: {
                // remove previous & next text from pagination
                previous: '&nbsp;',
                next: '&nbsp;'
            },
        },
        "oSearch": {"bSmart": false, "bRegex": true},
        buttons: [
            {
                text: feather.icons['trash'].toSvg({class: 'me-50 font-small-4'}) + 'Eliminar documentos',
                className: 'button error small btnDeleteRecords d-none',
                attr: {
                    'onclick': 'deleteMultiplesRecords()'
                },
            },
            {
                text: feather.icons['plus'].toSvg({class: 'me-50 font-small-4'}) + 'Nuevo Documento',
                className: 'create-new button default small',
                attr: {
                    'data-bs-toggle': 'modal',
                    'data-bs-target': '#modal-documento',
                    'onclick': ''
                },
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');
                }
            },
            {
                extend: 'collection',
                className: 'create-new button default small me-2 report-button',
                text: feather.icons['share'].toSvg({class: 'font-small-4 me-50'}) + 'Descargar reporte de documentos',
                buttons: [
                    {
                        extend: 'csv',
                        text: feather.icons['file-text'].toSvg({class: 'font-small-4 me-50 mr-2'}) + '.csv',
                        charset: 'utf-8',
                        title: 'Documentos',
                        bom: true,
                        fieldSeparator: ';',
                        className: 'dropdown-item',
                        exportOptions: {columns: [1, 3, 4, 5, 6, 7]}
                    }
                ],
                init: function (api, node, config) {
                    $(node).removeClass('btn-secondary');
                    $(node).parent().removeClass('btn-group');
                    setTimeout(function () {
                        $(node).closest('.dt-buttons').removeClass('btn-group').addClass('d-inline-flex');
                    }, 50);
                }
            }]


    });
    setTimeout(function () {
        let filter = $("#tdFilterCreator").find('#am_aplicacion_id');
        filter.val(nombreUsuario);
        filter.change();
    }, 3000);
    $('#min, #max').on('change', function () {
        dt_basic.draw();
    });
    dt_basic.on('select', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas > 0) {
                $(".btnDeleteRecords").removeClass("d-none");
            }
            if (filasSeleccionadas === dt.rows({search: 'applied'}).count()) {
                $('#select-all').prop('checked', true);
            } else {
                $('#select-all').prop('checked', false);
            }
        }
    });
    dt_basic.on('deselect', function (e, dt, type, indexes) {
        if (type === 'row') {
            let filasSeleccionadas = dt.rows({selected: true}).count();
            if (filasSeleccionadas === 0) {
                $(".btnDeleteRecords").addClass("d-none");
            }
        }
    });
    $("#btnRefresh").on("click", function () {
        $('#min, #max').val('');
        minDate.val('');
        maxDate.val('');
        dt_basic.draw();
    });
    $("#frmDocumentos").on("submit", function () {
        if (tempIdDocumento) {
            editarDocumento();
        } else {
            guardarDocumento();
        }
    });

    /* A click event handler for the delete-user class. */
    $('.lista_documentos tbody').on('click', 'a.ver-documento', function () {
        var data = dt_basic.row($(this).parents('tr')).data();
        if (data) {
            visualizarDocumento(data.id, false);
        }
    });
    /* A click event handler for the delete-user class. */
    $('.lista_documentos tbody').on('click', 'a.eliminar-documento', function () {
        var data = dt_basic.row($(this).parents('tr')).data();
        eliminarDocumento(data.id);
        eliminarDocumento(data.id);
    });
    $('.lista_documentos tbody').on('click', 'a.duplicar-documento', function () {
        let data = dt_basic.row($(this).parents('tr')).data();
        $(".file-manager-item").removeClass("d-none");
        $("#multimediaFiles").attr('required', false);
        $('#modal-documento').modal('show');
        $("#modal-documento").val(data.nombre_documento);
        $('#descripcion_documento').val('');
        $('#nombre_documento').val(data.nombre);
        if (data.descripcion != undefined || data.descripcion != '') {
            $('#descripcion_documento').val(data.descripcion);
        }
        tempIdDocumentoVisualizar = data.id;
        tempDuplicate = data.id;
        $('#nombre_documento_cargado').html(data.nombre_documento);

    });
    /* A click event handler for the delete-user class. */
    $('.lista_documentos tbody').on('click', 'a.editar-documento', function () {
        let data = dt_basic.row($(this).parents('tr')).data();
        if (data.publicaciones_count > 0) {
            Swal.fire({
                title: '¿Este documento esta siendo utilizado seguro deseas editarlo?',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Si, continuar!',
                cancelButtonText: 'Cancelar',
                customClass: {
                    confirmButton: 'button btn-primary  small mr-4',
                    cancelButton: 'button btn-danger small'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.value) {
                    $(".file-manager-item").removeClass("d-none");
                    $("#multimediaFiles").attr('required', false);
                    /* MODO EDiTAR*/
                    $('#modal-documento').modal('show');
                    $("#modal-documento").val(data.nombre_documento);

                    $('#descripcion_documento').val('');
                    $('#nombre_documento').val(data.nombre);
                    if (data.descripcion != undefined || data.descripcion != '') {
                        $('#descripcion_documento').val(data.descripcion);
                    }
                    tempIdDocumento = data.id;
                    tempIdDocumentoVisualizar = data.id;
                    $('#nombre_documento_cargado').html(data.nombre_documento);
                }
            })
        } else {
            $(".file-manager-item").removeClass("d-none");
            $("#multimediaFiles").attr('required', false);
            $('#modal-documento').modal('show');
            $("#modal-documento").val(data.nombre_documento);
            $('#descripcion_documento').val('');

            $('#nombre_documento').val(data.nombre);
            if (data.descripcion != undefined || data.descripcion != '') {
                $('#descripcion_documento').val(data.descripcion);
            }
            tempIdDocumento = data.id;
            tempIdDocumentoVisualizar = data.id;
            $('#nombre_documento_cargado').text(data.nombre_documento);
        }
    });
    $('.verDocumentoCargado').on('click', function () {
        visualizarDocumento(tempIdDocumentoVisualizar, true);

    });
    modalControl.on('hidden.bs.modal', function () {
        tempDuplicate = null;
        tempIdDocumento = null;
        tempIdDocumentoVisualizar = null;
        $("#frmDocumentos")[0].reset();
        $(".file-manager-item").addClass('d-none');
        $("#multimediaFiles").attr('required', 'required');
    })
    $('#select-all').on('change', function () {
        if ($(this).is(':checked')) {
            dt_basic.rows({search: 'applied'}).select();
        } else {
            dt_basic.rows({search: 'applied'}).deselect();
        }
    });
});

function deleteMultiplesRecords() {
    textoAlertaRestricDelete = "";
    let textoAlerta = "A continuación se procesara la eliminación de los siguientes documentos:";
    dt_basic.rows({selected: true}).data().toArray().map(function (item) {
        if (item.publicaciones_count == 0) {
            DocumentoSelected.push(item.id);
            textoAlerta += " </br>*" + item.nombre;
        } else {
            textoAlertaRestricDelete += " </br>*" + item.nombre;
        }
    });
    if (DocumentoSelected.length == 0) {
        textoAlerta = "Los documentos seleccionados se encuentran en uso, no puede ser eliminado";
    }
    Swal.fire({
        title: '¿Deseas eliminar los documentos seleccionados?',
        html: textoAlerta,
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            if (DocumentoSelected.length > 0) {
                EliminarDocumentosMultiples();
            }
        }
    })
}

function EliminarDocumentosMultiples() {

    $.ajax({
        url: './deleteDocumentoMultiple',
        dataType: "json",
        method: "post",
        data: {
            "_token": csrf,
            "datos": DocumentoSelected

        },
        success: function (data) {
            $(".toast-body").html('Se ha eliminado correctamente.');
            dt_basic.ajax.reload();
            showBasicToast.show();
            if (textoAlertaRestricDelete != "") {
                Swal.fire({
                    title: '¡Algunos documentos no fueron eliminados ya que se encuentran en uso!',
                    html: textoAlertaRestricDelete,
                    icon: 'info',
                    customClass: {
                        confirmButton: 'button btn-primary  small mr-4',
                    },
                    buttonsStyling: false
                })
            }
            textoAlertaRestricDelete = "";
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#lista_publicaciones_wrapper').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#lista_publicaciones_wrapper').LoadingOverlay('hide', true);

        }
    });
}

function visualizarDocumento(id) {
    let id_documento = id;
    let visualizarDocumento = $('#visualizarDocumento');
    let containerVisualizacion = $('#offcanvasBackdropFormulario');

    $.ajax({
        url: './cargarDocumento/' + id_documento,
        dataType: "json",
        method: "get",
        success: function (data) {
            let pdf = 'data:application/pdf;base64,' + data['data'].documento_base_64 + '#toolbar=0';
            let pdfClean = convertHtmlToJQueryObject(pdf, true, false);
            visualizarDocumento.attr('src', pdfClean);
        },
        error: function (xhr, status, error) {
            $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
            showBasicToast.show();
        },
        beforeSend: function () {
            containerVisualizacion.LoadingOverlay('show', loading);
            visualizarDocumento.attr('src', '');
        },
        complete: function (data) {
            containerVisualizacion.LoadingOverlay('hide', true);
        }
    });


}

function guardarDocumento() {
    let form = $("#frmDocumentos");
    let formData = new FormData(form[0]);
    if (tempDuplicate !== null) {
        formData.append("idDuplicated", tempDuplicate);
    }
    $.ajax({
        url: './saveDocumento',
        type: 'POST',
        cache: false,
        contentType: false,
        headers: {'X-CSRF-Token': csrf},
        processData: false,
        data: formData,
        success: function (data) {
            if (data.code === 200) {
                tempIdDocumento = data['data'];
                Swal.fire({
                    title: '¿Desea generar una publicación asociada?',
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonText: 'Si, continuar!',
                    cancelButtonText: 'Cancelar',
                    customClass: {
                        confirmButton: 'button btn-primary  small mr-4',
                        cancelButton: 'button btn-danger small'
                    },
                    buttonsStyling: false
                }).then(function (result) {
                    if (result.value) {
                        $.ajax({
                            url: './generarSesiones/iddocumento/' + data['data'],
                            dataType: "json",
                            async: false,
                            method: "get",
                            data: {
                                "_token": csrf
                            },
                            success: function (data) {
                                window.location.href = './publicaciones';
                            },
                            error: function (xhr, status, error) {
                            },
                            beforeSend: function () {
                            },
                            complete: function () {

                            }
                        });
                    }
                })
                dt_basic.ajax.reload();
                modalControl.modal('hide');
                $(".toast-body").text('Se ha registrado correctamente.');
                form[0].reset();
                tempDuplicate = null;
                $(".file-manager-item").addClass("d-none");
            } else {
                $(".toast-body").text(data);
            }
            showBasicToast.show();
        },
        error: function (xhr, status, error) {
            let message = xhr.responseJSON.message;
            message = message.replace(/[\[\]"]/g, "");
            $(".toast-body").text(message);
            showBasicToast.show();
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#modal-documento').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#modal-documento').LoadingOverlay('hide', true);
        }
    });
}

function editarDocumento() {
    let id = tempIdDocumento;
    let form = $("#frmDocumentos");
    let formData = new FormData(form[0]);
    formData.append("id", id);
    $.ajax({
        url: './updateDocumento',
        type: 'POST',
        cache: false,
        contentType: false,
        headers: {'X-CSRF-Token': csrf},
        processData: false,
        data: formData,
        success: function (data) {
            tempIdDocumentoVisualizar = data['data'];
            $(".toast-body").html('Se ha actualizado correctamente.');
            modalControl.modal('hide');
            form[0].reset();
            dt_basic.ajax.reload();
            showBasicToast.show();
            $("#multimediaFiles").attr('required', 'required');
            $(".file-manager-item").addClass("d-none");
        },
        error: function (xhr, status, error) {
            let message = xhr.responseJSON.message;
            message = message.replace(/[\[\]"]/g, "");
            $(".toast-body").text(message);
            showBasicToast.show();
        },
        beforeSend: function () {
            $('#modal-documento').LoadingOverlay('show', loading);
        },
        complete: function (data) {
            $('#modal-documento').LoadingOverlay('hide', true);
        }
    });
}

function eliminarDocumento(id) {

    let newdataform = new FormData();
    newdataform.append("id", id);
    newdataform.append("_token", csrf);

    Swal.fire({
        title: '¿Deseas eliminar este documento?',
        text: "A continuación se procesara la eliminación.",
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Si, continuar!',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'button btn-primary  small mr-4',
            cancelButton: 'button btn-danger small'
        },
        buttonsStyling: false
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: './deleteDocumento',
                dataType: "json",
                method: "POST",
                data: newdataform,
                processData: false,
                contentType: false,
                success: function (data) {
                    dt_basic.ajax.reload(function () {
                        // Esta función se ejecutará después de que la tabla haya sido recargada
                        // Aquí puedes agregar el código que desees ejecutar después de recargar la tabla
                    }, false);
                    $(".toast-body").html('Se ha eliminado correctamente.');
                    showBasicToast.show();
                },
                error: function (xhr, status, error) {
                    $(".toast-body").html('Ha ocurrido un error, intente nuevamente.');
                    //$('.contenedorListarAudiencias').LoadingOverlay('hide',true);
                    showBasicToast.show();
                },
                beforeSend: function () {
                    $('.contenedorListarDocumentos').LoadingOverlay('show', loading);
                },
                complete: function (data) {
                    $('.contenedorListarDocumentos').LoadingOverlay('hide', true);
                }
            });
        }
    });

}
