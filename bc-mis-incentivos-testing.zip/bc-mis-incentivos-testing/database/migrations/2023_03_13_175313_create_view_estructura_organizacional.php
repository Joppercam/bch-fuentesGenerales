<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateViewEstructuraOrganizacional extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::statement($this->createView());
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement($this->dropView());
    }
    private function createView(): string
    {
        return <<<SQL
            CREATE VIEW mis_incentivos_view_estructura_organizacional AS select silla_id_division, division, id_unidad, unidad, silla_id_cargo, cargo from users where division is not null and unidad is not null and cargo is not null group by silla_id_division, division, id_unidad, unidad, silla_id_cargo, cargo order by silla_id_division, id_unidad, silla_id_cargo;
            SQL;
    }

    private function dropView(): string
    {
        return <<<SQL
            DROP VIEW IF EXISTS `mis_incentivos_view_estructura_organizacional`;
        SQL;
    }
}
