<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AudienciaUnidad extends Model
{
    use HasFactory;

    /**
     * The database connection used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql';

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'mis_incentivos_audiencia_unidades';

    /**
     * Get all of the comments for the AudienciaCargo
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function usuarios()
    {
        return $this->hasMany(User::class, 'silla_id_unidad', 'id_unidad')->select('rut','nombre_completo','silla_id_division','silla_division','silla_id_unidad','silla_unidad','silla_id_cargo','silla_cargo');
    }

    public function nombre_unidad(){
        return $this->hasOne(EstructuraOrganizacional::class, 'silla_id_unidad', 'id_unidad')->select('silla_id_unidad','silla_unidad');
    }

}
