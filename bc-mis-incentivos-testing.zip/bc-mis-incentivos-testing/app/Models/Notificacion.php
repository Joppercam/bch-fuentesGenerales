<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notificacion extends Model
{
    use HasFactory;

    /**
     * The database connection used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql';
   // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'mis_incentivos_notificaciones';

    public function cantidadNotificacionesEnviadas()
    {
        return $this->hasMany(NotificacionDetail::class, 'notifdet_notifcodigo', 'notif_codigo')
            ->where('notifdet_estatus', 1);
    }
    public function cantidadNotificacionesRecibidas()
    {
        return $this->hasMany(NotificacionDetail::class, 'notifdet_notifcodigo', 'notif_codigo')
            ->where('notifdet_estatus', 2);
    }
    public function template()
    {
        return $this->hasOne(NotificacionTemplate::class, 'nottem_codigo', 'notif_template');
    }
    public function publicacion()
    {
        return $this->hasOne(Publicacion::class, 'id', 'notif_publication');
    }
}
