<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Documento extends Model
{
    use HasFactory;

    /**
     * The database connection used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql';
   // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'mis_incentivos_documento';
    /**
     * Get the user associated with the Documento
    *
    * @return \Illuminate\Database\Eloquent\Relations\HasOne
    */
    public function nombre_autor()
    {
        return $this->hasOne(User::class, 'rut', 'autor')->select('rut','nombre_completo');
    }
    public function publicaciones()
    {
        return $this->hasMany(Publicacion::class, 'id_documento', 'id');
    }

}
