<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Publicacion extends Model
{
    use HasFactory;

    /**
     * The database connection used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql';
   // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'mis_incentivos_publicaciones';

    public function nombre_autor()
    {
        return $this->hasOne(User::class, 'rut', 'autor')->select('rut','nombre_completo');
    }

    public function audiencia()
    {
        return $this->hasOne(Audiencia::class, 'id', 'id_audiencia');
    }

    public function nombre_audiencia()
    {
        return $this->hasOne(Audiencia::class, 'id', 'id_audiencia')->select('id','nombre');
    }

    public function nombre_documento()
    {
        return $this->hasOne(Documento::class, 'id', 'id_documento')->select('id','nombre');
    }
    public function clasificacion()
    {
        return $this->hasOne(PublicacionOption::class, 'id_item', 'id_clasificacion')->select('id_item','nombre_item');
    }
    public function negocio()
    {
        return $this->hasOne(PublicacionOption::class, 'id_item', 'id_negocio')->select('id_item','nombre_item');
    }

    public function categoria()
    {
        return $this->hasOne(PublicacionOption::class, 'id_item', 'id_categoria')->select('id_item','nombre_item')->whereNotNull('nombre_item');
    }

    public function periodicidad()
    {
        return $this->hasOne(PublicacionOption::class, 'id_item', 'id_periodicidad')->select('id_item','nombre_item')->whereNotNull('nombre_item');
    }
    public function perfil()
    {
        return $this->hasOne(PublicacionOption::class, 'id_item', 'id_perfil')->select('id_item','nombre_item');
    }

    public function notificaciones()
    {
        return $this->hasMany(Notificacion::class, 'notif_publication', 'id');
    }

    public function visualizaciones()
    {
        return $this->hasMany(PublicacionView::class, 'publicacion_codigo', 'id')->distinct();
    }
}
