<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PublicacionView extends Model
{
    use HasFactory;

    /**
     * The database connection used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql';
   // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'mis_incentivos_publicaciones_views';

    public function publicaciones()
    {
        return $this->hasOne(Publicacion::class, 'id', 'publicacion_codigo');
    }

    public function usuarios()
    {
        return $this->hasOne(User::class, 'rut', 'view_rut')->select('nombre_completo','silla_id_cargo','silla_cargo');
    }
}
