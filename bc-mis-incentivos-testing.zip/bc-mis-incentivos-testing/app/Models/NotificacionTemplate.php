<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NotificacionTemplate extends Model
{
    use HasFactory,SoftDeletes;

    protected $primaryKey = 'nottem_codigo';
    /**
     * The database connection used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql';
   // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'mis_incentivos_notificacion_template';
}
