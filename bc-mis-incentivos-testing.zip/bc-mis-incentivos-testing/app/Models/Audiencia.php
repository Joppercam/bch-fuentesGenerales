<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Audiencia extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The database connection used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql';
    // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'mis_incentivos_audiencia';

    /**
     * Get all of the comments for the Audiencia
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function cargos()
    {
        return $this->hasMany(AudienciaCargo::class, 'id_audiencia', 'id')->withCount('usuarios')->with('nombre_cargo');
    }

    public function divisiones()
    {
        return $this->hasMany(AudienciaDivision::class, 'id_audiencia', 'id')->withCount('usuarios')->with('nombre_division');
    }

    public function unidades()
    {
        return $this->hasMany(AudienciaUnidad::class, 'id_audiencia', 'id')->withCount('usuarios')->with('nombre_unidad');
    }

    public function cargosUsuarios()
    {
        return $this->hasMany(AudienciaCargo::class, 'id_audiencia', 'id')->with('usuarios');
    }

    public function divisionesUsuarios()
    {
        return $this->hasMany(AudienciaDivision::class, 'id_audiencia', 'id')->with('usuarios');
    }

    public function unidadesUsuarios()
    {
        return $this->hasMany(AudienciaUnidad::class, 'id_audiencia', 'id')->with('usuarios');
    }

    public function usuarios()
    {
        return $this->hasMany(AudienciaUsuario::class, 'id_audiencia', 'id');
    }

    public function nombre_creador()
    {
        return $this->hasOne(User::class, 'rut', 'autor')->select('rut', 'nombre_completo');
    }

    public function publicaciones()
    {
        return $this->hasMany(Publicacion::class, 'id_audiencia', 'id');
    }

    public function num_incluidos()
    {
        return $this->hasMany(AudienciaUsuario::class, 'id_audiencia', 'id')
            ->where('tipo', '=', 2);
    }

    public function num_excluidos()
    {
        return $this->hasMany(AudienciaUsuario::class, 'id_audiencia', 'id')
            ->where('tipo', '=', 1);
    }

}
