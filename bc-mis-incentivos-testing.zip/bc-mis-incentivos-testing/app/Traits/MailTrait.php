<?php

namespace App\Traits;

use App\Jobs\SendEmailJob;
use Carbon\Carbon;

/*
|--------------------------------------------------------------------------
| Mail Trait
|--------------------------------------------------------------------------
|
| Sera usado para enviar correos que se envien en el sistema.
|
*/

trait MailTrait
{
    /**
     * Return a success JSON response.
     *
     * @param array|string $data
     * @param string $message
     * @param int|null $code
     * @return \Illuminate\Http\JsonResponse
     */

    protected function sendEmailQueue($data, $destinatario)
    {
        dispatch(new SendEmailJob($data, $destinatario))->onQueue('emails');
    }

}
