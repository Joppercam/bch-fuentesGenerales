<?php

namespace App\Traits;

trait EncodearTrait
{

    protected function cifrar($value)
    {
        $string = $value;
        $encrypt_method = "AES-256-CBC";
        $key = hash('sha256', env('SECRET_KEY_ENCODE'));
        $iv = substr(hash('sha256', env('SECRET_IV_ENCODE')), 0, 16);
        return base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
    }

    protected function descifrar($value)
    {
        $string = $value;
        $encrypt_method = "AES-256-CBC";
        $key = hash('sha256', env('SECRET_KEY_ENCODE)'));
        $iv = substr(hash('sha256', env('SECRET_IV_ENCODE')), 0, 16);
        return openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    protected function EncodeartkMI($valor)
    {
        $valor =  $this->my_simple_crypt_encodeartkMI($valor);
        return ($valor);
    }

    protected function DecodeartkMI($valor)
    {
        $valor = $this->my_simple_crypt_decodeartkMI($valor);
        $valor =  $this->VerificaArregloSQLInjectionDecodear($valor);
        return ($valor);
    }

    private function my_simple_crypt_encodeartkMI($string)
    {
        $encrypt_method = "AES-256-CBC";
        $key = hash('sha256', env('SECRET_KEY_ENCODE)'));
        $iv = substr(hash('sha256', env('SECRET_IV_ENCODE')), 0, 16);
        $output = base64_encode(openssl_encrypt($string, $encrypt_method, $key, 0, $iv));
        return $output;
    }

    private function my_simple_crypt_decodeartkMI($string)
    {
        $encrypt_method = "AES-256-CBC";
        $key = hash('sha256', env('SECRET_KEY_ENCODE)'));
        $iv = substr(hash('sha256', env('SECRET_IV_ENCODE')), 0, 16);
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        return $output;
    }
}
