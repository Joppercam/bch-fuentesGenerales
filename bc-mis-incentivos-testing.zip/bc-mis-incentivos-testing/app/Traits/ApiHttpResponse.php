<?php

namespace App\Traits;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

/*
|--------------------------------------------------------------------------
| Api Responser Trait
|--------------------------------------------------------------------------
|
| This trait will be used for any response we sent to clients.
|
*/

trait ApiHttpResponse
{
    use EncodearTrait;

    /**
     * Return a success JSON response.
     *
     * @param string $url
     * @param bool|false $hasParameters
     * @param array|null $parameters
     * @param string|null $typeCall
     * @param string|null $accion
     * @return \Illuminate\Http\JsonResponse
     */

    protected function callAPI(string $url, bool $hasParameters, array $parameters = null, string $typeCall = null, string $accion = null)
    {
        try {

            //URL de la call
            $url = config('app.urlApi') . $url;
            //tipo post, get, delete, put
            if ($typeCall) {
                $data = '';
                if (!is_null($accion)) {
                    $data = [
                        "modulo" => session('modulo'),
                        "userRut" => Auth::user()->rut,
                        "userName" => Auth::user()->name,
                        "accion" => $accion
                    ];
                    $data = $this->cifrar(json_encode($data));
                }
                if ($typeCall == 'get') {
                    Log::info('Http Request sin parámetros: ' . $url);
                    $response = Http::withHeaders([
                        'x-api-key' => config('app.keyApi'),
                        'logger' => $data
                    ])->acceptJson()->get($url);
                } else if ($typeCall == 'post') {
                    Log::info('Http Request con parámetros: ' . $url);
                    $response = Http::withHeaders([
                        'x-api-key' => config('app.keyApi'),
                        'logger' => $data,
                    ])->acceptJson()->post($url, $parameters);

                } else if ($typeCall == 'put') {
                    Log::info('logger: ' . $data);
                    Log::info('Http Request con parámetros: ' . $url);
                    $response = Http::withHeaders([
                        'x-api-key' => config('app.keyApi'),
                        'logger' => $data,
                    ])->acceptJson()->put($url, $parameters);

                } else if ($typeCall == 'delete') {
                    Log::info('Http Request con parámetros: ' . $url);
                    $response = Http::withHeaders([
                        'x-api-key' => config('app.keyApi'),
                        'logger' => $data,
                    ])->acceptJson()->delete($url, $parameters);
                }
            } else {
                Log::info('No se ha especificado el tipo de llamado (POST,GET,PUT,DELETE) en callAPI : ' . $url);
                return array("code" => 400, "response" => 'No se ha especificado el tipo de llamado (POST,GET,PUT,DELETE)');
            }

            if ($response->successful()) {
                return array("code" => 200, "response" => json_decode($response));
            }

            if ($response->failed()) {
                return array("code" => 400, "response" => json_decode($response));
            }
        } catch (Exception $exception) {
            Log::error('Error de ApiHttpResponse - callAPI: ' . $exception);
            return array(
                "code" => 400,
                "response" => json_decode($exception)
            );
        }


    }

}
