<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class EnvioNotificacionPublicacion extends Mailable
{
    use Queueable, SerializesModels;

    public $subject;

    public $nombre;
    public $correo;
    public $mensaje;
    public $tittle;


    public function __construct($nombre, $correo,$mensaje,$subject,$tittle)
    {
        $this->nombre = $nombre;
        $this->correo = $correo;
        $this->mensaje = $mensaje;
        $this->subject = $subject;
        $this->tittle = $tittle;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.notificarPublicacion');
    }
}
