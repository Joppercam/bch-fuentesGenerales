<?php

namespace App\Imports;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class AudienciaUsuarios implements ToCollection, WithHeadingRow
{
    use Importable;

    private $arrayRutAgregar;

    /**
     * @param Heading $array
     */
    public function headings(): array
    {
        return [
            'ruts' => 'A1',
        ];
    }

    /**
     * @param Collection $collection
     */
    public function collection(Collection $rows)
    {
        $rutAgregados = [];
        foreach ($rows as $key => $row) {
            if ($row->filter()->isNotEmpty()) {
                if (!in_array($row, $rutAgregados)) {
                    array_push($rutAgregados, $row);
                }

            }
        }
        $this->arrayRutAgregar = $rutAgregados;
    }

    /**
     * @param colaboradores $array
     */
    public function colaboradores(): array
    {
        return [
            'registrar' => $this->arrayRutAgregar,
        ];
    }
}
