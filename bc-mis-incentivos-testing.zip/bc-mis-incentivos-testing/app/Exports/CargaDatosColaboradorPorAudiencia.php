<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\WithCustomCsvSettings;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CargaDatosColaboradorPorAudiencia implements WithHeadings, WithCustomCsvSettings
{

    private $columns;

    public function __construct($columns = [])
    {
        $this->columns = $columns;
    }

    public function headings(): array
    {
        return $this->columns;
    }

    public function getCsvSettings(): array
    {
        return [
            'delimiter' => ';', // Cambia ';' por el delimitador que desees utilizar
            'charset' => 'utf8', // Cambia ';' por el delimitador que desees utilizar
        ];
    }
}
