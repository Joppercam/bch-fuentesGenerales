<?php

namespace App\Providers;

use Aacotroneo\Saml2\Events\Saml2LoginEvent;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;
use Aacotroneo\Saml2\Events\Saml2LogoutEvent;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        Event::listen(Saml2LoginEvent::class, static function (Saml2LoginEvent $event) {
            // Add your own code preventing reuse of a $messageId to stop replay attacks

            $user = $event->getSaml2User();
            $userData = [
                'id' => $user->getUserId(),
                'attributes' => $user->getAttributes(),
                'assertion' => $user->getRawSamlAssertion()
            ];
            $email = $userData['attributes']['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'][0];
            $laravelUser = User::where('tbl_usuario.email', $email)
                ->leftJoin('tbl_admin', 'user', '=', 'tbl_usuario.rut')
                ->select('tbl_usuario.id','tbl_usuario.rut','tbl_usuario.nombre_completo','acceso')
                ->first();
            if (!$laravelUser) {
                Auth::logout();
            }
            $idUser = $laravelUser->id;
            session(['perfilmi' => 0]);
            if (isset($laravelUser->acceso) && $laravelUser->acceso != "") {
                session(['perfilmi' => $laravelUser->acceso]);
            }
            if (Auth::guard('web')->loginUsingId($idUser, false)) {
                return redirect(RouteServiceProvider::HOME);
            }
        });
        Event::listen(Saml2LogoutEvent::class, static function () {
            Auth::logout();
        });
    }
}
