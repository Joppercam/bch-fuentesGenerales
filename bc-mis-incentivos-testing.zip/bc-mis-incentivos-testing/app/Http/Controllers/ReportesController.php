<?php

namespace App\Http\Controllers;

use App\Exports\CargaDatosColaboradorPorAudiencia;
use App\Models\Audiencia;
use App\Models\EstructuraAudiencias;
use App\Models\Notificacion;
use App\Models\Publicacion;
use App\Models\PublicacionView;
use App\Models\User;
use App\Traits\ApiResponser;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Validator;

class ReportesController extends Controller
{
    use ApiResponser;
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (session('perfilmi') !== 111) {
                return redirect()->route('home');
            }

            return $next($request);
        });
    }
    public function index()
    {
        if(session('perfilmi')!=111){
            return redirect()->route('home');
        }
        return view('reportes.principal');
    }

    public function PublicacionesByRut(Request $request)
    {
        $result[] = [
            'codigo publicación', 'publicacion', 'fecha_inicio', 'fecha_termino', 'codigo documento', 'documento', 'codigo audiencia', 'audiencia', 'rut', 'nombre_completo', 'cargo', 'Email', 'Division', 'Area', 'Zona', 'Periodicidad', 'Perfil', 'Categoria', 'Clasificacion', 'Negocio'
        ];
        $desde = $request->desde;
        $hasta = $request->hasta;
        $validator = Validator::make($request->toArray(), [
            'desde' => 'required',
            'hasta' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json('Debe indicar fecha de inicio y fin', 422);
        }
        $consulPublicaciones = Publicacion::whereBetween('fecha_inicio', [$desde, $hasta])
            ->with('periodicidad', 'perfil', 'categoria', 'clasificacion', 'negocio')
            ->join('mis_incentivos_documento as mid', 'mid.id', 'id_documento')
            ->join('mis_incentivos_audiencia as mia', 'mia.id', 'id_documento')
            ->select('mis_incentivos_publicaciones.id as idPublicacion', 'mis_incentivos_publicaciones.nombre as publicacion', 'fecha_inicio', 'fecha_termino', 'mid.id as idDocumento', 'nombre_documento_mascara as documento', 'mia.nombre as audiencia', 'id_audiencia', 'id_periodicidad', 'id_categoria', 'id_negocio', 'id_clasificacion', 'id_perfil')
            ->get();
        $publicacionController = new PublicacionesController();
        foreach ($consulPublicaciones as $row) {
            $consulAudiencia = $publicacionController->cargarAudienciaUsuarios($row->id_audiencia, false, false);
            foreach ($consulAudiencia as $rowAudiencia) {
                $datos = [
                    $row->idPublicacion,
                    $row->publicacion,
                    $row->fecha_inicio,
                    $row->fecha_termino,
                    $row->idDocumento,
                    $row->documento,
                    $row->id_audiencia,
                    $row->audiencia,
                    $rowAudiencia->rut,
                    $rowAudiencia->nombre_completo,
                    $rowAudiencia->silla_cargo,
                    $rowAudiencia->email,
                    $rowAudiencia->silla_division,
                    $rowAudiencia->silla_area,
                    $rowAudiencia->silla_zona,
                    $row->periodicidad['nombre_item'],
                    $row->perfil['nombre_item'],
                    $row->categoria['nombre_item'],
                    $row->clasificacion['nombre_item'],
                    $row->negocio['nombre_item']
                ];
                $result[] = $datos;
            }
        }
        return Excel::download(new CargaDatosColaboradorPorAudiencia($result), 'colaboradores_activos_por_publicacion.csv');
    }

    public function ListVisualizaciones(Request $request)
    {
        $desde = $request->desde;
        $hasta = $request->hasta;
        $validator = Validator::make($request->toArray(), [
            'desde' => 'required',
            'hasta' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json('Debe indicar fecha de inicio y fin', 422);
        }
        $result[] = [
            'Rut', 'Nombre', 'Cod Cargo', 'Cargo', '1er Fecha Visualizacion', 'Hora Visualizacion', 'Tipo', 'id_publicacion', 'Publicacion', 'PublicacionFechaInicio', 'PublicacionFechaTermino'
        ];
        $consulVisualizaciones = PublicacionView::whereBetween('mis_incentivos_publicaciones_views.fecha', [$desde, $hasta])
            ->join('mis_incentivos_publicaciones as p', 'id', 'publicacion_codigo')
            ->join('tbl_usuario', 'rut', 'view_rut')
            ->select('rut', 'nombre_completo', 'silla_id_cargo', 'silla_cargo', 'mis_incentivos_publicaciones_views.fecha', 'mis_incentivos_publicaciones_views.hora', 'fecha_inicio', 'fecha_termino', 'p.id', 'p.nombre')
            ->orderby('rut')
            ->orderby('p.id')
            ->groupBy('rut', 'p.id')
            ->get();
        foreach ($consulVisualizaciones as $row) {
            $datos = [
                $row->rut,
                $row->nombre_completo,
                $row->silla_id_cargo,
                $row->silla_cargo,
                $row->fecha,
                $row->hora,
                '',
                $row->id,
                $row->nombre,
                $row->fecha_inicio,
                $row->fecha_termino
            ];
            $result[] = $datos;
        }
        return Excel::download(new CargaDatosColaboradorPorAudiencia($result), 'visualizacion_publicaciones.csv', \Maatwebsite\Excel\Excel::CSV, [
            'Content-Type' => 'text/csv;charset=utf8',
        ]);
    }

    public function ListVisualizacionesPercent(Request $request)
    {
        $desde = $request->desde;
        $hasta = $request->hasta;
        $validator = Validator::make($request->toArray(), [
            'desde' => 'required',
            'hasta' => 'required',
        ]);

        if ($validator->fails()) return response()->json('Debe indicar fecha de inicio y fin', 422);
        $audienciaController = app(AudienciasController::class);
        $result[] = [
            'Codigo publicacion', 'Nombre', 'Fecha de inicio', 'Fecha_termino', 'Perfil', 'Negocio', 'Clasificacion', 'Periodicidad', 'Categoria', 'Total Audiencia', 'Total Vistas', '% Visualizacion'
        ];
        $consulVisualizaciones = Publicacion::whereBetween('mis_incentivos_publicaciones.fecha', [$desde, $hasta])
            ->join('mis_incentivos_publicaciones_options as mpon', 'mpon.id_item', '=', 'id_negocio')
            ->join('mis_incentivos_publicaciones_options as mpop', 'mpop.id_item', '=', 'id_perfil')
            ->join('mis_incentivos_publicaciones_options as mpoc', 'mpoc.id_item', '=', 'id_clasificacion')
            ->join('mis_incentivos_publicaciones_options as mpopd', 'mpopd.id_item', '=', 'id_periodicidad')
            ->join('mis_incentivos_publicaciones_options as mpopcg', 'mpopcg.id_item', '=', 'id_categoria')
            ->select('mpopcg.nombre_item as categoria', 'mpopd.nombre_item as periodicidad', 'mpon.nombre_item as negocio', 'mpop.nombre_item as perfil', 'mpoc.nombre_item as clasificacion', 'mis_incentivos_publicaciones.id', 'nombre', 'fecha_inicio', 'fecha_termino', 'id_audiencia', DB::raw('(select count(distinct view_rut) from mis_incentivos_publicaciones_views pbv where pbv.publicacion_codigo= mis_incentivos_publicaciones.id) as visualizaciones_count'))
            ->get();
        foreach ($consulVisualizaciones as $row) {
            $porcentaje = 0;
            $countUsuarios = $audienciaController->cargarAudienciaUsuarios($row->id_audiencia, true);
            if ($countUsuarios > 0 && $row->visualizaciones_count > 0) {
                $porcentaje = round(($row->visualizaciones_count * 100) / $countUsuarios, 2);
            }
            $datos = [
                $row->id,
                $row->nombre,
                $row->fecha_inicio,
                $row->fecha_termino,
                $row->perfil,
                $row->negocio,
                $row->clasificacion,
                $row->periodicidad,
                $row->categoria,
                $countUsuarios,
                $row->visualizaciones_count,
                $porcentaje,
            ];
            $result[] = $datos;
        }
        return Excel::download(new CargaDatosColaboradorPorAudiencia($result), 'porcentaje_visualizacion_publicaciones.csv', \Maatwebsite\Excel\Excel::CSV, [
            'Content-Type' => 'text/csv;charset=utf8',
        ]);
    }

    public function cargarAudienciaUsuarios($audiencia, $count = false, $uno = false)
    {

        $audiencia = Audiencia::where('id', $audiencia)->with('cargos')->with('divisiones')
            ->with('unidades')->with('usuarios')->first();
        $usuariosIncluir = [];
        $usuariosExcluir = [];
        $unidades = [];
        $cargos = [];
        $divisiones = [];
        foreach ($audiencia->unidades as $unidad) {
            $unidades[] = $unidad['id_unidad'];
        }
        foreach ($audiencia->divisiones as $division) {
            $divisiones[] = $division['id_division'];
        }

        foreach ($audiencia->cargos as $cargo) {
            $cargos[] = $cargo['id_cargo'];
        }
        foreach ($audiencia->usuarios as $usuario) {
            if ($usuario['tipo'] == 2) {
                $usuariosIncluir[] = $usuario['id_usuario'];
            } else {
                $usuariosExcluir[] = $usuario['id_usuario'];
            }
        }

        if ($count) {

            if ((count($divisiones) == 0 && count($unidades) == 0 && count($cargos) == 0)) {

                return User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                    ->whereNotIn('rut', $usuariosExcluir)
                    ->where(function ($query) use ($usuariosIncluir) {
                        foreach ($usuariosIncluir as $incluir) {
                            $query->orWhere('rut', $incluir);
                        }
                    })
                    ->count();
            } elseif (count($divisiones) > 0 || count($unidades) > 0 || count($cargos) > 0) {

                return User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                    ->whereNotNull('silla_id_unidad')
                    ->whereNotNull('silla_id_cargo')
                    ->whereNotNull('silla_id_division')
                    ->when($divisiones, function ($query) use ($divisiones) {
                        return $query->whereIn('silla_id_division', $divisiones);

                    })
                    ->when($unidades, function ($query) use ($unidades) {
                        return $query->whereIn('silla_id_unidad', $unidades);

                    })
                    ->when($cargos, function ($query) use ($cargos) {
                        return $query->whereIn('silla_id_cargo', $cargos);

                    })
                    ->whereNotIn('rut', $usuariosExcluir)
                    ->orWhere(function ($query) use ($usuariosIncluir) {
                        foreach ($usuariosIncluir as $incluir) {
                            $query->orWhere('rut', $incluir);
                        }
                    })
                    ->count();

            } else {
                return 0;
            }

        } else {
            if (count($divisiones) == 0 && count($unidades) == 0 && count($cargos) == 0) {

                if (!$uno) {
                    $usuarios = User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->where(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->get();
                } else {
                    $usuarios = User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->where(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->first();
                }


                return $usuarios;
            } elseif (count($divisiones) > 0 || count($unidades) > 0 || count($cargos) > 0) {
                if (!$uno) {

                    $usuarios = User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotNull('silla_id_unidad')
                        ->whereNotNull('silla_id_cargo')
                        ->whereNotNull('silla_id_division')
                        ->when($divisiones, function ($query) use ($divisiones) {
                            return $query->whereIn('silla_id_division', $divisiones);

                        })
                        ->when($unidades, function ($query) use ($unidades) {
                            return $query->whereIn('silla_id_unidad', $unidades);

                        })
                        ->when($cargos, function ($query) use ($cargos) {
                            return $query->whereIn('silla_id_cargo', $cargos);

                        })
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->orWhere(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->get();
                } else {
                    $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotNull('silla_id_unidad')
                        ->whereNotNull('silla_id_cargo')
                        ->whereNotNull('silla_id_division')
                        ->when($divisiones, function ($query) use ($divisiones) {
                            return $query->whereIn('silla_id_division', $divisiones);

                        })
                        ->when($unidades, function ($query) use ($unidades) {
                            return $query->whereIn('silla_id_unidad', $unidades);

                        })
                        ->when($cargos, function ($query) use ($cargos) {
                            return $query->whereIn('silla_id_cargo', $cargos);

                        })
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->orWhere(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->first();
                }

                return $usuarios;
            } else {
                return [];
            }
        }

    }

    public function AudenciasNuevosColaboradores(Request $request): BinaryFileResponse
    {

        $result[] = [
            'Rut', 'Nombre', 'Cargo', 'Division', 'Fecha_Ingreso', 'Audiencia'
        ];
        $currentYear = Carbon::now()->year;
        $consulUsers = User::whereYear('fecha_ingreso', $currentYear)
            ->select('rut', 'nombre_completo', 'silla_cargo', 'silla_division', 'fecha_ingreso', 'a.nombre', 'mia.cargos', 'mia.divisiones', 'mia.unidades')
            ->join('mis_incentivos_estructura_audiencias as mia', function ($join) {
                $join->on('mia.cargos', 'like', DB::raw("concat('%', silla_id_cargo, '%')"))
                    ->orOn('mia.divisiones', 'like', DB::raw("concat('%', silla_id_division, '%')"))
                    ->orOn('mia.unidades', 'like', DB::raw("concat('%', silla_id_unidad, '%')"));
            })
            ->join('mis_incentivos_audiencia as a', 'a.id', '=', 'mia.id')
            ->orderBy('rut')
            ->get();
        foreach ($consulUsers as $row) {
            $datos = [
                $row->rut,
                $row->nombre_completo,
                $row->silla_cargo,
                $row->silla_division,
                $row->fecha_ingreso,
                $row->nombre
            ];
            //Si solo una de las condiciones posee datos entonces el usuario pertenece a esa audiencia
            if (($row->cargos) === null && ($row->divisiones) !== null && ($row->unidades) === null) {
                $result[] = $datos;
            }
            if (($row->cargos) !== null && ($row->divisiones) === null && ($row->unidades) === null) {
                $result[] = $datos;
            }
            if (($row->cargos) === null && ($row->divisiones) === null && ($row->unidades) !== null) {
                $result[] = $datos;
            }
            if (($row->divisiones) !== null && ($row->unidades) !== null && ($row->cargos) === null) {
                if (strstr($row->divisiones, $row->silla_id_division) && strstr($row->silla_id_unidad, $row->unidades)) {
                    $result[] = $datos;
                }
            }
            if (($row->divisiones) === null && ($row->unidades) !== null && ($row->cargos) !== null) {
                if (strstr($row->unidades, $row->silla_id_unidad) && strstr($row->cargos, $row->silla_id_cargo)) {
                    $result[] = $datos;
                }
            }

        }
        return Excel::download(new CargaDatosColaboradorPorAudiencia($result), 'nuevos_colaboradores_audiencia.csv');
    }

    public function ListAudienciaDetail(Request $request): BinaryFileResponse
    {
        $audiencias = $request->audiencias;
        $validator = Validator::make($request->toArray(), [
            'audiencias' => 'required',
        ]);
        $result[] = [
            'id_audiencia', 'Nombre', 'Fecha', 'Fecha creación', 'Rut Autor', 'Creador', 'Fecha edicion', 'Divisiones', 'Unidades', 'Cargos'
        ];
        $consulUsers = Audiencia::whereIn('id', $audiencias)
            ->with('nombre_creador')
            ->with('divisiones')
            ->with('unidades')
            ->with('cargos')
            ->get();
        foreach ($consulUsers as $row) {
            $divisiones = "";
            $cargos = "";
            $unidades = "";
            foreach ($row->divisiones as $rowDivision) {
                $divisiones .= $rowDivision->nombre_division['silla_division'] . "| ";
            }
            foreach ($row->cargos as $rowDivision) {
                $cargos .= $rowDivision->nombre_cargo['silla_cargo'] . "| ";
            }
            foreach ($row->unidades as $rowUnidad) {
                $unidades .= $rowUnidad->nombre_unidad['silla_unidad'] . "| ";
            }
            $datos = [
                $row->id,
                $row->nombre,
                $row->fecha,
                $row->created_at,
                $row->autor,
                $row->nombre_creador->nombre_completo,
                $row->updated_at,
                $divisiones,
                $cargos,
                $unidades,
            ];
            $result[] = $datos;
        }
        return Excel::download(new CargaDatosColaboradorPorAudiencia($result), 'audiencia detallada.csv');
    }

    public function ListAudiencias(Request $request): BinaryFileResponse
    {
        $audiencias = $request->audiencias;
        $validator = Validator::make($request->toArray(), [
            'audiencias' => 'required',
        ]);
        $result[] = [
            'Código audiencia', 'rut','Nombre completo', 'Cargo', 'Division', 'Unidad'
        ];
        $usuariosExcluir = [];
        $consulUsers = EstructuraAudiencias::whereIn('mis_incentivos_estructura_audiencias.id', $audiencias)
            ->join('tbl_usuario', function ($join) {
                $join->where('divisiones', 'like', DB::raw("concat('%', silla_id_division, '%')"))
                    ->orWhere('unidades', 'like', DB::raw("concat('%', silla_id_unidad, '%')"))
                    ->orWhere('cargos', 'like', DB::raw("concat('%', silla_id_cargo, '%')"));
            })
            ->select('rut','nombre_completo','silla_cargo','silla_division','silla_unidad','silla_id_division','silla_id_unidad','silla_id_cargo','mis_incentivos_estructura_audiencias.id','cargos','unidades','divisiones')
            ->orderby('id')
            ->get();
        $consulAudienciaUsuarios = Audiencia::whereIn('id', $audiencias)->with('usuarios')->get();
        foreach ($consulAudienciaUsuarios as $rowAudiencia) {
            $idAudiencia = $rowAudiencia->id;
            foreach ($rowAudiencia->usuarios as $usuario) {
                if ($usuario['tipo'] == 2) {
                    $datosUser = User::where('rut', $usuario['id_usuario'])->first();
                    if ($datosUser) {
                        $datos = [
                            "id audiencia" => $idAudiencia,
                            "rut" => $datosUser->rut,
                            "nombre_completo" => $datosUser->nombre_completo,
                            "silla_cargo" => $datosUser->silla_cargo,
                            "silla_division" => $datosUser->silla_division,
                            "silla_unidad" => $datosUser->silla_unidad
                        ];
                        $result[] = $datos;
                    }
                } else {
                    $usuariosExcluir[] = $usuario['id_usuario'];
                }
            }
        }
        foreach ($consulUsers as $row) {
            if (!in_array($row->rut, $usuariosExcluir)) {
                $datos = [
                    "id audiencia" => $row->id,
                    "rut" => $row->rut,
                    "nombre_completo" => $row->nombre_completo,
                    "silla_cargo" => $row->silla_cargo,
                    "silla_division" => $row->silla_division,
                    "silla_unidad" => $row->silla_unidad
                ];
                //Si solo una de las condiciones posee datos entonces el usuario pertenece a esa audiencia
                if (($row->cargos) === null && ($row->divisiones) !== null && ($row->unidades) === null) {
                    $result[] = $datos;
                }
                if (($row->cargos) !== null && ($row->divisiones) === null && ($row->unidades) === null) {
                    $result[] = $datos;
                }
                if (($row->cargos) === null && ($row->divisiones) === null && ($row->unidades) !== null) {
                    $result[] = $datos;
                }
                if (($row->divisiones) !== null && ($row->unidades) !== null && ($row->cargos) === null) {
                    if (strstr($row->silla_id_division, $row->divisiones) && strstr($row->silla_id_unidad, $row->unidades)) {
                        $result[] = $datos;
                    }
                }
                if (($row->divisiones) === null && ($row->unidades) !== null && ($row->cargos) !== null) {
                    if (strstr($row->unidades, $row->silla_id_unidad) && strstr($row->cargos, $row->silla_id_cargo)) {
                        $result[] = $datos;
                    }
                }
            }
        }
        return Excel::download(new CargaDatosColaboradorPorAudiencia($result), 'Lista de audiencia.csv');
    }

    public function reportNotificaciones(Request $request): BinaryFileResponse
    {
        $desde = $request->desde;
        $hasta = $request->hasta;
        $validator = Validator::make($request->toArray(), [
            'desde' => 'required',
            'hasta' => 'required',
        ]);
        $result[] = [
            'id Notificación', 'Fecha', 'Hora', 'Template', 'Notificaciones enviadas', 'Ruts', 'id publicación', 'Publicación'
        ];
        $consulUsers = Notificacion::whereBetween('notif_fecha', [$desde, $hasta])
            ->with('publicacion')
            ->with('template')
            ->withCount('cantidadNotificacionesEnviadas')
            ->with('cantidadNotificacionesEnviadas')
            ->get();
        foreach ($consulUsers as $row) {
            $ruts = "";
            foreach ($row->cantidadNotificacionesEnviadas as $rowRuts) {
                $ruts .= $rowRuts->notifdet_rut . " | ";
            }
            $datos = [
                $row->notif_codigo,
                $row->notif_fecha,
                $row->notif_hour,
                $row->template->nottem_titulo,
                $row->cantidad_notificaciones_enviadas_count,
                $ruts,
                $row->publicacion->id,
                $row->publicacion->nombre,
            ];
            $result[] = $datos;
        }
        return Excel::download(new CargaDatosColaboradorPorAudiencia($result), 'notificaciones.csv');
    }

    public function ColaboradoresVariasAudiencias(Request $request): JsonResponse
    {
        $result = array();
        return $this->success('Listado de colaboradores en varias audiencias', 200, $result);
    }

    public function AudienciasVariasPublicaciones(Request $request): JsonResponse
    {
        $result = array();
        return $this->success('Listado de colaboradores en varias audiencias', 200, $result);
    }
}
