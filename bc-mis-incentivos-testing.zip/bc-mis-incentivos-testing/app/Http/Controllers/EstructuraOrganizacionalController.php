<?php

namespace App\Http\Controllers;

use App\Models\EstructuraOrganizacional;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
class EstructuraOrganizacionalController extends Controller
{
    use ApiResponser;
    public function listDivisiones()
    {
        $divisiones = EstructuraOrganizacional::whereNotNull('silla_id_division')
            ->groupBy('silla_id_division', 'silla_division')
            ->select('silla_id_division', 'silla_division')
            ->orderBy('silla_division','asc')
            ->get();
        return $this->success('consulta exitosa.', 200, $divisiones);
    }
    public function listUnidades(Request $request)
    {

        $query = EstructuraOrganizacional::query()->whereNotNull('silla_division');
        if(isset($request->data)){

            foreach($request->data as $key => $division){
                if($key == 0 ){
                    if(isset($division['id_division'])){
                        $query->Where('silla_id_division', $division['id_division']);
                    }else{
                        $query->Where('silla_id_division', $division);
                    }
                }else{

                    if(isset($division['id_division'])){
                        $query->orWhere('silla_id_division', $division['id_division']);
                    }else{
                        $query->orWhere('silla_id_division', $division);

                    }
                }
            }
        }
        $query->groupBy('silla_id_unidad', 'silla_unidad');

        $query->select('silla_id_unidad', 'silla_unidad');

        $query->orderBy('silla_unidad');
        $unidades = $query->get();
        return $this->success('consulta exitosa.', 200, $unidades);

    }

    public function listCargos(Request $request)
    {

        $query = EstructuraOrganizacional::query()->whereNotNull('silla_division')->whereNotNull('silla_unidad');

        if(isset($request->data['divisiones'])){
            foreach($request->data['divisiones'] as $key => $division){
                if($key == 0 ){
                    if(isset($division['id_division'])){
                        $query->Where('silla_id_division', $division['id_division']);
                    }else{
                        $query->Where('silla_id_division', $division);

                    }
                }else{
                    if(isset($division['id_division'])){
                        $query->orWhere('silla_id_division', $division['id_division']);
                    }else{
                        $query->orWhere('silla_id_division', $division);

                    }
                }
            }
        }
        if(isset($request->data['unidades'])){

            foreach($request->data['unidades'] as $key => $unidad){
                if($key == 0 ){
                    if(isset($unidad['id_unidad'])){
                        $query->Where('silla_id_unidad', $unidad['id_unidad']);
                    }else{
                        $query->Where('silla_id_unidad', $unidad);

                    }
                }else{
                    if(isset($unidad['id_unidad'])){
                        $query->orWhere('silla_id_unidad', $unidad['id_unidad']);
                    }else{
                        $query->orWhere('silla_id_unidad', $unidad);

                    }
                }
            }
        }
        $query->groupBy('silla_id_cargo', 'silla_cargo');
        $query->select('silla_id_cargo as id', 'silla_cargo as text');

        $query->orderBy('silla_cargo','asc');
        $cargos = $query->get();

        /*foreach ($cargos as $key => $cargo) {
            $cargo->text = $cargo->text.' ('.$cargo->unidad.')';
        }*/
        return $this->success('consulta exitosa.', 200, $cargos);
    }
}
