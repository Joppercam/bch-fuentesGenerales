<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidateStoreDocument;
use App\Http\Requests\ValidateUpdateDocument;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Traits\ApiResponser;
use App\Models\Documento;
use Illuminate\Support\Facades\Storage;

class DocumentosController extends Controller
{
    use ApiResponser;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (session('perfilmi') !== 111) {
                return redirect()->route('home');
            }

            return $next($request);
        });
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('documentos.principal');
    }

    public function saveDocumento(ValidateStoreDocument $request)
    {
        $nombre = $request->nombre_documento;
        $descripcion = $request->descripcion_documento;
        $idDuplicated = $request->idDuplicated;
        $documento = $request->file('multimediaFiles');
        $extensionArchivo = $documento->getClientOriginalExtension();
        $nombreDocumento = $documento->getClientOriginalName();
        //Se verifica no haya documentos con este mismo nombre ya registrado
        $documentoRepetido = Documento::where('nombre_documento_mascara', $nombreDocumento)->count();
        if ($documentoRepetido == 0) {
            $nombreOriginalDocumento2 = $nombre . Carbon::now()->format('Ymdhms');
            $rutaArchivo = Storage::putFileAs('public/documentos', $documento, $nombreOriginalDocumento2);
            $documentoBase64 = base64_encode(file_get_contents($documento));
        } else {
            return $this->error('Ya existe un documento PDF bajo el mismo nombre', 400);
        }

        $newDocumento = new Documento;
        $newDocumento->nombre = $nombre;
        $newDocumento->descripcion = $descripcion;
        $newDocumento->nombre_documento = $nombreOriginalDocumento2;
        $newDocumento->nombre_documento_mascara = $nombreDocumento;
        $newDocumento->autor = Auth::user()->rut;
        $newDocumento->fecha = date('Y-m-d');
        $newDocumento->url = $rutaArchivo;
        $newDocumento->extension = $extensionArchivo;
        if ($extensionArchivo == 'pdf' || $extensionArchivo == 'PDF') {
            $newDocumento->documento_base_64 = $documentoBase64;
        }

        $newDocumento->estado = 1;
        $newDocumento->save();
        return $this->success('Documento guardado correctamente', 200, $newDocumento->id);

    }

    public
    function listarDocumentos()
    {
        $documentos = Documento::with('nombre_autor')
            ->where('estado', 1)
            ->select('id', 'nombre', 'autor', 'fecha', 'url', 'extension', 'estado', 'nombre_documento', 'nombre_documento_mascara', 'descripcion', 'updated_at', 'created_at')
            ->withCount('publicaciones')
            ->orderBy('fecha', 'DESC')
            ->orderBy('id', 'DESC')->get();
        return $this->success('Documentos listados correctamente', 200, $documentos);
    }

    public
    function listarDocumentosSimple()
    {
        $rut = Auth::user()->rut;
        $documentosCreador = Documento::select('id', 'nombre','autor')
            ->with('nombre_autor')
            ->where('estado', 1)
            ->where('autor', $rut)
            ->orderBy('fecha', 'DESC')
            ->orderBy('id', 'DESC');
        $documentosNoCreador = Documento::select('id', 'nombre','autor')
            ->with('nombre_autor')
            ->where('estado', 1)
            ->where('autor', "!=", $rut)
            ->orderBy('fecha', 'DESC')
            ->orderBy('id', 'DESC');
        $documentos = $documentosCreador->union($documentosNoCreador)->get();
        return $this->success('Documentos listados correctamente', 200, $documentos);
    }


    public
    function updateDocumento(ValidateUpdateDocument $request)
    {

        $nombre = $request->nombre_documento;
        $descripcion = $request->descripcion_documento;

        $id = $request->id;
        $documento = $request->file('multimediaFiles');

        if ($documento) {
            $nombreOriginalDocumento = $documento->getClientOriginalName();
            $extensionArchivo = $documento->getClientOriginalExtension();
            $nombreOriginalDocumento2 = str_replace(' ', '_', $nombreOriginalDocumento);
            $rutaArchivo = Storage::putFileAs('public/documentos', $documento, $nombreOriginalDocumento2);


            $editDocumento = Documento::where('id', $id)->first();
            $editDocumento->nombre = $nombre;
            $editDocumento->descripcion = $descripcion;
            $editDocumento->nombre_documento = $nombreOriginalDocumento2;
            $editDocumento->nombre_documento_mascara = $nombreOriginalDocumento;
            $editDocumento->url = $rutaArchivo;
            $editDocumento->extension = $extensionArchivo;
            if ($extensionArchivo == 'pdf' || $extensionArchivo == 'PDF') {
                $editDocumento->documento_base_64 = base64_encode(file_get_contents($documento));
            }
            $editDocumento->estado = 1;
            $editDocumento->save();

        } else {
            $editDocumento = Documento::where('id', $id)->first();
            $editDocumento->nombre = $nombre;
            $editDocumento->descripcion = $descripcion;

            $editDocumento->save();
        }

        return $this->success('Documento editado correctamente', 200, $editDocumento->id);

    }

    public
    function cargarDocumento($id)
    {
        $documento = Documento::select('id', 'documento_base_64')->where('id', $id)->first();
        return $this->success('Documento cargado correctamente', 200, $documento);

    }

    public
    function duplicarDocumento(Request $request)
    {

        $validator = Validator::make($request->toArray(), [
            'id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        }

        $id = $request->id;

        $documento = Documento::where('id', $id)->first();

        $newDocumento = new Documento;
        $newDocumento->nombre = $documento->nombre . '- copia';
        $newDocumento->autor = Auth::user()->rut;
        $newDocumento->fecha = date('Y-m-d');

        if ($documento->nombre_documento) {
            $newDocumento->nombre_documento = $documento->nombre_documento;
            $newDocumento->url = $documento->url;
            $newDocumento->extension = $documento->extension;
            $newDocumento->documento_base_64 = $documento->documento_base_64;
        }

        $newDocumento->estado = 1;
        $newDocumento->save();

        return $this->success('Documento duplicado correctamente', 200, $newDocumento->id);

    }

    public
    function deleteDocumento(Request $request)
    {

        $validator = Validator::make($request->toArray(), [
            'id' => 'required|exists:documento,id',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        }

        $id = $request->id;

        Documento::where('id', $id)->update(['estado' => 0]);
        Documento::where('id', $id)->delete();

        return $this->success('Documento eliminado correctamente', 200, null);


    }

    public
    function deleteDocumentoMultiple(Request $request)
    {

        Documento::whereIn('id', $request->datos)->update(['estado' => 0]);
        Documento::whereIn('id', $request->datos)->delete();
        return $this->success('Documentos eliminado correctamente', 200, null);


    }
}
