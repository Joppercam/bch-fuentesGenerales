<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidateStorePublicacion;
use App\Http\Requests\ValidateUpdatePublicacion;
use App\Mail\EnvioNotificacionPublicacion;
use App\Models\Audiencia;
use App\Models\Documento;
use App\Models\Notificacion;
use App\Models\NotificacionDetail;
use App\Models\NotificacionTemplate;
use App\Models\User;
use App\Traits\EncodearTrait;
use App\Traits\MailTrait;
use Illuminate\Http\Request;
use App\Models\PublicacionOption;
use App\Models\Publicacion;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Validator;
use Auth;
use Carbon\Carbon;

class PublicacionesController extends Controller
{
    use ApiResponser, MailTrait, EncodearTrait;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('publicaciones.principal');
    }

    public function usuarioByRut($rut)
    {
        $result = [
            'rut' => "",
            'nombre_completo' => "",
            'silla_cargo' => "",
            'rutToken' => ""
        ];
        $usuarioCount = User::where("rut", $rut)
            ->count();
        if ($usuarioCount > 0) {
            $usuario = User::where("rut", $rut)
                ->first();
            $perfil = "misincentivos";
            $fecha = date("ymdhi");
            $token = $fecha . "-$usuario->rut-" . $perfil;
            $token_enc = $this->EncodeartkMI($token);
            $usuario->rutToken = $token_enc;
            $result['rut'] = $usuario->rut;
            $result['nombre_completo'] = $usuario->nombre_completo;
            $result['silla_cargo'] = $usuario->silla_cargo;
            $result['rutToken'] = $usuario->rutToken;
        }
        return response(['usuario' => $result, 'message' => 'Retrieved successfully'], 200);
    }

    public function listarPublicaciones()
    {
        $perfil = "";
        if (session('perfilmi')) {
            $perfil = config('constants.perfiles')[session('perfilmi')];
        }

        if ($perfil != 'ControlGestion') {
            $publicaciones = Publicacion::with('periodicidad', 'perfil', 'categoria', 'clasificacion', 'negocio', 'nombre_autor', 'nombre_audiencia', 'nombre_documento')
                ->where('estado', 1)
                ->orderBy('fecha', 'DESC')
                ->orderBy('id', 'DESC')
                ->get();
        } else {
            $publicaciones = Publicacion::with('periodicidad', 'perfil', 'categoria', 'clasificacion', 'negocio', 'nombre_autor', 'nombre_audiencia', 'nombre_documento')
                ->where('id_perfil', '113')
                ->where('estado', 1)
                ->orderBy('fecha', 'DESC')
                ->orderBy('id', 'DESC')
                ->get();
        }

        return ['data' => $publicaciones];
    }

    public function listarOpciones()
    {

        $opciones = PublicacionOption::get();
        return $this->success('Opciones listadas correctamente', 200, $opciones);
    }

    public function savePublicacion(validateStorePublicacion $request)
    {
        $nombre_publicacion = $request->nombre_publicacion;
        $fecha_inicio = $request->fecha_inicio;
        $fecha_termino = $request->fecha_termino;
        $select_audiencia = $request->select_audiencia;
        $select_documento = $request->select_documento;
        $select_categoria = $request->select_categoria;
        $select_clasificacion = $request->select_clasificacion;
        $select_negocio = $request->select_negocio;
        $select_perfil = $request->select_perfil;

        $newPublicacion = new Publicacion;
        $newPublicacion->nombre = $nombre_publicacion;
        $newPublicacion->autor = Auth::user()->rut;
        $newPublicacion->fecha = date('Y-m-d');

        $newPublicacion->fecha_inicio = $fecha_inicio;
        $newPublicacion->fecha_termino = $fecha_termino;
        $newPublicacion->id_audiencia = $select_audiencia;
        $newPublicacion->id_documento = $select_documento;

        $newPublicacion->id_categoria = $this->obtenerCategoria($fecha_inicio);
        $newPublicacion->id_clasificacion = $select_clasificacion;
        $newPublicacion->id_negocio = $select_negocio;
        $newPublicacion->id_perfil = $select_perfil;
        $newPublicacion->id_periodicidad = $this->obtenerPeriodicidad($fecha_inicio, $fecha_termino);


        $newPublicacion->estado = 1;
        $newPublicacion->updated_at = Carbon::today();
        $newPublicacion->save();
        session()->forget('iddocumento');
        session()->forget('idaudiencia');

        return $this->success('Publicacion registrada correctamente', 200, $newPublicacion->id);
    }

    public function editarPublicacion(ValidateUpdatePublicacion $request)
    {
        $id = $request->id;
        $nombre_publicacion = $request->nombre_publicacion_editar;
        $fecha_inicio = $request->fecha_inicio_editar;
        $fecha_termino = $request->fecha_termino_editar;
        $select_audiencia = $request->select_audiencia_editar;
        $select_documento = $request->select_documento_editar;
        $select_categoria = $request->select_categoria_editar;
        $select_clasificacion = $request->select_clasificacion_editar;
        $select_negocio = $request->select_negocio_editar;
        $select_perfil = $request->select_perfil_editar;

        $editPublicacion = Publicacion::where('id', $id)->first();;
        $editPublicacion->nombre = $nombre_publicacion;
        $editPublicacion->autor = Auth::user()->rut;
        $editPublicacion->fecha = date('Y-m-d');

        $editPublicacion->fecha_inicio = $fecha_inicio;
        $editPublicacion->fecha_termino = $fecha_termino;
        $editPublicacion->id_audiencia = $select_audiencia;
        $editPublicacion->id_documento = $select_documento;

        $editPublicacion->id_categoria = $this->obtenerCategoria($fecha_inicio);
        $editPublicacion->id_clasificacion = $select_clasificacion;
        $editPublicacion->id_negocio = $select_negocio;
        $editPublicacion->id_perfil = $select_perfil;
        $editPublicacion->id_periodicidad = $this->obtenerPeriodicidad($fecha_inicio, $fecha_termino);

        $editPublicacion->updated_at = Carbon::today();
        $editPublicacion->save();


        return $this->success('Publicacion editada correctamente', 200, $editPublicacion->id);
    }


    public function duplicarPublicacion(Request $request)
    {

        $validator = Validator::make($request->toArray(), [
            'id' => 'required|exists:mis_incentivos_publicaciones,id',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        }

        $publicacion = Publicacion::where('id', $request->id)->first();

        $nombre_publicacion = $publicacion->nombre;

        $fecha_inicio = $publicacion->fecha_inicio;
        $fecha_termino = $publicacion->fecha_termino;
        $select_audiencia = $publicacion->id_audiencia;
        $select_documento = $publicacion->id_documento;

        $select_categoria = $publicacion->id_categoria;
        $select_clasificacion = $publicacion->id_clasificacion;
        $select_negocio = $publicacion->id_negocio;
        $select_perfil = $publicacion->id_perfil;
        $select_periodicidad = $publicacion->id_periodicidad;


        $newPublicacion = new Publicacion;
        $newPublicacion->nombre = $nombre_publicacion . ' - copia';
        $newPublicacion->autor = Auth::user()->rut;
        $newPublicacion->fecha = date('Y-m-d');

        $newPublicacion->fecha_inicio = $fecha_inicio;
        $newPublicacion->fecha_termino = $fecha_termino;
        $newPublicacion->id_audiencia = $select_audiencia;
        $newPublicacion->id_documento = $select_documento;

        $newPublicacion->id_categoria = $select_categoria;
        $newPublicacion->id_clasificacion = $select_clasificacion;
        $newPublicacion->id_negocio = $select_negocio;
        $newPublicacion->id_perfil = $select_perfil;
        $newPublicacion->id_periodicidad = $select_periodicidad;


        $newPublicacion->estado = 1;
        $newPublicacion->updated_at = Carbon::today();
        $newPublicacion->save();


        return $this->success('Publicación registrada correctamente', 200, $newPublicacion->id);
    }

    public function eliminarPublicacion(Request $request)
    {

        $validator = Validator::make($request->toArray(), [
            'id' => 'required|exists:mis_incentivos_publicaciones,id',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        }

        $id = $request->id;

        Publicacion::where('id', $id)->update(['estado' => 0]);
        Publicacion::where('id', $id)->delete();

        return $this->success('Publicacion eliminado correctamente', 200, null);
    }

    public function eliminarPublicacionMultiple(Request $request)
    {
        Publicacion::whereIn('id', $request->datos)->update(['estado' => 0]);
        Publicacion::whereIn('id', $request->datos)->delete();
        return $this->success('Publicación eliminado correctamente', 200, null);
    }

    function obtenerPeriodicidad($fecha_inicio, $fecha_fin)
    {

        // Reemplaza estas fechas de ejemplo con las fechas que deseas comparar
        $date1 = $fecha_inicio;
        $date2 = $fecha_fin;

        $fechaCarbon1 = Carbon::parse($date1);
        $fechaCarbon2 = Carbon::parse($date2);

        $mesesDiferencia = $fechaCarbon1->diffInMonths($fechaCarbon2);
        /* 63	periodicidad	per_1	Mensual
         64	periodicidad	per_2	Bimestral
         65	periodicidad	per_3	Trimestral
         66	periodicidad	per_4	Semestral
         67	periodicidad	per_5	Anual
         68	periodicidad	per_6	Otro*/

        if ($mesesDiferencia == 0) {
            return 'per_1';
        } else if ($mesesDiferencia == 1) {
            return 'per_2';
        } else if ($mesesDiferencia == 2) {
            return 'per_3';
        } else if ($mesesDiferencia == 5) {
            return 'per_4';
        } else if ($mesesDiferencia == 11) {
            return 'per_5';
        } else {
            return 'per_6';
        }


        return $mesesDiferencia;
    }

    function obtenerCategoria($fecha_inicio)
    {

        $year = Carbon::parse($fecha_inicio)->format('Y');

        $mes = Carbon::parse($fecha_inicio)->format('m');

        $estacion = null;
        if ($mes >= 1 && $mes <= 3) {
            $estacion = 'Q1';
        } else if ($mes >= 4 && $mes <= 6) {
            $estacion = 'Q2';

        } else if ($mes > 6 && $mes <= 9) {
            $estacion = 'Q3';

        } else if ($mes > 9 && $mes <= 12) {
            $estacion = 'Q4';
        }
        return $year . '_' . $estacion;
    }

    public function AsignarFechaHoraPublicacion(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'fecha_publicacion' => 'required|date',
                'template' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json(['status' => 'Revise los datos proporcionados', 'code' => 400]);
            }
            if ($request->hora_publicacion == "") {
                $request->hora_publicacion = 9;
            }
            $data = $request->datos;
            foreach ($data as $rowNotif) {
                $notificacionModel = new Notificacion();
                $notificacionModel->notif_fecha = $request->fecha_publicacion;
                $notificacionModel->notif_hour = $request->hora_publicacion;
                $notificacionModel->notif_publication = $rowNotif;
                $notificacionModel->notif_template = $request->template;
                $notificacionModel->save();
            }
            return response()->json(['status' => 'registrado correctamente', 'code' => 201]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente' . json_encode($th), 400);
        }
    }

    public function publicacionesPorNotificar()
    {
        try {
            $publicacionArray = [];
            $templateArray = [];
            $usuariosNotificados = [];
            //Se obtienen las publicaciones que aun no han sido notificadas y cumplen con el criterio de notificación
            $hoy = Carbon::now()->format('Y-m-d');
            $hora = Carbon::now()->format('H');
            $notificacionesConsul = Notificacion::where('notif_fecha', $hoy)
                ->where('notif_hour', $hora)
                ->get();
            foreach ($notificacionesConsul as $rowNotif) {
                $datosTemplate = NotificacionTemplate::where('nottem_codigo', $rowNotif['notif_template'])->first();
                $templateArray[$rowNotif['notif_template']]['titulo'] = $datosTemplate['nottem_titulo'];
                $templateArray[$rowNotif['notif_template']]['asunto'] = $datosTemplate['nottem_asunto'];
                $templateArray[$rowNotif['notif_template']]['contenido'] = $datosTemplate['nottem_contenido'];

                $publicaciones = $rowNotif['notif_publication'];
                $consulPublicaciones = Publicacion::where('id', $publicaciones)->select('id', 'id_audiencia')->get();
                foreach ($consulPublicaciones as $rowPub) {
                    $publicacionArray[$rowPub['id']]['audiencia'] = $rowPub['id_audiencia'];
                    $publicacionArray[$rowPub['id']]['notificacion']['id'] = $rowNotif['notif_codigo'];
                    $publicacionArray[$rowPub['id']]['notificacion']['fecha'] = $rowNotif['notif_fecha'];
                    $publicacionArray[$rowPub['id']]['notificacion']['hora'] = $rowNotif['notif_hour'];
                    $publicacionArray[$rowPub['id']]['notificacion']['template'] = $rowNotif['notif_template'];
                }
            }
            //Se buscan las audiencias que corresponden a las publicaciones seleccionadas
            foreach ($publicacionArray as $key => $rowPub) {
                $idTemplate = $rowPub['notificacion']['template'];
                $idNotificacion = $rowPub['notificacion']['id'];
                $templateData = $templateArray[$idTemplate];
                $consulUsuarios = $this->cargarAudienciaUsuarios($rowPub['audiencia']);
                foreach ($consulUsuarios as $rowUSer) {
                    $destinatario = $rowUSer['email'];
                    $data = [
                        'nombre' => $rowUSer['nombre_completo'],
                        'email' => $rowUSer['email'],
                        'mensaje' => $templateData['contenido'],
                        'subject' => $templateData['asunto'],
                        'tittle' => $templateData['titulo']
                    ];
                    try {
                        $notificacion = new EnvioNotificacionPublicacion($data['nombre'], $data['email'], $data['mensaje'], $data['subject'], $data['tittle']);
                        Mail::to($destinatario)->send($notificacion);
                        $usuariosNotificados[] = [
                            'notifdet_rut' => $rowUSer['rut'],
                            'notifdet_fecha_envio' => Carbon::now(),
                            'notifdet_estatus' => 1,
                            'notifdet_notifcodigo' => $idNotificacion
                        ];
                    } catch (\Exception $e) {
                        $usuariosNotificados[] = [
                            'notifdet_rut' => $rowUSer['rut'],
                            'notifdet_error' => $e,
                            'notifdet_notifcodigo' => $idNotificacion
                        ];
                    }
                }
            }
            NotificacionDetail::insert($usuariosNotificados);
        } catch (\Exception $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente' . json_encode($th), 400);
        }
    }

    public function cargarAudienciaUsuarios($audiencia, $count = false, $uno = false)
    {

        $audiencia = Audiencia::where('id', $audiencia)->with('cargos')->with('divisiones')->with('unidades')->with('usuarios')->first();

        $divisiones = [];
        $unidades = [];
        $cargos = [];
        $usuarios_incluir = [];
        $usuarios_excluir = [];
        if (isset($audiencia->divisiones)) {
            foreach ($audiencia->divisiones as $division) {
                array_push($divisiones, $division['id_division']);
            }
        }
        if (isset($audiencia->unidades)) {
            foreach ($audiencia->unidades as $unidad) {
                array_push($unidades, $unidad['id_unidad']);
            }
        }
        if (isset($audiencia->cargos)) {
            foreach ($audiencia->cargos as $cargo) {
                array_push($cargos, $cargo['id_cargo']);
            }
        }
        if (isset($audiencia->usuarios)) {
            foreach ($audiencia->usuarios as $usuario) {
                if ($usuario['tipo'] == 2) {
                    array_push($usuarios_incluir, $usuario['id_usuario']);
                } else {
                    array_push($usuarios_excluir, $usuario['id_usuario']);
                }
            }
        }

        if ($count) {

            if ((count($divisiones) == 0 && count($unidades) == 0 && count($cargos) == 0 && count($usuarios_incluir) != 0) || count($usuarios_excluir) != 0) {

                return $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                    ->whereNotIn('rut', $usuarios_excluir)
                    ->where(function ($query) use ($usuarios_incluir) {
                        foreach ($usuarios_incluir as $incluir) {
                            $query->orWhere('rut', $incluir);
                        }
                    })
                    ->count();
            } else if (count($divisiones) > 0 || count($unidades) > 0 || count($cargos) > 0) {

                return $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                    ->whereNotNull('silla_id_unidad')
                    ->whereNotNull('silla_id_cargo')
                    ->whereNotNull('silla_id_division')
                    ->when($divisiones, function ($query) use ($divisiones) {
                        return $query->whereIn('silla_id_division', $divisiones);

                    })
                    ->when($unidades, function ($query) use ($unidades) {
                        return $query->whereIn('silla_id_unidad', $unidades);

                    })
                    ->when($cargos, function ($query) use ($cargos) {
                        return $query->whereIn('silla_id_cargo', $cargos);

                    })
                    ->whereNotIn('rut', $usuarios_excluir)
                    ->orWhere(function ($query) use ($usuarios_incluir) {
                        foreach ($usuarios_incluir as $incluir) {
                            $query->orWhere('rut', $incluir);
                        }
                    })
                    ->count();

            } else {
                return 0;
            }

        } else {
            if ((count($divisiones) == 0 && count($unidades) == 0 && count($cargos) == 0 && count($usuarios_incluir) != 0) || count($usuarios_excluir) != 0) {

                if (!$uno) {
                    $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotIn('rut', $usuarios_excluir)
                        ->where(function ($query) use ($usuarios_incluir) {
                            foreach ($usuarios_incluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->get();
                } else {
                    $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotIn('rut', $usuarios_excluir)
                        ->where(function ($query) use ($usuarios_incluir) {
                            foreach ($usuarios_incluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->first();
                }


                return $usuarios;
            } else if (count($divisiones) > 0 || count($unidades) > 0 || count($cargos) > 0) {
                if (!$uno) {

                    $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotNull('silla_id_unidad')
                        ->whereNotNull('silla_id_cargo')
                        ->whereNotNull('silla_id_division')
                        ->when($divisiones, function ($query) use ($divisiones) {
                            return $query->whereIn('silla_id_division', $divisiones);

                        })
                        ->when($unidades, function ($query) use ($unidades) {
                            return $query->whereIn('silla_id_unidad', $unidades);

                        })
                        ->when($cargos, function ($query) use ($cargos) {
                            return $query->whereIn('silla_id_cargo', $cargos);

                        })
                        ->whereNotIn('rut', $usuarios_excluir)
                        ->orWhere(function ($query) use ($usuarios_incluir) {
                            foreach ($usuarios_incluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->get();
                } else {
                    $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotNull('silla_id_unidad')
                        ->whereNotNull('silla_id_cargo')
                        ->whereNotNull('silla_id_division')
                        ->when($divisiones, function ($query) use ($divisiones) {
                            return $query->whereIn('silla_id_division', $divisiones);

                        })
                        ->when($unidades, function ($query) use ($unidades) {
                            return $query->whereIn('silla_id_unidad', $unidades);

                        })
                        ->when($cargos, function ($query) use ($cargos) {
                            return $query->whereIn('silla_id_cargo', $cargos);

                        })
                        ->whereNotIn('rut', $usuarios_excluir)
                        ->orWhere(function ($query) use ($usuarios_incluir) {
                            foreach ($usuarios_incluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->first();
                }

                return $usuarios;
            } else {
                return [];
            }
        }

    }

    public function resumenGeneral()
    {
        try {
            $audienciaController = app(AudienciasController::class);
            $totalAudiencias = Audiencia::count();
            $totalDocumentos = Documento::count();
            $totalPublicaciones = Publicacion::count();
            $consulVisualizaciones = Publicacion::select('id_audiencia', DB::raw('(select count(distinct view_rut) from mis_incentivos_publicaciones_views pbv where pbv.publicacion_codigo= mis_incentivos_publicaciones.id) as visualizaciones'),)->get();
            $porcentaje = 0;
            $cantidadAudiencia = 0;
            $cantidadVisualizaciones = 0;
            foreach ($consulVisualizaciones as $row) {
                $countUsuarios = $audienciaController->cargarAudienciaUsuarios($row->id_audiencia, true);
                $cantidadAudiencia = $cantidadAudiencia + $countUsuarios;
                $cantidadVisualizaciones = $cantidadVisualizaciones + $row->visualizaciones;
            }
            if ($cantidadAudiencia > 0 && $cantidadVisualizaciones > 0) {
                $porcentaje = round(($cantidadVisualizaciones * 100) / $cantidadAudiencia, 1);
            }
            $result = [
                "totalAudiencias" => $totalAudiencias,
                "totalDocumentos" => $totalDocumentos,
                "totalPublicaciones" => $totalPublicaciones,
                "totalColAudiencia" => $cantidadAudiencia,
                "totalVisualizaciones" => $cantidadVisualizaciones,
                "porcenVisualizacion" => $porcentaje
            ];
            return $result;
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente' . json_encode($th), 400);
        }
    }

    public function resumenDetail()
    {
        $porcentajes = [];
        $audienciaController = app(AudienciasController::class);
        $negocios = [];
        $meses = [];
        $years = [];
        $desde = Carbon::now()->subMonths(12)->toDateString();
        $result = Publicacion::select(
            'mpo.nombre_item', 'mis_incentivos_publicaciones.id_audiencia',
            DB::raw('extract(month from mis_incentivos_publicaciones.fecha_inicio) as mes'),
            DB::raw('extract(year from mis_incentivos_publicaciones.fecha_inicio) as yearPub'),
            DB::raw('(select count(mp1.id) from mis_incentivos_publicaciones mp1 where mp1.id_negocio=mis_incentivos_publicaciones.id_negocio and extract(month from mis_incentivos_publicaciones.fecha_inicio) = extract(month from mp1.fecha_inicio)) as totpublicaciones'),
            DB::raw('(select count(distinct view_rut) from mis_incentivos_publicaciones_views pbv where pbv.publicacion_codigo= mis_incentivos_publicaciones.id) as visualizaciones'),
        )
            ->join('mis_incentivos_publicaciones_options as mpo', 'mpo.id_item', '=', 'mis_incentivos_publicaciones.id_negocio')
            ->where('mis_incentivos_publicaciones.fecha_inicio', '>', $desde)
            ->where('mis_incentivos_publicaciones.fecha_inicio', '<=', Carbon::now())
            ->groupBy('mis_incentivos_publicaciones.id', 'mis_incentivos_publicaciones.id_negocio', 'mpo.nombre_item', DB::raw('extract(month from mis_incentivos_publicaciones.fecha_inicio)'), 'totpublicaciones')
            ->get();
        foreach ($result as $row) {
            if (!isset($meses[$row["yearPub"]])) {
                $meses[$row["yearPub"]] = [];
            }
        }
        foreach ($result as $row) {
            if (!isset($meses[$row["yearPub"]][$row["mes"]])) {
                $meses[$row["yearPub"]][$row["mes"]] = [];
            }
        }
        foreach ($result as $row) {
            if (!isset($negocios["negocio"][$row['nombre_item']])) {
                $negocios["negocio"][$row['nombre_item']] = $meses;
            }
        }
        $resultUsuarios = [];
        foreach ($result as $row) {
            $porcentajePublicacion = 0;
            $audiencia = $audienciaController->cargarAudienciaUsuarios($row->id_audiencia, true);
            if (isset($negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['usuariosTotal'])) {
                $negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['usuariosTotal'] += $audiencia;
            } else {
                $negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['usuariosTotal'] = $audiencia;
            }
            if (isset($negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['visualizacionesTotal'])) {
                $negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['visualizacionesTotal'] += $row['visualizaciones'];
            } else {
                $negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['visualizacionesTotal'] = $row['visualizaciones'];
            }
            $visualizacionesTotal = $negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['visualizacionesTotal'];
            $usuariosTotal = $negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']]['usuariosTotal'];
            $porcentajeFinal = ($visualizacionesTotal * 100 / $usuariosTotal);

            $negocios["negocio"][$row['nombre_item']][$row['yearPub']][$row['mes']] = ["publicaciones" => $row['totpublicaciones'], "usuariosTotal" => $usuariosTotal, "visualizacionesTotal" => $visualizacionesTotal, "porcentaje" => round($porcentajeFinal, 0)];
        }
        return $negocios;
    }
}
