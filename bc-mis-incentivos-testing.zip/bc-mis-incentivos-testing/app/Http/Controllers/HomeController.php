<?php

namespace App\Http\Controllers;

use App\Traits\ApiHttpResponse;
use App\Traits\ApiResponser;
use App\Traits\EncodearTrait;
use MongoDB\Driver\Session;

class HomeController extends Controller
{
    use ApiHttpResponse, ApiResponser;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $perfil = "";
        if (session('perfilmi')) {
            $perfil = config('constants.perfiles')[session('perfilmi')];
        }
        if ($perfil == 'ControlGestion') {
            return redirect('/publicaciones');
        }
        $publicacionController = new PublicacionesController();
        $datosGenerales = $publicacionController->resumenGeneral();
        $totAudiencia = $datosGenerales['totalAudiencias'];
        $totDocumento = $datosGenerales['totalDocumentos'];
        $totPublicacion = $datosGenerales['totalPublicaciones'];
        $porcenVisual = $datosGenerales['porcenVisualizacion'];
        return view('home', compact('totAudiencia', 'totDocumento', 'totPublicacion', 'porcenVisual'));
    }

    public function generarSesiones($key, $valor)
    {
        session()->forget($key);
        session([$key => $valor]);
        return $this->success('Sesión generada correctamente', 200);
    }
}
