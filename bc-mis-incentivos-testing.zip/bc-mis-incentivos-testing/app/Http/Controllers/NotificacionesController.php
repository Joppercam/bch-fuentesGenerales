<?php

namespace App\Http\Controllers;

use App\Models\Notificacion;
use App\Models\NotificacionDetail;
use App\Models\Publicacion;
use App\Models\User;
use App\Traits\ApiResponser;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificacionesController extends Controller
{
    use ApiResponser;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (session('perfilmi') !== 111) {
                return redirect()->route('home');
            }

            return $next($request);
        });
    }
    public function index()
    {
        return view('notificaciones.principal');
    }

    public function listarNotificaciones(): array
    {
        $publicaciones = Publicacion::with('periodicidad', 'perfil', 'nombre_autor', 'nombre_audiencia', 'nombre_documento', 'negocio')
            ->withCount('notificaciones')
            ->where('estado', 1)
            ->orderBy('fecha', 'DESC')
            ->orderBy('id', 'DESC')->get();

        return ['data' => $publicaciones];
    }

    public function cargarNotificacionesByPublicacion(int $idPublication): JsonResponse
    {
        try {
            $listNotifyAssign = Notificacion::where('notif_publication', $idPublication)
                ->with('template')
                ->withCount('cantidadNotificacionesEnviadas')
                ->withCount('cantidadNotificacionesRecibidas')
                ->get();
            return $this->success('Notificaciones Asignadas', 200, $listNotifyAssign);
        } catch (\Exception $e) {
            return $this->error('Ha ocurrido un error al listar las notificaciones', 409);
        }
    }

    public function cargarNotificacionTemplate($idNotificacion): JsonResponse
    {
        try {
            $listNotifyAssign = Notificacion::where('notif_codigo', $idNotificacion)
                ->with('template')
                ->first();
            $datosUser = User::where('rut', Auth::user()->rut)->first();
            $datos = [
                'tittle' => $listNotifyAssign->template->nottem_titulo,
                'nombre' => $datosUser->nombre_completo,
                'mensaje' => $listNotifyAssign->template->nottem_contenido,
            ];
            $template = view('emails/notificarPublicacion', $datos)->render();
            return $this->success('Template asociado', 200, $template);
        } catch (\Exception $e) {
            return $this->error('Ha ocurrido un error en cargarNotificacionTemplate', 409);
        }
    }

    public function cargarUsuariosNotificadosById(int $idNotificacion): JsonResponse
    {
        try {
            $listNotifyAssign = NotificacionDetail::where('notifdet_notifcodigo', $idNotificacion)
                ->with('usuarios')
                ->get();
            return $this->success('Usuarios Asignados', 200, $listNotifyAssign);
        } catch (\Exception $e) {
            return $this->error('Ha ocurrido un error al listar los usuarios', 409);
        }
    }

    public function eliminarNotificacion(int $idNotificacion)
    {
        try {
            $allowDelete = false;
            //Se verifica la notificacion no haya sido enviada aun
            $hoy = Carbon::now();
            $horaActual = Carbon::now();
            $horaFormateada = $horaActual->format('H:i:s');
            $diaFormateada = $hoy->format('Y-m-d');
            $datosNotificacion = Notificacion::where('notif_codigo', $idNotificacion)->first();
            if ($datosNotificacion->notif_fecha >= $diaFormateada) {
                if ($datosNotificacion->notif_fecha > $diaFormateada) {
                    $allowDelete = true;
                } elseif ($datosNotificacion->notif_hour > $horaFormateada) {
                    $allowDelete = true;
                }
                if ($allowDelete) {
                    Notificacion::where('notif_codigo', $idNotificacion)->delete();
                    return $this->success('Notificación eliminada', 200);
                }
            }
            return $this->error('Notificación no puede ser eliminada', 401);
        } catch (\Exception $e) {
            return $this->error('Ha ocurrido un error al eliminar la notificacion', 409);
        }
    }

    public function eliminarNotificacionesPublicacion(Request $request)
    {
        $notificaciones = Publicacion::whereIn('id', $request->datos)
            ->join('mis_incentivos_notificaciones', 'notif_publication', 'id')
            ->get();
        foreach ($notificaciones as $rowNotif) {
            $allowDelete = false;
            //Se verifica la notificacion no haya sido enviada aun
            $hoy = Carbon::now();
            $horaActual = Carbon::now();
            $horaFormateada = $horaActual->format('H:i:s');
            $diaFormateada = $hoy->format('Y-m-d');
            $datosNotificacion = Notificacion::where('notif_codigo', $rowNotif->notif_codigo)->first();
            if ($datosNotificacion->notif_fecha >= $diaFormateada) {
                if ($datosNotificacion->notif_fecha > $diaFormateada) {
                    $allowDelete = true;
                } elseif ($datosNotificacion->notif_hour > $horaFormateada) {
                    $allowDelete = true;
                }
                if ($allowDelete) {
                    Notificacion::where('notif_codigo', $rowNotif->notif_codigo)->delete();
                }
            }
        }
        return $this->success('Notificaciones eliminadas correctamente', 200, null);
    }
}
