<?php

namespace App\Http\Controllers;

use App\Models\Notificacion;
use App\Models\NotificacionTemplate;
use App\Models\User;
use App\Traits\ApiResponser;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificacionTemplateController extends Controller
{
    use ApiResponser;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (session('perfilmi') !== 111) {
                return redirect()->route('home');
            }

            return $next($request);
        });
    }
    public function index()
    {
        return view('template.principal');
    }

    public function listTemplate()
    {
        try {
            $listTemplate = NotificacionTemplate::where('nottem_status', 1)
                ->orderBy('nottem_titulo')
                ->get();
            return $this->success('Audiencias cargada correctamente', 200, $listTemplate);
        } catch (\Exception $e) {
            return $this->error('Ha ocurrido un error al listar los template', 409);
        }
    }

    public function getTemplates()
    {
        try {
            $listTemplate = NotificacionTemplate::where('nottem_status', 1)
                ->orderBy('nottem_titulo')
                ->get();
            return datatables()->of($listTemplate)->toJson();
        } catch (\Exception $e) {
            return $this->error('Ha ocurrido un error al listar los template', 409);
        }
    }
    public function cargarTemplate($idTemplate)
    {
        try {
            $listNotifyAssign = NotificacionTemplate::where('nottem_codigo', $idTemplate)
                ->first();
            $datosUser = User::where('rut', Auth::user()->rut)->first();
            $datos = [
                'tittle' => $listNotifyAssign->nottem_titulo,
                'nombre' => $datosUser->nombre_completo,
                'mensaje' => $listNotifyAssign->nottem_contenido,
            ];
            $template = view('emails/notificarPublicacion', $datos)->render();
            return $this->success('Template asociado', 200, $template);
        } catch (\Exception $e) {
            return $this->error('Ha ocurrido un error en cargarTemplate', 409);
        }
    }
    public function saveTemplate(Request $request)
    {
        try {
            $titulo = $request->nottem_titulo;
            $asunto = $request->nottem_asunto;
            $contenido = $request->nottem_contenido;

            $newTemplate = new NotificacionTemplate();
            $newTemplate->nottem_titulo = $titulo;
            $newTemplate->nottem_asunto = $asunto;
            $newTemplate->nottem_contenido = $contenido;
            $newTemplate->updated_at = Carbon::today();
            $newTemplate->save();

            return response()->json(['status' => 'registrado correctamente', 'code' => 201, 'data' => $newTemplate->nottem_codigo]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente' . json_encode($th), 400);
        }
    }

    public function updateTemplate(Request $request)
    {
        try {
            $idNotificacion = $request->nottem_codigo;
            $titulo = $request->nottem_titulo;
            $asunto = $request->nottem_asunto;
            $contenido = $request->nottem_contenido;

            $updateTemplate = NotificacionTemplate::where('nottem_codigo', $idNotificacion)->first();
            $updateTemplate->nottem_titulo = $titulo;
            $updateTemplate->nottem_asunto = $asunto;
            $updateTemplate->nottem_contenido = $contenido;
            $updateTemplate->updated_at = Carbon::today();
            $updateTemplate->save();

            return response()->json(['status' => 'Modificado correctamente', 'code' => 201, 'data' => $updateTemplate->nottem_codigo]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente' . json_encode($th), 400);
        }
    }

    public function deleteTemplate($id)
    {
        try {
            $today = Carbon::now();
            //Se verifica el template no se encuentra asignado a una notificacion pendiente
            $consulNotificacion = Notificacion::where('notif_estado',1)
                ->join('mis_incentivos_notificacion_template', 'nottem_codigo','notif_template')
                ->where('notif_template',$id)
                ->where('notif_fecha','>=',$today)
                ->count();
            if($consulNotificacion==0) {
                //Se elimina el template
                NotificacionTemplate::where('nottem_codigo', $id)->update(['nottem_status' => 0]);
                NotificacionTemplate::where('nottem_codigo', $id)->delete();
            }else{
                return $this->success('Template se encuentra en uso no puede ser eliminado', 403, null);
            }
            return $this->success('Documento eliminado correctamente', 200, null);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente' . json_encode($th), 400);
        }
    }
}
