<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidateSaveAudiencia;
use App\Http\Requests\ValidateUpdateAudiencia;
use App\Models\EstructuraAudiencias;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Models\Audiencia;
use App\Models\User;
use App\Models\AudienciaCargo;
use App\Models\AudienciaUnidad;
use App\Models\AudienciaDivision;
use App\Models\AudienciaUsuario;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Importer;
use App\Imports\AudienciaUsuarios;
use App\Traits\ApiResponser;
use Validator;

class AudienciasController extends Controller
{

    use ApiResponser;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $importer;

    public function __construct(Importer $importer)
    {
        $this->importer = $importer;
        $this->middleware(function ($request, $next) {
            if (session('perfilmi') !== 111) {
                return redirect()->route('home');
            }

            return $next($request);
        });
    }

    public function index()
    {
        $autores = $this->listCreadoresAudiencia();
        return view('audiencias.principal', compact('autores'));
    }

    public function listCreadoresAudiencia()
    {
        return Audiencia::where('estado', 1)
            ->join('tbl_usuario', 'autor', 'rut')
            ->select('autor', 'nombre_completo')
            ->groupBy('autor', 'nombre_completo')
            ->orderBy('nombre_completo')
            ->get();
    }

    public function listarAudiencias(Request $request)
    {
        $draw = $request->draw;
        $offset = $request->start;
        $limit = $request->length;
        $creador = $request->creador;
        $search = $request->search['value'];
        $audiencias = Audiencia::query()->where('estado', 1)
            ->with('cargos')
            ->with('divisiones')
            ->with('unidades')
            ->with('nombre_creador')
            ->withCount('publicaciones')
            ->withCount('num_incluidos')
            ->withCount('num_excluidos');
        if ($search != "" && !is_null($search)) {
            $audiencias->Where('mis_incentivos_audiencia.nombre', 'like', '%' . $search . '%');
        }
        if ($creador != "" && !is_null($creador)) {
            $audiencias->Where('autor', $creador);
        }
        if ($request->desde != "" && !is_null($request->desde)) {
            $audiencias->Where('fecha', '>=', $request->desde);
        }
        if ($request->hasta != "" && !is_null($request->hasta)) {
            $audiencias->Where('fecha', '<=', $request->hasta . " 23:59:59");
        }
        $audiencias->limit($limit);
        $audiencias->offset($offset);
        $datosTable = $audiencias->orderBy('fecha', 'DESC')->orderBy('id', 'DESC')->get();

        $audienciasCount = Audiencia::where('estado', 1)
            ->with('cargos')
            ->with('divisiones')
            ->with('unidades')
            ->with('nombre_creador')
            ->withCount('publicaciones')
            ->withCount('num_incluidos')
            ->withCount('num_excluidos')
            ->orderBy('fecha', 'DESC')->orderBy('id', 'DESC')->count();

        $audienciasFiltered = Audiencia::query()->where('estado', 1)
            ->with('cargos')
            ->with('divisiones')
            ->with('unidades')
            ->with('nombre_creador')
            ->withCount('publicaciones')
            ->withCount('num_incluidos')
            ->withCount('num_excluidos');
        if ($search != "" && !is_null($search)) {
            $audienciasFiltered->Where('mis_incentivos_audiencia.nombre', 'like', '%' . $search . '%');
        }
        if ($creador != "" && !is_null($creador)) {
            $audiencias->Where('autor', $creador);
        }
        if ($request->desde != "" && !is_null($request->desde)) {
            $audienciasFiltered->Where('fecha', '>=', $request->desde);
        }
        if ($request->hasta != "" && !is_null($request->hasta)) {
            $audienciasFiltered->Where('fecha', '<=', $request->hasta . " 23:59:59");
        }
        $datosTableFiltered = $audienciasFiltered->orderBy('fecha', 'DESC')->orderBy('id', 'DESC')->count();

        foreach ($datosTable as $audiencia) {
            $countUsuarios = $this->cargarAudienciaUsuarios($audiencia->id, true);
            $audiencia->usuarios = $countUsuarios;
        }
        $dataToTable = array(
            "draw" => $draw,
            "recordsTotal" => $audienciasCount,
            "recordsFiltered" => $datosTableFiltered,
            "data" => $datosTable
        );
        echo json_encode($dataToTable);

    }

    public function listarAudienciasSinUsuarios()
    {
        $rut = Auth::user()->rut;
        $audienciasCreador = Audiencia::select('id', 'nombre', 'autor')
            ->with('nombre_creador')
            ->where('estado', 1)
            ->where('autor', $rut)
            ->orderBy('fecha', 'DESC')
            ->orderBy('id', 'DESC');
        $audienciasNoCreador = Audiencia::select('id', 'nombre', 'autor')
            ->with('nombre_creador')
            ->where('estado', 1)
            ->where('autor', "!=", $rut)
            ->orderBy('fecha', 'DESC')
            ->orderBy('id', 'DESC');
        $audiencias = $audienciasCreador->union($audienciasNoCreador)->get();
        return $this->success('Audiencias listados correctamente', 200, $audiencias);

    }

    public function cargarAudienciaUsuarios($audiencia, $count = false, $uno = false)
    {
        $audiencia = Audiencia::where('id', $audiencia)->with('cargos')->with('divisiones')
            ->with('unidades')->with('usuarios')->first();
        $usuariosIncluir = [];
        $usuariosExcluir = [];
        $unidades = [];
        $cargos = [];
        $divisiones = [];
        foreach ($audiencia->unidades as $unidad) {
            $unidades[] = $unidad['id_unidad'];
        }
        foreach ($audiencia->divisiones as $division) {
            $divisiones[] = $division['id_division'];
        }

        foreach ($audiencia->cargos as $cargo) {
            $cargos[] = $cargo['id_cargo'];
        }
        foreach ($audiencia->usuarios as $usuario) {
            if ($usuario['tipo'] == 2) {
                $usuariosIncluir[] = $usuario['id_usuario'];
            } else {
                $usuariosExcluir[] = $usuario['id_usuario'];
            }
        }

        if ($count) {

            if ((count($divisiones) == 0 && count($unidades) == 0 && count($cargos) == 0)) {

                return User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                    ->whereNotIn('rut', $usuariosExcluir)
                    ->where(function ($query) use ($usuariosIncluir) {
                        foreach ($usuariosIncluir as $incluir) {
                            $query->orWhere('rut', $incluir);
                        }
                    })
                    ->count();
            } elseif (count($divisiones) > 0 || count($unidades) > 0 || count($cargos) > 0) {

                return User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                    ->whereNotNull('silla_id_unidad')
                    ->whereNotNull('silla_id_cargo')
                    ->whereNotNull('silla_id_division')
                    ->when($divisiones, function ($query) use ($divisiones) {
                        return $query->whereIn('silla_id_division', $divisiones);

                    })
                    ->when($unidades, function ($query) use ($unidades) {
                        return $query->whereIn('silla_id_unidad', $unidades);

                    })
                    ->when($cargos, function ($query) use ($cargos) {
                        return $query->whereIn('silla_id_cargo', $cargos);

                    })
                    ->whereNotIn('rut', $usuariosExcluir)
                    ->orWhere(function ($query) use ($usuariosIncluir) {
                        foreach ($usuariosIncluir as $incluir) {
                            $query->orWhere('rut', $incluir);
                        }
                    })
                    ->count();

            } else {
                return 0;
            }

        } else {
            if (count($divisiones) == 0 && count($unidades) == 0 && count($cargos) == 0) {

                if (!$uno) {
                    $usuarios = User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->where(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->get();
                } else {
                    $usuarios = User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->where(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->first();
                }


                return $usuarios;
            } elseif (count($divisiones) > 0 || count($unidades) > 0 || count($cargos) > 0) {
                if (!$uno) {

                    $usuarios = User::select('rut', 'nombre_completo', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotNull('silla_id_unidad')
                        ->whereNotNull('silla_id_cargo')
                        ->whereNotNull('silla_id_division')
                        ->when($divisiones, function ($query) use ($divisiones) {
                            return $query->whereIn('silla_id_division', $divisiones);

                        })
                        ->when($unidades, function ($query) use ($unidades) {
                            return $query->whereIn('silla_id_unidad', $unidades);

                        })
                        ->when($cargos, function ($query) use ($cargos) {
                            return $query->whereIn('silla_id_cargo', $cargos);

                        })
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->orWhere(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->get();
                } else {
                    $usuarios = User::select('rut', 'nombre_completo', 'email', 'silla_id_division', 'silla_id_unidad', 'silla_id_cargo', 'silla_division', 'silla_unidad', 'silla_cargo')
                        ->whereNotNull('silla_id_unidad')
                        ->whereNotNull('silla_id_cargo')
                        ->whereNotNull('silla_id_division')
                        ->when($divisiones, function ($query) use ($divisiones) {
                            return $query->whereIn('silla_id_division', $divisiones);

                        })
                        ->when($unidades, function ($query) use ($unidades) {
                            return $query->whereIn('silla_id_unidad', $unidades);

                        })
                        ->when($cargos, function ($query) use ($cargos) {
                            return $query->whereIn('silla_id_cargo', $cargos);

                        })
                        ->whereNotIn('rut', $usuariosExcluir)
                        ->orWhere(function ($query) use ($usuariosIncluir) {
                            foreach ($usuariosIncluir as $incluir) {
                                $query->orWhere('rut', $incluir);
                            }
                        })
                        ->first();
                }

                return $usuarios;
            } else {
                return [];
            }
        }

    }

    public function getAudienciaUsuarios($audiencia)
    {
        $result = [];
        $usuariosIncluir = [];
        $usuariosExcluir = [];
        $consulUsers = EstructuraAudiencias::where('mis_incentivos_estructura_audiencias.id', $audiencia)
            ->join('tbl_usuario', function ($join) {
                $join->where('divisiones', 'like', DB::raw("concat('%', silla_id_division, '%')"))
                    ->orWhere('unidades', 'like', DB::raw("concat('%', silla_id_unidad, '%')"))
                    ->orWhere('cargos', 'like', DB::raw("concat('%', silla_id_cargo, '%')"));
            })
            ->get();
        $consulAudienciaUsuarios = Audiencia::where('id', $audiencia)->with('usuarios')->first();
        foreach ($consulAudienciaUsuarios->usuarios as $usuario) {
            if ($usuario['tipo'] == 2) {
                $datosUser = User::where('rut', $usuario['id_usuario'])->first();
                if ($datosUser) {
                    $datos = [
                        "rut" => $datosUser->rut,
                        "nombre_completo" => $datosUser->nombre_completo,
                        "silla_cargo" => $datosUser->silla_cargo,
                        "silla_division" => $datosUser->silla_division,
                        "silla_unidad" => $datosUser->silla_unidad
                    ];
                    $result[] = $datos;
                }
                $usuariosIncluir[] = $usuario['id_usuario'];
            } else {
                $usuariosExcluir[] = $usuario['id_usuario'];
            }
        }
        foreach ($consulUsers as $row) {
            if (!in_array($row->rut, $usuariosExcluir) && !in_array($row->rut, $usuariosIncluir)) {
                $datos = [
                    "rut" => $row->rut,
                    "nombre_completo" => $row->nombre_completo,
                    "silla_cargo" => $row->silla_cargo,
                    "silla_division" => $row->silla_division,
                    "silla_unidad" => $row->silla_unidad
                ];
                //Si solo una de las condiciones posee datos entonces el usuario pertenece a esa audiencia
                if (($row->cargos) === null && ($row->divisiones) !== null && ($row->unidades) === null) {
                    $result[] = $datos;
                }
                if (($row->cargos) !== null && ($row->divisiones) === null && ($row->unidades) === null) {
                    $result[] = $datos;
                }
                if (($row->cargos) === null && ($row->divisiones) === null && ($row->unidades) !== null) {
                    $result[] = $datos;
                }
                if (($row->divisiones) !== null && ($row->unidades) !== null && ($row->cargos) === null) {
                    if (strstr($row->divisiones, $row->silla_id_division) && strstr($row->silla_id_unidad, $row->unidades)) {
                        $result[] = $datos;
                    }
                }
                if (($row->divisiones) === null && ($row->unidades) !== null && ($row->cargos) !== null) {
                    if (strstr($row->unidades, $row->silla_id_unidad) && strstr($row->cargos, $row->silla_id_cargo)) {
                        $result[] = $datos;
                    }
                }
            }
        }
        return datatables()->of($result)->toJson();
    }

    public function getAudienciaUsuariosExInc($audiencia)
    {
        $result = [];
        $consulAudienciaUsuarios = AudienciaUsuario::where('id_audiencia', $audiencia)
            ->join('tbl_usuario', 'rut', 'id_usuario')
            ->get();
        foreach ($consulAudienciaUsuarios as $usuario) {
            $datos = [
                "tipo" => $usuario->tipo,
                "rut" => $usuario->rut,
                "nombre_completo" => $usuario->nombre_completo,
                "silla_cargo" => $usuario->silla_cargo,
                "silla_division" => $usuario->silla_division,
                "silla_unidad" => $usuario->silla_unidad
            ];
            $result[] = $datos;

        }
        return datatables()->of($result)->toJson();
    }

    public function verAudiencia($id)
    {

        $audiencia = Audiencia::where('estado', 1)->where('id', $id)->with('cargos')->with('divisiones')->with('unidades')->with('nombre_creador')->first();

        $usuarios = $this->cargarAudienciaUsuarios($audiencia->id, false, true);
        $audiencia->usuarios = $usuarios;

        return $this->success('Audiencias cargada correctamente', 200, $audiencia);
    }

    public function deleteUsuarioExcInc(Request $request)
    {
        $rut = $request->rut;
        $idAudiencia = $request->idAudiencia;
        $deleteUsuario = AudienciaUsuario::where('id_usuario', $rut)->where('id_audiencia', $idAudiencia)->delete();
        return $this->success('Audiencias cargada correctamente', 200, $deleteUsuario);
    }

    public function saveAudiencia(ValidateSaveAudiencia $request)
    {
        try {
            $nombreAudiencia = $request->nombre_audiencia;
            $selectDivision = $request->selectDivision;
            $selectUnidad = $request->selectUnidad;
            $selectCargo = $request->selectCargo;

            $newAudiencia = new Audiencia;
            $newAudiencia->nombre = $nombreAudiencia;
            $newAudiencia->autor = Auth::user()->rut;
            $newAudiencia->fecha = date('Y-m-d');
            $newAudiencia->estado = 1;
            $newAudiencia->updated_at = Carbon::today();
            $newAudiencia->save();

            $audienciaCargoData = [];
            $audienciaUnidadData = [];
            $audienciaDivisionData = [];
            if ($selectCargo) {
                foreach ($selectCargo as $cargo) {
                    $audienciaCargoData[] = [
                        'id_audiencia' => $newAudiencia->id,
                        'id_cargo' => $cargo,
                        'estado' => 1,
                        'created_at' => Carbon::now()
                    ];
                }
            }

            if ($selectUnidad) {
                foreach ($selectUnidad as $unidad) {
                    $audienciaUnidadData[] = [
                        'id_audiencia' => $newAudiencia->id,
                        'id_unidad' => $unidad,
                        'estado' => 1,
                        'created_at' => Carbon::now()
                    ];
                }
            }

            if ($selectDivision) {
                foreach ($selectDivision as $division) {
                    $audienciaDivisionData[] = [
                        'id_audiencia' => $newAudiencia->id,
                        'id_division' => $division,
                        'estado' => 1,
                        'created_at' => Carbon::now()
                    ];
                }
            }

            AudienciaCargo::insert($audienciaCargoData);
            AudienciaUnidad::insert($audienciaUnidadData);
            AudienciaDivision::insert($audienciaDivisionData);


            $file = $request->file('multimediaFiles'); // Asume que el archivo se subió con el nombre de campo 'uploadedFile'
            if ($file) {

                $import = new AudienciaUsuarios();
                $import->import($file);


                $colaboradores = $import->colaboradores();
                foreach ($colaboradores['registrar'] as $usuario) {

                    $newUsuarioAudiencia = new AudienciaUsuario;
                    $newUsuarioAudiencia->id_usuario = $usuario['rut'];
                    if ($usuario['tipo'] == 'excluir') {
                        $newUsuarioAudiencia->tipo = 1;
                    } elseif ($usuario['tipo'] == 'incluir') {
                        $newUsuarioAudiencia->tipo = 2;

                    }
                    $newUsuarioAudiencia->id_audiencia = $newAudiencia->id;
                    $newUsuarioAudiencia->estado = 1;

                    $newUsuarioAudiencia->save();

                }

            }
            if (isset($request->idDuplicated)) {
                $usuariosAudiencia = AudienciaUsuario::where('id_audiencia', $request->idDuplicated)->get();
                foreach ($usuariosAudiencia as $audiencia) {
                    $nuevoUsuario = $audiencia->replicate();
                    $nuevoUsuario->id_audiencia = $newAudiencia->id;
                    $nuevoUsuario->save();
                }
            }
            return response()->json(['status' => 'registrado correctamente', 'code' => 201, 'data' => $newAudiencia->id]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente' . json_encode($th), 400);
        }
    }

    public function deleteAudiencia(Request $request)
    {

        $validator = Validator::make($request->toArray(), [
            'id' => 'required',

        ]);

        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        }

        try {
            Audiencia::where('id', $request->id)->update(['estado' => 0]);
            AudienciaCargo::where('id_audiencia', $request->id)->update(['estado' => 0]);
            Audiencia::where('id', $request->id)->delete();
            AudienciaCargo::where('id_audiencia', $request->id)->delete();
            return response()->json(['status' => 'eliminado correctamente', 'code' => 201]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente', 400);
        }
    }

    public function deleteAudienciaMultiple(Request $request)
    {
        try {
            Audiencia::whereIn('id', $request->datos)->update(['estado' => 0]);
            AudienciaCargo::whereIn('id_audiencia', $request->datos)->update(['estado' => 0]);
            Audiencia::whereIn('id', $request->datos)->delete();
            AudienciaCargo::whereIn('id_audiencia', $request->datos)->delete();
            return response()->json(['status' => 'eliminado correctamente', 'code' => 201]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente', 400);
        }
    }

    public function updateAudiencia(ValidateUpdateAudiencia $request): JsonResponse
    {
        try {
            $nombreAudiencia = $request->nombre_audiencia;
            $selectDivision = $request->selectDivision;
            $selectUnidad = $request->selectUnidad;
            $selectCargo = $request->selectCargo;

            $id = $request->id;


            $audiencia = Audiencia::where('id', $id)->first();
            $audiencia->nombre = $nombreAudiencia;
            $audiencia->save();

            AudienciaCargo::where('id_audiencia', $request->id)->delete();
            AudienciaUnidad::where('id_audiencia', $request->id)->delete();
            AudienciaDivision::where('id_audiencia', $request->id)->delete();

            $audienciaCargoData = [];
            $audienciaUnidadData = [];
            $audienciaDivisionData = [];
            if ($selectCargo) {
                foreach ($selectCargo as $cargo) {
                    $audienciaCargoData[] = [
                        'id_audiencia' => $request->id,
                        'id_cargo' => $cargo,
                        'estado' => 1,
                        'created_at' => Carbon::now()
                    ];
                }
            }

            if ($selectUnidad) {
                foreach ($selectUnidad as $unidad) {
                    $audienciaUnidadData[] = [
                        'id_audiencia' => $request->id,
                        'id_unidad' => $unidad,
                        'estado' => 1,
                        'created_at' => Carbon::now()
                    ];
                }
            }

            if ($selectDivision) {
                foreach ($selectDivision as $division) {
                    $audienciaDivisionData[] = [
                        'id_audiencia' => $request->id,
                        'id_division' => $division,
                        'estado' => 1,
                        'created_at' => Carbon::now()
                    ];
                }
            }

            AudienciaCargo::insert($audienciaCargoData);
            AudienciaUnidad::insert($audienciaUnidadData);
            AudienciaDivision::insert($audienciaDivisionData);


            $file = $request->file('multimediaFiles'); // Asume que el archivo se subió con el nombre de campo 'uploadedFile'

            if ($file) {

                AudienciaUsuario::where('id_audiencia', $id)->delete();

                $import = new AudienciaUsuarios();
                $import->import($file);
                $colaboradores = $import->colaboradores();
                foreach ($colaboradores['registrar'] as $usuario) {
                    $newUsuarioAudiencia = new AudienciaUsuario;
                    $newUsuarioAudiencia->id_usuario = $usuario['rut'];
                    if ($usuario['tipo'] == 'excluir') {
                        $newUsuarioAudiencia->tipo = 1;
                    } elseif ($usuario['tipo'] == 'incluir') {
                        $newUsuarioAudiencia->tipo = 2;

                    }
                    $newUsuarioAudiencia->id_audiencia = $id;
                    $newUsuarioAudiencia->estado = 1;
                    $newUsuarioAudiencia->save();
                }
            }


            return response()->json(['status' => 'actualizado correctamente', 'code' => 201, 'data' => $audiencia->id]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente', 400);
        }
    }

    public function duplicarAudiencia(Request $request)
    {

        $validator = Validator::make($request->toArray(), [
            'id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        }

        try {
            $id = $request->id;

            $audiencia = Audiencia::where('id', $id)->first();

            $selectCargo = AudienciaCargo::where('id_audiencia', $audiencia->id)->get();
            $selectUnidad = AudienciaUnidad::where('id_audiencia', $audiencia->id)->get();
            $selectDivision = AudienciaDivision::where('id_audiencia', $audiencia->id)->get();


            $newAudiencia = new Audiencia;
            $newAudiencia->nombre = $audiencia->nombre . ' - copia';
            $newAudiencia->autor = Auth::user()->rut;
            $newAudiencia->fecha = date('Y-m-d');
            $newAudiencia->estado = $audiencia->estado;
            $newAudiencia->updated_at = Carbon::today();
            $newAudiencia->save();


            foreach ($selectCargo as $cargo) {
                $newAudienciaCargo = new AudienciaCargo;
                $newAudienciaCargo->id_audiencia = $newAudiencia->id;
                $newAudienciaCargo->id_cargo = $cargo->id_cargo;
                $newAudienciaCargo->estado = 1;
                $newAudienciaCargo->save();
            }


            foreach ($selectUnidad as $unidad) {
                $newAudienciaCargo = new AudienciaUnidad;
                $newAudienciaCargo->id_audiencia = $newAudiencia->id;
                $newAudienciaCargo->id_unidad = $unidad->id_unidad;
                $newAudienciaCargo->estado = 1;
                $newAudienciaCargo->save();
            }


            foreach ($selectDivision as $division) {
                $newAudienciaCargo = new AudienciaDivision;
                $newAudienciaCargo->id_audiencia = $newAudiencia->id;
                $newAudienciaCargo->id_division = $division->id_division;
                $newAudienciaCargo->estado = 1;
                $newAudienciaCargo->save();
            }
            $usuarios = AudienciaUsuario::where('id_audiencia', $audiencia->id)->get();

            foreach ($usuarios as $usuario) {
                $newUsuarioAudiencia = new AudienciaUsuario;
                $newUsuarioAudiencia->id_usuario = $usuario->id_usuario;
                $newUsuarioAudiencia->tipo = $usuario->tipo;
                $newUsuarioAudiencia->id_audiencia = $newAudiencia->id;
                $newUsuarioAudiencia->estado = 1;
                $newUsuarioAudiencia->save();
            }
            return response()->json(['status' => 'duplicado correctamente', 'code' => 201, 'data' => $newAudiencia->id]);
        } catch (\Throwable $th) {
            return response()->json('Ha ocurrido un error. intente nuevamente', 400);
        }
    }
}
