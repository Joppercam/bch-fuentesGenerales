<?php

namespace App\Http\Requests;

use App\Traits\ApiResponser;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Validation\Rule;

class ValidateStorePublicacion extends FormRequest
{
    use ApiResponser;
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nombre_publicacion' => 'required|' . Rule::unique('mis_incentivos_publicaciones', 'nombre')->withoutTrashed(),
            'fecha_inicio' => 'required',
            'fecha_termino' => 'required',
            'select_audiencia' => 'required|exists:mis_incentivos_audiencia,id',
            'select_documento' => 'required|exists:mis_incentivos_documento,id',
            'select_clasificacion' => 'required|exists:mis_incentivos_publicaciones_options,id_item',
            'select_negocio' => 'required|exists:mis_incentivos_publicaciones_options,id_item',
            'select_perfil' => 'required|exists:mis_incentivos_publicaciones_options,id_item',
        ];
    }

    public function messages()
    {
        return [
            'nombre_publicacion.required' => 'El nombre de la publicación es obligatorio.',
            'nombre_publicacion.unique' => 'El nombre de la publicación ya se encuentra registrado.',
            'fecha_inicio.required' => 'Fecha de inicio es obligatorio.',
            'fecha_termino.required' => 'Fecha de termino es obligatorio.',
            'select_audiencia.required' => 'Código de audiencia es obligatorio.',
            'select_audiencia.exists' => 'Audiencia inválida.',
            'select_documento.required' => 'Código de documento es obligatorio.',
            'select_documento.exists' => 'Documento inválido.',
            'select_clasificacion.required' => 'Código de clasificación es obligatorio.',
            'select_clasificacion.exists' => 'Clasificación inválida.',
            'select_negocio.required' => 'Código de negocio es obligatorio.',
            'select_negocio.exists' => 'Negocio inválido.',
            'select_perfil.required' => 'Código de perfil es obligatorio.',
            'select_perfil.exists' => 'Perfil inválido.',
        ];
    }

    protected function failedValidation(Validator $validator)
    {

        /* Throwing an error with a 422 status code. With message errors*/
        throw new HttpResponseException($this->error(json_encode($validator->errors()->all()), 422));
    }
}
