<?php

namespace App\Http\Requests;

use App\Traits\ApiResponser;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Validation\Rule;

class ValidateStoreDocument extends FormRequest
{
    use ApiResponser;
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nombre_documento' => 'required|' . Rule::unique('mis_incentivos_documento', 'nombre')->withoutTrashed(),
            'descripcion_documento' => 'required',
            'multimediaFiles' => 'required|file|mimes:pdf',
        ];
    }

    public function messages()
    {
        return [
            'nombre_documento.required' => 'El nombre del documento es obligatorio.',
            'nombre_documento.unique' => 'El nombre de documento ya se encuentra registrado.',
            'descripcion_documento.required' => 'La descripción del documento es obligatoria.',
            'multimediaFiles.required' => 'El archivo pdf es obligatorio.',
        ];
    }

    protected function failedValidation(Validator $validator)
    {

        /* Throwing an error with a 422 status code. With message errors*/
        throw new HttpResponseException($this->error(json_encode($validator->errors()->all()), 422));
    }
}
