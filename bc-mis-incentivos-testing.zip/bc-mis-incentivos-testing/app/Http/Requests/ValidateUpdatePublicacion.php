<?php

namespace App\Http\Requests;

use App\Traits\ApiResponser;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ValidateUpdatePublicacion extends FormRequest
{
    use ApiResponser;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(Request $request)
    {
        return [
            'nombre_publicacion_editar' => 'required|' . Rule::unique('mis_incentivos_publicaciones', 'nombre')
                    ->ignore($request->id, 'id')
                    ->withoutTrashed(),
            'fecha_inicio_editar' => 'required',
            'fecha_termino_editar' => 'required',
            'select_audiencia_editar' => 'required|exists:mis_incentivos_audiencia,id',
            'select_documento_editar' => 'required|exists:mis_incentivos_documento,id',
            'select_clasificacion_editar' => 'required|exists:mis_incentivos_publicaciones_options,id_item',
            'select_negocio_editar' => 'required|exists:mis_incentivos_publicaciones_options,id_item',
            'select_perfil_editar' => 'required|exists:mis_incentivos_publicaciones_options,id_item',
        ];
    }

    public function messages()
    {
        return [
            'nombre_publicacion_editar.required' => 'El nombre de la publicación es obligatorio.',
            'nombre_publicacion_editar.unique' => 'El nombre de la publicación ya se encuentra registrado.',
            'fecha_inicio_editar.required' => 'Fecha de inicio es obligatorio.',
            'fecha_termino_editar.required' => 'Fecha de termino es obligatorio.',
            'select_audiencia_editar.required' => 'Código de audiencia es obligatorio.',
            'select_documento_editar.required' => 'Código de documento es obligatorio.',
            'select_clasificacion_editar.required' => 'Código de clasificación es obligatorio.',
            'select_negocio_editar.required' => 'Código de negocio es obligatorio.',
            'select_perfil_editar.required' => 'Código de perfil es obligatorio.',
        ];
    }

    protected function failedValidation(Validator $validator)
    {

        /* Throwing an error with a 422 status code. With message errors*/
        throw new HttpResponseException($this->error(json_encode($validator->errors()->all()), 422));
    }
}
