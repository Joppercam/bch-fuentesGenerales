<?php

namespace App\Http\Requests;

use App\Traits\ApiResponser;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Validation\Rule;

class ValidateSaveAudiencia extends FormRequest
{
    use ApiResponser;
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nombre_audiencia' => 'required|' . Rule::unique('mis_incentivos_audiencia', 'nombre')->withoutTrashed(),
            'selectDivision' => 'nullable',
            'selectUnidad' => 'nullable',
            'selectCargo' => 'nullable',
            'multimediaFiles' => 'file|mimes:xlsx',
        ];
    }

    public function messages()
    {
        return [
            'nombre_audiencia.required' => 'El nombre de la audiencia es obligatoria.',
            'nombre_audiencia.unique' => 'Ya existe una audiencia bajo este nombre.',
            'multimediaFiles.required' => 'El archivo es inválido o no se reconoce la extensión.',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        /* Throwing an error with a 422 status code. With message errors*/
        throw new HttpResponseException($this->error(json_encode($validator->errors()->all()), 422));
    }
}
