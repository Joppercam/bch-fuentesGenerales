<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\EstructuraOrganizacionalController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\NotificacionesController;
use App\Http\Controllers\NotificacionTemplateController;
use App\Http\Controllers\ReportesController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AudienciasController;
use App\Http\Controllers\DocumentosController;
use App\Http\Controllers\PublicacionesController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});
Route::auth();
Route::post('/logout', [LoginController::class, 'logout']);
Route::group(['middleware' => 'usuario'], function () {
    Route::get('/inicio', [HomeController::class, 'index'])->name('home');
    Route::get('/generarSesiones/{key}/{valor}', [HomeController::class, 'generarSesiones'])->name('generarSesiones');
    Route::get('/publicaciones', [PublicacionesController::class, 'index'])->name('publicaciones.list');
    Route::get('/notificaciones', [NotificacionesController::class, 'index'])->name('notificaciones.list');

    /* Audiencias */
    Route::get('/audiencias', [AudienciasController::class, 'index'])->name('audiencias.list');
    Route::get('/listarAudienciasSinUsuarios', [AudienciasController::class, 'listarAudienciasSinUsuarios'])->name('listarAudienciasSinUsuarios');
    Route::get('/listCreadoresAudiencia', [AudienciasController::class, 'listCreadoresAudiencia'])->name('listCreadoresAudiencia');
    Route::post('/deleteAudiencia', [AudienciasController::class, 'deleteAudiencia']);
    Route::post('/deleteAudienciaMultiple', [AudienciasController::class, 'deleteAudienciaMultiple']);
    Route::get('/cargarAudienciaUsuarios/{audiencia?}', [AudienciasController::class, 'cargarAudienciaUsuarios']);
    Route::get('/getAudienciaUsuarios/{audiencia?}', [AudienciasController::class, 'getAudienciaUsuarios']);
    Route::get('/getAudienciaUsuariosExInc/{audiencia?}', [AudienciasController::class, 'getAudienciaUsuariosExInc']);
    Route::post('/duplicarAudiencia', [AudienciasController::class, 'duplicarAudiencia']);
    Route::get('/verAudiencia/{id}', [AudienciasController::class, 'verAudiencia']);
    Route::post('/deleteUsuarioExcInc', [AudienciasController::class, 'deleteUsuarioExcInc']);
    Route::get('/ListaMisAudenciasByRut/{rut}/{cargo}/{division}/{unidad}', [AudienciasController::class, 'ListaMisAudenciasByRut']);

    /**Documentos */
    Route::get('/listarDocumentosSimple', [DocumentosController::class, 'listarDocumentosSimple'])->name('listarDocumentosSimple');
    Route::get('/documentos', [DocumentosController::class, 'index'])->name('documentos.list');
    Route::post('/deleteDocumento', [DocumentosController::class, 'deleteDocumento']);
    Route::post('/deleteDocumentoMultiple', [DocumentosController::class, 'deleteDocumentoMultiple']);
    Route::get('/cargarDocumento/{documento?}', [DocumentosController::class, 'cargarDocumento']);
    Route::post('/duplicarDocumento', [DocumentosController::class, 'duplicarDocumento']);

    /**Publicaciones */
    Route::get('/listarOpciones', [PublicacionesController::class, 'listarOpciones'])->name('listarOpciones');
    Route::post('/duplicarPublicacion', [PublicacionesController::class, 'duplicarPublicacion']);
    Route::post('/eliminarPublicacion', [PublicacionesController::class, 'eliminarPublicacion']);
    Route::post('/eliminarPublicacionMultiple', [PublicacionesController::class, 'eliminarPublicacionMultiple']);

    /**Reportes**/
    Route::get('/reportes', [ReportesController::class, 'index']);
    Route::post('/ListVisualizaciones', [ReportesController::class, 'ListVisualizaciones'])->name('reporte.ListVisualizaciones');
    Route::post('/ListVisualizacionesPercent', [ReportesController::class, 'ListVisualizacionesPercent'])->name('reporte.ListVisualizacionesPercent');
    Route::post('/PublicacionesByRut', [ReportesController::class, 'PublicacionesByRut'])->name('reporte.PublicacionesByRut');
    Route::post('/AudenciasNuevosColaboradores', [ReportesController::class, 'AudenciasNuevosColaboradores'])->name('reporte.AudenciasNuevosColaboradores');
    Route::post('/ListAudienciaDetail', [ReportesController::class, 'ListAudienciaDetail'])->name('reporte.ListAudienciaDetail');
    Route::post('/reportNotificaciones', [ReportesController::class, 'reportNotificaciones'])->name('reporte.reportNotificaciones');

    Route::post('/AsignarFechaHoraPublicacion', [PublicacionesController::class, 'AsignarFechaHoraPublicacion']);
    Route::get('/publicacionesPorNotificar', [PublicacionesController::class, 'publicacionesPorNotificar']);

    /**Notificaciones**/
    Route::get('/eliminarNotificacion/{id}', [NotificacionesController::class, 'eliminarNotificacion'])->name('eliminarNotificacion');
    Route::post('/eliminarNotificacionesPublicacion', [NotificacionesController::class, 'eliminarNotificacionesPublicacion'])->name('eliminarNotificacionesPublicacion');
    Route::get('/cargarNotificacionesByPublicacion/{idPublicacion}', [NotificacionesController::class, 'cargarNotificacionesByPublicacion'])->name('cargarNotificacionesByPublicacion');
    Route::get('/cargarNotificacionTemplate/{idNotificacion}', [NotificacionesController::class, 'cargarNotificacionTemplate'])->name('cargarNotificacionTemplate');
    Route::get('/cargarUsuariosNotificadosById/{idNotificacion}', [NotificacionesController::class, 'cargarUsuariosNotificadosById'])->name('cargarUsuariosNotificadosById');

    Route::get('/templates', [NotificacionTemplateController::class, 'index'])->name('index');
    Route::get('/getTemplates', [NotificacionTemplateController::class, 'getTemplates'])->name('getTemplates');
    Route::get('/usuarioByRut/{rut}', [PublicacionesController::class, 'usuarioByRut'])->name('usuarioByRut');
    Route::get('/cargarTemplate/{idTemplate}', [NotificacionTemplateController::class, 'cargarTemplate'])->name('cargarTemplate');
    Route::get('/eliminarTemplate/{idTemplate}', [NotificacionTemplateController::class, 'deleteTemplate'])->name('deleteTemplate');

    Route::get('/resumenDetail', [PublicacionesController::class, 'resumenDetail'])->name('resumenDetail');
    Route::post('/listUnidades', [EstructuraOrganizacionalController::class, 'listUnidades'])->name('unidades.list');
    Route::post('/listCargos', [EstructuraOrganizacionalController::class, 'listCargos'])->name('cargos.list');

    Route::group(['middleware' => 'XSS'], function () {
        Route::post('/ListAudiencias', [ReportesController::class, 'ListAudiencias'])->name('reporte.ListAudiencias');
        Route::get('/listarAudiencias', [AudienciasController::class, 'listarAudiencias'])->name('listarAudiencias');
        Route::post('/saveAudiencia', [AudienciasController::class, 'saveAudiencia']);
        Route::post('/updateAudiencia', [AudienciasController::class, 'updateAudiencia']);

        Route::get('/listarDocumentos', [DocumentosController::class, 'listarDocumentos'])->name('listarDocumentos');
        Route::post('/saveDocumento', [DocumentosController::class, 'saveDocumento']);
        Route::post('/updateDocumento', [DocumentosController::class, 'updateDocumento']);

        Route::get('/listarPublicaciones', [PublicacionesController::class, 'listarPublicaciones'])->name('listarPublicaciones');
        Route::post('/editarPublicacion', [PublicacionesController::class, 'editarPublicacion']);
        Route::post('/savePublicacion', [PublicacionesController::class, 'savePublicacion']);

        Route::get('/listTemplate', [NotificacionTemplateController::class, 'listTemplate'])->name('listTemplate');
        Route::post('/saveTemplate', [NotificacionTemplateController::class, 'saveTemplate'])->name('saveTemplate');
        Route::post('/updateTemplate', [NotificacionTemplateController::class, 'updateTemplate'])->name('updateTemplate');


        Route::get('/listDivisiones', [EstructuraOrganizacionalController::class, 'listDivisiones'])->name('diviciones.list');


        Route::get('/listarNotificaciones', [NotificacionesController::class, 'listarNotificaciones'])->name('listarNotificaciones');
    });
});
