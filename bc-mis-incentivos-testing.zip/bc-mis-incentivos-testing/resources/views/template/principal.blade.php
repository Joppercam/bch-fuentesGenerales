@extends('layouts.notificacionTemplate')
@section('title', 'Templates')
@section('content')
    <h1>Templates de notificación</h1>
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
                <div class="contenedorListarTemplate">
                    <table id="lista_template" class="display lista_template table">
                        <thead>
                        <tr>
                            <th>Código</th>
                            <th>Título</th>
                            <th>Asunto</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>
                    </table>
                </div>
                <div class="modal fade" backdrop='static' id="modalTemplate" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-xl modal-dialog-centered modal-edit-user">
                        <div class="modal-content">
                            <div class="modal-header bg-transparent">
                                <h3 class="mb-0">Templates</h3>
                                <button type="button" class="btn-close btn-close-modal" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                            </div>
                            <div id="modal-audiencia-body" class="modal-body pb-5 px-sm-5 pt-50">
                                <div id="account-details-vertical" class="content active dstepper-block"
                                     role="tabpanel"
                                     aria-labelledby="account-details-vertical-trigger">
                                    <form id="frmTemplate" action="javascript:void(0)">
                                        <div class="row">
                                            <div class="mt-1 mb-1 col-md-12">
                                                <label class="form-label" for="nottem_titulo">Título</label>
                                                <input type="text" id="nottem_titulo"
                                                       class="form-control" name="nottem_titulo"
                                                       placeholder="" required>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label"
                                                       for="nottem_asunto">Asunto</label>
                                                <input type="text" class="form-select" id="nottem_asunto"
                                                       name="nottem_asunto" required>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label"
                                                       for="nottem_contenido">Contenido</label>
                                                <textarea type="text" class="form-select" id="nottem_contenido"
                                                          name="nottem_contenido" required></textarea>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-end  mt-5">
                                            <button id="saveTemplate" type="submit"
                                                    class=" editar-button dt-button create-new button default small waves-effect waves-float waves-light">
                                                <span class="align-middle d-sm-inline-block ">Guardar</span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                     stroke-width="2"
                                                     stroke-linecap="round" stroke-linejoin="round"
                                                     class="feather feather-arrow-right align-middle ms-sm-25 ms-0">
                                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                                    <polyline points="12 5 19 12 12 19"></polyline>
                                                </svg>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdropPreview"
                     aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
                    <div class="offcanvas-header">
                        <h1 id="offcanvasBothLabel" class="offcanvas-title">Previsualización de notificación</h1>
                        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                                aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body my-auto mx-0">

                        <!--contenedor de usuarios en lista de asignados-->
                        <div id="containerNotificacionPreview" class="mb-5" style="overflow-y: auto; min-height: 200px">
                        </div>
                    </div>
                    <!--modal de asignacion de usuarios a documento-->
                    <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                         style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                        <div class="align-self-right">
                            <button type="button" class="button default align-self-right"
                                    data-bs-dismiss="offcanvas">
                                Cerrar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

