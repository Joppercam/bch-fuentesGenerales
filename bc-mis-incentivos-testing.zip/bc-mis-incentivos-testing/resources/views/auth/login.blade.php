@extends('layouts.app')

@section('content')
    <div class="content-header row">
    </div>
    <div class="mat-bch content-body content-login">
        <div class="auth-wrapper auth-basic px-2">
            <div class="auth-inner my-2">
                <!-- Login basic -->
                <div class="bch-login card mb-0">
                    <div class="card-body ta-c">
                        <a href=".." class="brand-logo">
                            <h2 class="brand-text mr-2 mt-2 tt-u" style="color: rgb(5, 101, 181)">Mis incentivos</h2>
                            @if(env('APP_ENV')=="productivo")
                                <i class="icon-icon-bch-logo-bch size-icon-lg c-brand d-flex ai-c pl-3 blw-3"></i>
                            @else

                            @endif
                        </a>
                        <p class="ta-c c-gray-dark">Inicia sesión con tu correo Banco de Chile </p>
                        <a class="button default" type="button" href="loginsml/misincentivos/login">
                            Iniciar sesión
                        </a>
                    </div>
                </div>
                <!-- /Login basic -->
            </div>
        </div>
    </div>
@endsection
