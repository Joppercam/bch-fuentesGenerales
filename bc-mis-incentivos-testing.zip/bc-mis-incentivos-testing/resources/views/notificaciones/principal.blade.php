@extends('layouts.notificaciones')
@section('title', 'Notificaciones')
@section('content')
    <style>
        div.dataTables_wrapper div.dataTables_scrollBody {
            min-height: 300px;
        }
    </style>
    <h1>Notificaciones programadas</h1>
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
                <div class="contenedorListarNotificaciones">
                    <h4>Filtros:</h4>
                    <table border="0" cellspacing="5" cellpadding="5">
                        <tbody>
                        <tr class="d-flex justify-content-end">
                            <td>Desde: <input class="form-control" type="text" id="min" name="min"></td>

                            <td>Hasta: <input class="form-control" type="text" id="max" name="max">
                            <td id="tdFilterCreator"></td>
                            <td id="tdFilterNegocio"></td>
                            <td>
                                <button id="btnRefresh" type="button"
                                        class="btn btn-icon btn-outline-primary  mt-6 pt-1 br-2" title="Limpiar fechas">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                         fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                         stroke-linejoin="round" class="feather feather-refresh-cw">
                                        <polyline points="23 4 23 10 17 10"></polyline>
                                        <polyline points="1 20 1 14 7 14"></polyline>
                                        <path
                                            d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                                    </svg>
                                </button>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <div class="row pb-2">
                        <h4>Datos para nueva notificación:</h4>
                        <div class="col-12 col-md-3">
                            <span>Fecha de notificación</span> <input id="fechaPubliacion" type="date"
                                                                      class="form-control">
                        </div>
                        <div class="col-12 col-md-3">
                            <span>hora de notificación</span> <select id="selHoraPublicacion" class="form-control">
                                <option value="">Seleccione un rango</option>
                                <option value="9">09:00:00 AM</option>
                                <option value="12">12:00:00 PM</option>
                                <option value="15">15:00:00 PM</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-3">
                            <span>Template</span>
                            <select id="selTemplate" class="form-control">
                                <option value="">Seleccione un template</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-3">
                            <button id="btnRefreshTemplate" type="button"
                                    class="btn btn-icon btn-outline-primary  mt-6 pt-1 br-2" title="Limpiar fechas">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                     stroke-linejoin="round" class="feather feather-refresh-cw">
                                    <polyline points="23 4 23 10 17 10"></polyline>
                                    <polyline points="1 20 1 14 7 14"></polyline>
                                    <path
                                        d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                    <table id="listNotificaciones" class="display listNotificaciones table" style="width:100%;">
                        <thead>
                        <tr>
                            <th><input type="checkbox" id="select-all"></th>
                            <th>Audiencia</th>
                            <th>Nombre</th>
                            <th>Creador</th>
                            <th>Fecha Inicio</th>
                            <th>Fecha Termino</th>
                            <th>Notificaciones agendadas</th>
                            <th>id_negocio</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>

                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdrop"
         aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
        <div class="offcanvas-header">
            <h1 id="offcanvasBothLabel" class="offcanvas-title">Usuarios asignados</h1>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                    aria-label="Close"></button>
        </div>
        <div class="offcanvas-body my-auto mx-0">

            <!--contenedor de usuarios en lista de asignados-->
            <div id="containerDocumentosUsuariosAsignados" class="mb-5" style="overflow-y: auto; min-height: 300px;">
                <table id="lista_audiencias_usuarios_ver"
                       class="lista_audiencias_usuarios_ver table display" style="width:100%">
                    <thead>
                    <tr>
                        <th>Rut</th>
                        <th>Nombre completo</th>
                        <th>División</th>
                        <th>Unidad</th>
                        <th>Cargo</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
        <!--modal de asignacion de usuarios a documento-->
        <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
             style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
            <div class="align-self-right">
                <button type="button" class="button default align-self-right"
                        data-bs-dismiss="offcanvas">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdropNotif"
         aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
        <div class="offcanvas-header">
            <h1 id="offcanvasBothLabel" class="offcanvas-title">Notificaciones Asignadas</h1>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                    aria-label="Close"></button>
        </div>
        <div class="offcanvas-body my-auto mx-0">

            <!--contenedor de usuarios en lista de asignados-->
            <div id="containerNotificacionesAsignadas" class="mb-5" style="overflow-y: auto; min-height: 200px">
                <table id="lista_notificaciones_asign" class="lista_notificaciones_asign table display"
                       style="width:100%;">
                    <thead>
                    <tr>
                        <th>Código</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Template</th>
                        <th>Notificaciones enviadas</th>
                        <th>Acciones</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
        <!--modal de asignacion de usuarios a documento-->
        <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
             style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
            <div class="align-self-right">
                <button type="button" class="button default align-self-right"
                        data-bs-dismiss="offcanvas">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdropPreview"
         aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
        <div class="offcanvas-header">
            <h1 id="offcanvasBothLabel" class="offcanvas-title">Previsualización de notificación</h1>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                    aria-label="Close"></button>
        </div>
        <div class="offcanvas-body my-auto mx-0">

            <!--contenedor de usuarios en lista de asignados-->
            <div id="containerNotificacionPreview" class="mb-5" style="overflow-y: auto; min-height: 200px">
            </div>
        </div>
        <!--modal de asignacion de usuarios a documento-->
        <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
             style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
            <div class="align-self-right">
                <button type="button" class="button default align-self-right"
                        data-bs-dismiss="offcanvas">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdropNotifUser"
         aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
        <div class="offcanvas-header">
            <h1 id="offcanvasBothLabel" class="offcanvas-title">Usuarios notificados</h1>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                    aria-label="Close"></button>
        </div>
        <div class="offcanvas-body my-auto mx-0">

            <!--contenedor de usuarios en lista de asignados-->
            <div id="containerUsuariosNotif" class="mb-5" style="overflow-y: auto;">
                <table id="lista_usuariosNotif"
                       class="lista_usuariosNotif table display" style="width:100%">
                    <thead>
                    <tr>
                        <th>Rut</th>
                        <th>Nombre completo</th>
                        <th>División</th>
                        <th>Unidad</th>
                        <th>Cargo</th>
                        <th>Recepción</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
        <!--modal de asignacion de usuarios a documento-->
        <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
             style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
            <div class="align-self-right">
                <button type="button" class="button default align-self-right"
                        data-bs-dismiss="offcanvas">
                    Cerrar
                </button>
            </div>
        </div>
    </div>

    <script>
        const listNotificaciones = "{{route('listarNotificaciones')}}"
    </script

@endsection

