@extends('layouts.documentos')
@section('title', 'Documentos')
@section('content')

    <h1>Documentos</h1>
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
                <div class="contenedorListarDocumentos">
                    <table border="0" cellspacing="5" cellpadding="5">
                        <tbody>
                        <tr>
                            <td>Desde: <input class="form-control" type="text" id="min" name="min"></td>

                            <td>Hasta: <input class="form-control" type="text" id="max" name="max">
                            <td>
                            <td>
                                <button id="btnRefresh" type="button"
                                        class="btn btn-icon btn-outline-primary  mt-5 pt-1 br-2" title="Limpiar fechas">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                         fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                         stroke-linejoin="round" class="feather feather-refresh-cw">
                                        <polyline points="23 4 23 10 17 10"></polyline>
                                        <polyline points="1 20 1 14 7 14"></polyline>
                                        <path
                                            d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                                    </svg>
                                </button>
                            </td>
                            <td id="tdFilterCreator"></td>
                        </tr>
                        </tbody>
                    </table>
                    <table id="lista_documentos" class="display lista_documentos table" style="width:100%">
                        <thead>
                        <tr>
                            <th><input type="checkbox" id="select-all"></th>
                            <th>Código</th>
                            <th>Nombre</th>
                            <th>Nombre documento</th>
                            <th>Descripcion</th>
                            <th>Documento</th>
                            <th>Autor</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>

                    </table>
                    <div class="offcanvas offcanvas-end" tabindex="-1"
                         id="offcanvasBackdropFormulario" aria-labelledby="offcanvasBackdropLabel"
                         style="width: 1300px; z-index: 1056 !important;">
                        <div class="offcanvas-header">
                            <h1 id="offcanvasBothLabel" class="offcanvas-title">Previsualización de
                                documento</h1>
                            <button type="button" class="btn-close text-reset"
                                    data-bs-dismiss="offcanvas" aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body my-auto mx-0 " style="overflow-y">

                            <!--contenedor de usuarios en lista de asignados-->
                            <div id="containerVisualizarDocumento" class="mb-5"
                                 style="overflow-y: auto; text-align-last: center;">
                                <iframe id="visualizarDocumento" src="" frameborder="0"
                                        width="80%" height="800px"></iframe>

                            </div>

                        </div>
                        <!--modal de asignacion de usuarios a documento-->
                        <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                             style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                            <div class="align-self-right">
                                <button type="button" class="button default align-self-right"
                                        data-bs-dismiss="offcanvas">
                                    Cerrar
                                </button>
                            </div>
                        </div>
                    </div>
                    <!--modal crear documento-->
                    <div class="modal fade" backdrop='static' id="modal-documento" tabindex="-10000" aria-hidden="true">
                        <div class="modal-dialog modal-xl modal-dialog-centered modal-edit-user">
                            <div class="modal-content">
                                <div class="modal-header bg-transparent">
                                    <h3 class="mb-0">Documentos</h3>
                                    <button type="button" class="btn-close btn-close-modal" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                </div>
                                <div id="modal-documento-body" class="modal-body pb-5 px-sm-5 pt-50">
                                    <div class="content-header">
                                        <!--<small class="text-muted">Texto texto texto.</small>-->
                                    </div>
                                    <div class="row">
                                        <form id="frmDocumentos" action="javascript:void(0)">
                                            <div class="mt-1 mb-1 col-md-12">
                                                <label class="form-label" for="nombre_documento">Nombre
                                                    Documento</label>
                                                <input type="text" id="nombre_documento" class="form-control"
                                                       placeholder="" name="nombre_documento" required>
                                            </div>
                                            <div class="mt-1 mb-1 col-md-12">
                                                <label class="form-label"
                                                       for="descripcion_documento">Descripción</label>
                                                <input type="text" id="descripcion_documento" class="form-control"
                                                       placeholder="" name="descripcion_documento" required>
                                            </div>
                                            <div class="row">
                                                <div class="mb-1 mt-5 form-password-toggle col-md-8">
                                                    <label class="form-label" for="vertical-username">Subir
                                                        Documento</label>
                                                    <input type="file" id="multimediaFiles"
                                                           name="multimediaFiles"
                                                           data-show-caption="true"
                                                           accept=".pdf" required>
                                                </div>
                                                <div class="col-md-4 file-manager-main-content">
                                                    <div class="file-manager-content-body ps ps--active-y">
                                                        <h3 class="form-label" for="vertical-username">Documento
                                                            cargado</h3>
                                                        <div class="view-container">
                                                            <div class="card file-manager-item file d-none">
                                                                <div class="card-img-top file-logo-wrapper">
                                                                    <div class="dropdown float-end">
                                                                        <i id="dropdownMenuButton33"
                                                                           data-feather="more-vertical"
                                                                           class="toggle-dropdown mt-n25"
                                                                           data-bs-toggle="dropdown"></i>
                                                                        <div
                                                                            class="dropdown-menu dropdown-menu-end file-dropdown"
                                                                            aria-labelledby="dropdownMenuButton33">
                                                                            <a
                                                                                class="dropdown-item verDocumentoCargado"
                                                                                href="javascript:void(0)"
                                                                                data-bs-toggle="offcanvas"
                                                                                data-bs-target="#offcanvasBackdropFormulario"
                                                                                aria-controls="offcanvasBackdropFormulario">
                                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                                     width="14" height="14"
                                                                                     viewBox="0 0 24 24" fill="none"
                                                                                     stroke="currentColor"
                                                                                     stroke-width="2"
                                                                                     stroke-linecap="round"
                                                                                     stroke-linejoin="round"
                                                                                     class="feather feather-eye toggle-dropdown mt-n25">
                                                                                    <path
                                                                                        d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                                                                    <circle cx="12" cy="12"
                                                                                            r="3"></circle>
                                                                                </svg>
                                                                                <span class="align-middle">Ver</span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="d-flex align-items-center justify-content-center w-100">
                                                                        <img
                                                                            src="{{asset('public/app-assets/images/icons/pdf.png')}}"
                                                                            alt="file-icon">
                                                                    </div>
                                                                </div>
                                                                <div class="card-body-file">
                                                                    <div class="content-wrapper">
                                                                        <p id="nombre_documento_cargado"
                                                                           class="card-text file-name mb-0"
                                                                           title=""></p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-end  mt-5">

                                                <button type="submit" id="guardarDocumento"
                                                        class="dt-button create-new button default small waves-effect waves-float waves-light">
                                                    <span class="align-middle d-sm-inline-block ">Guardar</span>

                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        const listDocumentos = "{{route('listarDocumentos')}}"
    </script

@endsection

