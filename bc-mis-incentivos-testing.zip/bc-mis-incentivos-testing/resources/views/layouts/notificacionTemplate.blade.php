<!DOCTYPE html>
<html class="loading" lang="es" data-textdirection="ltr">
<!-- BEGIN: Head-->
<head>
    @include('common.head')
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-icons.min.css?v1.0.0') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/components.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/select2.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/dataTables.dateTime.min.css') }}">


</head>
<body class="mat-bch">
@include('common.header')
@include('common.horizontalMenu')


<div class="app-content content ">
    <div class="content-wrapper p-0">
        <div class="content-header row">
            @include('common.toast')
            <div class="content-body">
                @yield('content')
            </div>
        </div>
    </div>

</div>

</body>
<!-- BEGIN: Footer-->
@include('common.footer')
<script src="{{ asset('public/app-assets/vendors/js/ui/jquery.sticky.js?' . $version) }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/select2.full.min.js?'.$version)}}"></script>
<script src="{{ asset('public/app-assets/js/scripts/dataTables.dateTime.min.js?' . $version) }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/ckeditor/ckeditor.js?'.$version)}}"></script>
<script src="{{ asset('js/template.js?' . $version) }}"></script>

</html>

