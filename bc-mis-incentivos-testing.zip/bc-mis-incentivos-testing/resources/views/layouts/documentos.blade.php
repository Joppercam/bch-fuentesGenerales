<!DOCTYPE html>
<html lang="es">
<!DOCTYPE html>
<html class="loading" lang="es" data-textdirection="ltr">
<!-- BEGIN: Head-->
<head>
    @include('common.head')
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-icons.min.css?v1.0.0') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/components.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/select2.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/dataTables.dateTime.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/fileinput.min.css') }}">

</head>
<body class="mat-bch">
@include('common.header')
@include('common.horizontalMenu')


<div class="app-content content ">
    <div class="content-wrapper  p-0">
        <div class="content-header row">
            @include('common.toast')
            <div class="content-body">
                @yield('content')
            </div>
        </div>
    </div>

</div>

</body>
<!-- BEGIN: Footer-->
@include('common.footer')
<script src="{{ asset('public/app-assets/js/scripts/forms/form-wizard.js?' . $version) }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/forms/wizard/bs-stepper.min.js?' . $version) }}"></script>

<script src="{{ asset('public/app-assets/vendors/js/ui/jquery.sticky.js?' . $version) }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/file-uploaders/dropzone.min.js?' . $version) }}"></script>
<script src="{{ asset('public/app-assets/js/scripts/forms/form-file-uploader.js?' . $version) }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/select2.full.min.js?'.$version)}}"></script>
<script src="{{ asset('public/app-assets/js/scripts/dataTables.dateTime.min.js?' . $version) }}"></script>
<script src="{{ asset('js/fileinput.js?' . $version) }}"></script>
<script src="{{ asset('js/documentos.js?' . $version) }}"></script>
<script>
    let idAudiencia = null;
    let nombreUsuario = "{!! Auth::user()->nombre_completo !!}";
    @if(session('idaudiencia'))
        idAudiencia = "{!! session('idaudiencia') !!}";
    @endif
</script>
</html>

