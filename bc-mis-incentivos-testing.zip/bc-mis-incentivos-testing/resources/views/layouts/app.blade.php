<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Mis incentivos</title>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- faivcon -->
    <link rel="Shortcut Icon" type="image/x-icon"
          href="{{ asset('images/favicon.ico') }}"/>
    <link rel="apple-touch-icon"
          href="{{ asset('images/favicon.ico') }}"/>
    <!-- Styles -->
    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-extended.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/colors.css') }}">
    <link href="{{ asset('css/style.css?'.config('constants.version')) }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bch-ui-kit.css?v1.0.0') }}">
</head>
<style>
    .bch-login {
        padding: 1rem;
    }
    .mat-bch .button {
        position: relative;
        color: #ffffff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 0.875rem;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        line-height: 1.5rem;
        min-height: 40px;
        padding: 1rem 1.5rem;
        margin-bottom: 1rem;
        border: none;
        border-radius: 16.875rem;
        transition: all 0.5s ease-in-out;
        z-index: 100;
    }
    .mat-bch .button:hover {
        color: #ffffff;
        box-shadow: 0 4px 12px rgb(0 36 100 / 20%);
    }
    .mat-bch .button.default {
        background-color: #295EFF;
        background: linear-gradient(135deg, #5583FF 0%, #295EFF 100%);
    }
    .auth-wrapper.auth-basic .auth-inner {
        max-width: 600px;
    }
    .auth-wrapper.auth-basic {
        align-items: center;
        justify-content: left;
        overflow: hidden;
        margin-left: 60px;
    }
    @media (max-width: 800px) {
        .bch-login {
            padding: 1.5rem;
        }
    }
</style>
<body class="vertical-layout vertical-menu-modern blank-page navbar-floating footer-static   menu-collapsed"
      data-open="click" data-menu="vertical-menu-modern" data-col="blank-page">
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        @yield('content')
    </div>
</div>
</body>
</html>
