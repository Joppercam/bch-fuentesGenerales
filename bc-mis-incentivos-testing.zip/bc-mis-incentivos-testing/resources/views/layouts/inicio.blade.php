<!DOCTYPE html>
<html class="loading" lang="es" data-textdirection="ltr">
<!-- BEGIN: Head-->
<head>
    @include('common.head')
    <!-- BEGIN: Vendor CSS-->
    <style>
        .contentHome {
            font-family: "Nunito Sans", sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            color: white !important;
            background-size: contain;
            position: relative;
            overflow: visible;
            margin-bottom: 50px;
            padding-top: 170px;
        }
    </style>
</head>
@include('common.header')
@include('common.horizontalMenu')
@yield('content')
</body>
<!-- BEGIN: Footer-->
@include('common.footer')
<script src="{{ asset('js/home.js?' . $version) }}"></script>
</html>


