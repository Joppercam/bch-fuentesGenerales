@extends('layouts.publicaciones')
@section('title', 'Publicaciones')
@section('content')

    <h1>Publicaciones</h1>
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="list-tab" data-bs-toggle="tab" href="#list"
                           aria-controls="list" role="tab" aria-selected="false">Todas las publicaciones</a>
                    </li>
                    @if(session('perfilmi')==111)
                        <li class="nav-item">
                            <a class="nav-link " id="viewUser-tab" data-bs-toggle="tab" href="#viewUser"
                               aria-controls="viewUser" role="tab" aria-selected="true">Ver publicaciones de un
                                usuario</a>
                        </li>
                    @endif
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="list" aria-labelledby="list-tab" role="tabpanel">
                        <div class="contenedorListarPublicaciones">
                            <table border="0" cellspacing="5" cellpadding="5">
                                <tbody>
                                <tr>
                                    <td>Desde: <input class="form-control" type="text" id="min" name="min"></td>

                                    <td>Hasta: <input class="form-control" type="text" id="max" name="max"></td>
                                    <td id="tdFilterCreator"></td>
                                    <td id="tdFilterClasif"></td>
                                    <td id="tdFilterNegocio"></td>
                                    <td id="tdFilterTrimestre"></td>
                                    <td id="tdFilterPeriod"></td>
                                    <td>
                                        <button id="btnRefresh" type="button"
                                                class="btn btn-icon btn-outline-primary  mt-5 pt-1 br-2"
                                                title="Limpiar filtros">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                 viewBox="0 0 24 24"
                                                 fill="none" stroke="currentColor" stroke-width="2"
                                                 stroke-linecap="round"
                                                 stroke-linejoin="round" class="feather feather-refresh-cw">
                                                <polyline points="23 4 23 10 17 10"></polyline>
                                                <polyline points="1 20 1 14 7 14"></polyline>
                                                <path
                                                    d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                                            </svg>
                                        </button>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <table id="lista_publicaciones" class="display lista_publicaciones table">
                                <thead>
                                <tr>
                                    <th><input type="checkbox" id="select-all"></th>
                                    <th>id_publicacion</th>
                                    <th>Nombre</th>
                                    <th>id_Audiencia</th>
                                    <th>Audiencia</th>
                                    <th>id_documento</th>
                                    <th>Documento</th>
                                    <th>Fecha Inicio</th>
                                    <th>Fecha Termino</th>
                                    <th>Clasificación</th>
                                    <th>Negocio</th>
                                    <th>Periodicidad</th>
                                    <th>Categoría</th>
                                    <th>rut Creador</th>
                                    <th>Creador</th>
                                    <th>Fecha</th>
                                    <th>Perfil</th>
                                    <th>Acción</th>
                                </tr>
                                </thead>

                            </table>


                            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdropFormulario"
                                 aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
                                <div class="offcanvas-header">
                                    <h1 id="offcanvasBothLabel" class="offcanvas-title">Previsualización de
                                        documento</h1>
                                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                                            aria-label="Close"></button>
                                </div>
                                <div class="offcanvas-body my-auto mx-0 " style="overflow-y">

                                    <!--contenedor de usuarios en lista de asignados-->
                                    <div id="containerVisualizarDocumento" class="mb-5"
                                         style="overflow-y: auto; text-align-last: center;">
                                        <iframe id="visualizarDocumento" src="" frameborder="0" width="80%"
                                                height="800px"></iframe>

                                    </div>

                                </div>
                                <!--modal de asignacion de usuarios a documento-->
                                <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                                     style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                                    <div class="align-self-right">
                                        <button type="button" class="button default align-self-right"
                                                data-bs-dismiss="offcanvas">
                                            Cerrar
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdropPublicacion"
                                 aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
                                <div class="offcanvas-header">
                                    <h1 id="offcanvasBothLabel" class="offcanvas-title">Previsualización de
                                        publicaci&oacute;n</h1>
                                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                                            aria-label="Close"></button>
                                </div>
                                <div class="offcanvas-body my-auto mx-0 " style="overflow-y">

                                    <div id="social-links-vertical" class="content" role="tabpanel"
                                         aria-labelledby="social-links-vertical-trigger">

                                        <div class="row">
                                            <div class="mb-1 col-md-12">
                                                <!-- avatar image title -->
                                                <div
                                                    class="d-flex justify-content-start align-items-center mb-1">
                                                    <div class="avatar me-1">
                                                        <img src="images/avatar-s-11.jpg" alt="avatar img"
                                                             style="border-radius: 50%;" height="50" width="50">
                                                    </div>
                                                    <div class="profile-user-info">
                                                        <h6 class="mb-0" id="ver_nombre_usuario">...</h6>
                                                        <h6 class="text-muted" id="ver_nombre_cargo">...</h6>
                                                        <small class="text-muted" id="ver_nombre_division">...</small>
                                                    </div>
                                                </div>
                                                <!--/ avatar image title -->
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="content-header">
                                                            <h1 class="mb-0" id="ver_nombre_publicacion">...</h1>
                                                            <span class="badge badge-light-primary">Negocio</span>
                                                            <small id="ver_nombre_rol">...</small>
                                                            <span class="badge badge-light-primary">Clasificación</span>
                                                            <small id="ver_nombre_clasificacion">...</small>
                                                            <span class="badge badge-light-primary">Categoría</span>
                                                            <small id="ver_nombre_categoria">...</small>
                                                            <span class="badge badge-light-primary">Periodicidad</span>
                                                            <small id="ver_nombre_periodicidad">...</small>
                                                        </div>
                                                        <div class="row">
                                                            <div class="mb-1 col-md-6">
                                                                <blockquote
                                                                    class="blockquote ps-1 border-start-primary border-start-3 mt-5">
                                                            <span
                                                                class="badge badge-light-primary">Periodo de Medición</span>
                                                                    <p>
                                                                        <i data-feather='calendar'></i> Desde: <small
                                                                            id="ver_fecha_inicio"
                                                                            style="margin-right: 25px">...</small>
                                                                        <i data-feather='calendar'></i> Hasta: <small
                                                                            id="ver_fecha_termino">...</small>
                                                                    </p>
                                                                </blockquote>
                                                                <!--<div class=" mb-1  mt-3">
                                                                    <span class="badge badge-light-dark">Restan 28 días para que finalice el periodo</span>
                                                                </div>-->
                                                            </div>
                                                            <div class="mb-1 col-md-6">
                                                                <div class=" mb-1  mt-3">
                                                                    <span class="badge badge-light-secondary">Este documento es confidencial y es de propiedad del Banco de Chile</span>
                                                                </div>
                                                            </div>
                                                            <!--contenedor de usuarios en lista de asignados-->
                                                            <div id="containerVisualizarDocumentoVer" class="mb-5"
                                                                 style="overflow-y: auto; text-align-last: center;">
                                                                <iframe id="visualizarDocumentoVer" src=""
                                                                        frameborder="0"
                                                                        width="80%" height="800px"></iframe>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                                <!--modal de asignacion de usuarios a documento-->
                                <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                                     style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                                    <div class="align-self-right">
                                        <button type="button" class="button default align-self-right"
                                                data-bs-dismiss="offcanvas">
                                            Cerrar
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdopAudiencia"
                                 aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
                                <div class="offcanvas-header">
                                    <h1 id="offcanvasBothLabel" class="offcanvas-title">Previsualización de
                                        audiencia</h1>
                                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                                            aria-label="Close"></button>
                                </div>
                                <div class="offcanvas-body my-auto mx-0 " style="overflow-y">


                                    <div class="bs-stepper-content">
                                        <div id="account-details-vertical" class="content active dstepper-block"
                                             role="tabpanel"
                                             aria-labelledby="account-details-vertical-trigger">
                                            <div class="content-header">
                                                <h3 class="mb-0">Creación de Audiencia</h3>
                                                <small class="text-muted"></small>
                                            </div>
                                            <div class="row">
                                                <div class="row">
                                                    <div class="mt-1 mb-1 col-md-12">
                                                        <label class="form-label" for="nombre_audiencia">Nombre
                                                            Audiencia</label>
                                                        <input type="text" id="nombre_audiencia"
                                                               class="form-control"
                                                               placeholder="">
                                                    </div>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label"
                                                           for="vertical-username">División</label>
                                                    <select class="form-select" id="selectDivision" multiple="multiple">
                                                    </select>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="vertical-username">Unidad</label>
                                                    <select class="form-select" id="selectUnidad" multiple="multiple">
                                                    </select>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="normalMultiSelect">Cargo</label>
                                                    <select class="form-control" multiple="multiple"
                                                            id="selectCargo">
                                                    </select>
                                                </div>
                                            </div>
                                            <button id="visualizarUsuarios" data-bs-toggle="offcanvas"
                                                    data-bs-target="#offcanvasBackdrop"
                                                    aria-controls="offcanvasBackdrop"
                                                    class="button default small col-md-4">
                                                <span class="align-middle d-sm-inline-block ">Visualizar usuarios</span>
                                            </button>


                                        </div>

                                    </div>


                                </div>
                                <!--modal de asignacion de usuarios a documento-->
                                <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                                     style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                                    <div class="align-self-right">
                                        <button type="button" class="button default align-self-right"
                                                data-bs-dismiss="offcanvas" data-bs-target="#offcanvasBackdopAudiencia">
                                            Cerrar
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal usuarios asignados -->
                            <div class="enable-backdrop">
                                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdrop"
                                     aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
                                    <div class="offcanvas-header">
                                        <h1 id="offcanvasBothLabel" class="offcanvas-title">Usuarios asignados</h1>
                                        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                                                aria-label="Close"></button>
                                    </div>
                                    <div class="offcanvas-body my-auto mx-0 " style="overflow-y">

                                        <!--contenedor de usuarios en lista de asignados-->
                                        <div id="containerDocumentosUsuariosAsignados" class="mb-5"
                                             style="overflow-y: auto;">
                                            <table id="lista_audiencias_usuarios"
                                                   class="lista_audiencias_usuarios table display" style="width:100%">
                                                <thead>
                                                <tr>
                                                    <th>Rut</th>
                                                    <th>Nombre completo</th>
                                                    <th>División</th>
                                                    <th>Unidad</th>
                                                    <th>Cargo</th>
                                                </tr>
                                                </thead>
                                            </table>

                                        </div>


                                    </div>
                                    <!--modal de asignacion de usuarios a documento-->
                                    <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                                         style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                                        <div class="align-self-right">
                                            <button type="button" class="button default align-self-right"
                                                    data-bs-dismiss="offcanvas" data-bs-target="#offcanvasBackdrop">
                                                Cerrar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--modal crear publicacion-->
                            <div class="modal fade" backdrop='static' id="modal-publicacion" tabindex="-1"
                                 aria-hidden="true">
                                <div class="modal-dialog modal-xl modal-dialog-centered modal-edit-user">
                                    <div class="modal-content">
                                        <div class="modal-header bg-transparent">
                                            <h3 class="mb-0">Publicaciones</h3>
                                            <button type="button" class="btn-close btn-close-modal"
                                                    data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div id="modal-publicacion-body" class="modal-body pb-5 px-sm-5 pt-50">
                                            <form id="frmPublicacion" class="form-control border-0"
                                                  action="javascript:void(0)">
                                                <div id="address-step-vertical" class="content" role="tabpanel"
                                                     aria-labelledby="address-step-vertical-trigger">
                                                    <div class="content-header">
                                                        <small class="text-muted"></small>
                                                    </div>
                                                    <div class="row">
                                                        <div class="mt-1 mb-1 col-md-12">
                                                            <label class="form-label" for="nombre_publicacion">Nombre
                                                                Publicación</label>
                                                            <input type="text" id="nombre_publicacion"
                                                                   name="nombre_publicacion"
                                                                   class="form-control"
                                                                   placeholder="" required>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="mb-1 col-md-3  mt-5">
                                                            <label class="form-label" for="fecha_inicio">Fecha de
                                                                Inicio</label>
                                                            <input type="date" id="fecha_inicio" class="form-control"
                                                                   required>
                                                        </div>
                                                        <div class="mb-1 col-md-3  mt-5">
                                                            <label class="form-label" for="fecha_termino">Fecha de
                                                                Término</label>
                                                            <input type="date" id="fecha_termino" class="form-control"
                                                                   required>
                                                        </div>

                                                        <div class="mb-1 col-md-12  mt-5">
                                                            <label class="form-label"
                                                                   for="select_audiencia">Audiencia</label>
                                                            <select class="form-select col-md-12" id="select_audiencia"
                                                                    required>
                                                                <option value="">Seleccionar audiencia</option>
                                                            </select>
                                                        </div>

                                                        <div class="mb-1 col-md-12  mt-5">
                                                            <label class="form-label"
                                                                   for="vselect_documento">Documento</label>
                                                            <select class="form-select" id="select_documento" required>
                                                                <option value="">Seleccionar documento</option>
                                                            </select>
                                                        </div>

                                                        <div class="mb-1 col-md-3  mt-5">
                                                            <label class="form-label"
                                                                   for="select_clasificacion">Clasificación</label>
                                                            <select class="form-select" id="select_clasificacion"
                                                                    required>
                                                                <option value="">Seleccionar clasificación</option>
                                                            </select>
                                                        </div>
                                                        <div class="mb-1 col-md-3  mt-5">
                                                            <label class="form-label"
                                                                   for="select_negocio">Negocio</label>
                                                            <select class="form-select" id="select_negocio" required>
                                                                <option value="">Seleccionar negocio</option>
                                                            </select>
                                                        </div>
                                                        <div class="mb-1 col-md-3  mt-5">
                                                            <label class="form-label"
                                                                   for="select_perfil">Perfil de Visualización</label>
                                                            <select class="form-select" id="select_perfil" required>
                                                                <option value="">Seleccionar visualización</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex justify-content-between  mt-5">
                                                        <button class="btn btn-outline-secondary btn-prev waves-effect"
                                                                disabled="">
                                                            <span
                                                                class="align-middle d-sm-inline-block d-none">Previous</span>
                                                        </button>

                                                    </div>
                                                </div>
                                                <div class="d-flex justify-content-between  mt-5">

                                                    <button id="guardarPublicacion" type="submit"
                                                            class="dt-button create-new button default small waves-effect waves-float waves-light">
                                                        <span class="align-middle d-sm-inline-block ">Guardar</span>

                                                    </button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if(session('perfilmi')==111)
                        <div class="tab-pane" id="viewUser" aria-labelledby="viewUser-tab" role="tabpanel">
                            <div class="row">
                                <div class="col-12 col-sm-4">
                                    <label>Ingrese rut del colaborador</label>
                                    <input id="rutUser" class="form-control" type="text">
                                </div>
                                <div class="col-12 col-sm-4">
                                    <button class="button default small mt-6" id="btnViewUser"><i data-feather="eye"
                                                                                                  class="mr-2"></i> Ver
                                    </button>
                                </div>
                                <div class="col-12 col-sm-4">
                                    <h3 id="nameUser"></h3>
                                    <h4 id="cargoUser"></h4>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection

