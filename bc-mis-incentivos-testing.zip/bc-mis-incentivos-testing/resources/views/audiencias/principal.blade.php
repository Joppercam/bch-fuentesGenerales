@extends('layouts.audiencias')
@section('title', 'Audiencias')
@section('content')
    <style>
        .swal2-container {
            z-index: 10001 !important;
        }
    </style>
    <h1>Audiencias</h1>
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
                <div class="contenedorListarAudiencias">
                    <table border="0" cellspacing="5" cellpadding="5">
                        <tbody>
                        <tr>
                            <td>Desde: <input class="form-control" type="text" id="min" name="min"></td>

                            <td>Hasta: <input class="form-control" type="text" id="max" name="max">
                            <td>
                            <td>
                                <button id="btnRefresh" type="button"
                                        class="btn btn-icon btn-outline-primary  mt-5 pt-1 br-2" title="Limpiar fechas">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                         fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                         stroke-linejoin="round" class="feather feather-refresh-cw">
                                        <polyline points="23 4 23 10 17 10"></polyline>
                                        <polyline points="1 20 1 14 7 14"></polyline>
                                        <path
                                            d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                                    </svg>
                                </button>
                            </td>
                            <td id="tdFilterCreator">
                                <label>Filtrar por creador</label>
                                <select class="form-control" id="am_aplicacion_id">
                                    <option value="">Todos</option>
                                    @foreach($autores as $row)
                                        @if($row->autor==Auth::user()->rut)
                                            <option value="{{$row->autor}}" selected>{{$row->nombre_completo}}</option>
                                        @else
                                            <option value="{{$row->autor}}">{{$row->nombre_completo}}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <table id="lista_audiencias" class="display lista_audiencias table" style="width:100%">
                        <thead>
                        <tr>
                            <th><input type="checkbox" id="select-all"></th>
                            <th>id_audiencia</th>
                            <th>Nombre</th>
                            <th>Fecha</th>
                            <th>Fecha creación</th>
                            <th>Rut Autor</th>
                            <th>Creador</th>
                            <th>Fecha edición</th>
                            <th>Num Colaboradores</th>
                            <th>Col. Incluidos</th>
                            <th>Col. Excluidos</th>
                            <th>Cargos</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>

                    </table>


                    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBackdropFormulario"
                         aria-labelledby="offcanvasBackdropLabel" style="width: 1300px">
                        <div class="offcanvas-header">
                            <h1 id="offcanvasBothLabel" class="offcanvas-title">Usuarios asignados</h1>
                            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                                    aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body my-auto mx-0 " style="overflow-y">

                            <!--contenedor de usuarios en lista de asignados-->
                            <div id="containerDocumentosUsuariosAsignados" class="mb-5" style="overflow-y: auto;">
                                <table id="lista_audiencias_usuarios_ver"
                                       class="lista_audiencias_usuarios_ver table display" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>Rut</th>
                                        <th>Nombre completo</th>
                                        <th>División</th>
                                        <th>Unidad</th>
                                        <th>Cargo</th>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                        <!--modal de asignacion de usuarios a documento-->
                        <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                             style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                            <div class="align-self-right">
                                <button type="button" class="button default align-self-right"
                                        data-bs-dismiss="offcanvas">
                                    Cerrar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" backdrop='static' id="modal-audiencia" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-xl modal-dialog-centered modal-edit-user">
                        <div class="modal-content">
                            <div class="modal-header bg-transparent">
                                <h3 class="mb-0">Audiencias</h3>
                                <button type="button" class="btn-close btn-close-modal" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                            </div>
                            <div id="modal-audiencia-body" class="modal-body pb-5 px-sm-5 pt-50">
                                <div id="account-details-vertical" class="content active dstepper-block"
                                     role="tabpanel"
                                     aria-labelledby="account-details-vertical-trigger">
                                    <form id="frmAudiencia" action="javascript:void(0)">
                                        <div class="row">
                                            <div class="mt-1 mb-1 col-md-12">
                                                <label class="form-label" for="nombre_audiencia">Nombre
                                                    Audiencia</label>
                                                <input type="text" id="nombre_audiencia"
                                                       class="form-control" name="nombre_audiencia"
                                                       placeholder="" required>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label"
                                                       for="selectDivision">División</label>
                                                <select class="form-select" id="selectDivision" name="selectDivision[]"
                                                        multiple="multiple">
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label" for="selectUnidad">Unidad</label>
                                                <select class="form-select" id="selectUnidad" name="selectUnidad[]"
                                                        multiple="multiple">
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label" for="selectCargo">Cargo</label>
                                                <select class="form-control" multiple="multiple" name="selectCargo[]"
                                                        id="selectCargo">
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="d-flex justify-content-center  mt-5">
                                                <button type="button" id="visualizarUsuarios" data-bs-toggle="offcanvas"
                                                        data-bs-target="#offcanvasBackdrop"
                                                        aria-controls="offcanvasBackdrop"
                                                        class="button secondary small mx-4">
                                                    <span
                                                        class="align-middle d-sm-inline-block ">Visualizar usuarios</span>
                                                </button>
                                                <button type="button" id="visualizarUsuariosExInc"
                                                        data-bs-toggle="offcanvas"
                                                        data-bs-target="#offcanvasBackdrop"
                                                        aria-controls="offcanvasBackdrop"
                                                        class="button secondary small mx-4">
                                                    <span
                                                        class="align-middle d-sm-inline-block ">Usuarios Incluidos/Excluidos</span>
                                                </button>
                                            </div>
                                            <div class="mb-5  mt-5 form-password-toggle col-md-12">
                                                <label class="form-label" for="vertical-username">Sube xlsx con
                                                    exclusion o inclusion</label>
                                                <input type="file" id="multimediaFiles"
                                                       name="multimediaFiles"
                                                       data-show-caption="true"
                                                       accept=".xlsx">
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-end  mt-5">
                                            <button id="saveAudiencia" type="submit"
                                                    class=" editar-button dt-button create-new button default small waves-effect waves-float waves-light">
                                                <span class="align-middle d-sm-inline-block ">Guardar</span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                     stroke-width="2"
                                                     stroke-linecap="round" stroke-linejoin="round"
                                                     class="feather feather-arrow-right align-middle ms-sm-25 ms-0">
                                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                                    <polyline points="12 5 19 12 12 19"></polyline>
                                                </svg>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal usuarios asignados -->

                <!-- Modal usuarios asignados -->
                <div class="enable-backdrop" style="z-index: 10001;">
                    <div class="offcanvas offcanvas-end" tabindex="-1"
                         id="offcanvasBackdrop"
                         aria-labelledby="offcanvasBackdropLabel"
                         style="width: 1300px">
                        <div class="offcanvas-header">
                            <h1 id="offcanvasBothLabel" class="offcanvas-title">
                                Usuarios asignados</h1>
                            <button type="button" class="btn-close text-reset"
                                    data-bs-dismiss="offcanvas"
                                    aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body my-auto mx-0 "
                             style="overflow-y">

                            <!--contenedor de usuarios en lista de asignados-->
                            <div id="containerDocumentosUsuariosAsignados"
                                 class="mb-5" style="overflow-y: auto;">
                                <table id="lista_audiencias_usuarios"
                                       class="lista_audiencias_usuarios table display"
                                       style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>Rut</th>
                                        <th>Nombre completo</th>
                                        <th>División</th>
                                        <th>Unidad</th>
                                        <th>Cargo</th>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                        <!--modal de asignacion de usuarios a documento-->
                        <div class="offcanvas-footer my-auto mx-0 footerBackdrop"
                             style="text-align: right;padding-right: 50px;padding-bottom: 50px;">
                            <div class="align-self-right">
                                <button type="button"
                                        class="button default align-self-right"
                                        data-bs-dismiss="offcanvas">
                                    Cerrar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <script>
        const listAudiencias = "{{route('listarAudiencias')}}"
    </script

@endsection

