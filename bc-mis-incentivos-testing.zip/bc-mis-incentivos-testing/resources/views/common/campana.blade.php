<li class="nav-item dropdown dropdown-notification dropdown-cart me-25 mr-1-timeline">
    <a class="nav-link campana-timeline" href="#" data-bs-toggle="dropdown">
        <i class="ficon" data-feather="bell"></i>
        <span class="badge rounded-pill bg-danger badge-up">{{session('notificaciones')}}</span>
    </a>
    <ul class="dropdown-menu dropdown-menu-media dropdown-menu-end">
        <li class="dropdown-menu-header">
            <div class="dropdown-header d-flex">
                <h4 class="notification-title mb-0 me-auto">Notificaciones</h4>
            </div>
        </li>
        <li class="scrollable-container media-list ps listNotificationsBeld" style="min-height: 100px;">
            <a class="d-flex" href="javascript:void(0)">
                <div class="list-item d-flex align-items-start">
                    <p class="mb-0">No tienes notificaciones</p>
                </div>
            </a>
            <div id="notificationsContent">
            </div>
        </li>
        <li class="dropdown-menu-footer d-none containerMoreNotif">
            <a class="btn btn-primary w-100" href="./notificacionesCampana">Todas las
                notificaciones
            </a>
        </li>
    </ul>
</li>
