<div class="toast-container">
    <div class="toast basic-toast position-fixed top-0 end-0 m-2" role="alert" aria-live="assertive"
         aria-atomic="true" style="z-index:1056">
        <div class="toast-header">
            <strong class="me-auto">Información</strong>
            <small class="text-muted">en este momento</small>
            <button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body"></div>
    </div>
</div>
