<div id="spinner">
    <section class="spinner my-6">
        <div class="bounce1"></div>
        <div class="bounce2"></div>
        <div class="bounce3"></div>
    </section>
</div>
