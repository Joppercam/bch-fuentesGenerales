<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
<meta name="description"
      content=".">
<meta name="keywords"
      content="Mis incentivos">
<meta name="author" content="GOP">
<title>Mis incentivos</title>
<!-- faivcon -->
<link rel="Shortcut Icon" type="image/x-icon"
      href="{{ asset('images/favicon.ico') }}"/>
<link rel="apple-touch-icon"
      href="{{ asset('images/favicon.ico') }}"/>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600"
      rel="stylesheet">



<!-- BEGIN: Vendor CSS-->
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/vendors/css/vendors.min.css?v1.0.7')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/vendors/css/file-uploaders/dropzone.min.css?v1.0.7')}}">

<link rel="stylesheet" type="text/css" href="{{ asset('css/extensions/nouislider.min.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('css/extensions/toastr.min.css?v1.0.7') }}"/>
<!-- END: Vendor CSS-->
<!-- BEGIN: Theme CSS-->
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-extended.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('css/colors.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('css/extensions/ext-component-sliders.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('css/fonts/font-awesome/css/font-awesome.css?v1.0.7') }}"/>

<link rel="stylesheet" href="{{ asset('css/bch-ui-kit.css?1.0.7') }}"/>
<link rel="stylesheet" href="{{ asset('public/app-assets/css/core/menu/menu-types/horizontal-menu.css?1.0.7') }}"/>
<!-- END: Page CSS-->
<!-- BEGIN: Custom CSS-->
<link rel="stylesheet" type="text/css" href="{{ asset('css/style.css?v1.0.8') }}"/>
<!-- END: Custom CSS-->

<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/vendors/css/forms/wizard/bs-stepper.min.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/vendors/css/forms/select/select2.min.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/plugins/forms/form-validation.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/plugins/forms/form-wizard.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/plugins/forms/form-file-uploader.css?v1.0.7') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/plugins/forms/form-file-uploader.min.css?v1.0.7')}}">



<!--DATATABLES-->
<link rel="stylesheet" type="text/css"
      href="{{ asset('public/app-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css') }}">
<link rel="stylesheet" type="text/css"
      href="{{ asset('public/app-assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css') }}">
<link rel="stylesheet" type="text/css"
      href="{{ asset('public/app-assets/vendors/css/tables/datatable/buttons.bootstrap5.min.css') }}">
<link rel="stylesheet" type="text/css"
      href="{{ asset('public/app-assets/vendors/css/tables/datatable/rowGroup.bootstrap5.min.css') }}">
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.2.7/css/select.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="{{ asset('css/components.css?v1.0.8') }}"/>
<link rel="stylesheet" type="text/css" href="{{ asset('public/app-assets/css/components.css?v1.0.8') }}"/>
<!--DATATABLES-->

<body class="mat-bch horizontal-layout horizontal-menu  navbar-floating footer-static  " data-open="hover"
      data-menu="horizontal-menu" data-col="">
<script>
    var csrf = "{{ csrf_token() }}";
</script>
