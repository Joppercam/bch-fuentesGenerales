
<!-- <footer class="footer footer-static footer-light">
</footer> -->
<footer></footer>
<button class="btn btn-primary btn-icon scroll-top d-none" type="button"><i data-feather="arrow-up"></i></button>
<!-- END: Footer-->
</body>
<!-- BEGIN: Vendor JS-->
<script src="{{ asset('js/scripts/vendors.min.js?v2')}}"></script>
<script src="{{ asset('public/app-assets/js/scripts/purify.js')}}"></script>

<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/dataTables.bootstrap5.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/responsive.bootstrap5.min.js') }}"></script>
<script src="https://cdn.datatables.net/select/1.6.2/js/dataTables.select.min.js"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/jszip.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/pdfmake.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/vfs_fonts.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/buttons.html5.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/buttons.print.min.js') }}"></script>
<script src="{{ asset('public/app-assets/vendors/js/tables/datatable/dataTables.rowGroup.min.js') }}"></script>
<script src="{{ asset('public/app-assets/js/scripts/extensions/loadingoverlay.min.js')}}"></script>
<script src="{{ asset('public/app-assets/vendors/js/extensions/sweetalert2.all.min.js') }}"></script>
<script src="{{ asset('js/global.js')}}"></script>

<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    let rutTmp = {{auth()->user()->rut}};
    let avatarDefault ="{{asset('images/robot.png')}}";
</script>

<script>
    $(window).on('load', function () {
        if (feather) {
            feather.replace({
                width: 14,
                height: 14
            });
        }
    })

    const loading = {
        image  : "",
        custom  : '<div class="spinner-border text-primary" role="status"></div>'
    };
</script>
