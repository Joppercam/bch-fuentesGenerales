<div class="horizontal-menu-wrapper">
    <div
        class="header-navbar navbar-expand-sm navbar navbar-horizontal floating-nav navbar-light navbar-shadow menu-border container-fluid mt-0"
        role="navigation" data-menu="menu-wrapper" data-menu-type="floating-nav">
        <div class="navbar-header p-0">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item me-auto text-center">
                    <h2 class="brand-text mb-0">Mis incentivos</h2>
                    <a class="navbar-brand" href="{{route('home')}}">
                        <span class="brand-logo">
                            <i class="icon-icon-bch-logo-bch size-icon-md c-brand d-flex ai-c pl-3 blw-3"></i>
                        </span>
                    </a>
                </li>
                <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pe-0" data-bs-toggle="collapse">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                             class="feather feather-x d-block d-xl-none text-primary toggle-icon font-medium-4">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </a>
                </li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <!-- Horizontal menu content-->
        <div class="navbar-container main-menu-content" data-menu="menu-container">
            <ul class="nav navbar-nav m-0" id="main-menu-navigation" data-menu="menu-navigation">
                <li data-menu="">
                    <a class="nav-link d-flex align-items-center"
                       href="./inicio"
                       data-bs-toggle="">
                        <i data-feather='home' class="size-icon-xl"></i>
                    </a>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown">
                    <a class="dropdown-toggle nav-link d-flex align-items-center" href="#"
                       data-bs-toggle="dropdown">
                        <i data-feather='list'></i>
                        <span data-i18n="archive">Listar</span>
                    </a>
                    <ul class="dropdown-menu" data-bs-popper="none">
                        @if(session('perfilmi')==111)
                            <li data-menu="">
                                <a class="dropdown-item d-flex align-items-center"
                                   href="audiencias"
                                   data-bs-toggle="" data-i18n="archive">
                                    <i data-feather='users'></i>
                                    <span data-i18n="users">Audiencia</span>
                                </a>
                            </li>
                            <li data-menu="">
                                <a class="dropdown-item d-flex align-items-center"
                                   href="documentos"
                                   data-bs-toggle="" data-i18n="archive">
                                    <i data-feather='file'></i>
                                    <span data-i18n="file">Documentos</span>
                                </a>
                            </li>
                        @endif
                        <li data-menu="">
                            <a class="dropdown-item d-flex align-items-center"
                               href="publicaciones"
                               data-bs-toggle="" data-i18n="archive">
                                <i data-feather='file-text'></i>
                                <span data-i18n="file-text">Publicaciones</span>
                            </a>
                        </li>
                    </ul>
                </li>
                @if(session('perfilmi')==111)
                    <li class="nav-item">
                        <a class="nav-link d-flex align-items-center" href="reportes">
                            <i data-feather='grid'></i>
                            <span data-i18n="grid">Reportes</span>
                        </a>
                    </li>
                    <li class="dropdown nav-item" data-menu="dropdown">
                        <a class="dropdown-toggle nav-link d-flex align-items-center" href="#"
                           data-bs-toggle="dropdown">
                            <i data-feather='list'></i>
                            <span data-i18n="archive">Notificaciones</span>
                        </a>
                        <ul class="dropdown-menu" data-bs-popper="none">
                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="notificaciones">
                                    <i data-feather='mail'></i>
                                    <span data-i18n="mail">Notificaciones</span>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="templates">
                                    <i data-feather='grid'></i>
                                    <span data-i18n="grid">Templates</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center" href="#">
                        <i data-feather='log-out'></i>
                        <span data-i18n="log-out">Cerrar sesión</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
