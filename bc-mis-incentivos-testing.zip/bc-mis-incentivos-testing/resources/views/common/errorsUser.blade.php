<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Ups... Ha ocurrido un error</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- faivcon -->
    <link rel="Shortcut Icon" type="image/x-icon"
          href="{{ asset('images/favicon.ico') }}"/>
    <link rel="apple-touch-icon"
          href="{{ asset('images/favicon.ico') }}"/>
    <!-- Styles -->
    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap-extended.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/colors.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/components.css?v1.0.2') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/themes/dark-layout.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/themes/bordered-layout.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/themes/semi-dark-layout.css') }}">
    <link href="{{ asset('css/style.css?v1.0.2') }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/plugins/forms/form-validation.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/pages/authentication.css?v1.0.0') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bch-ui-kit.css?v1.0.0') }}">
</head>
<style>
    .bch-login {
        padding: 1rem;
    }

    .mat-bch .button {
        position: relative;
        color: #ffffff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 0.875rem;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        line-height: 1.5rem;
        min-height: 40px;
        padding: 1rem 1.5rem;
        margin-bottom: 1rem;
        border: none;
        border-radius: 16.875rem;
        transition: all 0.5s ease-in-out;
        z-index: 100;
    }

    .mat-bch .button:hover {
        color: #ffffff;
        box-shadow: 0 4px 12px rgb(0 36 100 / 20%);
    }

    .mat-bch .button.default {
        background-color: #295EFF;
        background: linear-gradient(135deg, #5583FF 0%, #295EFF 100%);
    }

    .auth-wrapper.auth-basic .auth-inner {
        max-width: 600px;
    }

    .auth-wrapper.auth-basic {
        align-items: center;
        justify-content: left;
        overflow: hidden;
        margin-left: 60px;
    }

    @media (max-width: 800px) {
        .bch-login {
            padding: 1.5rem;
        }
    }
</style>
<body class="vertical-layout vertical-menu-modern blank-page navbar-floating footer-static   menu-collapsed"
      data-open="click" data-menu="vertical-menu-modern" data-col="blank-page">
<div class="mat-bch content-body content-login">
    <div class="auth-wrapper auth-basic px-2">
        <div class="auth-inner my-2">
            <!-- Login basic -->
            <div class="bch-login card mb-0">
                <div class="card-body ta-c">
                    <a href="https://localhost/bch/firma_dig/" class="brand-logo">
                        <h2 class="brand-text mr-2 mt-2 tt-u c-error--imp">Ha ocurrido un error</h2>
                        @if(env('APP_ENV')=="productivo")
                            <i class="icon-icon-bch-logo-bch size-icon-lg c-brand d-flex ai-c pl-3 blw-3"></i>
                        @else

                        @endif
                    </a>
                    <p class="ta-c c-gray-dark c-re">Han ocurrido un error de ejecución</p>
                    <a class="button default" type="button" href="./">
                        Volver al inicio
                    </a>
                    <p class="text--small mb-2 fw-b">¿Necesitas ayuda?</p>
                    <p class="text--smaller px-4 mb-0">Si tienes problemas contacta a la <b>Mesa de Ayuda</b>:</p>
                    <p class="text--smaller px-4 mt-n1 mb-0 letra">
                        Correo:
                        <a class="link mail" href="mailto:G_MAUBancoChile@entel.cl">
                                <span class="link__wrapper">
                                    <span class="link__text text--smaller">G_MAUBancoChile@entel.cl</span>
                                </span>
                        </a>
                    </p>
                </div>
            </div>
            <!-- /Login basic -->
        </div>
    </div>
</div>
</body>
</html>
