<nav aria-label="Page navigation example">
  <ul class="pagination d-flex justify-content-center">
    {{-- <li class="page-item">
      <a class="page-link" href="#" aria-label="Previous">
        <span aria-hidden="true">«</span>
      </a>
    </li>
    <li class="page-item active pag-active"><a class="page-link paginacion" href="#">1</a></li>
    <li class="page-item">                  <a class="page-link paginacion" href="#">2</a></li>
    <li class="page-item">                  <a class="page-link paginacion" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">»</span>
      </a>
    </li> --}}
  </ul>
</nav>

<script>
  function cargarPaginador(publicaciones) {
    if (publicaciones > 0) {
      let totalPaginas = Math.trunc(publicaciones / 10);
      if (publicaciones % 10 != 0) {
          totalPaginas++;
      }
      let primeraPagina = `
          <li class="page-item">
              <a class="page-link" href="#" aria-label="Previous" onclick="llenarPublicaciones(1)">
                  <span aria-hidden="true">«</span>
              </a>
          </li>
      `;
      let ultimaPagina = `
          <li class="page-item">
              <a class="page-link" href="#" onclick="llenarPublicaciones(${totalPaginas})" aria-label="Previous">
                  <span aria-hidden="true">»</span>
              </a>
          </li>
      `;
      let paginasInternas = "";
      for(let i = 1; i <= totalPaginas; i++){
          paginasInternas += `
              <li class="page-item page_${i}"><a class="page-link paginacion" href="#" onclick="llenarPublicaciones(${i})">${i}</a></li>
          `;
      }
      let html = primeraPagina + paginasInternas + ultimaPagina;
      $(".pagination").html(html);
    }
  }
</script>