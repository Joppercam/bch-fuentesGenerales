@extends('layouts.inicio')
@section('title', 'Inicio')
@section('content')
    <div class="toast-container">
        <div class="toast basic-toast position-fixed top-0 end-0 m-2" role="alert" aria-live="assertive"
             aria-atomic="true">
            <div class="toast-header">
                <strong class="me-auto">Información</strong>
                <small class="text-muted">en este momento</small>
                <button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body"></div>
        </div>
    </div>
    <div class="container-fluid contentHome">
        <div class="row">
            <h1>Bienvenido a Mis incentivos</h1>
        </div>
        <section id="dashboard-detail">
            <div class="row match-height">
                <!-- Statistics Card -->
                <div class="col-12  mt-6">
                    <div class="card card-statistics">
                        <div class="card-body statistics-body">
                            <div class="row">
                                <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-xl-0">
                                    <div class="d-flex flex-row">
                                        <div class="avatar bg-light-info me-2">
                                            <div class="avatar-content">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                     class="feather feather-user avatar-icon">
                                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                                    <circle cx="12" cy="7" r="4"></circle>
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="my-auto">
                                            <h4 id="totalAudiencias" class="fw-bolder mb-0">{{$totAudiencia}}</h4>
                                            <p class="card-text font-small-4 mb-0 fw-b c-brand-dark">Audiencias</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-sm-0">
                                    <div class="d-flex flex-row">
                                        <div class="avatar bg-light-danger me-2">
                                            <div class="avatar-content">
                                                <i data-feather='file-text'></i>
                                            </div>
                                        </div>
                                        <div class="my-auto">
                                            <h4 id="totalDocumentos" class="fw-bolder mb-0">{{$totDocumento}}</h4>
                                            <p class="card-text font-small-4 mb-0 fw-b c-brand-dark">Documentos</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-sm-6 col-12">
                                    <div class="d-flex flex-row">
                                        <div class="avatar bg-light-success me-2">
                                            <div class="avatar-content">
                                                <i data-feather='book-open'></i>
                                            </div>
                                        </div>
                                        <div class="my-auto">
                                            <h4 id="totalPublicaciones" class="fw-bolder mb-0">{{$totPublicacion}}</h4>
                                            <p class="card-text font-small-4 mb-0 fw-b c-brand-dark">Publicaciones</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-xl-0">
                                    <div class="d-flex flex-row">
                                        <div class="avatar bg-light-primary me-2">
                                            <div class="avatar-content">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                     class="feather feather-trending-up avatar-icon">
                                                    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                                                    <polyline points="17 6 23 6 23 12"></polyline>
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="my-auto">
                                            <h4 id="porcenVisuali" class="fw-bolder mb-0">{{$porcenVisual}}%</h4>
                                            <p class="card-text font-small-4 mb-0 fw-b c-brand-dark">Por.
                                                visualización</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ Statistics Card -->
            </div>

            <div class="row match-height ">
                <!-- Revenue Report Card -->
                <div class="col-12 ">
                    <div class="card card-revenue-budget">
                        <div class="row mx-0">
                            <div class="col-12 revenue-report-wrapper" style="position: relative;">
                                <div class="d-sm-flex justify-content-between align-items-center mb-3">
                                    <h4 class="card-title mb-50 mb-sm-0">Resumen de publicaciones</h4>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead class="table-light">
                                    <tr id="trMeses" class="text-center">
                                    </tr>
                                    <tr id="trTittles" class="text-center">

                                    </tr>
                                    </thead>
                                    <tbody id="trDatos">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ Revenue Report Card -->
            </div>
        </section>
    </div>
@endsection
