@extends('layouts.reportes')
@section('title', 'Reportes')
@section('content')
    <a href="" download="" id="linkDownload"></a>
    <div class="toast-container">
        <div class="toast basic-toast position-fixed top-0 end-0 m-2" role="alert" aria-live="assertive"
             aria-atomic="true">
            <div class="toast-header">
                <strong class="me-auto">Información</strong>
                <small class="text-muted">en este momento</small>
                <button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body"></div>
        </div>
    </div>
    <h1>Reportes</h1>
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
                <div class="contenedorReportes">
                    <div class="row">
                        <div class="col-xs-12 col-lg-6">
                            <label>Seleccione su reporte</label>
                            <select class="form-control" id="selReporte">
                                <option value="PublicacionesByRut">Publicaciones por RUT</option>
                                <option value="ListVisualizaciones">Visualización</option>
                                <option value="ListVisualizacionesPercent">Porcentaje visualización</option>
                                <option value="AudenciasNuevosColaboradores">Personas Nuevas</option>
                                <option value="ListAudienciaDetail">Audiencias estructura detallada</option>
                                <option value="ListAudiencias">Audiencias Activas</option>
                                <option value="reportNotificaciones">Notificaciones</option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-6 containerDates">
                            <div class="row">
                                <div class="col-xs-12 col-md-6">
                                    <label>Desde</label>
                                    <input class="form-control" type="date" id="filterDesde">
                                </div>
                                <div class="col-xs-12 col-md-6">
                                    <label>Hasta</label>
                                    <input class="form-control" type="date" id="filterHasta">
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-6 d-none containerAudiencias">
                            <label class="form-label"
                                   for="select_audiencia">Audiencias</label>
                            <select class="form-select col-md-12" id="select_audiencia">
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center  mt-5">
                        <button id="generarReporte" type="submit"
                                class="dt-button button default small waves-effect waves-float waves-light">
                            <span class="align-middle d-sm-inline-block ">Generar</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
@endsection

