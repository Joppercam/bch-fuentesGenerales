<?php

return [
    //VERSION GLOBAL
    'version' => 'v1.2.0.1',
    'perfiles' => [111 => 'admin', 135 => 'GestionInc', 113 => 'ControlGestion']
];
