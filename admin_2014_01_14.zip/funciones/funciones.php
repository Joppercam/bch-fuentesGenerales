<?php

function Utf8_parametro($string){
    global $utf_var;
    if($utf_var==1){
        // echo "Utf8_parametro a";
        $string_utf=utf8_encode($string)."";
    } else {
        // echo "Utf8_parametro b";
        $string_utf=($string)."";
    }
    return $string_utf;
}
function Utf8_parametroInv($string){
    global $utf_var;
    if($utf_var==1){
        // echo "Utf8_parametro a";
        $string_utf=($string)."";
    } else {
        // echo "Utf8_parametro b";
        $string_utf=utf8_encode($string)."";
    }
    return $string_utf;
}
function Utf8_decode_parametroInv($string){
    global $utf_var;
    if($utf_var==1){
        // echo "Utf8_parametro a";
        $string_utf=utf8_decode($string)."";
    } else {
        // echo "Utf8_parametro b";
        $string_utf=($string)."";
    }
    return $string_utf;
}
function Utf8_decode_parametro($string){
    //echo "Utf8_decode_parametro ".$string;
    global $utf_var;
    if($utf_var==0){
         //echo "<br>Utf8_parametro a";
        $string_utf=utf8_decode($string)."";
    } else {
         //echo "<br>Utf8_parametro b";
        $string_utf=($string)."";
    }
    //echo "<br>$string_utf";exit();
    return $string_utf;
}
function Agradecimientos_Masivos_Lista($PRINCIPAL, $id_empresa, $filtro, $activa, $vigencia_usuarios){

	$row = file_get_contents("views/puntos/entorno_puntos_stock.html");
    return($PRINCIPAL);
}
function lista_puntos_stock($html, $id_empresa, $idcategoria)
{
    //$lista_puntos_stock_fe = lista_puntos_stock_data($id_empresa);
    //print_r($lista_puntos_stock_fe);    //$categorias_options=mp_busca_Categorias($id_empresa);    //print_r($categorias_options);

    $row = file_get_contents("views/puntos/entorno_puntos_stock.html");
    foreach($lista_puntos_stock_fe as $unico)
    {

        $saldo=round($unico->stock - $unico->canjeados);

        if($saldo<0){$saldo=0;}
        $row = file_get_contents("views/puntos/row_puntos_stock.html");
        $row = str_replace("{ID}", ($unico->id) , $row);
        $row = str_replace("{ORDEN}", ($unico->orden) , $row);
        $row = str_replace("{CODIGO}", ($unico->id_premio) , $row);
        $row = str_replace("{NOMBRE}", ($unico->premio) , $row);
        $row = str_replace("{DESCRIPCION}", ($unico->premio_descripcion) , $row);
        $row = str_replace("{CONDICIONES}", ($unico->condiciones) , $row);
        $row = str_replace("{REQUISITOS}", ($unico->requisitos) , $row);
        $row = str_replace("{DIMENSION}", ($unico->TextoDim) , $row);
        $row = str_replace("{SEGMENTO}", ($unico->segmento) , $row);
        $row = str_replace("{PUNTOS}", ($unico->puntos) , $row);
        $row = str_replace("{CANJEADOS}", ($unico->canjeados) , $row);
        $row = str_replace("{VALIDAJEFE}", ($unico->aprobacionjefe) , $row);
        $row = str_replace("{TEMPORAL}", ($unico->temporalidad) , $row);
        $row = str_replace("{REGION}", ($unico->region) , $row);
        $row = str_replace("{DIA}", ($unico->dia) , $row);
        $row = str_replace("{SOLICITADIA}", ($unico->solicitadia) , $row);
        $row = str_replace("{ULTIMASUNIDADES}", ($unico->alertaultimasunidades) , $row);
        $row = str_replace("{STOCK}", ($unico->stock) , $row);
        $row = str_replace("{SALDO}", $saldo , $row);
        $row = str_replace("{ALERTAWEB}", ($unico->alertaweb) , $row);
        $row = str_replace("{ALERTAEMAILCOL}", ($unico->alertaemailusuario) , $row);
        $row = str_replace("{ALERTAEMAILJEFE}", ($unico->alertaemailjefe) , $row);
        $row = str_replace("{IMAGEN}", ($unico->imagen) , $row);
        $row = str_replace("{FECHA_VENCIMIENTO}", ($unico->fecha_vencimiento) , $row);
        $row = str_replace("{FECHA_INICIO}", ($unico->fecha_inicio) , $row);
        $row = str_replace("{RESTRICCION_RUT}", ($unico->restriccion_rut) , $row);
        $total_html.= $row;
    }

    $html = str_replace("{LISTA}", $total_html, $html);
    $html = str_replace("{TITULO}", "Gestión de Stock", $html);
    $html = str_replace("{BTN}", "Nueva Pregunta", $html);
    $html = str_replace("{BTN_A}", "?sw=admin_biblio&n=fc", $html);
    $html = str_replace("{BTN_VOLVER}", '', $html);
    $html = str_replace("{COLUMNA}", 'Pregunta', $html);
    return ($html);
}
function Otas_2022_Lista_Participantes_Induccion_Otas($PRINCIPAL, $id_empresa, $id_inscripcion, $activa, $vigencia_usuarios){
    $cuenta=0;
    $Automatizacion=Ota_Induccion_Automatizacion_2022();
    foreach ($Automatizacion as $unico1){
        //echo "<br>-> ". $unico1->id_malla." ".$unico1->id_notificacion_email."<br>";
        $sql_usuarios="			select 
						
																* from ". $unico1->tbl_1_trigger." 
																
																where
																
																". $unico1->campo_1_trigger."
																". $unico1->condicion_1_trigger."
																'". $unico1->dato_1_trigger."'
																
																and
																
																". $unico1->campo_2_trigger."
																". $unico1->condicion_2_trigger."
																'". $unico1->dato_2_trigger."'

																and
																
																". $unico1->campo_3_trigger."
																". $unico1->condicion_3_trigger."
																'". $unico1->dato_3_trigger."'

																";


        $Ruts=Ota_Induccion_Automatizacion_usuarios_2022($sql_usuarios);
        foreach ($Ruts as $unico2){

            $ListaParticipantes[$cuenta]["rut"]=$unico2->rut;
            $ListaParticipantes[$cuenta]["id_malla"]=$unico1->id_malla;
            $ListaParticipantes[$cuenta]["id_notificacion_email"]=$unico1->id_notificacion_email;
            $cuenta++;
        }

    }



    foreach ($ListaParticipantes as $unico){
        //print_r($unico);
        //echo "<br>unico ".$unico["rut"]." ".$unico["id_malla"]." ".$unico["id_notificacion_email"];

        $rows.=file_get_contents("views/gestion_otas_2022/row_participantes_otas_induccion.html");
        $rows= str_replace("{RUT}",										$unico["rut"],$rows);
        $usu=Otas_2022_checkUserVigenteTblusuario($unico["rut"]);

        if($usu[0]->nombre_completo==""){
            $usu[0]->nombre_completo="NO VIGENTE";
        }
        $rows= str_replace("{NOMBRE_COMPLETO}",				$usu[0]->nombre_completo,$rows);
        $rows= str_replace("{CARGO}",									$usu[0]->cargo,$rows);
        $rows= str_replace("{EMAIL}",									$usu[0]->email,$rows);
        $rows= str_replace("{DIVISION}",							$usu[0]->division,$rows);
        $rows= str_replace("{FECHA_INGRESO}",					$usu[0]->fecha_ingreso,$rows);
        $Ota=Ota_Busca_InscripcionUsuarios_LogEmail($unico["rut"],$unico["id_malla"],$unico["id_notificacion_email"]);
        $Malla=DatosMalla_2022($unico["id_malla"]);

        //$Check=CheckOtaParticipante_2022($unico->rut, $id_inscripcion, $unico->id_curso);
        $rows= str_replace("{ESTA_INSCRIPCION_USUARIOS}",							$Check[1],$rows);
        $rows= str_replace("{ESTA_INSCRIPCION_USUARIOS_OTROCURSO}",	 	$Check[2],$rows);
        $rows= str_replace("{ID_MALLA_INSCRIPCION_USUARIOS}",						$Check[3],$rows);
        $rows= str_replace("{MALLA_INSCRIPCION_USUARIOS}",						($Malla[0]->nombre),$rows);
        $rows= str_replace("{NOTIFICACIONES}",						$unico["id_notificacion_email"],$rows);
        $rows= str_replace("{FECHA_NOTIFICACION}",				 $Ota[0]->fecha_notificacion,$rows);
        $rows= str_replace("{CANTIDAD_OTAS}",						 $Ota[0]->cuenta_otas,$rows);


        $rows= str_replace("{ESTA_LMS_REPORTES}",											$Check[5],$rows);
        $rows= str_replace("{ID_MALLA_INSCRIPCION_USUARIOS_OTROCURSO}",						$Check[6],$rows);

    }

    $PRINCIPAL= str_replace("{ID_INSCRIPCION}",						$id_inscripcion,$PRINCIPAL);
    $PRINCIPAL= str_replace("{VERSIONES}",									$cuenta_mallas,$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_CURSO}",									$id_curso,$PRINCIPAL);

    $PRINCIPAL= str_replace("{NOMBRE_INSCRIPCION}",				($Ota[0]->nombre_inscripcion),$PRINCIPAL);
    $PRINCIPAL= str_replace("{CURSO}",									$id_curso,$PRINCIPAL);

    $PRINCIPAL= str_replace("{FECHA_INICIO}",							$fecha_inicio,$PRINCIPAL);
    $PRINCIPAL= str_replace("{FECHA_TERMINO}",							$fecha_termino,$PRINCIPAL);
    $PRINCIPAL= str_replace("{OPCIONAL}",							$opcional_txt,$PRINCIPAL);
    $PRINCIPAL= str_replace("{PRE_INSCRITOS}",						$pre_inscritos,$PRINCIPAL);
    $PRINCIPAL= str_replace("{INSCRITOS}",								$inscritos,$PRINCIPAL);
    $PRINCIPAL= str_replace("{BRECHAS}",									$brechas,$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_INSCRIPCION}",($id_inscripcion),$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_INSCRIPCION_ENC}",Encodear3($id_inscripcion),$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_CURSO_ENC}",Encodear3($id_curso),$PRINCIPAL);


    $PRINCIPAL= str_replace("{OPTIONS_ID_MALLA_VERSIONES}",($options_mallas),$PRINCIPAL);

    $PRINCIPAL= str_replace("{ROW_LISTADO_PARTICIPANTES_OTAS}",($rows),$PRINCIPAL);
    return($PRINCIPAL);
}

function Otas_2022_Lista_Participantes_Otas_Activas($PRINCIPAL, $id_empresa, $id_inscripcion, $activa, $vigencia_usuarios){


    //echo "<br>FN Otas_2022_Lista_Participantes_Otas_Activas $id_empresa, $id_inscripcion, $activa, $vigencia_usuarios";
    $Participantes=Otas_2022_lista_participantes_por_ota_data($id_inscripcion, "rel_lms_rut_id_curso_id_inscripcion", $vigencia_usuarios);

    $Ota=Otas_2022_visualiza_multimalla_Otas_Activas_data($id_inscripcion);

    //print_r($Ota);

    $hoy=date("Y-m-d");
    if($hoy>=$Ota[0]->fecha_inicio_inscripcion){
        //echo "activa";
        $activa="1";
    } else {
        //echo "inactiva";
        $inactiva="1";
    }


    $malla=	$Ota[0]->malla;

    $pre_inscritos 	= Otas_2022_check_por_ota($id_inscripcion, "rel_lms_rut_id_curso_id_inscripcion", $vigencia_usuarios);
    $inscritos 			= Otas_2022_check_por_ota($id_inscripcion, "tbl_inscripcion_usuarios", $vigencia_usuarios);
    $cuenta_mallas	= Otas_2022_cuenta_multimalla_Otas_Activas_data($id_inscripcion);
    //print_r($Participantes);
    $id_curso			=$Ota[0]->id_curso;
    $fecha_inicio	=$Ota[0]->fecha_inicio_inscripcion;
    $fecha_termino=$Ota[0]->fecha_termino_inscripcion;
    $opcional=$Ota[0]->opcional;

    if($opcional=="1"){
        $opcional_txt="OPCIONAL";
    } else {
        $opcional_txt="OBLIGATORIO";
    }

    //echo "<br>id_inscripcion $id_inscripcion pre_inscritos $pre_inscritos inscritos $inscritos cuenta_mallas $cuenta_mallas
    //<br> id_curso $id_curso fecha_inicio $fecha_inicio fecha_termino $fecha_termino";
    //exit();
    if($pre_inscritos<>$inscritos){
        if($cuenta_mallas=="1"){
            //Otas_2022_Insert_Tbl_inscripcion_usuario_reportes($id_inscripcion, $id_curso, $id_empresa, $fecha_inicio, $id_malla);
        }
    }
    $brechas = $inscritos-$pre_inscritos;

    foreach ($Participantes as $unico){
        $rows.=file_get_contents("views/gestion_otas_2022/row_participantes_otas.html");
        $rows= str_replace("{RUT}",										$unico->rut,$rows);
        $usu=Otas_2022_checkUserVigente($unico->rut);

        if($usu[0]->nombre_completo==""){
            $usu[0]->nombre_completo="NO VIGENTE";
        }
        $rows= str_replace("{NOMBRE_COMPLETO}",				$usu[0]->nombre_completo,$rows);
        $rows= str_replace("{CARGO}",									$usu[0]->cargo,$rows);
        $rows= str_replace("{EMAIL}",									$usu[0]->email,$rows);
        $rows= str_replace("{DIVISION}",							$usu[0]->c1,$rows);
        $Check=CheckOtaParticipante_2022($unico->rut, $id_inscripcion, $unico->id_curso);
        $rows= str_replace("{ESTA_INSCRIPCION_USUARIOS}",							$Check[1],$rows);
        $rows= str_replace("{ESTA_INSCRIPCION_USUARIOS_OTROCURSO}",	 	$Check[2],$rows);
        $rows= str_replace("{ID_MALLA_INSCRIPCION_USUARIOS}",						$Check[3],$rows);
        $rows= str_replace("{MALLA_INSCRIPCION_USUARIOS}",						$malla,$rows);
        $rows= str_replace("{ESTA_REL_LMS_MALLA_PERSONA}",						$Check[4],$rows);
        $rows= str_replace("{ESTA_LMS_REPORTES}",											$Check[5],$rows);
        $rows= str_replace("{ID_MALLA_INSCRIPCION_USUARIOS_OTROCURSO}",						$Check[6],$rows);
        if($Check[1]<>""){
        } else {
            if($Check[6]<>"" and $activa=="1"){
                Ota_InsertaInscripcionUsuarios_2022($id_inscripcion, $unico->rut, $unico->id_curso, $id_empresa,  $unico->fecha_inicio_inscripcion, $Check[6]);
            }
        }
    }
    $PRINCIPAL= str_replace("{ID_INSCRIPCION}",						$id_inscripcion,$PRINCIPAL);
    $PRINCIPAL= str_replace("{VERSIONES}",									$cuenta_mallas,$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_CURSO}",									$id_curso,$PRINCIPAL);

    $PRINCIPAL= str_replace("{NOMBRE_INSCRIPCION}",				($Ota[0]->nombre_inscripcion),$PRINCIPAL);
    $PRINCIPAL= str_replace("{CURSO}",									$id_curso,$PRINCIPAL);

    $PRINCIPAL= str_replace("{FECHA_INICIO}",							$fecha_inicio,$PRINCIPAL);
    $PRINCIPAL= str_replace("{FECHA_TERMINO}",							$fecha_termino,$PRINCIPAL);
    $PRINCIPAL= str_replace("{OPCIONAL}",							$opcional_txt,$PRINCIPAL);
    $PRINCIPAL= str_replace("{PRE_INSCRITOS}",						$pre_inscritos,$PRINCIPAL);
    $PRINCIPAL= str_replace("{INSCRITOS}",								$inscritos,$PRINCIPAL);
    $PRINCIPAL= str_replace("{BRECHAS}",									$brechas,$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_INSCRIPCION}",($id_inscripcion),$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_INSCRIPCION_ENC}",Encodear3($id_inscripcion),$PRINCIPAL);
    $PRINCIPAL= str_replace("{ID_CURSO_ENC}",Encodear3($id_curso),$PRINCIPAL);

    $hoy=date("Y-m-d");

    if($hoy>=$fecha_inicio and $hoy<=$fecha_termino){
        $agregar_participantes="	<button class='btn btn-link' type='button' data-toggle='collapse' data-target='#footwear' aria-expanded='false' aria-controls='footwear'>
																							Agregar Participantes
																			</button>";
    }
    elseif($hoy<$fecha_inicio)  {

        $agregar_participantes="	<button class='btn btn-link' type='button' data-toggle='collapse' data-target='#footwear' aria-expanded='false' aria-controls='footwear'>
																							Agregar Participantes
																			</button>";
    }

    else {
        $agregar_participantes="";
    }


    $PRINCIPAL= str_replace("{BOTON_AGREGAR_PARTICIPANTES}",($agregar_participantes),$PRINCIPAL);



    $Versiones=Otas_2022_visualiza_multimalla_Otas_Activas_data($id_inscripcion);
    //print_r($Versiones);
    foreach ($Versiones as $unico){
        $options_mallas.="<option value='".$unico->id_malla."'>".$unico->malla."</option>";
    }

    $PRINCIPAL= str_replace("{OPTIONS_ID_MALLA_VERSIONES}",($options_mallas),$PRINCIPAL);

    $PRINCIPAL= str_replace("{ROW_LISTADO_PARTICIPANTES_OTAS}",($rows),$PRINCIPAL);
    return($PRINCIPAL);
}

function Otas_2022_Lista_Otas_Activas($PRINCIPAL, $id_empresa, $filtro, $activa, $vigencia_usuarios){
    //total Usuarios Empresa
    //$total_usuarios=DatosTablaUsuarioTodosPorEmpresa($id_empresa);
    //traigo los programas por empresa
    $Otas=Otas_2022_Lista_Otas_Activas_Groupby_ota_data($PRINCIPAL, $id_empresa, $filtro, $activa, $vigencia_usuarios);
    foreach($Otas as $unico){
        //echo "<br>Id Proyecto $id_proyecto, ".$unico->usuarios." respuestas ".$unico->respuestas;
        $pre_inscritos = Otas_2022_check_por_ota($unico->id_inscripcion, "rel_lms_rut_id_curso_id_inscripcion", $vigencia_usuarios);
        $inscritos 		= Otas_2022_check_por_ota($unico->id_inscripcion, "tbl_inscripcion_usuarios", $vigencia_usuarios);
        $cuenta_mallas= Otas_2022_cuenta_multimalla_Otas_Activas_data($unico->id_inscripcion);
        if($pre_inscritos<>$inscritos){
            //cho "<br>Diferencias $pre_inscritos<$inscritos<br>";
            //print_r($unico);
            if($cuenta_mallas=="1"){
                //Otas_2022_Insert_Tbl_inscripcion_usuario_reportes($unico->id_inscripcion, $unico->id_curso, $id_empresa, $unico->fecha_inicio_inscripcion, $unico->id_malla);
            }
            //exit();
        }

        $brechas = $inscritos-$pre_inscritos;
        $rows.=file_get_contents("views/gestion_otas_2022/row_otas.html");
        $rows= str_replace("{ID_INSCRIPCION}",					$unico->id_inscripcion,$rows);
        $rows= str_replace("{INSCRIPCION}",							$unico->nombre_inscripcion,$rows);
        $rows= str_replace("{ID_CURSO}",								$unico->id_curso,$rows);
        $rows= str_replace("{CURSO}",										"",$rows);
        $rows= str_replace("{FECHA_INICIO}",						$unico->fecha_inicio_inscripcion,$rows);
        $rows= str_replace("{FECHA_TERMINO}",						$unico->fecha_termino_inscripcion,$rows);
        if($unico->opcional=="1"){
            $opcional="OPCIONAL";

        } ELSE {
            $opcional="OBLIGATORIO";
        }


        if($cuenta_mallas=="1"){$cuenta_malla_txt="Una Version";}
        if($cuenta_mallas=="2"){$cuenta_malla_txt="Dos Versiones";}
        if($cuenta_mallas=="3"){$cuenta_malla_txt="Tres Versiones";}
        if($cuenta_mallas=="4"){$cuenta_malla_txt="Cuatro Versiones";}


        $rows= str_replace("{OPCIONAL}",								$opcional,$rows);
        $rows= str_replace("{PRE_INSCRITOS}",						$pre_inscritos,$rows);
        $rows= str_replace("{INSCRITOS}",								$inscritos,$rows);
        $rows= str_replace("{BRECHAS}",									$brechas,$rows);
        $rows= str_replace("{ALERTA}",									$cuenta_malla_txt,$rows);
        $rows= str_replace("{ID_MALLA}",								$unico->id_malla,$rows);

        $malla=BuscaNombreMalla_2022($unico->id_malla);
        $rows= str_replace("{MALLA}",								$malla,$rows);

        $accion=" <a href='?sw=gestion_ota_2022_vista_participantes&id_inscripcion=".Encodear3($unico->id_inscripcion)."' class='btn btn-link'> Gestionar </a>";

        $rows= str_replace("{ACCION}",		$accion,$rows);
    }
    $PRINCIPAL= str_replace("{ROW_LISTADO_OTAS}",($rows),$PRINCIPAL);
    return($PRINCIPAL);
}

function LimpiaTextosTrimAdmin($texto){

    $texto = str_replace(";", ".", $texto);
    $texto = str_replace("<br>", "", $texto);
    $texto = str_replace("/\r|\n/", "", $texto);
    $texto = str_replace("/\r|\n/", "", $texto);
    $texto = str_replace("/\r|\n/", "", $texto);
    $texto = str_replace(array("\r", "\n"), '',  $texto);
    $texto = str_replace(array("\r\n", "\r", "\n"), "",  $texto);

    return $texto;
}

function FuncionesTransversalesAdmin($html){
    $id_empresa=$_SESSION["id_empresa"];
    //$datos_proceso=DatosProceso();
    //Dado el perfil, muestro el menu izquierdo
	
    $perfil=PerfilAdmin($_SESSION["perfil"]);
	$acceso_admin_perfil=VerificaTipoDePerfilAdminAcceso($_SESSION["user_"]);
	
    //$html = str_replace("{MENU_IZQUIERDO}",file_get_contents("views/menu_izquierdo/".$perfil[0]->template.""),$html);
	$html = str_replace("{MENU_IZQUIERDO}",file_get_contents("views/menu_izquierdo/".$acceso_admin_perfil[0]->template.""),$html);
	
	$random=rand(5, 100005);
	
    //Veo si existen reportes de capacitacion en la tabla, para que se coloquen en el menu izquierdo
    //Reportes Capacitacion por empresa
   /* $reportes_capacitacion=TiposReportesPorEmpresa($id_empresa, 1);
    foreach ($reportes_capacitacion as $unico) {
        $ul.=file_get_contents("views/menu_izquierdo/li_menu.html");
        $ul = str_replace("{NOMBRE_REPORTE}",$unico->nombre,$ul);
        $ul = str_replace("{CASE_REPORTE}",$unico->case,$ul);
    }
    $html = str_replace("{REPORTES_CAPACITACION}",$ul,$html); */
    //$html = str_replace("{MENU_INFERIOR}",file_get_contents("views/menu_inferior.html"),$html);
    //$html = str_replace("{FOOTER}",file_get_contents("views/footer.html"),$html);
    //$html = str_replace("{LOGO}",file_get_contents("views/logo.html"),$html);
    $html = str_replace("{HEAD}",file_get_contents("views/head.html"),$html);
    //$html = str_replace("{HEAD_FOOTER}",file_get_contents("views/head_footer.html"),$html);
    $html = str_replace("{HEADER}",file_get_contents("views/header.html"),$html);
    $html = str_replace("{NAVEGACION}",file_get_contents("views/navegacion.html"),$html);
    $html = str_replace("{USER_TEMPLATE}",file_get_contents("views/menu_izquierdo/user_menu.html"),$html);
    $html = str_replace("{IMAGEN_USUARIO}",VerificaFotoPersonalDesdeAdmin($_SESSION["admin_"]),$html);
    $html = str_replace("{FOOTER_ADMIN}",file_get_contents("views/footer.html"),$html);
    $html = str_replace("{HOME_INICIAL}",$perfil[0]->home,$html);
    
    $html = str_replace("{RANDOM}",$random,$html);
    
    
    //$html = str_replace("{STATUS_SUPERIOR_DERECHA}",file_get_contents("views/status_superior_derecha.html"),$html);
    $html = str_replace("{TITTLE}","Administracion",$html);
    $html = str_replace("{NOMBRE_USUARIO}",($_SESSION["nombre"]),$html);
    $html = str_replace("{PERFIL_ADMIN}",($perfil[0]->nombre_perfil),$html);
return($html);
}

function VerificaFotoPersonalDesdeAdmin($rut){
    $datos_usuario=UsuarioEnBasePersonas($rut, $rut);
    $rut_completo=$datos_usuario[0]->rut_completo;
    $ruta_admin="img/personas/".$rut;
    $ruta="../sgd/front/img/personas/".$rut;
    $ruta_rut_completo="../fsgd/ront/img/personas/".$rut_completo;
    if (file_exists($ruta_admin.".jpg")) {
        $imagen=$ruta_admin.".jpg";
    } else if (file_exists($ruta_admin.".JPG")) {
        $imagen=$ruta_admin.".JPG";
    } else if (file_exists($ruta_admin.".gif")) {
        $imagen=$ruta_admin.".gif";
    }
    else if (file_exists($ruta.".jpg")) {
        $imagen=$ruta.".jpg";
    } else if (file_exists($ruta.".JPG")) {
        $imagen=$ruta.".JPG";
    } else if (file_exists($ruta.".gif")) {
        $imagen=$ruta.".gif";
    }
    else if (file_exists($ruta_rut_completo.".jpg")) {
        $imagen=$ruta_rut_completo.".jpg";
    } else if (file_exists($ruta_rut_completo.".JPG")) {
        $imagen=$ruta_rut_completo.".JPG";
    } else if (file_exists($ruta_rut_completo.".gif")) {
        $imagen=$ruta_rut_completo.".gif";
    }else{
        $imagen="../front/img/foto_perfil.jpg";
    }
    return($imagen);
}

function lista_gestion_usuarios($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        	
        	//Rellena 
        	CopiatblUsuario_Egresados($id_empresa);
        	//exit();
        	
        	truncate_tbl_usuario($id_empresa);
			BorraDuplicados($tipo, $id_empresa);
     			//lee desde tbl_usuario_temporal
      		usuario_temporal_lee($id_empresa);
      		cron_tbl_cron_sillas_data();
			fill_contingencia_tbl_cron_sillas_data();
 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function reportes_online_lista_cursos_programa($PRINCIPAL, $id_empresa, $filtro, $excel)
{
   
   $Array_C1C2C3C4=reportes_online_trae_c1c2c3c4($id_empresa);
   //print_r($Array_C1C2C3C4);
   
   
    $PRINCIPAL = str_replace("{C1}", 						$Array_C1C2C3C4[0]->c1_texto, $PRINCIPAL);
    $PRINCIPAL = str_replace("{C2}", 						$Array_C1C2C3C4[0]->c2_texto, $PRINCIPAL);
    $PRINCIPAL = str_replace("{C3}", 						$Array_C1C2C3C4[0]->c3_texto, $PRINCIPAL);
    $PRINCIPAL = str_replace("{C4}", 						$Array_C1C2C3C4[0]->c4_texto, $PRINCIPAL);
  
  	$Options_c1=reportes_online_groupby_c1c2c3c4("c1");
  	$op_c1.="<option value=''></option>";
  	foreach ($Options_c1 as $unico){
  		if($unico->dato==$_POST["c1"]){$selected=" selected ";} else {$selected="";}
  		$op_c1.="<option value='".$unico->dato."' ".$selected.">".$unico->dato."</option>";
  	}

  	$Options_c2=reportes_online_groupby_c1c2c3c4("c2");
  	$op_c2.="<option value=''></option>";
  	foreach ($Options_c2 as $unico){
  		if($unico->dato==$_POST["c2"]){$selected=" selected ";} else {$selected="";}
  		$op_c2.="<option value='".$unico->dato."' ".$selected.">".$unico->dato."</option>";
  	}

  	$Options_c3=reportes_online_groupby_c1c2c3c4("c3");
  	$op_c3.="<option value=''></option>";
  	foreach ($Options_c3 as $unico){
  		if($unico->dato==$_POST["c3"]){$selected=" selected ";} else {$selected="";}
  		$op_c3.="<option value='".$unico->dato."' ".$selected.">".$unico->dato."</option>";
  	}

  	$Options_c4=reportes_online_groupby_c1c2c3c4("c4");
  	$op_c4.="<option value=''></option>";
  	foreach ($Options_c4 as $unico){
  		if($unico->dato==$_POST["c4"]){$selected=" selected ";} else {$selected="";}
  		$op_c4.="<option value='".$unico->dato."' ".$selected.">".$unico->dato."</option>";
  	}  	  	  	

    $PRINCIPAL = str_replace("{OPTIONS_C1}", 						$op_c1, $PRINCIPAL);
    $PRINCIPAL = str_replace("{OPTIONS_C2}", 						$op_c2, $PRINCIPAL);
    $PRINCIPAL = str_replace("{OPTIONS_C3}", 						$op_c3, $PRINCIPAL);
    $PRINCIPAL = str_replace("{OPTIONS_C4}", 						$op_c4, $PRINCIPAL);

    $PRINCIPAL = str_replace("{rut_colaborador}", 			$_POST["rut_colaborador"], $PRINCIPAL);
   
		$tipo="Curso";
		$array=reportes_online_lista_cursos_programa_data($id_empresa, $tipo);
		
		foreach ($array as $unico) {

			$ProgramaArray=reportes_online_busca_programas_dado_idCurso($unico->id);
			$Programa="";
			foreach ($ProgramaArray as $unico2){
				$Programa.="".$unico2->programa."<br>";
			}			
			
				$row_listado_cursos.="<tr>";
				$row_listado_cursos.="<td>".($unico->id)."</td>";
				$row_listado_cursos.="<td>".($unico->nombre)."</td>";
				$row_listado_cursos.="<td>".($Programa)."</td>";	
				$row_listado_cursos.="<td><a href='?sw=reportes_online_descarga&id=".$unico->id."&tipo=".$tipo."'>Descargar Reporte</a></td>";
				$row_listado_cursos.="<td><a href='?sw=reportes_online_descarga&id=".$unico->id."&tipo=".$tipo."&vista=graph'>Ver Resumen</a></td>";
				$row_listado_cursos.="</tr>";
		}

    $PRINCIPAL = str_replace("{ROW_LISTADO_CURSOS}", 						$row_listado_cursos, $PRINCIPAL);
    
 		$tipo="Programa";
		$array=reportes_online_lista_cursos_programa_data($id_empresa, $tipo);
		
		foreach ($array as $unico) {
				$row_listado_programas.="<tr>";
				$row_listado_programas.="<td>".($unico->id)."</td>";
				$row_listado_programas.="<td>".($unico->nombre)."</td>";
				$row_listado_programas.="<td><a href='?sw=reportes_online_descarga&id=".$unico->id."&tipo=".$tipo."Consolidado'>Descargar Reporte</a></td>";
				$row_listado_programas.="<td><a href='?sw=reportes_online_descarga&id=".$unico->id."&tipo=".$tipo."Consolidado&vista=graph'>Ver Resumen</a></td>";
				$row_listado_programas.="</tr>";
		}

    $PRINCIPAL = str_replace("{ROW_LISTADO_PROGRAMAS}", 						$row_listado_programas, $PRINCIPAL);   

		$tipo="ProgramaDetalle";
		$array=reportes_online_lista_cursos_programa_data($id_empresa, $tipo);
		
		foreach ($array as $unico) {
				$row_listado_programas_detalle.="<tr>";
				$row_listado_programas_detalle.="<td>".($unico->id)."</td>";
				$row_listado_programas_detalle.="<td>".($unico->nombre)."</td>";
				$row_listado_programas_detalle.="<td><a href='?sw=reportes_online_descarga&id=".$unico->id."&tipo=".$tipo."'>Descargar Reporte</a></td>";
				$row_listado_programas_detalle.="</tr>";
		}

    $PRINCIPAL = str_replace("{ROW_LISTADO_PROGRAMAS_DETALLE}", 						$row_listado_programas_detalle, $PRINCIPAL);   
    
    $display_rut_colaborador="display:none; ";
		//print_r($_SESSION);
		if($_SESSION["cuenta_filter"]=="1"){
			$filter_text.="<strong>Filtros </strong>: ";
			if($_SESSION["c1text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c1text"]."</span>&nbsp;";	
			}
			if($_SESSION["c2text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c2text"]."</span>&nbsp;";	
			}
			if($_SESSION["c3text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c3text"]."</span>&nbsp;";	
			}
			if($_SESSION["c4text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c4text"]."</span>&nbsp;";	
			}
			if($_SESSION["rut_colaborador_text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["rut_colaborador_text"]."</span>&nbsp;";	
				$display_rut_colaborador="";
			} else {
			}


		} else {
			$filter_text="";
		}
		
		$CheckBox_Cursos=reportes_online_lista_cursos_checkbox($id_empresa);
		$PRINCIPAL = str_replace("{cursos_agrupacion_checkbox}", $CheckBox_Cursos	, $PRINCIPAL);   
		

		$tipo="Agrupaciones";
		$array=reportes_online_lista_cursos_programa_data($id_empresa, $tipo);
		//print_r($array);
		$id_agrupacion="";
		foreach ($array as $unico) {
						$ListaCursos=reportes_online_ListaCursoDadoIdAgrupacion($unico->id_agrupacion);
						$lista_nombre_cursos="";
						//print_r($ListaCursos);
							foreach ($ListaCursos as $unico2) {
								$lista_nombre_cursos.=$unico2->id_curso." ".$unico2->nombre_curso."<br>";
							}
				$row_listado_agrupaciones.="<tr>";
				$row_listado_agrupaciones.="<td>".($unico->id_agrupacion)."</td>";
				$row_listado_agrupaciones.="<td>".($unico->nombre)."</td>";
				$row_listado_agrupaciones.="<td>".($lista_nombre_cursos)."</td>";
				$row_listado_agrupaciones.="<td>
					<a href='?sw=reportes_online_descarga&id=".$unico->id_agrupacion."&tipo=".$tipo."'>Descargar Reporte Cursos</a>
					<br>
					<a href='?sw=reportes_online_descarga&id=".$unico->id_agrupacion."&tipo=".$tipo."&version=2'>Descargar Reporte Cursos V2</a>
					<br>					
					<a href='?sw=reportes_online_descarga&id=".$unico->id_agrupacion."&tipo=".$tipo."&actividades=1'>Descargar Reporte Actividades</a>
																		</td>";
				$row_listado_agrupaciones.="</tr>";
		}		

    $PRINCIPAL = str_replace("{ROW_LISTADO_AGRUPACION}", 						$row_listado_agrupaciones, $PRINCIPAL);   

		
		
		$PRINCIPAL = str_replace("{DISPLAY_RUT_COLABORADOR}", $display_rut_colaborador	, $PRINCIPAL);   

    $PRINCIPAL = str_replace("{FILTROS_REALIZADOS_FILTRO_SUPERIOR}", 	$filter_text, $PRINCIPAL);   
    
     echo CleanHTMLWhiteList($PRINCIPAL);exit;
}

function reportes_online_lista_cursos_checkbox($id_empresa){

		$tipo="Curso";
		$array=reportes_online_lista_cursos_programa_data($id_empresa, $tipo);
		//print_r($array);
		
		foreach ($array as $unico){
			$checkbox.="<input type='checkbox' name='".$unico->id."' value='1'> ".$unico->id." ".strip_tags(($unico->nombre))."<br>";
		}
		return $checkbox;
		

} 
function FechaExcelPhp($number)  {
  $UNIX_DATE = ($number - 25569) * 86400;
$fecha=gmdate("Y-m-d", $UNIX_DATE);
return $fecha;
}

function LimpiaRut($rut){

    $id_empresa = $_SESSION["id_empresa"];

    if($id_empresa<>'75'){
        $rut = str_replace(".","",$rut);
        $arreglo_rut=explode("-", $rut);
        return($arreglo_rut[0]);
    } else {
        return  $rut;
    }

}

function lista_gestion_amonestaciones($html,  $id_empresa, $rut_col, $lista){
   
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function Lista_fc_eventos($html,  $id_empresa, $idcategoria){
    $lista_puntos_stock_fe=Lista_fc_eventos_data($id_empresa);
    //print_r($lista_puntos_stock_fe);

    //$categorias_options=mp_busca_Categorias($id_empresa);    //print_r($categorias_options);
    $row=file_get_contents("views/formacion_continua/entorno_formacioncontinua_eventos.html");
    foreach($lista_puntos_stock_fe as $unico){
                    $row = file_get_contents("views/formacion_continua/row_fc_eventos.html");
                    $row = str_replace("{ID}",                ($unico->id),$row);

                    if($unico->invisible==1){$estado="<span class='label bg-red'>DESACTIVO</span>";} else {$estado="<span class='label bg-blue'>ACTIVO</span>";}

                    $row = str_replace("{ESTADO}",            ($estado),$row);
                    $row = str_replace("{CODIGO}",            ($unico->id_postulable),$row);
                    $row = str_replace("{NOMBRE}",            ($unico->nombre),$row);
                    $row = str_replace("{DESCRIPCION}",        ($unico->descripcion),$row);
                    $row = str_replace("{DATO1}",            ($unico->dato1),$row);
                    $row = str_replace("{MODALIDAD}",        ($unico->modalidad),$row);
                    $row = str_replace("{FICHA}",            ($unico->ficha),$row);
                    $row = str_replace("{INSTITUCION}",        ($unico->institucion),$row);
                    $row = str_replace("{REGION}",            ($unico->region),$row);
                    $row = str_replace("{DIMENSION}",        ($unico->dimension),$row);
                    $row = str_replace("{DESACTIVO}",        ($unico->desactivo),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Gestión de Eventos",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_formacion_continua($html,  $id_empresa, $idcategoria){
    $lista_fc=lista_formacion_continua_data($id_empresa);
    foreach($lista_fc as $unico){
                    $row=file_get_contents("views/formacion_continua/row_formacioncontinua.html");
                    $row = str_replace("{ID}",                    ($unico->id_postulable),$row);
                    $row = str_replace("{NOMBRE}",                ($unico->nombre),$row);
                    $row = str_replace("{DESCRIPCION}",                ($unico->descripcion),$row);
                    $row = str_replace("{DIMENSION}",                ($unico->dimension),$row);
                    $row = str_replace("{POSTULANTES}",            ($unico->postulantes),$row);
                    $row = str_replace("{JEFEOK}",                ($unico->jefeok),$row);
                    $row = str_replace("{JEFENOOK}",            ($unico->jefeno),$row);
                    $row = str_replace("{VALIDADOS}",            ($unico->validados),$row);
                    $row = str_replace("{RECHAZADOS}",            ($unico->rechazados),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Inscripción Webinars",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_formacion_continua_validacion($html,  $id_empresa, $idcategoria){
    $lista_postulablesv=lista_formacion_continua_validacion_data($idcategoria, $id_empresa);
    //print_r($lista_postulablesv);
    foreach($lista_postulablesv as $unico){
                    $row=file_get_contents("views/formacion_continua/row_lista_formacioncontinua.html");
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
                    //print_r($unico);echo" <br>";
                    $Datosusuario=TraeDatosUsuario($unico->rut);
                    //print_r($Datosusuario);
                    $row = str_replace("{NOMBRE}",        ($Datosusuario[0]->nombre_completo),$row);
                    $row = str_replace("{FECHA}",        ($unico->fecha),$row);


                    $nombre_postulable=FC_NombrePostulable($unico->id_postulable, $id_empresa);
                    $descripcion_postulable=FC_DescripcionPostulable($unico->id_postulable, $id_empresa);

$id_enc=Encodear3($unico->id);
$botones_validacion='';
//echo $botones_documentacion;

$botones_jefe='';


if($unico->validacionok==''){
    $botones_validacion='
    <a href="?sw=formacioncontinua_validacion_admin&idenc='.$id_enc.'&v=SI&id='.$idcategoria.'" class="btn btn-success">Validaci&oacute;n Admin</a>
        <br><br>
    <a href="?sw=formacioncontinua_validacion_admin&idenc='.$id_enc.'&v=NO&id='.$idcategoria.'" class="btn btn-danger">Desistir Admin</a> ';
} else {
        if($unico->validacionok=='SI'){
    $botones_validacion='<span class="badge badge-success">SI</span>';
    } else {
    $botones_validacion='<span class="badge badge-danger">NO</span>';
    }
}
    if($unico->jefeok=='SI'){
    $botones_jefe='<span class="badge badge-success">SI</span>';
    } elseif($unico->jefeok=='NO'){
    $botones_jefe='<span class="badge badge-danger">NO</span>';
    } 
	
	elseif($unico->jefeok=='NO_POR_FECHA'){
    $botones_jefe='<span class="badge badge-danger">NO_POR_FECHA</span>';
    }
	else {

    $botones_jefe='<span class="badge badge-warning">PENDIENTE</span>';
    }
                    //echo $unico->nombre_postulable;
                    $row = str_replace("{POSTULABLE}",            ($nombre_postulable."<br>".$descripcion_postulable),$row);
                    $row = str_replace("{VALIDACION_JEFE}",        ($botones_jefe),$row);
                    $row = str_replace("{VALIDACION_FINAL}",    ($botones_validacion),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Validación Formación Continua",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=formacion_continua" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_notificaciones_a_buscar($html,  $id_empresa, $idcategoria){
    $emb_notificaciones=lista_notificaciones_a_buscar_data($id_empresa);
    //print_r($emb_notificaciones);
    //$categorias_options=mp_busca_Categorias($id_empresa);
    //print_r($categorias_options);
    $row=file_get_contents("views/notificaciones/entorno_notificaciones.html");
    foreach($emb_notificaciones as $unico){
                    $row=file_get_contents("views/notificaciones/row_notificaciones_pendientes.html");
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{TIPO_ENVIO}",            ($unico->tipoenvio),$row);
                    $row = str_replace("{NUM_CUENTA}",            ($unico->cuenta),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Notificaciones",$html);
    $html = str_replace("{BTN}","Notificaciones Pendientes Automáticas",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function Copia_lista_notificaciones_a_buscar_detalle($id_empresa, $tipoenvio){
		  $emb_notificaciones=lista_notificaciones_a_buscar_data_detalle($id_empresa, $tipoenvio);
    
    	$count_total_loop=count($emb_notificaciones);
			ini_set('output_buffering', 0);
			ini_set('zlib.output_compression', 0);
			if( !ob_get_level() ){ ob_start(); }
			else { ob_end_clean(); ob_start(); }

    
  foreach($emb_notificaciones as $unico){

				$cuenta_loop++;
				echo "<center><span style='position: absolute;z-index:$current;background:#36C6D3; padding:10px; color:#FFF'>Procesando $cuenta_loop de $count_total_loop Registros</span></center>";
				flush();
				ob_flush();

        $tipoenvio          =$unico->tipoenvio;
        $rut                =$unico->rut;
        $fecha_envio        =$unico->fecha_envio;
        $estado             =$unico->estado;
        $hacia              =$unico->hacia;
        $nombreto           =$unico->nombreto;
        $desde              =$unico->desde;
        $nombrefrom         =$unico->nombrefrom;
        $tipo               =$unico->tipo;
        $asunto             =$unico->asunto;
        $titulo1            =$unico->titulo1;
        $subtitulo1         =$unico->subtitulo1;
        $texto1             =$unico->texto1;
        $url                =$unico->url;
        $texto_url          =$unico->texto_url;
        $texto2             =$unico->texto2;
        $texto3             =$unico->texto3;
        $texto4             =$unico->texto4;
        $logo               =$unico->logo;
        $tipomensaje        =$unico->tipomensaje;
        $clave              =$unico->clave;
        $template           =$unico->template;
        $subject            =$unico->asunto;

    // echo "<br>$tipoenvio,$nombre,$rut,$fecha_envio,$id_empresa,$to,$nombreto,$from,$nombrefrom,$tipo,$subject,$titulo1,$subtitulo1,$texto1,$url,$texto_url,$texto2,    $texto3,$texto4,$logo,$tipomensaje,$key,$template";


    echo "<br>$tipoenvio, $rut";
    Notificaciones_crea_not_automaticas($tipoenvio,$tipoenvio,$rut,$fecha_envio,$id_empresa,$hacia,$nombreto,$desde,$nombrefrom,$tipo,$subject,$titulo1,$subtitulo1,$texto1,$url,$texto_url,$texto2,    $texto3,$texto4,$logo,$tipomensaje,$rut,$template);

   }


}

function NotificacionesBuscaPendientesAutomatico($id_empresa,$url_front,$url_front_admin,$logo,$from,$nombrefrom, $id_programa){
               //echo "NotificacionesBuscaPendientesAutomatico $id_empresa,$url_front,$url_front_admin,$logo,$from,$nombrefrom, $id_programa"; 
               
    					DeleteFullTbltbl_notificaciones_pendientes();
							//1. Envio a Administrador de Mediciones con Fecha
                $hoy=date("Y-m-d");
                //$hoy="2018-03-02";
                $diamanana= date("Y-m-d",strtotime("+1 day"));
                $diadosveces= date("Y-m-d",strtotime("+2 day"));
                //busca mediciones que parte en dos dias más
                //Notificacion a responsable Medicion

                //$Not_array_MR=Not_buscaMedicionResponsable($diadosveces,$id_empresa);
                //echo "<br>Not_array_MR";
                //print_r($Not_array_MR);
                foreach ($Not_array_MR as $unico) {
                $array_u=TraeDatosUsuario($unico->rut);
                $tipoenvio="Medicion";
                $tipoenvio="Medicion_responsable";
                $rut=$array_u[0]->rut;
                $fecha_envio=$diamañana;
                $to=$array_u[0]->email;
                $nombreto=$array_u[0]->nombre_completo;
                $tipo        ="text/html";
                $subject="Esta pronto a activarse una Medicion";
                $titulo1="Está pronto a activarse una Medición";
                $subtitulo1="Mañana se activará la Medición ID: ".$unico->id." ".$unico->nombre;
                $texto1="Recuerda revisar la lista de usuarios a los que se les enviará la notificación";
                $url=$url_front_admin;
                $texto_url="Ingresa aqui";
                $texto2=" ";$texto3=" ";$texto4=" ";
                $tipomensaje="Medicion_responsable_alerta";
                $key=$rut;
                $template="";                $not_cuenta1++;
                InsertNotificacionesPendientes($tipoenvio,$nombre,$rut,$fecha_envio,$id_empresa,
                $to,$nombreto,$from,$nombrefrom,$tipo,($subject),($titulo1),($subtitulo1),
                ($texto1),
                $url,($texto_url),
                ($texto2),($texto3),($texto4),$logo,$tipomensaje,$key,$template);
                }
        				
        				//        echo "<br>1 $not_cuenta1";
								//2. busca mediciones pendientes de mañana pero jefe a usuario (TODOS)
                //$Not_array_MP=Not_buscamediciones_Pendientes_usuarios_Jefe_usuario($diamañana, $id_empresa);
                //echo "<br>Not_array_MP";
                //print_r($Not_array_MP);
                foreach ($Not_array_MP as $unico) {
                $array_u=TraeDatosUsuario($unico->jefe);
                $array_c=TraeDatosUsuario($unico->rut);
                $tipoenvio="Medicion";
                $tipoenvio="Medicion_Invitacion";
                $rut=$array_u[0]->rut;
                $fecha_envio=$diamañana;
                $to=$array_u[0]->email;
                $nombreto=$array_u[0]->nombre_completo;
                $tipo        ="text/html";
                $subject="Te invitamos a contestar una Evaluacion de Impacto";
                $titulo1="Te invitamos a contestar una Evaluación de Impacto";
                $subtitulo1="Debes realizar la evaluación de impacto ".nombremedicion."
                para el colaborador: ".$array_c[0]->nombre_completo."";
                $texto1="No te tomará más de 5 minutos";
                $url=$url_front;
                $texto_url="Ingresa aqui";
                $texto2=" ";$texto3=" ";$texto4=" ";
                $tipomensaje="Medicion_pendiente_usuario";
                $key=$rut;
                $template="";                $not_cuenta2++;
                InsertNotificacionesPendientes($tipoenvio,$nombre,$rut,$fecha_envio,$id_empresa,
                $to,$nombreto,$from,$nombrefrom,$tipo,($subject),($titulo1),($subtitulo1),
                ($texto1),
                $url,($texto_url),
                ($texto2),($texto3),($texto4),$logo,$tipomensaje,$key,$template);
           			 }
    						
    						//  echo "<br>2 $not_cuenta2";
								// 3. busca mediciones pendientes de mañana INDIVIDUAL (SOLO PENDIENTES)
    						//$Not_array_Evaluaciones_Individuales=Not_buscamediciones_Pendientes_Evaluaciones_individuales($diamañana, $id_empresa);
								//print_r($Not_array_Evaluaciones_Individuales);
    						foreach ($Not_array_Evaluaciones_Individuales as $unico) {
                $array_u=TraeDatosUsuario($unico->rut);
                $array_c=TraeDatosUsuario($unico->rut);
                $tipoenvio="Evaluacion";
                $tipoenvio="evaluacion_pendiente";
                $rut=$array_u[0]->rut;
                $fecha_envio=$hoy;
                $to=$array_u[0]->email;
                $nombreto=$array_u[0]->nombre_completo;
                $tipo        ="text/html";
                $subject="¡Tienes una evaluación pendiente!";
                $titulo1="¡Tienes una evaluación pendiente!";
                $subtitulo1="Te invitamos a contestar la Evaluación: <strong>".($unico->nombremedicion)."</strong>.
                <br><br>Recuerda que responder estas evaluaciones son una actividad obligatoria, con fecha de término 16 de Marzo 2018.";
                $texto1="No te tomará más de 3 minutos, ¡Aprovecha ahora!<br><br>
                Al ingresar a la plataforma, ingresa con tu RUT y clave los primeros cuatro digitos de tu RUT.<br>
                Luego de llenar tu perfil, aparecerá una alerta que dice que tienes una Evaluación Pendiente.
                ";
                $url=$url_front;
                $texto_url="Ingresa aqui";
                $texto2=" ";$texto3=" ";$texto4=" ";
                $tipomensaje="evaluacion_pendiente_usuario";
                $key=$rut;
                $template="";                $not_cuenta3++;
                InsertNotificacionesPendientes($tipoenvio,$nombre,$rut,$fecha_envio,$id_empresa,
                $to,$nombreto,$from,$nombrefrom,$tipo,($subject),($titulo1),($subtitulo1),
                ($texto1),
                $url,($texto_url),
                ($texto2),($texto3),($texto4),$logo,$tipomensaje,$key,$template);
            	}


							// 4. Cursos Elearning Pendientes   Usuarios


							// 5. Cursos Elearning Pendientes con mas de un mes
    					 $fecha_inicio=date("Y-m-d");
    					 
  						ini_set('output_buffering', 0);
							ini_set('zlib.output_compression', 0);
							if( !ob_get_level() ){ ob_start(); }
							else { ob_end_clean(); ob_start(); }
    					 
    					 
  						 $Not_array_ElearningPendientes=Not_cursosElearningObligatoriosPendientes($id_programa, $id_empresa);
  						 $fila=count($Not_array_ElearningPendientes);
  						 //echo "fila 1 $fila";
    						foreach ($Not_array_ElearningPendientes as $unico) {
								                        								$l++;
						    		echo "<center><span style='position: absolute;z-index:$current;background:#36C6D3; padding:10px; color:#FFF'>Registro Colaborador $l de $fila</span></center>";
        						flush();	ob_flush();			
    							
    							
    							
    							$Ausente=Ausentismo_rut($unico->rut);
    							if($Ausente>0){
    								continue;
    								echo "<script>alert('Ausente ".$unico->rut."');</script>";
    							}
							                
							                $array_u=TraeDatosUsuario($unico->rut);
							                $array_c=TraeDatosUsuario($unico->rut);
							                $tipoenvio="Cursos_Elearning_Pendientes";
							                $tipoenvio="Cursos_Elearning_Pendientes";
							                $rut=$array_u[0]->rut;
							                $fecha_envio=$hoy;
							                $to=$array_u[0]->email;
							                $nombreto=$array_u[0]->nombre_completo;
							                $tipo        ="text/html";
							                $subject="Cursos Digitales Pendientes";
							                $Not_Array_curso=Not_listacursosElearningObligatoriosPendientes($unico->rut, $id_programa, $id_empresa);

							                $lista_curso=""; $cuenta_cursos=0;
							                foreach ($Not_Array_curso as $curso){ $cuenta_cursos++;
							                    $lista_curso.="<br>Curso: ".$curso->nombre_curso."";
							                }

							                if($cuenta_cursos>1){
							                    $titulo1="Estimado(a) colaborador(a),";
							                    $subtitulo1="Te invitamos a terminar tus cursos digitales pendientes";

							                } else {
							                    $titulo1="Estimado(a) colaborador(a),";
							                    $subtitulo1="Te invitamos a terminar tu curso digital pendiente";

							                }

							                    $texto1='<p class="text-left">'.($lista_curso).'</p>';
							                    $texto2="Te recomendamos planificar anticipadamente espacios en tu agenda para que puedas cumplir con la aprobación de este curso en el plazo definido.";
							                    $texto3="Si necesitas ayuda, nos puedes contactar en nuestra Central de Soporte: 2 258 30 236.<br> ¡Mucho Éxito!";
							                    $url=$url_front;
							                    $texto_url="";
							                    $texto4="";
							                    $tipomensaje="Curso_Pendiente_usuario";
							                    $key=$rut;
							                    $template="";                $not_cuenta4++;
							                    

							                    
							                    InsertNotificacionesPendientes($tipoenvio,$nombre,$rut,$fecha_envio,$id_empresa, 
							                $to,$nombreto,$from,$nombrefrom,$tipo,($subject),($titulo1),($subtitulo1),
							                ($texto1),
							                $url,($texto_url),
							                ($texto2),($texto3),($texto4),$logo,$tipomensaje,$key,$template);
           		 }
					  
		            DeleteNotificacionesPendientesCargosNoPermitidos($rut);
            echo "<br>Fin BuscaPendientes<br>";
           
		
					 
					  	// Por Jefatura
					  	
					  	
					  	ini_set('output_buffering', 0);
							ini_set('zlib.output_compression', 0);
							if( !ob_get_level() ){ ob_start(); }
							else { ob_end_clean(); ob_start(); }
					  	
					  	//PENDIENTES JEFATURA DESACTIVOS
					    $Not_array_ElearningPendientesFecha=Not_cursosElearningObligatoriosPendientesFechaJefe($id_empresa, $id_programa, $fecha_inicio, "Division Personas y Organizacion");
					    
					    $fila=count($Not_array_ElearningPendientesFecha);
					    //echo "fila 2 $fila";
					    foreach ($Not_array_ElearningPendientesFecha as $unico) {
					    	
						       				 	$l2++;
						    						echo "<center><span style='position: absolute;z-index:$current;background:#36C6D3; padding:10px; color:#FFF'>Registro Jefatura $l2 de $fila</span></center>";
        										flush();	ob_flush();		
        						
					                $array_u=TraeDatosUsuario($unico->Jefe);
					                $array_c=TraeDatosUsuario($unico->Jefe);
					                $tipoenvio="Cursos_Elearning_PendientesJefe";
					                $tipoenvio="Cursos_Elearning_PendientesJefe";
					                $rut=$array_u[0]->rut;
					                $fecha_envio=$hoy;
					                $to=$array_u[0]->email;
					                $nombreto=$array_u[0]->nombre_completo;
					                $tipo        ="text/html";
					                $subject="Cursos Digitales pendientes";
					                $Not_Array_curso=Not_listacursosElearningObligatoriosPendientesFechaJefe($unico->Jefe, $fecha_inicio, $id_programa, $id_empresa);

					                $lista_curso=""; $cuenta_cursos=0;
					                foreach ($Not_Array_curso as $curso){ 
					                	//echo "<h2>Jefe ".$unico->Jefe." --> ".$curso->rut."</h2>";
					                	    							$Ausente=Ausentismo_rut($curso->rut);
															    							if($Ausente>0){
															    								//continue;
															    								//echo "<script>alert('Ausente ".$curso->rut."');</script>";
															    							} else {
															    								//echo "<br>--->".$curso->rut;
															    									$cuenta_cursos++;
															    								  $lista_curso.="<br>".$curso->nombre.", Curso: ".$curso->nombre_curso."";
															    							}
					                	//echo "<br>----> cuenta curso ".$cuenta_cursos;
					                 
					                }
					                
					                
					                
					                if($cuenta_cursos>1){
							                $titulo1="Estimado(a) Jefe,";
							                $subtitulo1="Te informamos que colaboradores de tu equipo tienen Cursos digitales pendientes:";
							                $texto1='<p class="text-left">'.($lista_curso).'</p>';
							                $texto2="Te invitamos a incentivar a tus colaboradores a terminar los cursos de capacitación, los cuales son de caracter obligatorio.
							                <br>Recomendamos que les sugieras que programen tiempo en sus agendas para estudiar de una forma óptima,
							                ya que estos cursos son importantes para el desempeño del cargo y su desarrollo profesional.";
					                } elseif($cuenta_cursos=="1"){
					                
					                
					                
							                $titulo1="Estimado(a) Jefe,";
							                $subtitulo1="Te informamos que un colaborador de tu equipo tiene un Curso Digital pendiente:";
							                $texto1='<p class="text-left">'.($lista_curso).'</p>';
							                $texto2="Te invitamos a incentivar a tu colaborador(a) a terminar el  curso de capacitaci󮬠el cual es de caracter obligatorio.
							                <br>Recomendamos que les sugieras que programen tiempo en sus agendas para estudiar de una forma óptima,
							                ya que estos cursos son importantes para el desempeño del cargo y su desarrollo profesional.";
					                } else {
					                	$cuenta_cursos=="0";
					                }
					                $texto3="¡Desde ya agradecemos tu colaboración";
					                $texto4="";

					                $url=$url_front;
					                $texto_url="";

					                $tipomensaje="Curso_Pendiente_usuarioJefe";
					                $key=$rut;
					                $template="";
					                $not_cuenta4++;
					                
					                if($cuenta_cursos>0){
					                	InsertNotificacionesPendientes($tipoenvio,$nombre,$rut,$fecha_envio,$id_empresa,
					                	$to,$nombreto,$from,$nombrefrom,$tipo,($subject),($titulo1),($subtitulo1),
					                	($texto1),$url,($texto_url),
					                	($texto2),($texto3),($texto4),$logo,$tipomensaje,$key,$template);
					                }
					                
					    }



											//echo "<br>4 $not_cuenta4";
											// 7. Cursos Elearning Inscritos Hoy
    									//$Not_array_InscripcionesHoy=Not_cursosElearningInscripcion($hoy,$id_empresa);
											//print_r($Not_array_Evaluaciones_Individuales);
									    foreach ($Not_array_InscripcionesHoy as $unico) {
									                $array_u=TraeDatosUsuario($unico->rut);
									                $array_c=TraeDatosUsuario($unico->rut);
									                $tipoenvio="Cursos_Elearning_InscritosHoy";
									                $rut=$array_u[0]->rut;
									                $fecha_envio=$diamañana;
									                $to=$array_u[0]->email;
									                $nombreto=$array_u[0]->nombre_completo;
									                $tipo        ="text/html";
									                $subject="¡Estás inscrito en un nuevo Curso!";
									                $Not_Array_curso=Not_lista_cursosElearningInscripcion($hoy,$unico->rut, $id_empresa);
									                $lista_curso="";
									                foreach ($Not_Array_curso as $curso){
									                    $lista_curso.="<br>".$curso->nombre_programa.", Curso: ".$curso->nombre_curso."";
									                }
									                $titulo1="Te invitamos a que realices un nuevo Curso Elearning";
									                $subtitulo1="La siguiente es la lista de cursos que están disponibles desde hoy para ti";
									                $texto1='<p class="text-left">'.($lista_curso).'</p>';
									                $texto2="Recuerda que terminar los cursos es una parte fundamental de tu desarrollo laboral";
									                $texto3="No te tomará más de 10 minutos por curso, ¡Aprovecha ahora!";
									                $url=$url_front;
									                $texto_url="Ingresa aqui";
									                $texto2=" ";$texto3=" ";$texto4=" ";
									                $tipomensaje="Cursos_Elearning_InscritosHoy";
									                $key=$rut;
									                $template="https://" . $_SERVER['SERVER_NAME'] . "/front/views/emails_notificaciones/" . $id_empresa . "_template_notificacion.html";
									                $not_cuenta5++;
									                InsertNotificacionesPendientes($tipoenvio,$nombre,$rut,$fecha_envio,$id_empresa,
									                $to,$nombreto,$from,$nombrefrom,$tipo,($subject),($titulo1),($subtitulo1),
									                ($texto1),
									                $url,($texto_url),
									                ($texto2),($texto3),($texto4),$logo,$tipomensaje,$key,$template);
									            }
            //echo "<br>5 $not_cuenta5";
            
            
            DeleteNotificacionesPendientesCargosNoPermitidos($rut);
            echo "<br>Fin BuscaPendientes<br>";
            
}

function notificaciones_email_lista_notificaciones($html,  $id_empresa, $idcategoria, $id_instancia, $tipo_instancia){
    $notificaciones=notificaciones_email_lista_notificaciones_data($id_empresa, $id_instancia, $tipo_instancia);
    foreach($notificaciones as $unico){
			$row=file_get_contents("views/notificaciones_email/row_notificaciones.html");
			$row = str_replace("{ID_ENCODE}",    	Encodear3($unico->id),$row);
			//echo "<br>$id_instancia, $tipo_instancia<br>";
			
			$row = str_replace("{NOMBRE}",    		($unico->nombre),$row);
			$row = str_replace("{SUBJECT}",   		($unico->subject),$row);
			$row = str_replace("{TITULO}",    		($unico->titulo),$row);
			$row = str_replace("{TEXTO}",     		($unico->texto),$row);
			
			$Notificacion			=	notificaciones_email_notificaciones_usuarios_envios($unico->id, $id_empresa); 
			$num_usuarios			=	$Notificacion[0]->usuarios;
			$num_envios				= $Notificacion[0]->emails_enviados;
			//print_r($Notificacion);
			
				$agrega_usuario	= "<a href='?sw=notificaciones_email_update_users&id=".Encodear3($unico->id)."' class='btn btn-link' >Usuarios Inscritos (".$num_usuarios.")</a>";
				$envia_usuario_nuevos	= "<a href='?sw=notificaciones_email_send_emails&id=".Encodear3($unico->id)."&tipo=envio_nuevos' class='btn btn-link' >Enviar No Enviados</a>";
				$envia_usuario_todos	= "<a href='?sw=notificaciones_email_send_emails&id=".Encodear3($unico->id)."&tipo=envio_todos' class='btn btn-link' >Enviar Todos</a>";	
			$row = str_replace("{AGREGAR_USUARIOS}",  	$agrega_usuario,$row);
			$row = str_replace("{ENVIADOS}",   					$num_envios,$row);
			$row = str_replace("{ENVIAR_A_NUEVOS}",  		$envia_usuario_nuevos,$row);
			$row = str_replace("{ENVIAR_A_TODOS}",   		$envia_usuario_todos,$row);
			$total_html.=$row;
     }
    $html = str_replace("{LISTA_NOTIFICACIONES}",$total_html,$html);
    
    if($id_instancia<>""){
      $html = str_replace("{TITULO}","Notificaciones Email",$html);
     	$html = str_replace("{VOLVER_BACK}","<a href='?sw=concurso_lista_concurso' class='btn btn-link'>Volver</a>",$html);   	
    } else {
     	$html = str_replace("{TITULO}","Notificaciones Email",$html);
     	$html = str_replace("{VOLVER_BACK}","",$html);
   	
    }
    
    return($html);
}
function lista_encuestas_fn_lb($html,  $id_empresa, $idcategoria){
    $Encuestas=TraeEncuestasLBEmpresa($id_empresa);
    $row=file_get_contents("views/encuesta_lb/entorno_mediciones_row.html");
    $listabancopregunta=EncuestasLBListaBancoPreguntas_data($id_empresa);
    //print_r($listabancopregunta);

								 foreach($Encuestas as $unico){
								    $activa=0;
								    if($unico->imagenlogo==""){$activa=1;}
								    if($activa==1) {$bot="<span class='badge badge-success'>Encuesta Activa</span><br><a href='?sw=lista_encuestas_lb&ie=".$unico->id."&desactiva=1' class='btn btn-link btn-sm'>Desactivar</a>";}
								    if($activa==0) {$bot="<span class='badge badge-light'>Encuesta Desactiva</span><br><a href='?sw=lista_encuestas_lb&ie=".$unico->id."&activa=1' class='btn btn-link btn-sm'>Activar</a>";}
								        $row=file_get_contents("views/encuesta_lb/row_mediciones.html");
								        $row = str_replace("{ID_MEDICION}",      ($unico->id),$row);
								        $row = str_replace("{NOMBRE_MEDICION}",  ($unico->nombre),$row);
								        $row = str_replace("{BANCO_PREGUNTA}",  ($unico->bancopreguntas),$row);
								        $row = str_replace("{ID_BANCO_PREGUNTA}",  ($unico->id_encuesta),$row);
								        $row = str_replace("{TIPO_MEDICION}",  ($unico->tipo_medicion),$row);
								        $row = str_replace("{FECHA1}",  ($unico->fecha1),$row);
								        $row = str_replace("{BOTON_ACTIVAR_DESACTIVAR}", $bot,$row);

												$usuarios											=	"<a href='?sw=update_users_encuestas_lb&id_encuesta=".$unico->id."&perfil=Usuario' 						style='btn btn-link'>Usuarios Inscritos (".$unico->usuarios.")</a>";
												$editores											=	"<br><a href='?sw=update_users_encuestas_lb&id_encuesta=".$unico->id."&perfil=Editor' 				style='btn btn-link'>Editores (".$unico->editores.")</a>";
												$visualizacion_resultados			=	"<br><a href='?sw=update_users_encuestas_lb&id_encuesta=".$unico->id."&perfil=Visualizador' 	style='btn btn-link'>Visualizacion Resultados (".$unico->visualizadores.")</a>";
												$editores	="";	
												$visualizacion_resultados	="";
												
								        $row = str_replace("{USUARIOS_INSCRITOS}", 	$usuarios,$row);
								        $row = str_replace("{EDITORES}", 						$editores,$row);
								        $row = str_replace("{REPORTES}", 						$visualizacion_resultados,$row);

								        $row = str_replace("{FECHA2}",  					($unico->fecha2),$row);
								        $row = str_replace("{FECHA3}",  					($unico->fecha3),$row);

								        $row = str_replace("{IMAGE_BANNER}",  		($unico->imagensuperior),$row);
								        $row = str_replace("{IMAGE_BACKGROUND}",  ($unico->imageninferior),$row);

								        $row = str_replace("{NUM_PREGUNTA}",  	($unico->cuentapreguntas),$row);
								        $row = str_replace("{NUM_USUARIOS}",  	($unico->cuentausuarios),$row);
								        $row = str_replace("{NUM_RESPUESTAS}",  ($unico->respuestas),$row);
								        $row = str_replace("{OPTIONS_LISTA_BANCO_PREGUNTAS_MEDICIONES}",($listabancopregunta),$row);
								        
								        
								        
								                    $total_html.=$row;
								 }
			        $listabancopregunta=EncuestasLBListaBancoPreguntas_data($id_empresa);
			        foreach($listabancopregunta as $unicobanco){
			            $option_encuestas.="<option value='".($unicobanco->id)."'>".($unicobanco->nombre)."</option>";
			        }

			    $html = str_replace("{LISTA}",$total_html,$html);
			    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
			    $html = str_replace("{BTN}","Nueva Pregunta",$html);
			    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
			    $html = str_replace("{BTN_VOLVER}",'',$html);
			    $html = str_replace("{COLUMNA}",'Pregunta',$html);
			    $html = str_replace("{OPTIONS_LISTA_BANCO_PREGUNTAS_MEDICIONES_FULL_DETALLE}",$option_encuestas,$html);
			    return($html);
			}
			
function jListarCamposEmpresaSubidaUsuarios($response,$idEmpresa){
    /*
        1 = Devuelve el nombre de los campos a mostrar ordenados y separados por Obligatorios y Opcionales.
        2 = Devuelve el nombre de los campos a mostrar en un arreglo.
        3 = Devuelve el nombre de los campos en la BD en un arreglo.
    */
    $result = listarEmpresaSubidaUsuarios($idEmpresa);
    $arr = array();
    $i = 0;
    if($response == 3){
        foreach($result as $row){
            $arr[$i] = $row->campo;
            $i++;
        }
        return $arr;
    }else if($response == 2){
        foreach($result as $row){
            $arr[$i] = $row->nombrecampoamostrar;
            $i++;
        }
        return $arr;
    }else{
        $obligatorios = "";
        $opcionales = "";
        foreach($result as $row){
            if($row->obligatorio == 1){
                $obligatorios .= ",".$row->nombrecampoamostrar;
            }else{
                $opcionales .= ",".$row->nombrecampoamostrar;
            }
        }
        $arr = $obligatorios."|".$opcionales;
        return $arr;
    }
}
function NotificacionesAutomaticas_envio($id_empresa){
        $hoy=date("Y-m-d");
        //$hoy="2018-02-20";
        $Not_array_MRH=Not_buscaNotificacionesEnvioHoyEstadoNull($hoy,$id_empresa);
        //print_r($Not_array_MRH);sleep(3);
        
				$count_total_loop=count($Arreglo);
				ini_set('output_buffering', 0);
				ini_set('zlib.output_compression', 0);
				if( !ob_get_level() ){ ob_start(); }
				else { ob_end_clean(); ob_start(); }
        
        foreach($Not_array_MRH as $unico){
        	
						$cuenta_loop++;
    		    echo "<center><span style='position: absolute;z-index:$current;background:#36C6D3; padding:10px; color:#FFF'>Enviando $cuenta_loop de $count_total_loop Registros</span></center>";
        		flush(); ob_flush();              	
        	
						$id_empresa=$unico->id_empresa;
						$to=$unico->hacia;
						$nombreto=$unico->nombreto;
						$from=($unico->desde);
						$nombrefrom=($unico->nombrefrom);
						$tipo=$unico->tipo;
						$subject=($unico->asunto);
						$titulo1=($unico->titulo1);
						$subtitulo1=($unico->subtitulo1);
						$texto1=($unico->texto1);
						$url=$unico->url;
						$texto_url=($unico->texto_url);
						$logo=$unico->logo;
						$texto2=($unico->texto2);
						$texto3=($unico->texto3);
						$texto4=($unico->texto4);
						$tipomensaje=$unico->tipomensaje;
						$rut=$unico->clave;
						$key=$unico->clave;
						$template=$unico->template;
						/*
						echo "<br>to $to, nombre $nombreto, fro $from, nombrefrom $nombrefrom, tipo $tipo, subject $subject,  titulo1 $titulo1, subtitulo1 $subtitulo1,  texto1 $texto1, url $url,  texto_url $texto_url,
						texto2 $texto2, texto3 $texto3,  texto4 $texto4, logo $logo, id_empresa $id_empresa, url $url, tipomensaje $tipomensaje, rut $rut,key $key, template $template";
						sleep(5); */
						SendGrid_Email($to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url, $texto_url,
						$texto2, $texto3, $texto4, $logo, $id_empresa, $url, $tipomensaje, $rut, $key, $template);
						echo "<br>to $to, nombre $nombreto,$subject";
						Not_Actualiza_estado($unico->id,"ENVIADA");
        }
}
function lista_puntos_canjes($html,  $id_empresa, $idcategoria, $fecha_inicio, $fecha_termino, $limit){
    $lista_puntos_stock_fe=lista_puntos_canjes_data($id_empresa,  $fecha_inicio, $fecha_termino, $limit);
    // print_r($lista_puntos-_stock_fe);


    //$categorias_options=mp_busca_Categorias($id_empresa);    //print_r($categorias_options);
    foreach($lista_puntos_stock_fe as $unico){
        //$datos_colaborador=TraeDatosUsuario($unico->rut);
        //$datos_jefe=TraeDatosUsuario($datos_colaborador[0]->jefe);
        if($unico->estadovalidacion=="1"){ $estado="VALIDADO"; $estado_estilo="<span class='badge badge-info'>Validado</span>"; $accion1=""; $accion2="";}
        if($unico->estadovalidacion=="2"){ $estado="PENDIENTE"; $estado_estilo="<span class='badge badge-warning'>Pendiente</span>"; }
        if($unico->estadovalidacion=="3"){ $estado="REVERDSADO"; $estado_estilo="<span class='badge badge-danger'>Reversado</span>"; $accion1=""; $accion2="";}

        $accion1="<a href='?sw=puntos_canjes&idbencanj=".$unico->id."&valida=1' class='btn btn-success btn-xs' style='display: inline;'>Validar</a>";
        $accion2="<a href='?sw=puntos_canjes&idbencanj=".$unico->id."&valida=3' class='btn btn-danger btn-xs' style='display: inline;'>Reversar</a>";

        if($unico->id_premio=="bch_cert"){
            $unico->premio="Certificacion Cursos Internacionales";
            $unico->dimension="Certificacion Cursos Internacionales";

        }
        $row = str_replace("{PREMIO}",                    ($unico->premio),$row);
        $row = str_replace("{DIMENSION}",                	($unico->dimension),$row);

        $row = file_get_contents("views/puntos/row_puntos_canjes.html");
        $row = str_replace("{ID_CANJE}",                	($unico->id),$row);
        $row = str_replace("{NOMBRE_COMPLETO}",           ($unico->nombre_completo),$row);
        $row = str_replace("{CARGO}",                    	($unico->rut),$row);
        $row = str_replace("{PREMIO}",                    ($unico->premio),$row);
        $row = str_replace("{DIMENSION}",                	($unico->dimension),$row);
        $row = str_replace("{PUNTOS}",                    ($unico->puntos),$row);
        $row = str_replace("{DETALLES_PREMIO}",           ($unico->dimension),$row);
        $row = str_replace("{NOMBRE_JEFATURA}",           ($unico->nombre_completo_jefe),$row);
        $row = str_replace("{CARGO_JEFATURA}",            ($unico->cargo),$row);
        $row = str_replace("{FECHA_CANJE}",        				($unico->fecha),$row);
        $row = str_replace("{ESTADO}",        						($estado_estilo),$row);
        $row = str_replace("{BOTON_ACCION1}",        			($accion1),$row);
        $row = str_replace("{BOTON_ACCION2}",        			($accion2),$row);
        $total_html.=$row;
    }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Canjes Realizados",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_puntos_canjes_despachos($html,  $id_empresa, $idcategoria){
    $lista_puntos_stock_fe=lista_puntos_canjes_despachos_data($id_empresa);
    //print_r($lista_puntos_stock_fe);    //$categorias_options=mp_busca_Categorias($id_empresa);    //print_r($categorias_options);
    foreach($lista_puntos_stock_fe as $unico){
        //$//datos_colaborador=TraeDatosUsuario($unico->rut);
        //$datos_jefe=TraeDatosUsuario($datos_colaborador[0]->jefe);

        $accion1="
<a href='?sw=puntos_canjes_despachos&idbencanj=".$unico->id."&valida=CAP' class='btn btn-success btn-xs' style='display: inline;'>CAP</a>
<a href='?sw=puntos_canjes_despachos&idbencanj=".$unico->id."&valida=VALIJA' class='btn btn-success btn-xs' style='display: inline;'>VALIJA</a>
<a href='?sw=puntos_canjes_despachos&idbencanj=".$unico->id."&valida=BCH' class='btn btn-success btn-xs' style='display: inline;'>BCH</a>
<a href='?sw=puntos_canjes_despachos&idbencanj=".$unico->id."&valida=CDR' class='btn btn-success btn-xs' style='display: inline;'>CDR</a>


";
        $accion2="<a href='?sw=puntos_canjes_despachos&idbencanj=".$unico->id."&valida=3' class='btn btn-danger btn-xs' style='display: inline;'>Deshacer</a>";


        if($unico->despacho=="CAP")     { $estado="DESPACHADO CAP"; $estado_estilo="<span class='badge badge-info'>Despachado por CAP</span>"; $accion1=""; }
        if($unico->despacho=="VALIJA")  { $estado="DESPACHADO VALIJA"; $estado_estilo="<span class='badge badge-info'>Despachado por VALIJA</span>"; $accion1=""; }
        if($unico->despacho=="CDR")     { $estado="DESPACHADO CDR"; $estado_estilo="<span class='badge badge-info'>Despachado por CDR</span>"; $accion1=""; }
        if($unico->despacho=="BCH")     { $estado="DESPACHADO BCH"; $estado_estilo="<span class='badge badge-info'>Despachado por BCH</span>"; $accion1=""; }
        if($unico->despacho=="")        { $estado="PENDIENTE"; $estado_estilo="<span class='badge badge-warning'>Pendiente</span>"; $accion2="";}
        if($unico->despacho=="3")       { $estado="RECHAZADO"; $estado_estilo="<span class='badge badge-danger'>Rechazado</span>"; $accion2="";}


        $row = file_get_contents("views/puntos/row_puntos_canjes_despachos.html");
        $row = str_replace("{ID_CANJE}",               ($unico->id),$row);
        $row = str_replace("{NOMBRE_COMPLETO}",        ($unico->nombre_completo),$row);
        $row = str_replace("{CARGO}",                  ($unico->rut),$row);
        $row = str_replace("{PREMIO}",                 ($unico->premio),$row);
        $row = str_replace("{DIMENSION}",              ($unico->dimension),$row);
        $row = str_replace("{PUNTOS}",                 ($unico->puntos),$row);
        $row = str_replace("{DETALLES_PREMIO}",        ($unico->dimension),$row);
        $row = str_replace("{NOMBRE_JEFATURA}",        ($unico->nombre_completo_jefe),$row);
        $row = str_replace("{CARGO_JEFATURA}",         ($unico->cargo_jefe),$row);
        $row = str_replace("{FECHA_DESPACHO}",         ($unico->fecha_despacho),$row);
        $row = str_replace("{FECHA}",                  ($unico->fecha),$row);
        $row = str_replace("{ESTADO_DESPACHO}",        ($estado_estilo),$row);
        $row = str_replace("{BOTON_ACCION1}",          ($accion1),$row);
        $row = str_replace("{BOTON_ACCION2}",          ($accion2),$row);
        $total_html.=$row;
    }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Lista de Despachos",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_puntos_canjes_entregas($html,  $id_empresa, $idcategoria){
    $lista_puntos_stock_fe=lista_puntos_canjes_entregas_data($id_empresa);
    //print_r($lista_puntos_stock_fe);exit();    //$categorias_options=mp_busca_Categorias($id_empresa);    //print_r($categorias_options);
    foreach($lista_puntos_stock_fe as $unico){
        $datos_colaborador=TraeDatosUsuario($unico->rut);
        $datos_jefe=TraeDatosUsuario($datos_colaborador[0]->jefe);

        $accion1="<a href='?sw=puntos_canjes_entregas&idbencanj=".$unico->id."&valida=1' class='btn btn-success btn-xs' style='display: inline;'>Entregado</a>";
        $accion2="<a href='?sw=puntos_canjes_entregas&idbencanj=".$unico->id."&valida=3' class='btn btn-danger btn-xs' style='display: inline;'>Deshacer</a>";

        $estado="PENDIENTE"; $estado_estilo="<span class='badge badge-warning'>Pendiente</span>"; $accion2="";

        if($unico->entrega=="1"){ $estado="ENTREGADO"; $estado_estilo="<span class='badge badge-info'>Entregado</span>"; $accion1=""; }
        if($unico->entrega==""){ $estado="PENDIENTE"; $estado_estilo="<span class='badge badge-warning'>Pendiente</span>"; $accion2="";}
        if($unico->entrega=="3"){ $estado="RECHAZADO"; $estado_estilo="<span class='badge badge-danger'>Rechazado</span>"; $accion1=""; }



        $row = file_get_contents("views/puntos/row_puntos_canjes_entregas.html");
        $row = str_replace("{ID_CANJE}",            ($unico->id),$row);
        $row = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
        $row = str_replace("{CARGO}",               ($unico->rut),$row);
        $row = str_replace("{PREMIO}",              ($unico->premio),$row);
        $row = str_replace("{DIMENSION}",           ($unico->dimension),$row);
        $row = str_replace("{PUNTOS}",              ($unico->puntos),$row);
        $row = str_replace("{DETALLES_PREMIO}",     ($unico->dimension),$row);
        $row = str_replace("{NOMBRE_JEFATURA}",     ($unico->nombre_completo_jefe),$row);
        $row = str_replace("{CARGO_JEFATURA}",      ($unico->cargo_jefe),$row);
        $row = str_replace("{FECHA}",               ($unico->fecha),$row);
        $row = str_replace("{DESPACHO}",            ($unico->despacho),$row);
        $row = str_replace("{FECHA_DESPACHO}",      ($unico->fecha_despacho),$row);
        $row = str_replace("{FECHA_ENTREGA}",       ($unico->fecha_entrega),$row);
        $row = str_replace("{ESTADO_ENTREGA}",      ($estado_estilo),$row);
        $row = str_replace("{BOTON_ACCION1}",       ($accion1),$row);
        $row = str_replace("{BOTON_ACCION2}",       ($accion2),$row);
        $total_html.=$row;
    }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Lista de Entregas CAP",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_puntos_canjes_entregas_cdr($html,  $id_empresa, $idcategoria){
    $lista_puntos_stock_fe=lista_puntos_canjes_entregas_data_cdr($id_empresa);
    //print_r($lista_puntos_stock_fe);    //$categorias_options=mp_busca_Categorias($id_empresa);    //print_r($categorias_options);
    foreach($lista_puntos_stock_fe as $unico){
        $datos_colaborador=TraeDatosUsuario($unico->rut);
        $datos_jefe=TraeDatosUsuario($datos_colaborador[0]->jefe);

        $accion1="<a href='?sw=puntos_canjes_entregas_cdr&idbencanj=".$unico->id."&valida=1' class='btn btn-success btn-xs' style='display: inline;'>Entregado</a>";
        $accion2="<a href='?sw=puntos_canjes_entregas_cdr&idbencanj=".$unico->id."&valida=3' class='btn btn-danger btn-xs' style='display: inline;'>Deshacer</a>";

        if($unico->entrega=="1"){ $estado="ENTREGADO"; $estado_estilo="<span class='badge badge-info'>Entregado</span>"; $accion1=""; }
        if($unico->entrega==""){ $estado="PENDIENTE"; $estado_estilo="<span class='badge badge-warning'>Pendiente</span>"; $accion2="";}
        if($unico->entrega=="3"){ $estado="RECHAZADO"; $estado_estilo="<span class='badge badge-danger'>Rechazado</span>"; $accion1=""; }



        $row = file_get_contents("views/puntos/row_puntos_canjes_entregas_cdr.html");
        $row = str_replace("{ID_CANJE}",            ($unico->id),$row);
        $row = str_replace("{NOMBRE_COMPLETO}",     ($datos_colaborador[0]->nombre_completo),$row);
        $row = str_replace("{CARGO}",               ($unico->rut),$row);
        $row = str_replace("{PREMIO}",              ($unico->premio),$row);
        $row = str_replace("{DIMENSION}",           ($unico->dimension),$row);
        $row = str_replace("{PUNTOS}",              ($unico->puntos),$row);
        $row = str_replace("{DETALLES_PREMIO}",     ($unico->dimension),$row);
        $row = str_replace("{NOMBRE_JEFATURA}",     ($datos_jefe[0]->nombre_completo),$row);
        $row = str_replace("{CARGO_JEFATURA}",      ($datos_jefe[0]->cargo),$row);
        $row = str_replace("{FECHA}",               ($unico->fecha),$row);
        $row = str_replace("{DESPACHO}",            ($unico->despacho),$row);
        $row = str_replace("{FECHA_DESPACHO}",      ($unico->fecha_despacho),$row);
        $row = str_replace("{FECHA_ENTREGA}",       ($unico->fecha_entrega),$row);
        $row = str_replace("{ESTADO_ENTREGA}",      ($estado_estilo),$row);
        $row = str_replace("{BOTON_ACCION1}",       ($accion1),$row);
        $row = str_replace("{BOTON_ACCION2}",       ($accion2),$row);
        $total_html.=$row;
    }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Lista de Entregas CDR",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_asignacion($html,  $id_empresa, $idcategoria){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
    $row=file_get_contents("views/puntos/entorno_puntos_asignacion.html");
    //$lista=lista_asignacion_usuarios_data($id_empresa);
    foreach($lista as $unico){
        //$datosusuario=TraeDatosUsuario($unico->rut);

        $row=file_get_contents("views/puntos/row_puntos_asignacion.html");
        // $row = str_replace("{RUT_COMPLETO}",    ($datosusuario[0]->rut_completo),$row);
        $row = str_replace("{RUT_COMPLETO}",    ($unico->rut),$row);
        $row = str_replace("{NOMBRE_COMPLETO}",    ($datosusuario[0]->nombre_completo),$row);
        $row = str_replace("{CARGO}",    ($datosusuario[0]->cargo),$row);
        $row = str_replace("{DIVISION}",    ($datosusuario[0]->division),$row);
        $row = str_replace("{NUM_EQUIPO}",    ($datosNumEquipo),$row);
        $row = str_replace("{RECIBIDOS}",    ($unico->recibidos),$row);

        if($unico->entregados==""){$unico->entregados=0;}
        if($unico->saldo==""){$unico->saldo=$unico->recibidos;}

        $row = str_replace("{ENTREGADOS}",    ($unico->entregados),$row);
        $row = str_replace("{PENDIENTES}",    ($unico->saldo),$row);

        $total_html.=$row;

    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Asignación de Puntos a usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_asignacion_notificaciones($html,  $id_empresa, $idcategoria){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
    $row=file_get_contents("views/puntos/entorno_puntos_asignacion.html");
    foreach($emb_embajadores as $unico){
                    $row=file_get_contents("views/embajadores/row_emb_inscribir.html");
                    $row = str_replace("{ID}",                    ($unico->id),$row);
                    $row = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
                    $row = str_replace("{NOMBRE_COMPLETO}",        ($unico->nombre_completo),$row);
                    $row = str_replace("{CARGO}",                ($unico->cargo),$row);
                    $row = str_replace("{GERENCIA}",            ($unico->gerencia),$row);
                    $row = str_replace("{GERENCIAR2}",            ($unico->gerenciaR2),$row);
                    $row = str_replace("{GERENCIAR3}",            ($unico->gerenciaR3),$row);
                    $row = str_replace("{OLA}",                    ($unico->nombre_ola),$row);
                    $row = str_replace("{OLA}",                    ($unico->nombre_ola),$row);
                    $row = str_replace("{OLA}",                    ($unico->nombre_ola),$row);
                    $row = str_replace("{OLA}",                    ($unico->nombre_ola),$row);
                    $row = str_replace("{RUT_TUTOR}",        ($unico->rut_tutor),$row);
                    $row = str_replace("{NOMBRE_COMPLETO_TUTOR}",        ($unico->nombre_completo_tutor),$row);
                    $row = str_replace("{CARGO_TUTOR}",                    ($unico->cargo_tutor),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Asignación de Notificaciones a usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function VerificaExtensionFilesAdmin($FILE){
		//echo "<br>file $file";

    /*FUNCION LIMPIA CABECERA*/
    $fileDir = $FILE['tmp_name'];
    if($fileDir!=""){
        $file = fopen($fileDir, "r");
        //Output lines until EOF is reached
        $palabras = array('/JS', '/JavaScript', '/Action', '/js', '/javascript', '/action');
        $encontrada=false;
        while(! feof($file)) {
            $line = fgets($file);
            foreach($palabras as $palabra) {
                if (strpos($line, $palabra) !== false) {
                    $encontrada = true;
                    break;
                }
            }
        }
    }

    if($encontrada){
        echo "<script>alert('Formato de Archivo Incompatible'); location.href='?sw=home_landing_2020';</script>";exit();
    }

    $file_name=$FILE['name'];

    $arreglo_archivo = explode(".", $file_name);
    $extension_archivo = $arreglo_archivo[1];
		//echo "<br>cuenta ".count($arreglo_archivo);		//print_r($arreglo_archivo);		//echo "<br>ex $extension_archivo";

    
    
    
	if(count($arreglo_archivo)<>2){
		echo "<br>archivo invalido con mas de una extension";	 echo "    <script>alert('Formato de Archivo Incompatible'); 			location.href='?sw=home_landing';    </script>";exit();
	}
			
	if($extension_archivo=="pdf" or $extension_archivo=="PDF" or $extension_archivo=="ppt" or $extension_archivo=="PPT"
	or $extension_archivo=="pptx" or $extension_archivo=="PPTX" or $extension_archivo=="doc" or $extension_archivo=="DOC"
	or $extension_archivo=="docx" or $extension_archivo=="DOCX" or $extension_archivo=="xls" or $extension_archivo=="XLS"
	or $extension_archivo=="xlsx" or $extension_archivo=="XLSX" or $extension_archivo=="jpg" or $extension_archivo=="JPG"
	or $extension_archivo=="jpeg" or $extension_archivo=="JPEG" or $extension_archivo=="zip" or $extension_archivo=="ZIP"
	or $extension_archivo=="png" or $extension_archivo=="PNG" or $extension_archivo=="CSV"  or $extension_archivo=="csv")	{
		//echo "<br>archivo valido";
	} else {
	 echo "<br>archivo invalido";	 echo "    <script>alert('Formato de Archivo Incompatible'); 			location.href='?sw=home_landing';    </script>";exit();
	 
	}

}

function lista_evaluaciones($html,  $id_empresa, $idcategoria){
    $ExpertosPracticas=TraeEvaluacionesPorEmpresa($id_empresa);
    $row=file_get_contents("views/evaluaciones/entorno_evaluaciones.html");
    foreach($ExpertosPracticas as $ExpertoPractica){
        $arreglo_cursos=traeCursosPorEvaluaciones($id_empresa, $ExpertoPractica->id);
        $lista_cursos="";
        foreach($arreglo_cursos as $arreglo_curso){
                $lista_cursos.="(".$arreglo_curso->id_curso.") ".($arreglo_curso->nombre)."<br>";
        }
        $row=file_get_contents("views/evaluaciones/lista_practicas_edit_evaluaciones.html");
        $row = str_replace("{ID_EVALUACION}",        ($ExpertoPractica->id),$row);
        $row = str_replace("{NOMBRE_EVALUACION}",    ($ExpertoPractica->nombre_evaluacion),$row);
        $row = str_replace("{CURSOS_UTILIZADOS}",    $lista_cursos,$row);
        $row = str_replace("{NUM_PREGUNTAS}",          ($ExpertoPractica->num_preguntas),$row);
        //$row = str_replace("{TIPO_RELATOR}",        ($ExpertoPractica->cargo),$row);
        $total_html.=$row;
                }
    $total_html = str_replace("{NIVEL}","2",$total_html);
    $total_html = str_replace("{SUB_CAT}","",$total_html);
    $total_html = str_replace("{NSUB}","",$total_html);
    $html = str_replace("{OPTIONS_CATEGORIAS_MEJORES_PRACTICAS_NUEVO}",($categorias_options),$html);
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function jListarPreguntas($PRINCIPAL, $idEval, $programa){
    $preguntas = listarRegistrosTablaGlobalFiltro("tbl_evaluaciones_preguntas","evaluacion",$idEval,"orden asc");
    $tableRows = "";
    if(count($preguntas) == 0){
        $tableRows .= "<tr><td colspan = '3'>No existen registros de preguntas para esta evaluaci&oacuten</td></tr>";
    }else if(count($preguntas) > 0){
        foreach($preguntas as $row1){
            $alternativas = listarRegistrosTablaGlobalFiltro("tbl_evaluaciones_alternativas","id_grupo_alternativas",$row1->id_grupo_alternativas,"");
            $totalAlternativas = count($alternativas);
            $tableRows .= "<tr>";
            $tableRows .= "<td rowspan='".($totalAlternativas+1)."'  class='lms_preg_num_eval'>".$row1->orden."</td>";
            //$tableRows .= "<td class='lms_preg_texto_eval'>".(($row1->pregunta))."</td>";
            if($row1->tipo==2){
                $tableRows .= "<td class='lms_preg_texto_eval'>".(($row1->pregunta))."<br><img src='../front/".$row1->url_archivo."'><br></td>";
            }else{
                $tableRows .= "<td class='lms_preg_texto_eval'>".(($row1->pregunta))."<br></td>";
            }
            $tableRows .= "
            <td rowspan='".($totalAlternativas+1)."' class='lms_preg_alternativas_eval' style='width: 100px;'>
                <a href='?sw=editPreg&idEval=$idEval&idGrup=".$row1->id_grupo_alternativas."' title='Editar Pregunta' class='btn btn-success btn-sm'><i class='glyphicon glyphicon-edit'></i></a>
                <a onclick = \"if (! confirm('Continue?')) return false;\"  href='?sw=dltPreg&idEval=$idEval&idPreg=".$row1->id."' title='Eliminar Pregunta' class='btn btn-danger btn-sm'><i class='glyphicon glyphicon-remove'></i></a>
                </td>";
            $tableRows .= "</tr>";
            foreach($alternativas as $row2){
                $tableRows .= "<tr>";
                if($row2->correcta == 1){
                    $tableRows .= "<td class='lms_preg_alternativa_correcta_eval'><i class='fa fa-check-circle' aria-hidden='true'></i> ".(($row2->alternativa))."</p></td>";
                }else{
                    $tableRows .= "<td class='lms_preg_alternativas_eval'> ".(($row2->alternativa))."</td>";
                }
                $tableRows .= "</tr>";
            }
        }
    }
    $js = "    <script type = 'text/javascript'>
            </script>";
$nombre_ev=nombreEvaL($idEval);
    $PRINCIPAL = str_replace("{ID_EVAL}",$idEval,$PRINCIPAL);
    $PRINCIPAL = str_replace("{PROGRAMA}",$programa,$PRINCIPAL);
    $PRINCIPAL = str_replace("{LISTADO_PREGUNTAS}",$tableRows,$PRINCIPAL);
    $PRINCIPAL = str_replace("{EVALUACION}",($nombre_ev[0]->nombre_evaluacion),$PRINCIPAL);
    $PRINCIPAL = str_replace("{CURSO}",$tableRows,$PRINCIPAL);
    $PRINCIPAL = str_replace("{LIST_PREG_JS}",$js,$PRINCIPAL);
    return ($PRINCIPAL);
}
function SubirPreguntasMasivo($PRINCIPAL, $idEval, $programa){
    $idEmpresa = $_SESSION["id_empresa"];
    $totalPreg = count(listarRegistrosTablaGlobalFiltro("tbl_evaluaciones_preguntas","evaluacion",$idEval,""));
    $evaluacion = BuscarEvaluacion($idEval);
    foreach($evaluacion as $row){
        $PRINCIPAL = str_replace("{EVALUACION}",($row->nombre_evaluacion),$PRINCIPAL);
        $PRINCIPAL = str_replace("{ID_EVAL}",$row->id,$PRINCIPAL);
    }
    $PRINCIPAL = str_replace("{PROGRAMA}",$programa,$PRINCIPAL);
    $PRINCIPAL = str_replace("{ID_EMPRESA}",$idEmpresa,$PRINCIPAL);
    $PRINCIPAL = str_replace("{DISPLAYFORM1}","display:none;",$PRINCIPAL);
    $PRINCIPAL = str_replace("{DISPLAYFORM2}","inline",$PRINCIPAL);
    $PRINCIPAL = str_replace("{ENTORNO_PREVIA}","",$PRINCIPAL);
    $PRINCIPAL = str_replace("{TITULO2}","Formulario de subida",$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOTAL_PREG}",$totalPreg,$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOT_ACTUALIZAR}","0",$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOT_INSERTAR}","0",$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOT_ELIMINAR}","0",$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOT_DESVINCULAR}","0",$PRINCIPAL);
    $PRINCIPAL = str_replace("{TOT_ERRORES}","0",$PRINCIPAL);
    $PRINCIPAL = str_replace("{ERRORES}","",$PRINCIPAL);
    $PRINCIPAL = str_replace("{DISPLAYERROR}","display:none;",$PRINCIPAL);
    return ($PRINCIPAL);
}
function BuscarEvaluacion($idEval){
    return buscarRegistroTablaGlobalFiltro("tbl_evaluaciones","id",$idEval);
}

function eliminardatospreguntasalternativastmp(){
    truncarTablaGlobal("tbl_evaluaciones_preguntas_tmp");
    truncarTablaGlobal("tbl_evaluaciones_alternativas_tmp");
}

function InsertarRegistroParaCalculoTablaPreguntasTmp(){
    $maxGrupoAlterId = 0;
    //$result = buscarMaxValueTablaGlobal("id_grupo_alternativas","id","tbl_evaluaciones_preguntas");
    $result = buscarMaxValueTablaGlobal("id_grupo_alternativas","id","tbl_evaluaciones_alternativas");
    foreach($result as $row){
        $maxGrupoAlterId = $row->id;
    }
    insertarRegistroTablaGlobal("tbl_evaluaciones_preguntas_tmp","id_grupo_alternativas",$maxGrupoAlterId);
}
function ExistePregunta($idEval, $idPreg){
    $arrNames = array("evaluacion","id");
    $arrValues = array($idEval,$idPreg);
    $result = buscarRegistroTablaGlobalFiltros("tbl_evaluaciones_preguntas",$arrNames, $arrValues);
    //var_dump($result);
    if(count($result) > 0){
        return true;
    }else{
        return false;
    }
}

function InsertarPreguntasAlternativasTmp($valuesPreg, $valuesAlter, $accion, $idEval, $idEmpresa){

    $nuevoIdGrupoAlter = 0;
    $totalAlter = 0;
    $totalNuevasAlter = 0;
    $arrValuesPreg = explode("|",$valuesPreg);
 
    if($arrValuesPreg[3] == "" || $arrValuesPreg[3] == " "){
        $arrValuesPreg[3] = 0;
    }
    if($arrValuesPreg[1] == 0 ){
        $result = buscarMaxValueTablaGlobal("id_grupo_alternativas","id","tbl_evaluaciones_preguntas_tmp");
        foreach($result as $row){
            $nuevoIdGrupoAlter = $row->id+1;
        }
    }else{
        $nuevoIdGrupoAlter = $arrValuesPreg[4];
    }
    $registroPreg = $arrValuesPreg[3].",$idEval,$nuevoIdGrupoAlter,$idEmpresa,".$arrValuesPreg[5].",1,'".($arrValuesPreg[0])."',
    '".$accion."','".($arrValuesPreg[1])."','".($arrValuesPreg[2])."'";
    $arrValuesAlter = explode("|",$valuesAlter);
//print_r($arrValuesAlter);
    if($arrValuesAlter[1] == "" || $arrValuesAlter[1] == " "){
        $separador = "";
        for($i=0; $i<count($arrValuesAlter); $i++){
            $valoresIdsAlter[$i] .= $separador."0";
            $separador = "_";
        }
    }else{
        $valoresIdsAlter = explode("_",$arrValuesAlter[1]);
        for($i=2; $i<count($arrValuesAlter); $i++){
            if(strlen($arrValuesAlter[$i]) > 0){
                $totalAlter++;
            }
        }
        $totalAlterNuevas = $totalAlter - count($valoresIdsAlter);
        for($j=0; $j<$totalAlterNuevas; $j++){
            array_push($valoresIdsAlter,"0");
        }
    }
//echo "<br><br>";var_dump($valoresIdsAlter);
    $registroAlter = "{ID},$nuevoIdGrupoAlter,$idEmpresa,{ORDEN},{CORRECTA}";
    $arrRegistrosAlter = array();
    for($x=1; $x<count($arrValuesAlter); $x++){
        if($arrValuesAlter[$x] == "" || $arrValuesAlter[$x] == " "){
            break;
        }else{
            $arrRegistrosAlter[$x-1] = $registroAlter.",'".($arrValuesAlter[$x])."','{ACCION}'";
            $arrRegistrosAlter[$x-1] = str_replace("{ORDEN}",$x-1,$arrRegistrosAlter[$x-1]);
            if($valoresIdsAlter[$x-1] == 0){
                $arrRegistrosAlter[$x-1] = str_replace("{ID}",0,$arrRegistrosAlter[$x-1]);
                $arrRegistrosAlter[$x-1] = str_replace("{ACCION}","INSERTAR",$arrRegistrosAlter[$x-1]);
            }else{
                $arrRegistrosAlter[$x-1] = str_replace("{ID}",$valoresIdsAlter[$x-1],$arrRegistrosAlter[$x-1]);
                $arrRegistrosAlter[$x-1] = str_replace("{ACCION}","ACTUALIZAR",$arrRegistrosAlter[$x-1]);
            }
        }
    }
    //print_r($arrRegistrosAlter);
    $result = insertarPreguntaAlternativaTmp($registroPreg, $arrRegistrosAlter,$arrValuesAlter[0]);
    return $result;
}

function ContarRegistrosTablaGlobalFiltro($tableName,$filterName,$filterValue){
    $total = listarRegistrosTablaGlobalFiltro($tableName,$filterName,$filterValue,"");
    return count($total);
}

function ListarPreguntasMasivoPreview($idEmpresa, $idEval){
    $table = "<div class='box-body table-responsive'>";
    $table .= "<table id='example2' class='table table-bordered table-hover sortable'>";
    $table .= "<thead>";
    $table .= "<tr>";
    $table .= "<th>ACCI&OacuteN</th>";
    $table .= "<th>ORDEN</th>";
    $table .= "<th>PREGUNTA</th>";
    $table .= "<th>NUM ALTERNATIVAS</th>";
    $table .= "</tr>";
    $table .= "</thead>";
    $table .= "<tbody>";
    $arrNames = array("id_evaluacion","id_empresa");
    $arrValues = array($idEval,$idEmpresa);
    $preguntas = listarRegistrosTablaGlobalFiltros("tbl_evaluaciones_preguntas_tmp",$arrNames,$arrValues,"orden asc");
    foreach($preguntas as $row1){
        $table .= "<tr>";
        $table .= "<td>".$row1->accion."</td>";
        $table .= "<td>".$row1->orden."</td>";
        $table .= "<td>".(($row1->pregunta))."</td>";
        $arrNames = array("id_grupo_alternativas","id_empresa");
        $arrValues = array($row1->id_grupo_alternativas,$idEmpresa);
        $alternativas = listarRegistrosTablaGlobalFiltros("tbl_evaluaciones_alternativas_tmp",$arrNames,$arrValues,"");
        $table .= "<td>".count($alternativas)."</td>";
        $table .= "</tr>";
    }
    $table .= "</tbody>";
    $table .= "</table>";
    $table .= "</div>";
    return $table;
} 

function CruzarPreguntasAlternativasTmpConOriginal($idEmpresa, $idEval){
    $arrNames = array("id_empresa","id_evaluacion");
    $arrValues = array($idEmpresa,$idEval);
    $preguntasTmp = listarRegistrosTablaGlobalFiltros("tbl_evaluaciones_preguntas_tmp",$arrNames,$arrValues,"");
    //print_r($preguntasTmp);exit;
    //traigo las preguntas que ahora en la base estan ingresadas por la evaluacion
    $preguntas_base=ListadoDePreguntasDadaEvaluacion($idEval);
    //Por cada pregunta, veo si estan en la tabla temporal, si no esta, la elimino.
    foreach($preguntas_base as $preg_orig){
        //Verifico si esta en la tabla de temporales, si no está, la elimino de la base
        $esta_pregunta_en_tmp=VerificoPreguntaEnTablaPReguntasTmp($preg_orig->id);
        if(!$esta_pregunta_en_tmp){
            EliminoPreguntayalternativasDadoIdPregunta($preg_orig->id, $preg_orig->id_grupo_alternativas);
            //echo "deberia haber borrado la la pregunta ".$preg_orig->id;exit;
        }
        //Con el id grupo alternativa, traigo todas las alternativas de la tabla de alternativas
        $alternativas=TraigoAernativasDadoIdGrupoAlternativaV2($preg_orig->id_grupo_alternativas);
        foreach($alternativas as $alt_unico){
            //Verifico si esta alternativa esta en la tabla de alternativas temporales, si no esta la borro
            $estaAltEnTmp=VerificoSiAlterativaEstEnTmp($alt_unico->id);
            if(!$estaAltEnTmp){
                EliminoAlternativasDadoIdPregunta($alt_unico->id);
            }
        }
    }
    //echo count($preguntas_base);
    //exit;
    $alternativasTmp = listarRegistrosTablaGlobalFiltro("tbl_evaluaciones_alternativas_tmp","id_empresa",$idEmpresa,"");
    //var_dump($alternativasTmp);
    foreach($preguntasTmp as $row1){
        if($row1->id == 0){
            insertarRegistroTablaGlobal("tbl_evaluaciones_preguntas","id,evaluacion,id_grupo_alternativas,orden,tipo,pregunta, refuerzo1, refuerzo2","null,".$row1->id_evaluacion.",".$row1->id_grupo_alternativas.",".$row1->orden.",".$row1->tipo.",'".($row1->pregunta)."','".($row1->refuerzo1)."','".($row1->refuerzo2)."'");
        }else{
            actualizarRegistroTablaGlobalFiltro("tbl_evaluaciones_preguntas","orden=".$row1->orden.",
            tipo=1,
            refuerzo1='".$row1->refuerzo1."',
            id_grupo_alternativas='".$row1->id_grupo_alternativas."',
            refuerzo2='".$row1->refuerzo2."' ,
            pregunta='".($row1->pregunta)."'","id",$row1->id);
        }
        foreach($alternativasTmp as $row2){
            if($row2->id == 0 && $row2->id_grupo_alternativas == $row1->id_grupo_alternativas){
                insertarRegistroTablaGlobal("tbl_evaluaciones_alternativas","id,id_grupo_alternativas,orden,correcta,alternativa","null,".$row2->id_grupo_alternativas.",".$row2->orden.",".$row2->correcta.",'".($row2->alternativa)."'");
            }else if($row2->id > 0 && $row2->id_grupo_alternativas == $row1->id_grupo_alternativas){
                actualizarRegistroTablaGlobalFiltro("tbl_evaluaciones_alternativas","orden=".$row2->orden.",correcta=".$row2->correcta.",alternativa='".($row2->alternativa)."'","id",$row2->id);
            }
        }
    }
}

function EditarPreguntaAlternativas($PRINCIPAL,$idEval,$idGrupo){
    $arrNames = array("evaluacion","id_grupo_alternativas");
    $arrValues = array($idEval,$idGrupo);
    $pregunta = buscarRegistroTablaGlobalFiltros("tbl_evaluaciones_preguntas",$arrNames,$arrValues);
    $alternativas = buscarRegistroTablaGlobalFiltro("tbl_evaluaciones_alternativas","id_grupo_alternativas",$idGrupo);
    $PRINCIPAL = str_replace("{TITULO}","Editar Pregunta",$PRINCIPAL);
    $PRINCIPAL = str_replace("{ID_EVAL}",$idEval,$PRINCIPAL);
    $PRINCIPAL = str_replace("{ID_GRUPO}",$idGrupo,$PRINCIPAL);
    $body = "";
    foreach($pregunta as $row){
        $pregunta = str_replace('"',"",$row->pregunta);
        $PRINCIPAL = str_replace("{PREGUNTA}",(($pregunta)),$PRINCIPAL);
    }
    $numCorrecta = 0;
    foreach($alternativas as $row){
        $correcta = "";
        if($row->correcta == 1){
            $correcta = "checked";
            $numCorrecta = $row->orden;
        }
        $body .= "<div class='form-group col-md-12'>";
        $body .= "<label style='font-weight:bold'>Alternativa ".$row->orden."</label>";
        $body .= "<div class='input-group'>";
        $body .= "<span class='input-group-addon'><input onchange='cambiarCorrecta(this)' type='radio' name=correcta[] value='".$row->orden."' $correcta></span>";
        $body .= "<input type='text' class='form-control' name='alternativa_".$row->orden."' value='".(($row->alternativa))."' />";
        $body .= "</div>";
        $body .= "<input type='hidden'  value='".$row->id."'  name='idAlter_".$row->orden."'/>";
        $body .= "</div>";
    }
    $body .= "<input type='hidden'  value='$numCorrecta'  name='alternativaCorrecta' id='alternativaCorrecta'/>";
    $PRINCIPAL = str_replace("{TOT_ALTER}",count($alternativas),$PRINCIPAL);
    $PRINCIPAL = str_replace("{ALTERNATIVAS}",$body,$PRINCIPAL);
    $PRINCIPAL = str_replace("{BOTON}","Guardar Cambios",$PRINCIPAL);
    return ($PRINCIPAL);
}

function fn_rel_id_inscripcion_rut_curso_lista($PRINCIPAL, $id_empresa, $filtro, $post, $get, $request, $excel)
{
   $excel=$get["excel"];
  
   $array_cursos=data_rel_id_inscripcion_curso_groupby_data($id_empresa);
   foreach ($array_cursos as $unico){
				$row_listado_id_inscripcion_cursos.="<tr>";
						$row_listado_id_inscripcion_cursos.="<td><a href='?sw=rel_id_inscripcion_rut_curso&id_curso=".$unico->id_curso."' class='btn btn-link'>".($unico->id_curso)."</a></td>";
						$row_listado_id_inscripcion_cursos.="<td><a href='?sw=rel_id_inscripcion_rut_curso&id_curso=".$unico->id_curso."' class='btn btn-link'>".($unico->curso)."</a></td>";

						$row_listado_id_inscripcion_cursos.="<td><a href='?sw=rel_id_inscripcion_rut_curso&id_curso=".$unico->id_curso."' class='btn btn-link'>".($unico->programa)."</a>
						<br><a href='?sw=rel_id_inscripcion_rut_curso&id_curso=".$unico->id_curso."' class='btn btn-link'>".($unico->malla)."</a></td>";


						$row_listado_id_inscripcion_cursos.="<td>";
						$array_ins=data_rel_id_inscripcion_curso_groupby_id_curso_data($unico->id_curso,$id_empresa);
						//print_r($array_ins);exit();
						foreach ($array_ins as $unico2){
							$row_listado_id_inscripcion_cursos.="<a href='?sw=rel_id_inscripcion_rut_curso&id_inscripcion=".$unico2->id_inscripcion."' class='btn btn-link'>".$unico2->id_inscripcion."</a> ".$unico2->fecha_inicio_inscripcion." - ".$unico2->fecha_termino_inscripcion."<br>";
						}
						
						
						$option_progra_malla=data_rel_progra_malla_por_curso_lista($unico->id_curso, $id_empresa);			
						$options_select="";
						foreach ($option_progra_malla as $unico){
							$options_select.="<option value='".$unico->IdGroupBy."'>".$unico->GroupBy."</option>";
						}			
						
							$row_listado_id_inscripcion_cursos.="
													
													<div class='accordion' id='accordion_".$unico->id_curso."'>
													  <div class='accordion-item' style='border: none;'>
													    <h2 class='accordion-header' id='heading_".$unico->id_curso."'>
													      <button class='btn btn-link pull-right' type='button' data-bs-toggle='collapse' data-bs-target='#collapse_".$unico->id_curso."' aria-expanded='true' aria-controls='collapse_".$unico->id_curso."'>
													        Agregar Nueva Id Inscripci&oacute;n
													      </button>
													    </h2>
													    <div id='collapse_".$unico->id_curso."' class='accordion-collapse collapse' aria-labelledby='heading_".$unico->id_curso."' data-bs-parent='#accordion_".$unico->id_curso."'>
													      <div class='accordion-body'>
													        <form name='".$unico->id_curso."' id='".$unico->id_curso."' action='?sw=usuarios_insert_tbl_rel_id_inscripcion_rut_curso' method='post' style='display: inline-block;' enctype='multipart/form-data'>
													        	Id Inscripci&oacute;n:<br>
													        	<input type='text' 	name='id_inscripcion' id='id_inscripcion'  	class='form form-control' required >
													        	
													        	Nombre:<br>
													        	<input type='text' 	name='nombre_inscripcion' id='nombre_inscripcion'  	class='form form-control' required >
													        	
													        	Fecha Inicio:<br>
													        	<input type='date' name='fecha_inicio' id='fecha_inicio' 			class='form form-control' required >
													        	
													        	Fecha T&eacute;rmino:<br>
													        	<input type='date' name='fecha_termino' id='fecha_termino' 		class='form form-control' required>

													        	Ejecutivo (Rut):<br>
													        	<input type='number' name='rut_ejecutivo' id='rut_ejecutivo' 		class='form form-control' required>

													        	<input type='hidden' name='nueva_id_inscripcion' id='nueva_id_inscripcion' value='1' >
													        	<input type='hidden' name='id_curso' id='id_curso' value='".$unico->id_curso."' >
																		
													        	Programa / Malla:<br>
													        	
																			<select name='programa_malla' id='programa_malla' class='form form-control' required>
																				<option value=''></option>
																				".($options_select)."
																			</select>
																			<br>
																			Opcional <input type='checkbox' name='opcional' id='opcional'>

																		<br>
																		Colaboradores (opcional):<br>	
																		<a href='rut.csv' class='btn btn-link'>Descarga Plantilla</a>;
										                <input type='file' name='file' /> 
										                <input type='hidden' value='upload' name='action' /> 
													        	<center><input type='submit' class='btn btn-info' value='Crear'></center>
													        </form>
													      </div>
													    </div>
													  </div>
													</div>													
													";
				
   }

    $PRINCIPAL = str_replace("{ROW_LISTADO_CURSO_IDINSCRIPCION}", 						$row_listado_id_inscripcion_cursos, $PRINCIPAL);
   
   
		$array=data_rel_id_inscripcion_rut_curso_lista_por_idcurso_idinscripcion_data($get["id_curso"], $get["id_inscripcion"], $request["rut_colaborador"], $id_empresa);
		if(count($array)=="0"){
			$display_id_inscripcion_rut_cursos=" display:none; ";
			$display_id_inscripcion_rut_cursos_v2="  ";
		} else {
			$display_id_inscripcion_rut_cursos=" ";
			$display_id_inscripcion_rut_cursos_v2=" display:none; ";
			
		}

    $PRINCIPAL = str_replace("{display_id_inscripcion_rut_cursos}",			$display_id_inscripcion_rut_cursos, $PRINCIPAL);
    $PRINCIPAL = str_replace("{display_id_inscripcion_rut_cursos_v2}", 	$display_id_inscripcion_rut_cursos_v2, $PRINCIPAL);

		if($excel=="1"){

				header('Content-Description: File Transfer');
				header('Content-Type: application/csv');
				header("Content-Disposition: attachment; filename=Base_IdInscripcion.csv");
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');

				$handle = fopen('php://output', 'w');
				//ob_clean();
				echo "rut;id_inscripcion;id_curso;fecha_inicio;fecha_termino;activo;ejecutivo\r\n";
		}

		foreach ($array as $unico) {
			//$ProgramaArray=reportes_online_busca_programas_dado_idCurso($unico->id);			//$Programa="";
			//foreach ($ProgramaArray as $unico2){//$Programa.="".$unico2->programa."<br>";//}			

					if($unico->activa==1){
						$activo="ACTIVA";
					} else {
						$activo="INACTIVA";
					}

				if($excel=="1"){

					echo "".$unico->rut.";".$unico->id_inscripcion.";".$unico->id_curso.";".$unico->fecha_inicio_inscripcion.";".$unico->fecha_termino_inscripcion.";".$activo.";".$unico->rut_ejecutivo."\r\n";

				} else {
					
					$row_listado_id_inscripcion_rut_cursos.="<tr>";
						$row_listado_id_inscripcion_rut_cursos.="<td>".($unico->rut)."</td>";
						$row_listado_id_inscripcion_rut_cursos.="<td>".($unico->id_inscripcion)."</td>";
						$row_listado_id_inscripcion_rut_cursos.="<td>".($unico->id_curso)."</td>";

						$row_listado_id_inscripcion_rut_cursos.="<td>".($unico->fecha_inicio_inscripcion)."</td>";
						$row_listado_id_inscripcion_rut_cursos.="<td>".($unico->fecha_termino_inscripcion)."</td>";
						$row_listado_id_inscripcion_rut_cursos.="<td>".($activo)."</td>";
						$row_listado_id_inscripcion_rut_cursos.="<td>".($unico->rut_ejecutivo)."</td>";
					$row_listado_id_inscripcion_rut_cursos.="</tr>";
	
				}
		}

		if($excel=="1"){
					//ob_flush();
					fclose($handle);
					die();
					exit();					
		}

    $PRINCIPAL = str_replace("{ROW_LISTADO_ID_INSCRIPCION_RUT_CURSOS}", 		$row_listado_id_inscripcion_rut_cursos, $PRINCIPAL);
    $PRINCIPAL = str_replace("{ROW_LISTADO_PROGRAMAS_DETALLE}", 						$row_listado_programas_detalle, $PRINCIPAL);   
    
    $display_rut_colaborador="display:none; ";
		//print_r($_SESSION);
		if($_SESSION["cuenta_filter"]=="1"){
			$filter_text.="<strong>Filtros </strong>: ";
			if($_SESSION["c1text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c1text"]."</span>&nbsp;";	
			}
			if($_SESSION["c2text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c2text"]."</span>&nbsp;";	
			}
			if($_SESSION["c3text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c3text"]."</span>&nbsp;";	
			}
			if($_SESSION["c4text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["c4text"]."</span>&nbsp;";	
			}
			if($_SESSION["rut_colaborador_text"]<>""){
				$filter_text.= "&nbsp;<span class='badge badge-secondary'>".$_SESSION["rut_colaborador_text"]."</span>&nbsp;";	
				$display_rut_colaborador="";
			} else {
			}

		} else {
			$filter_text="";
		}
		$PRINCIPAL = str_replace("{DISPLAY_RUT_COLABORADOR}", $display_rut_colaborador	, $PRINCIPAL);   
    $PRINCIPAL = str_replace("{FILTROS_REALIZADOS_FILTRO_SUPERIOR}", 	$filter_text, $PRINCIPAL);   

    $PRINCIPAL = str_replace("{ID_INSCRIPCION_GET}", 	$get["id_inscripcion"], 		$PRINCIPAL);   
    $PRINCIPAL = str_replace("{ID_CURSO_GET}", 				$get["id_curso"], 					$PRINCIPAL);   
    $PRINCIPAL = str_replace("{RUT_COL_GET}", 				$request["rut_colaborador"], 	$PRINCIPAL);   
    
     echo CleanHTMLWhiteList($PRINCIPAL);exit;
}

function Reporte_Full_Filtros($PRINCIPAL, $id_empresa, $arreglo_post, $excel)
{
    $datos_empresa = DatosEmpresa($id_empresa);
    $campos_subida = REL_MALLA_CURSO_trarCamposSubidaParaReporte($id_empresa);
    $total_vueltas = ceil(count($campos_subida) / 4);
    $html_filtros = "";
    $vuelta = 1;
    $arreglo_post2 = $_POST;
    
    foreach($campos_subida as $campo) {
        if ($vuelta == 1) {
            $html_filtros.= "<div class=''>";
        }
        $html_filtros.= file_get_contents("views/reportes/capacitacion/filtros_dinamicos.html");
        $html_filtros = str_replace("{NOMBRECAMPOAMOSTRAR}", ($campo->nombrecampoamostrar) , $html_filtros);
        $html_filtros = str_replace("{ID}", ($campo->id) , $html_filtros);
        $html_filtros = str_replace("{CAMPO}", ($campo->campo) , $html_filtros);
        $valores_option = TraigoValoresDadoCampoPorEmpreas($campo->campo, $id_empresa, $arreglo_post2); 
        $options = "";
        foreach($valores_option as $valor) {
            if ($_POST[$campo->campo]) {
                for ($contador_valores = 0; $contador_valores < count($_POST[$campo->campo]); $contador_valores++) {
                    if (utf8_decode($_POST[$campo->campo][$contador_valores]) == $valor->valor) {
                        $selected = "selected='selected'";
                        break;
                    }
                    else {
                        $selected = "";
                    }
                }
            }
            $options.= "<option $selected  value='" . $valor->valor . "'>" . $valor->valor . "</option>";
            $selected = "";
        }
        $html_filtros = str_replace("{OPTIONS}", ($options) , $html_filtros);
        if ($vuelta == 4) {
            $html_filtros.= "</div>";
            $vuelta = 1;
        }
        else {
            $vuelta++;
        }
    }

    $focos=TraeFocosPorEmpresa($id_empresa);
    $options_focos="";
    foreach($focos as $foc){
        if($arreglo_post["foco"]==$foc->codigo_foco){
            $options_focos.='<option value="'.$foc->codigo_foco.'" selected>'.$foc->descripcion.'</option>';
        }else{
            $options_focos.='<option value="'.$foc->codigo_foco.'">'.$foc->descripcion.'</option>';
        }
    }

    $PRINCIPAL = str_replace("{OPTIONS_FOCOS}", ($options_focos) , $PRINCIPAL);


	//Programas Globales
	$programas_globales=TraeProgramasGlobales($id_empresa);
	foreach($programas_globales as $prog_g){
		$options_progamas_globales.="<option value='".$prog_g->id_programa."'>".$prog_g->nombre_programa."</option>";
	}
	$PRINCIPAL = str_replace("{OPTIONS_PROGRAMAS_GLOBAL}", ($options_progamas_globales) , $PRINCIPAL);


	//Programas Elearning
	$programas_elearning=TraeProgramasElearning($id_empresa);
	foreach($programas_elearning as $prog_e){
		$options_progamas_elearning.="<option value='".$prog_e->id_programa."'>".$prog_e->nombre_programa."</option>";
	}
	$PRINCIPAL = str_replace("{OPTIONS_PROGRAMAS_BBDD}", ($options_progamas_elearning) , $PRINCIPAL);

	//Mallas
	$mallas=TraeMallasReportesFull($id_empresa);
	foreach($mallas as $mall){
		$options_mallas.="<option value='".$mall->id."'>".$mall->nombre."</option>";
	}
	$PRINCIPAL = str_replace("{MALLAS}", ($options_mallas) , $PRINCIPAL);

	//cursos
	$cursos=TraeCursosReportesFull($id_empresa);
	foreach($cursos as $cur){
        $options_cursos.="<option value='".$cur->id."'>".$cur->nombre."</option>";
        $options_cursos_id.="<option value='".$cur->id."'>".$cur->id."</option>";
	}
    $PRINCIPAL = str_replace("{CURSOS}", ($options_cursos) , $PRINCIPAL);
   
  $id_cursos=TraeCursosReportesFullAsc($id_empresa);
    foreach($id_cursos as $cur){
        $options_cursos_id3.="<option value='".$cur->id."'>".$cur->id."</option>";
    }

    $PRINCIPAL = str_replace("{ID_CURSOS}", ($options_cursos_id3) , $PRINCIPAL);

	//Imparticiones
	$imparticiones=TraeImparticionesReportesFull($id_empresa);
	foreach($imparticiones as $imp){
		$options_imparticiones.="<option value='".$imp->codigo_inscripcion."'>".$imp->codigo_inscripcion."</option>";
	}
	$PRINCIPAL = str_replace("{IMPARTICIONES}", ($options_imparticiones) , $PRINCIPAL);

            $fecha_ultima=buscaUltimaFechaFull();
    $PRINCIPAL = str_replace("{FECHA_ACTUALIZACION_REPORTE}", ($fecha_ultima) , $PRINCIPAL);

    $PRINCIPAL = str_replace("{FILTROS_DINAMICOS}", ($html_filtros) , $PRINCIPAL);
    
      //	REPORTES AUTOMATICOS
     $ReportesAutomaticosFN = ReportesAutomaticosFN($id_empresa); 
     $PRINCIPAL = str_replace("{ROW_REPORTES_AUTOMATICOS_ULTIMOS_8}", $ReportesAutomaticosFN, $PRINCIPAL);    

		$programa_array=Reportes_Express_Programa($id_empresa);
		foreach ($programa_array as $unico) {
			$row_programas_array.="<option value='".$unico->id_programa."'>".($unico->programa)."</option>";
		}

    $PRINCIPAL = str_replace("{ROW_PROGRAMAS_ARRAY}", 						$row_programas_array, $PRINCIPAL);
    
    
     echo CleanHTMLWhiteList($PRINCIPAL);exit;
}

function FiltroPerfilado($user_admin, $id_empresa, $tipo){
    //echo "$user_admin, $id_empresa";
    //Veo si tiene datos en la tabla de rel_admin_rut_perfil
    $datos_rel=TRaeDatosRelADminPerfil($id_empresa, $user_admin, "capacitacion");
    if($tipo=="rel_lms_malla_curso"){
        if($datos_rel){
            $sql=" and (";
            $contador=0;
            foreach($datos_rel as $rel){
                $sql.="rel_lms_malla_curso.".$rel->campo."='".$rel->valor."' ";
                $contador++;
                if(count($datos_rel)<>$contador){
                    $sql.=" or ";
                }
            }
            $sql.=" )";
        }else{
            $sql="";
        }
    }else{
        if($datos_rel){
            $sql=" and (";
            $contador=0;
            foreach($datos_rel as $rel){
                $sql.=$rel->tabla.".".$rel->campo."='".$rel->valor."' ";
                $contador++;
                if(count($datos_rel)<>$contador){
                    $sql.=" or ";
                }
            }
            $sql.=" )";
        }else{
            $sql="";
        }
    }
    return($sql);
}

function ReportesAutomaticosFN($id_empresa){
	
	//echo "<br>Funcion<br>ReportesAutomaticosFN<br>$id_empresa";
	$array_ultimas_fechas	=	ReportesAutomaticosBuscaUltimasFechas($id_empresa);
	//print_r($array_ultimas_fechas);
	foreach ($array_ultimas_fechas as $un1){
		$row_reportes_automaticos.="<div class='col-lg-4' style='border: 1px solid #ddd;border-radius: 3px;''><strong>".$un1->fecha."</strong><br>
			";
			$array_linea=ReportesAutomaticosBuscaLineas($un1->fecha, $id_empresa);
			foreach ($array_linea as $un2){

                if($un2->nombre=="Full_Elearning"){
                    $row_reportes_automaticos.="<div style='text-align: left;'><a href='https://www.masconectadosbch.cl/admin/reportes/Reporte_".$un2->filtro."_".($un2->id_reporte)."_".$un2->fecha.".zip' class='btn btn-link'><span class='negro'><i class='fas fa-angle-right'></i> Reporte  <strong>".($un2->nombre)."</strong></a></div>";
                } else {
                    $row_reportes_automaticos.="<div style='text-align: left;'><a href='https://www.masconectadosbch.cl/admin/reportes/Reporte_".$un2->filtro."_".($un2->id_reporte)."_".$un2->fecha.".csv' class='btn btn-link'><span class='negro'><i class='fas fa-angle-right'></i> Reporte  <strong>".($un2->nombre)."</strong></a></div>";
                }


			}
		$row_reportes_automaticos.="</div>";
	}
	//echo "<br>row_reportes_automaticos ".$row_reportes_automaticos;
	//exit();
return $row_reportes_automaticos; 
}

function Reporte_Full_Filtros_v2($PRINCIPAL, $id_empresa, $arreglo_post, $excel)
{
    $datos_empresa = DatosEmpresa($id_empresa);
    $campos_subida = REL_MALLA_CURSO_trarCamposSubidaParaReporte($id_empresa);
    $total_vueltas = ceil(count($campos_subida) / 4);
    $html_filtros = "";
    $vuelta = 1;
    $arreglo_post2 = $_POST;
    
    foreach($campos_subida as $campo) {
        if ($vuelta == 1) {
            $html_filtros.= "<div class=''>";
        }
        $html_filtros.= file_get_contents("views/reportes/capacitacion/filtros_dinamicos.html");
        $html_filtros = str_replace("{NOMBRECAMPOAMOSTRAR}", ($campo->nombrecampoamostrar) , $html_filtros);
        $html_filtros = str_replace("{ID}", ($campo->id) , $html_filtros);
        $html_filtros = str_replace("{CAMPO}", ($campo->campo) , $html_filtros);
        $valores_option = TraigoValoresDadoCampoPorEmpreas($campo->campo, $id_empresa, $arreglo_post2);
        $options = "";
        foreach($valores_option as $valor) {
            if ($_POST[$campo->campo]) {
                for ($contador_valores = 0; $contador_valores < count($_POST[$campo->campo]); $contador_valores++) {
                    if (utf8_decode($_POST[$campo->campo][$contador_valores]) == $valor->valor) {
                        $selected = "selected='selected'";
                        break;
                    }
                    else {
                        $selected = "";
                    }
                }
            }
            $options.= "<option $selected  value='" . $valor->valor . "'>" . $valor->valor . "</option>";
            $selected = "";
        }
        $html_filtros = str_replace("{OPTIONS}", ($options) , $html_filtros);
        if ($vuelta == 4) {
            $html_filtros.= "</div>";
            $vuelta = 1;
        }
        else {
            $vuelta++;
        }
    }

    $focos=TraeFocosPorEmpresa($id_empresa);
    $options_focos="";
    foreach($focos as $foc){
        if($arreglo_post["foco"]==$foc->codigo_foco){
            $options_focos.='<option value="'.$foc->codigo_foco.'" selected>'.$foc->descripcion.'</option>';
        }else{
            $options_focos.='<option value="'.$foc->codigo_foco.'">'.$foc->descripcion.'</option>';
        }
    }

    $PRINCIPAL = str_replace("{OPTIONS_FOCOS}", ($options_focos) , $PRINCIPAL);


	//Programas Globales
	$programas_globales=TraeProgramasGlobales($id_empresa);
	foreach($programas_globales as $prog_g){
		$options_progamas_globales.="<option value='".$prog_g->id_programa."'>".$prog_g->nombre_programa."</option>";
	}
	$PRINCIPAL = str_replace("{OPTIONS_PROGRAMAS_GLOBAL}", ($options_progamas_globales) , $PRINCIPAL);


	//Programas Elearning
	$programas_elearning=TraeProgramasElearning($id_empresa);
	foreach($programas_elearning as $prog_e){
		$options_progamas_elearning.="<option value='".$prog_e->id_programa."'>".$prog_e->nombre_programa."</option>";
	}
	$PRINCIPAL = str_replace("{OPTIONS_PROGRAMAS_BBDD}", ($options_progamas_elearning) , $PRINCIPAL);

	//Mallas
	$mallas=TraeMallasReportesFull($id_empresa);
	foreach($mallas as $mall){
		$options_mallas.="<option value='".$mall->id."'>".$mall->nombre."</option>";
	}
	$PRINCIPAL = str_replace("{MALLAS}", ($options_mallas) , $PRINCIPAL);

	//cursos
	$cursos=TraeCursosReportesFull($id_empresa);
	foreach($cursos as $cur){
        $options_cursos.="<option value='".$cur->id."'>".$cur->nombre."</option>";
        $options_cursos_id.="<option value='".$cur->id."'>".$cur->id."</option>";
	}
    $PRINCIPAL = str_replace("{CURSOS}", ($options_cursos) , $PRINCIPAL);
   
  $id_cursos=TraeCursosReportesFullAsc($id_empresa);
    foreach($id_cursos as $cur){
        $options_cursos_id3.="<option value='".$cur->id."'>".$cur->id."</option>";
    }

    $PRINCIPAL = str_replace("{ID_CURSOS}", ($options_cursos_id3) , $PRINCIPAL);

	//Imparticiones
	$imparticiones=TraeImparticionesReportesFull($id_empresa);
	foreach($imparticiones as $imp){
		$options_imparticiones.="<option value='".$imp->codigo_inscripcion."'>".$imp->codigo_inscripcion."</option>";
	}
	$PRINCIPAL = str_replace("{IMPARTICIONES}", ($options_imparticiones) , $PRINCIPAL);

            $fecha_ultima=buscaUltimaFechaFull();
    $PRINCIPAL = str_replace("{FECHA_ACTUALIZACION_REPORTE}", ($fecha_ultima) , $PRINCIPAL);

    $PRINCIPAL = str_replace("{FILTROS_DINAMICOS}", ($html_filtros) , $PRINCIPAL);
    
      //	REPORTES AUTOMATICOS
     $ReportesAutomaticosFN = ReportesAutomaticosFN($id_empresa); 
     $PRINCIPAL = str_replace("{ROW_REPORTES_AUTOMATICOS_ULTIMOS_8}", $ReportesAutomaticosFN, $PRINCIPAL);    

		$programa_array=Reportes_Express_Programa($id_empresa);
		foreach ($programa_array as $unico) {
			$row_programas_array.="<option value='".$unico->id_programa."'>".($unico->programa)."</option>";
		}

    $PRINCIPAL = str_replace("{ROW_PROGRAMAS_ARRAY}", 						$row_programas_array, $PRINCIPAL);
    
    
     echo CleanHTMLWhiteList($PRINCIPAL);exit;
}

function lista_becas($html,  $id_empresa, $idcategoria){
    $emb_olas=lista_becas_data($id_empresa); 
    foreach($emb_olas as $unico){
                    $row=file_get_contents("views/becas/row_becas.html");
                    
                    //echo "<br>nombre beca ".$unico->nombre_beca;


                    if($unico->tipo_beca=="beca_pre_2022_1")		{$nombreBeca	= "Beca Pregrado 2022 S1";}
                    if($unico->tipo_beca=="beca_post_2022_1")		{$nombreBeca	= "Beca Postgrado 2022 S1";}

                    if($unico->tipo_beca=="beca_pre_2022_2")		{$nombreBeca	= "Beca Pregrado 2022 S2";}
                    if($unico->tipo_beca=="beca_post_2022_2")		{$nombreBeca	= "Beca Postgrado 2022 S2";}


                    if($unico->tipo_beca=="beca_pre_2021_2")		{$nombreBeca	= "Beca Pregrado 2021 S2";}
                    if($unico->tipo_beca=="beca_post_2021_2")		{$nombreBeca	= "Beca Postgrado 2021 S2";}


                    if($unico->tipo_beca=="beca_pre_2021_1")		{$nombreBeca	= "Beca Pregrado 2021 S1";}
                    if($unico->tipo_beca=="beca_post_2021_1")		{$nombreBeca	= "Beca Postgrado 2021 S1";}


                    if($unico->tipo_beca=="beca_post_2020")		{$nombreBeca	= "Beca Postgrado 2020";}
                    if($unico->tipo_beca=="beca_pre_2020")		{$nombreBeca	= "Beca Pregrado 2020";}
                    if($unico->tipo_beca=="bch_prg")					{$nombreBeca	= "Beca Pregrado 2018";}
                    if($unico->tipo_beca=="beca_post_2019")		{$nombreBeca	= "Beca Postgrado 2019";}
                    if($unico->tipo_beca=="beca_pre_2019")		{$nombreBeca	= "Beca Pregrado 2019";}                  
                    
                    if($unico->tipo_beca=="beca_pre_2023_1")		{$nombreBeca	= "Beca Pregrado 2023 S1";}
                    if($unico->tipo_beca=="beca_post_2023_1")		{$nombreBeca	= "Beca Postgrado 2023 S1";}

                    if($unico->tipo_beca=="beca_pre_2023_2")		{$nombreBeca	= "Beca Pregrado 2023 S2";}
                    if($unico->tipo_beca=="beca_post_2023_2")		{$nombreBeca	= "Beca Postgrado 2023 S2";}
                    
                    
                    
                    $row = str_replace("{ID}",    										($unico->tipo_beca),$row);
                    $row = str_replace("{NOMBRE}",    								($nombreBeca),$row);
                    $row = str_replace("{POSTULANTES}",            		($unico->postulantes),$row);
                    $row = str_replace("{DOCUMENTACION_OK}",        	($unico->documentacion_ok),$row);
                    $row = str_replace("{VALIDACION_JEFE_1}",        	($unico->validacionjefe_1),$row);
                    $row = str_replace("{VALIDACION_JEFE_2}",        	($unico->validacionjefe_2),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Becas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_becas_validacion($html,  $id_empresa, $idcategoria){
    $lista_becav=lista_becas_validacion_data($idcategoria, $id_empresa);
    foreach($lista_becav as $unico){
                    $row=file_get_contents("views/becas/row_lista_becas.html");
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
                    $row = str_replace("{NOMBRE}",       ($unico->nombre),$row);
                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{DIVISION}",     ($unico->division),$row);
                    $row = str_replace("{FECHA}",        ($unico->fecha),$row);

$Jefe1						= TraeDatosUsuario($unico->rutjefe1);
$Jefe2						= TraeDatosUsuario($unico->rutjefe2);
//echo "tipo beca ".$unico->tipo_beca;

if (strpos($unico->tipo_beca, 'pre') !== false) {
 $nombre_beca="Beca Pregrado";
} else {
	$nombre_beca="Beca PostGrado";
}


							
							if($unico->comentario1jefe1<>""){$unico->comentario1jefe1=" -Meritos: ".$unico->comentario1jefe1;}
							if($unico->comentario2jefe1<>""){$unico->comentario2jefe1=" -Aspectos: ".$unico->comentario2jefe1;}
							
							
									if($unico->validacionjefe1=="1"){ 
										
										$validacion_jefe1="<div class='alert alert-success'>Aprobado por Jefe 1 <br>".$Jefe1[0]->nombre_completo." ".$Jefe1[0]->email."<br>".($unico->comentario1jefe1)."<br>".($unico->comentario2jefe1)."</div>";
										
										
										if($unico->validacionjefe2=="1"){
											$validacion_jefe2="<div class='alert alert-success'>Aprobado por Jefe 2  <br>".$Jefe2[0]->nombre_completo." ".$Jefe2[0]->email." </div>";
										} elseif($unico->validacionjefe2=="2"){
											$validacion_jefe2="<div class='alert alert-danger'>No Aprobado por Jefe 2 <br>".$Jefe2[0]->nombre_completo." ".$Jefe2[0]->email." </div>";
										} else {
											$validacion_jefe2="<div class='alert alert-warning'>Pendiente Jefe 2  <br>".$Jefe2[0]->nombre_completo." ".$Jefe2[0]->email." </div>";
										}
										
										}
									elseif($unico->validacionjefe1=="2"){ $validacion_jefe1="<div class='alert alert-danger'>No Aprobado por Jefe 1  <br>".$Jefe1[0]->nombre_completo." ".$Jefe1[0]->email."<br>".($unico->comentario1jefe1)."<br>".($unico->comentario2jefe1)."</div>";
										$validacion_jefe2="";}
									else { $validacion_jefe1="<div class='alert alert-warning'>Pendiente Jefe 1  <br>".$Jefe1[0]->nombre_completo." ".$Jefe1[0]->email."<br>".($unico->comentario1jefe1)."<br>".($unico->comentario2jefe1)."</div>";
												$validacion_jefe2="";
										
										}

                    $row = str_replace("{NOMBRE_BECA}",        $nombre_beca, $row);
                    $row = str_replace("{NOMBRE_CARRERA}",     ($unico->carrera).($unico->otracarrera), $row);
                    $row = str_replace("{NOMBRE_INSTITUCION}", ($unico->otracasa), $row);

                    $documentacion="";


               
   if (strpos($unico->tipo_beca, 'pre') !== false) {
                    if($unico->certificado_acredita<>'')		{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info">Certificado alumno regular </a> ';
                    	
		                    	if($unico->certificado_acredita_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=1&nombre=Certificado alumno regular' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=2&nombre=Certificado alumno regular' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->certificado_acredita_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=2&nombre=Certificado alumno regular' class='btn btn-danger pull-right'>Rechazar</a>

		                    		";

		                    	} elseif($unico->certificado_acredita_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=1&nombre=Certificado alumno regular' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=2&nombre=Certificado alumno regular' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}

                    	}
                    	
                    if($unico->certificado_carga<>'')    		{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info">Concentracion notas </a> ';

		                    	if($unico->certificado_carga_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=1&nombre=Concentracion notas' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=2&nombre=Concentracion notas' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->certificado_carga_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=2&nombre=Concentracion notas' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->certificado_carga_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=1&nombre=Concentracion notas' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=2&nombre=Concentracion notas' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}

                    	}
                    	
                    if($unico->concentracion_notas <>'')    {	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info">Pago matricula </a> ';

		                    	if($unico->concentracion_notas_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=1&nombre=Pago matricula' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=2&nombre=Pago matricula' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->concentracion_notas_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=2&nombre=Pago matricula' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->concentracion_notas_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=1&nombre=Pago matricula' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=2&nombre=Pago matricula' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}                    										
                    	
                    	}
                    	
                    if($unico->licencia_edmedia<>'')    		{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info">Comprobante arancel </a> ';

		                    	if($unico->licencia_edmedia_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=1&nombre=Comprobante arancel' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=2&nombre=Comprobante arancel' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->licencia_edmedia_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=2&nombre=Comprobante arancel' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->licencia_edmedia_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=1&nombre=Comprobante arancel' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=2&nombre=Comprobante arancel' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}    
                    	
                    	
                    	}

                    if($unico->certificado_notas<>'')    		{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info">Pago Arancel</a> ';

		                    	if($unico->certificado_notas_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=1&nombre=Otro Documento' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=2&nombre=Otro Documento' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->certificado_notas_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=2&nombre=Otro Documento' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->certificado_notas_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=1&nombre=Otro Documento' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=2&nombre=Otro Documento' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}    
                    	
                    	
                    	}

                    	
                    if($unico->boletinpsu<>'')            	{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->boletinpsu).'" target="_blank" class="btn btn-info">Declaracion jurada </a> ';
                    	

		                    	if($unico->boletinpsu_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=1&nombre=Declaracion jurada' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=2&nombre=Declaracion jurada' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->boletinpsu_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=2&nombre=Declaracion jurada' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->boletinpsu_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=1&nombre=Declaracion jurada' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=2&nombre=Declaracion jurada' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}                        	
											
                    	
                    	}
									
									
                    if($unico->pago_arancel<>'')            	{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->pago_arancel).'" target="_blank" class="btn btn-info">Archivo Adicional </a> ';
                    	
                    	}									
							
									                 $documentacion.="<hr><br>   			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&vdocs=docs_pendiente' class='btn btn-primary'>Recordatorio Docs Pendientes</a>";

							
									
	}

                  else { 
                   	if($unico->licencia_edmedia<>'')    		{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info">Certificado titulo </a> ';
                   		
		                    	if($unico->licencia_edmedia_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=1&nombre=Certificado titulo' class='btn btn-success pull-right pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=2&nombre=Certificado titulo' class='btn btn-danger pull-right pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->licencia_edmedia_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div>
		                    		<br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=2&nombre=Certificado titulo' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->licencia_edmedia_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=1&nombre=Certificado titulo' class='btn btn-success pull-right pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=licencia_edmedia_doc_ok&v=2&nombre=Certificado titulo' class='btn btn-danger pull-right pull-right'>Rechazar</a>
		                    		";
		                    	}    
		                    	
		                    	               		
                   		}
                    if($unico->certificado_acredita<>'')		{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info">Carta aceptacion </a> ';
                    	
                    
		                    	if($unico->certificado_acredita_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=1&nombre=Carta aceptacion' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=2&nombre=Carta aceptacion' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->certificado_acredita_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=2&nombre=Carta aceptacionr' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->certificado_acredita_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=1&nombre=Carta aceptacion' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_acredita_doc_ok&v=2&nombre=Carta aceptacion' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}    
                    	
                    	}
                    if($unico->certificado_carga<>'')    		{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info">Detalle postgrado </a> ';
                    	
                    	
 		                    	if($unico->certificado_carga_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=1&nombre=Detalle postgrado' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=2&nombre=Detalle postgrado' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->certificado_carga_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div>
		                    		<br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=2&nombre=Detalle postgrado' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	} elseif($unico->certificado_carga_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=1&nombre=Detalle postgrado' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_carga_doc_ok&v=2&nombre=Detalle postgrado' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}                     	
                    	
                    	}
                    if($unico->concentracion_notas <>'')    {	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info">Comprobante Pago </a> ';
                    	
 		                    	if($unico->concentracion_notas_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=1&nombre=Comprobante Pago' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=2&nombre=Comprobante Pago' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->concentracion_notas_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=2&nombre=Comprobante Pago' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->concentracion_notas_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=1&nombre=Comprobante Pago' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=concentracion_notas_doc_ok&v=2&nombre=Comprobante Pago' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	} 

                    	
                    	}
                    if($unico->boletinpsu<>'')            	{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->boletinpsu).'" target="_blank" class="btn btn-info">Declaracion jurada </a> ';
                    	
 		                    	if($unico->boletinpsu_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=1&nombre=Declaracion Jurada' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=2&nombre=Declaracion Jurada' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->boletinpsu_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=2&nombre=Declaracion Jurada' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->boletinpsu_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=1&nombre=Declaracion Jurada' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=boletinpsu_doc_ok&v=2&nombre=Declaracion Jurada' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}   
		                    	
                  	
                    	}
                    	

                    if($unico->certificado_notas<>'')            	{	$documentacion.='<br><br> <a href="../front/docs/'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info">Pagos a la Fecha </a> ';
                    	
 		                    	if($unico->certificado_notas_doc_ok=="")	{
		                    		$documentacion.="
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=1&nombre=Pagos a la Fecha' class='btn btn-success pull-right'>Validar</a>
		                    			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=2&nombre=Pagos a la Fecha' class='btn btn-danger pull-right'>Rechazar</a>
		                    			";
		                    	} elseif($unico->certificado_notas_doc_ok=="SI") {
		                    		$documentacion.="<div class='badge badge-success pull-right'>Validado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=2&nombre=Pagos a la Fecha' class='btn btn-danger pull-right'>Rechazar</a>";
		                    	} elseif($unico->certificado_notas_doc_ok=="NO") {
		                    		$documentacion.="<div class='badge badge-danger pull-right'>Rechazado</div><br>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=1&nombre=Pagos a la Fecha' class='btn btn-success pull-right'>Validar</a>
		                    		<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&tipo=certificado_notas_doc_ok&v=2&nombre=Pagos a la Fecha' class='btn btn-danger pull-right'>Rechazar</a>
		                    		";
		                    	}   
		                    	
                  	
                    	}
                    	
		                    										                 $documentacion.="<hr><br>   			<a href='?sw=becas_validacion&idenc=".Encodear3($unico->id)."&id=".$idcategoria."&vdocs=docs_pendiente' class='btn btn-primary'>Recordatorio Docs Pendientes</a>";
                    	
									}

                    $row = str_replace("{VALIDACION_JEFE_1}", $validacion_jefe1, $row);
                    $row = str_replace("{VALIDACION_JEFE_2}", $validacion_jefe2, $row);


$id_enc=Encodear3($unico->id);
$botones_documentacion='';
if($unico->documentacionok==''){
        $botones_documentacion='<a href="?sw=becas_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" class="btn btn-success">Validar</a><br><br> <a href="?sw=becas_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" class="btn btn-danger">Rechazar</a> ';
} else {
    if($unico->documentacionok=='SI'){
    $botones_documentacion='<span class="badge badge-success">SI</span>';
    $botones_documentacion.='<a href="?sw=becas_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" class="btn btn-success">Validar</a><br><br> <a href="?sw=becas_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" class="btn btn-danger">Rechazar</a> ';

    } elseif($unico->documentacionok=='NO') {
    $botones_documentacion.='<span class="badge badge-danger">NO</span><br><br>';
    $botones_documentacion.='<a href="?sw=becas_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" class="btn btn-success">Validar</a><br><br> <a href="?sw=becas_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" class="btn btn-danger">Rechazar</a> ';
    }
    //echo "hola $botones_documentacion";
}
$botones_validacion='';
//echo $botones_documentacion;
if($unico->validacionok==''){
    $botones_validacion='<a href="?sw=becas_validacion&idenc='.$id_enc.'&v=1&id='.$idcategoria.'" class="btn btn-success">Validar</a><br><br> <a href="?sw=becas_validacion&idenc='.$id_enc.'&v=2&id='.$idcategoria.'" class="btn btn-danger">Rechazar</a> ';
} else {
        if($unico->validacionok=='SI'){
    $botones_validacion='<span class="badge badge-success">SI</span>';
    } else {
    $botones_validacion='<span class="badge badge-danger">NO</span>';
    }
}
                    $row = str_replace("{BECA}",        ($unico->nombre_beca),$row);
                    $row = str_replace("{DOCUMENTACION}",        ($documentacion),$row);
                    $row = str_replace("{CHEQUEO_DOCS}",        ($botones_documentacion),$row);
                    $row = str_replace("{VALIDACION_FINAL}",    ($botones_validacion),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Becas",$html);
    
    $html = str_replace("{IDENC}",($idcategoria),$html);
    
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=becas" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_mediciones($html,  $id_empresa, $idcategoria){ 
   $ExpertosPracticas=TraeMedicionesPorEmpresa($id_empresa);
   $row=file_get_contents("views/mediciones/entorno_mediciones.html");
   foreach($ExpertosPracticas as $ExpertoPractica){
        $row=file_get_contents("views/mediciones/lista_practicas_edit_evaluaciones.html");
        $row = str_replace("{ID_EVALUACION}",       ($ExpertoPractica->id),$row);
        $row = str_replace("{NOMBRE_EVALUACION}",   ($ExpertoPractica->nombre),$row);
        $row = str_replace("{CURSOS_UTILIZADOS}",   $lista_cursos,$row);
        $row = str_replace("{NUM_PREGUNTAS}",       ($ExpertoPractica->num_preguntas),$row);
        $row = str_replace("{TIPO_RELATOR}",        ($ExpertoPractica->cargo),$row);
        $total_html.=$row;
              }
    $total_html = str_replace("{NIVEL}","2",$total_html);
    $total_html = str_replace("{SUB_CAT}","",$total_html);
    $total_html = str_replace("{NSUB}","",$total_html);
    $html = str_replace("{OPTIONS_CATEGORIAS_MEJORES_PRACTICAS_NUEVO}",($categorias_options),$html);
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Preguntas y Respuestas",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function jListarPreguntasMedicion($PRINCIPAL, $idEval, $programa){
    $preguntas = listarRegistrosTablaGlobalFiltro("tbl_enc_elearning_preg","id_encuesta",$idEval,"id asc");
    $tableRows = "";
    //print_r($preguntas);
    if(count($preguntas) == 0){
            $tableRows .= "<tr><td colspan = '4'>No existen registros de preguntas para esta evaluaci&oacuten</td></tr>";
    }else if(count($preguntas) > 0){
        foreach($preguntas as $row1){
            $alternativas = listarRegistrosTablaGlobalFiltro("tbl_evaluaciones_alternativas","id_grupo_alternativas",$row1->id_grupo_alternativas,"");
            $totalAlternativas = count($alternativas);
            $tableRows .= "<tr>";
            $tableRows .= "<td rowspan='".($totalAlternativas+1)."'  class='lms_preg_num_eval'>".$row1->id_pregunta."</td>";
            $tableRows .= "<td class='lms_preg_texto_eval'>".(($row1->pregunta))."</td>";
            $tableRows .= "<td class='lms_preg_texto_eval'>".(($row1->tipo))."</td>";
            $tableRows .= "
            <td rowspan='".($totalAlternativas+1)."' class='lms_preg_alternativas_eval'>
                <a href='?sw=editPreg&idEval=$idEval&idGrup=".$row1->id_grupo_alternativas."' title='Editar Pregunta' class='btn btn-success btn-sm'><i class='glyphicon glyphicon-edit'></i></a>
                <a onclick = \"if (! confirm('Continue?')) return false;\"  href='?sw=dltPreg&idEval=$idEval&idPreg=".$row1->id."' title='Eliminar Pregunta' class='btn btn-danger btn-sm'><i class='glyphicon glyphicon-remove'></i></a>
             </td>";
            $tableRows .= "</tr>";
            foreach($alternativas as $row2){
                $tableRows .= "<tr>";
                if($row2->correcta == 1){
                    $tableRows .= "<td class='lms_preg_alternativa_correcta_eval'><i class='fa fa-check-circle' aria-hidden='true'></i> ".(($row2->alternativa))."</p></td>";
                }else{
                    $tableRows .= "<td class='lms_preg_alternativas_eval'> ".(($row2->alternativa))."</td>";
                }
                $tableRows .= "</tr>";
            }
        }
    }
    $js = " <script type = 'text/javascript'>
            </script>";
$nombre_ev=nombreEvaL($idEval);
    $PRINCIPAL = str_replace("{ID_EVAL}",$idEval,$PRINCIPAL);
    $PRINCIPAL = str_replace("{PROGRAMA}",$programa,$PRINCIPAL);
    $PRINCIPAL = str_replace("{LISTADO_PREGUNTAS}",$tableRows,$PRINCIPAL);
    $PRINCIPAL = str_replace("{EVALUACION}",($nombre_ev[0]->nombre_evaluacion),$PRINCIPAL);
    $PRINCIPAL = str_replace("{CURSO}",$tableRows,$PRINCIPAL);
    $PRINCIPAL = str_replace("{LIST_PREG_JS}",$js,$PRINCIPAL);
    return ($PRINCIPAL);
}
function CreaPReguntasEvaluaciones($html, $id_evaluacion){

        $html = str_replace("{ID_EVAL}",$id_evaluacion,$html);
        $html = str_replace("{TOT_ALTER}",0,$html);
    return($html);
}
function lista_publicaciones_fn($html,  $id_empresa, $idcategoria, $filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $nombre_audiencia, $descripcion_audiencia, $campos_filtros, $id_documento,$filtro_categoria, $perfil_admin, $nombre_perfil_admin, $filtro_temporalidad,$filtro_creador,$filtro_mes_ano){
    
	$html = str_replace("{NUMERO_PERSONAS}",		$arreglo[7],			$html);
	$html = str_replace("{EXCLUIR}",				$excluir,				$html);
    $html = str_replace("{NOMBRE_AUDIENCIA}",		$nombre_audiencia,		$html);
    $html = str_replace("{DESCRIPCION_AUDIENCIA}",	$descripcion_audiencia,	$html);


if($perfil_admin =="113" or $perfil_admin =="135"){
    $lista_fc=lista_publicaciones_fns_categoria_data($filtro_categoria,$nombre_perfil_admin,$id_empresa,$filtro_temporalidad,$filtro_creador,$filtro_mes_ano);
} else {
	$lista_fc=lista_publicaciones_fns_categoria_data($filtro_categoria,"",$id_empresa,$filtro_temporalidad,$filtro_creador,$filtro_mes_ano);
}
	//print_r($lista_fc);
	
    foreach($lista_fc as $unico){
	//$num_colaboradores=Audiencia_Sql(Decodear3($unico->sqlquery));
	
	if($perfil_admin =="113" or $perfil_admin =="135"){
                    $row=file_get_contents("views/incentivos/row_publicaciones_read.html");
	} else {
                    $row=file_get_contents("views/incentivos/row_publicaciones.html");
	}

	
                    $row = str_replace("{NOMBRE_PUBLICACION}",                    	($unico->nombre),$row);
                    $row = str_replace("{DESCRIPCION_PUBLICACION}",               	($unico->descripcion),$row);
                    $row = str_replace("{FECHA_INICIO}",               				($unico->fecha_inicio),$row);
                    $row = str_replace("{FECHA_TERMINO}",               			($unico->fecha_termino),$row);
                    $row = str_replace("{CATEGORIA}",               				($unico->agrupacion),$row);
                    $row = str_replace("{NEGOCIO}",               				($unico->nombre_negocio),$row);


if($unico->perfil==""){$perfil="TODOS";} else {
	$perfil=$unico->perfil;
}

                    $row = str_replace("{PERFIL}",               				($perfil),$row);
                    $row = str_replace("{DOCUMENTO}",               				($unico->documento),$row);
                    $row = str_replace("{AUDIENCIA}",              					($unico->audiencia),$row);
					$row = str_replace("{ID_PUBLICACION}",               			($unico->id),$row);
					
					$row = str_replace("{CREADOR}",               					($unico->autor),$row);
					$row = str_replace("{FECHA_CREACION}",               			($unico->fecha_creacion),$row);

$row = str_replace("{VERDOCUMENTO_AUDIENCIA}","




<a href='docs/".$unico->filename_enc."' class='btn btn-info  btn-sm' target='_blank' style='margin-top: 10px;margin-right: 10px;font-size: 12px; '>Ver Documento</a>

<BR><BR>

<a href='?sw=FC_Descarga_Audiencia&amp;sql=".$unico->sqlquery."' class='btn btn-info btn-sm' style='margin-top: 10px;'>Descargar Colaboradores</a>"

 ,$row);

                    $row = str_replace("{FORMULARIO_EDITAR}",       			"
					
					
					
					
					<form name='form_".$unico->id.">
						<input type='text' name='id_audiencia' id='id_audiencia' value='".$unico->id."'>
						<input type='submit' class='btn btn-primary btn-sm pull-right flat' value='Editar Publicacion' style='margin-top: 10px;margin-right: 10px;font-size: 14px; width: 150px;'>
					</form>
					
					",$row);

					$total_html.=$row;
					
					
					
					
                }
    
	$html = str_replace("{VISTA_AGRUPACION_CAMPO1}",	$row1,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO2}",	$row2,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO3}",	$row3,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO4}",	$row4,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO5}",	$row5,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO6}",	$row6,	$html);

    $html = str_replace("{CADENA_FILTRO}",			$campos_filtros,	$html);
    $html = str_replace("{ID_AUDIENCIA_EDIT}",		$id_audiencia,		$html);




	$data_negocio	=	lista_negocios_data($id_empresa);
		$option_negocio.=" <option value=''></option>";
		foreach ($data_negocio as $unique1)
		{
			$option_negocio.=" <option value='".$unique1->id."'>".($unique1->negocio)."</option>";
		}
	

	$data_documentos	=	lista_documentos_data($id_empresa);
		$option_documentos.=" <option value=''></option>";
		foreach ($data_documentos as $unique1)
		{
			$option_documentos.=" <option value='".$unique1->id."'>".($unique1->nombre)."</option>";
		}


$YEAR_ACTUAL=date("Y");
 	$data_documentos	=	lista_documentos_data_tipoYear($id_empresa,"","",$YEAR_ACTUAL,"yearactual");
		$option_documentos_year_actual.=" <option value=''></option>";
		foreach ($data_documentos as $unique1)
		{
			$option_documentos_year_actual.=" <option value='".$unique1->id."'>".($unique1->nombre)."</option>";
		}   
    


    
   	$data_documentos	=	lista_documentos_data_tipoYear($id_empresa,"","",$YEAR_ACTUAL,"NOT_yearactual");
		$option_documentos_historicos.=" <option value=''></option>";
		foreach ($data_documentos as $unique1)
		{
			$option_documentos_historicos.=" <option value='".$unique1->id."'>".($unique1->nombre)."</option>";
		}     


	
	$data_audiencia		=	AUDIENCIA_TotalAudienciasPorempresaOrderDesc($id_empresa);
		$option_audiencia.=" <option value=''></option>";
		foreach ($data_audiencia as $unique1)
		{
			$option_audiencia.=" <option value='".$unique1->id."'>".($unique1->nombre)."</option>";
		}
	
	
	

    $html = str_replace("{SELECT_OPTION_DOCUMENTO}",$option_documentos,$html);
    
    $html = str_replace("{SELECT_OPTION_DOCUMENTO_YEAR_ACTUAL}",$option_documentos_year_actual,$html);
    $html = str_replace("{SELECT_OPTION_DOCUMENTO_historicos}",$option_documentos_historicos,$html);
    
    $html = str_replace("{SELECT_OPTION_NEGOCIO}",$option_negocio,$html);

    
    
    
    $html = str_replace("{SELECT_OPTION_AUDIENCIA}",$option_audiencia,$html);
	 
    $html = str_replace("{FILTRO_CATEGORIA}",               			($filtro_categoria),$html);


    $html = str_replace("{LISTA_READ}",$total_html,$html);

	
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Publicaciones",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
	
    return($html);
}
function lista_audiencia($html,  $id_empresa, $filtro_edit, 
$filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $incluir,
$nombre_audiencia, $descripcion_audiencia, $campos_filtros, $id_audiencia, $reset, $filtro_creador, $filtro_mes_ano){
 
    //echo "<BR> $id_empresa, $filtro_edit,$filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $incluir,$nombre_audiencia, $descripcion_audiencia, $campos_filtros, $id_audiencia, $reset, $filtro_creador, $filtro_mes_ano";
    //echo "id_audiencia $id_audiencia";

$array_Audiencia=BuscaDatosAudiencia($id_audiencia);
//print_r($array_Audiencia);

$arreglo=MatrizIncentivos_Lista_campo_data("division", "area", "zona","sucursal", "unidad_negocio", "cargo", $filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $incluir, $id_empresa);				
		//echo "<pre>";print_r($arreglo);exit();

foreach ($arreglo[1] as $unico){
	$row1.=file_get_contents("views/incentivos/row_lista_checkbox.html");
	$row1 = str_replace("{CAMPO}"	,  ($unico->dato),$row1);
	$row1 = str_replace("{ID}"		,  "campo1_".($unico->dato),$row1);	
		if($id_audiencia>0){
			if (in_array($unico->dato, $filtro_edit[1])) {
				$checked1="checked";
			} else {
				$checked1="";	
			}
		} else {
			if($filtro1<>""){
				$checked1="checked";
			} else {
				$checked1="";
			}	
		}	
	$row1 = str_replace("{CHECKED}"		,  $checked1,$row1);	
}
foreach ($arreglo[2] as $unico){
	$row2.=file_get_contents("views/incentivos/row_lista_checkbox.html");
	$row2 = str_replace("{CAMPO}"	,  ($unico->dato),$row2);
	$row2 = str_replace("{ID}"		,  "campo2_".($unico->dato),$row2);
		if($id_audiencia>0){
			if (in_array($unico->dato, $filtro_edit[2])) {
				$checked2="checked";
			} else {
				$checked2="";	
			}
		} else {
			if($filtro2<>""){
				$checked2="checked";
			} else {
				$checked2="";
			}	
		}	
	$row2 = str_replace("{CHECKED}"		,  $checked2,$row2);	
}
foreach ($arreglo[3] as $unico){
	$row3.=file_get_contents("views/incentivos/row_lista_checkbox.html");
	$row3 = str_replace("{CAMPO}"	,  ($unico->dato),$row3);
	$row3 = str_replace("{ID}"		,  "campo3_".($unico->dato),$row3);		
		if($id_audiencia>0){
			if (in_array($unico->dato, $filtro_edit[3])) {
				$checked3="checked";
			} else {
				$checked3="";	
			}
		} else {
			if($filtro3<>""){
				$checked3="checked";
			} else {
				$checked3="";
			}	
		}	
	$row3 = str_replace("{CHECKED}"		,  $checked3,$row3);	
}
foreach ($arreglo[4] as $unico){
	$row4.=file_get_contents("views/incentivos/row_lista_checkbox.html");
	$row4 = str_replace("{CAMPO}"	,  ($unico->dato),$row4);
	$row4 = str_replace("{ID}"		,  "campo4_".($unico->dato),$row4);		
		if($id_audiencia>0){
			if (in_array($unico->dato, $filtro_edit[4])) {
				$checked4="checked";
			} else {
				$checked4="";	
			}
		} else {
			if($filtro4<>""){
				$checked4="checked";
			} else {
				$checked4="";
			}	
		}	
	$row4 = str_replace("{CHECKED}"		,  $checked4,$row4);	
}
foreach ($arreglo[5] as $unico){
	$row5.=file_get_contents("views/incentivos/row_lista_checkbox.html");
	$row5 = str_replace("{CAMPO}"	,  ($unico->dato),$row5);
	$row5 = str_replace("{ID}"		,  "campo5_".($unico->dato),$row5);		
		if($id_audiencia>0){
			if (in_array($unico->dato, $filtro_edit[5])) {
				$checked5="checked";
			} else {
				$checked5="";	
			}
		} else {
			if($filtro5<>""){
				$checked5="checked";
			} else {
				$checked5="";
			}	
		}	
	$row5 = str_replace("{CHECKED}"		,  $checked5,$row5);	
}
foreach ($arreglo[6] as $unico){
	$row6.=file_get_contents("views/incentivos/row_lista_checkbox.html");
	$row6 = str_replace("{CAMPO}"	,  ($unico->dato),$row6);
	$row6 = str_replace("{ID}"		,  "campo6_".($unico->dato),$row6);		
	
	
	//echo "filtro 6, id audiencia $id_audiencia, print filtro edit 6  ". print_r($filtro_edit[6]);
	
		if($id_audiencia>0){
			if (in_array($unico->dato, $filtro_edit[6])) {
				$checked6="checked";
			} else {
				$checked6="";	
			}
		} else {
			if($filtro6<>""){
				$checked6="checked";
			} else {
				$checked6="";
			}	
		}	
	$row6 = str_replace("{CHECKED}"		,  $checked6,$row6);	
}
	//echo "<br>Numero ".$arreglo[5];//echo "<br>Usuario ".$arreglo[6];//echo "<br>Sql ".$arreglo[7];

if($nombre_audiencia<>"" and $arreglo[9]<>"" and $descripcion_audiencia<>""){
	//echo "<sql> ".$arreglo[7];	//echo "<br>Encodear3 ".Encodear3($arreglo[7]);	//echo "zbr>Descodear3 ".Decodear3(Encodear3($arreglo[7]));
	Audiencia_Save_NuevaAudiencia($nombre_audiencia,$descripcion_audiencia, $id_empresa, Encodear3($arreglo[9]), $excluir, $incluir, $campos_filtros, $id_audiencia);
	
	if($id_audiencia>0){
		echo "<script>alert('Audiencia Actualizada');</script>";
    echo "<script>location.href='?sw=lista_audiencias&reset=1';    </script>";
			
	} else {
		echo "<script>alert('Audiencia Registrada');</script>";	
    echo "<script>location.href='?sw=lista_audiencias&reset=1';    </script>";
		}
}

if($nombre_audiencia==""){$nombre_audiencia=$array_Audiencia[0]->nombre;}
if($descripcion_audiencia==""){$descripcion_audiencia=$array_Audiencia[0]->descripcion;}   

//echo "<br>excluir $excluir. POST ".$array_Audiencia[0]->excluir;
//echo "<br>incluir $incluir. POST ".$array_Audiencia[0]->incluir;

if($excluir==""){$excluir=$array_Audiencia[0]->excluir;}
if($incluir==""){$incluir=$array_Audiencia[0]->incluir;}

//echo "<br>excluir $excluir. POST ".$array_Audiencia[0]->excluir;
//echo "<br>incluir $incluir. POST ".$array_Audiencia[0]->incluir;

	$html = str_replace("{NUMERO_PERSONAS}",		$arreglo[7],			$html);
	$html = str_replace("{EXCLUIR}",				$excluir,				$html);
	$html = str_replace("{INCLUIR}",				$incluir,				$html);
    $html = str_replace("{NOMBRE_AUDIENCIA}",		$nombre_audiencia,		$html);
    $html = str_replace("{DESCRIPCION_AUDIENCIA}",	$descripcion_audiencia,	$html);
 
    $lista_fc=lista_audiencia_data($id_empresa, $filtro_creador, $filtro_mes_ano);
    foreach($lista_fc as $unico){
	    
	//echo "<br>";  
	//print_r($unico);
	//echo "<br>";
	
	$campos_filtros_data="";

		$campos_filtros_data=$unico->campos_filtros;
	
	
	
	$num_colaboradores=Cuenta_Audiencia_Sql(Decodear3($unico->sqlquery), $unico->id, $id_empresa);
	
		if($_SESSION["admin_"] =="control_gestion" or $unico->no_editable=="1"){
			       $row=file_get_contents("views/incentivos/row_audienciat_read.html");
		} else {
			       $row=file_get_contents("views/incentivos/row_audienciat.html");
		}
             
                    $row = str_replace("{ID_AUDIENCIA}",                    ($unico->id),$row);
                    $row = str_replace("{NOMBRE_AUDIENCIA}",                    ($unico->nombre),$row);
                    $row = str_replace("{DESCRIPCION_AUDIENCIA}",               ($unico->descripcion),$row);
                    $row = str_replace("{FILTRO}",               				($campos_filtros_data),$row);
					
                    $row = str_replace("{SQLQUERY}",               				($unico->sqlquery),$row);
                    $row = str_replace("{SQLQUERY_DEC}",               			(Decodear3($unico->sqlquery)),$row);
                    $row = str_replace("{EXCLUSION}",              				($unico->excluir),$row);
                    $row = str_replace("{INCLUSION}",              				($unico->incluir),$row);

                    $row = str_replace("{CREADOR}",              				($unico->autor),$row);
                    $row = str_replace("{FECHA_CREACION}",              		($unico->fecha_creacion),$row);

					
					$row = str_replace("{FORMULARIO_EDITAR}",       			"
					
					<form name='form_".$unico->id."' id='form_".$unico->id."' action='?sw=lista_audiencias&id_audiencia=".Encodear3($unico->id)."&filt_enc=".($unico->campos_filtros_enc)."' method='post'>
						<input type='submit' class='btn btn-link flat' value='Editar Audiencia' style='margin-top: 0px;margin-right: 10px;  font-size: 10px; display: inline-flex;'>
					</form>
					
					",$row);
					$row = str_replace("{ELIMINA}",	"
					<a href='?sw=lista_audiencias&delaudiencia=1&ida=".Encodear3($unico->id)."' 
					class='btn btn-link' style='font-size: 12px;' onclick='return confirm(\"Estas seguro de eliminar la Audiencia\")'>
					<small>Eliminar</small></a>",$row);
					

$row = str_replace("{DESCARGAR_USUARIOS}",       			"
					
					<form name='form_".$unico->id."2' id='form_".$unico->id."2' action='?sw=FC_Descarga_Audiencia' method='post'>
					
					<input type='hidden' id='sqlquery' name='sqlquery' value='".$unico->sqlquery."'>
					<input type='submit' class='btn btn-link flat' value='Descargar Usuarios Audiencia' style='margin-top: 0px;margin-right: 10px;  font-size: 10px; display: inline-flex;'>
					</form>
					
					",$row);

					
                    $row = str_replace("{NUM_COLABORADORES}",            		$num_colaboradores,$row);
                    $row = str_replace("{DESCARGA_EXCEL}",           			$unico->sqlquery,$row);
                    $total_html.=$row;
					
					
				
					
					
                }

				///print_r($row5);
    
	$html = str_replace("{VISTA_AGRUPACION_CAMPO1}",	$row1,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO2}",	$row2,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO3}",	$row3,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO4}",	$row4,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO5}",	$row5,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO6}",	$row6,	$html);

	//echo "reset $reset funciones";
	if($reset==1){
		
		$campos_filtros="";
		
	}
	//echo "campos_filtros $campos_filtros";
	
    $html = str_replace("{CADENA_FILTRO}",			$campos_filtros,	$html);
    $html = str_replace("{ID_AUDIENCIA_EDIT}",		$id_audiencia,		$html);
    $html = str_replace("{ID_AUDIENCIA_EDIT_ENC}",		Encodear3($id_audiencia),		$html);

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Lista de Audiencias",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
	
    return($html);
}

function ListadoLMSMallas($PRINCIPAL, $id_empresa, $id_malla, $id_programa, $rut, $url_base, $id_curso_sent){
    $url_objetos=$url_base;
    if($id_curso_sent<>""){
    //echo "..............hol1";
    $id_programa_array=BuscaIdProgramadadoIdCurso($id_curso_sent, $id_empresa);
        //print_r($id_programa_array);
        //$id_programa=$id_programa_array[0]->id_programa;
    $mallas=TraeMallasPorProgramaT($id_empresa, $rut, $id_curso_sent);
    } else {
    //echo "..............hol2";
    $mallas=TraeMallasPorProgramaEmpresaRutSinVacios($id_empresa, $id_programa, $rut);
    }
    //echo "<br>$id_empresa, $id_malla, id programa $id_programa, $rut, $url_base, $id_curso_sent";
    //$mallas=TotalMallas2($id_empresa);
    $total_mallas="";
    $i=1;
    $nombre_completo_usuario="";
    if($rut<>''){$nombre_completo=TraeNombreUsuario($rut);
    $nombre_completo_usuario="".$nombre_completo[0]->nombre_completo."";
    }
    //print_r($mallas);//$n_mallas=Cuenta_Mallas($id_empresa);
    foreach($mallas as $unico){
        $row=file_get_contents("views/capacitacion/lms_malla_clas_cursos/row_listado_lms_malla.html");
        $row = str_replace("{NUMERO}",$unico->orden,$row);
        $i++;
        $row = str_replace("{TOTALCURSOS}",CuentaCursosMalla($unico->id_malla,$id_empresa),$row);
        $row = str_replace("{CODIGO_PROGRAMA}",$id_programa,$row);
        $row = str_replace("{CODIGO_MALLA}",$unico->id_malla,$row);
        $row = str_replace("{CODIGO_MALLA_ENCODEADO}",Encodear($unico->id_malla),$row);
        $row = str_replace("{NOMBRE_MALLA}",$unico->nombre_malla,$row);
        $row = str_replace("{TIPO_MALLA}",$unico->tipo,$row);
        $row = str_replace("{DATOS_PARAMETROS}","$nombre_completo_usuario",$row);
        $row = str_replace("{CORREO_RESPONSABLE}",$unico->correo,$row);
        $row = str_replace("{BTN_ORDEN}",crear_boton_orden("?sw=listcmallas",$n_mallas,$unico->orden,"tbl_malla","orden"),$row);
        $clasificaciones=TotalClasifSinVacios($id_empresa, $unico->id_malla);
        $total_clasif="";
        $cont_cla=1;
        foreach($clasificaciones as $clasif){
            $row_clasificacion=file_get_contents("views/capacitacion/lms_malla_clas_cursos/row_listado_lms_clasificacion.html");
            $row_clasificacion = str_replace("{CODIGO_PROGRAMA}",$id_programa,$row_clasificacion);
            $row_clasificacion= str_replace("{NOMBRE_CLASIFICACION}",$clasif->nombre,$row_clasificacion);
            $row_clasificacion= str_replace("{CODIGO_CLASIFICACION}",$clasif->id_clasificacion,$row_clasificacion);
            $row_clasificacion= str_replace("{DATOS_PARAMETROS}","",$row_clasificacion);
            $row_clasificacion= str_replace("{TIPO_CLASIFICACION}","",$row_clasificacion);
            $row_clasificacion= str_replace("{CODIGO_MALLA}",$unico->id,$row_clasificacion);
            if($id_curso_sent<>''){
            $cursos=TotalCursoSinVaciosDadoCurso($id_empresa, $unico->id_malla, $id_curso_sent);
            } else {
            $cursos=TotalCursoSinVacios($id_empresa, $unico->id_malla, $clasif->id_clasificacion);
            }
            $total_html_cursos="";
            //print_r($cursos);
            foreach($cursos as $cur){
                $row_curso=file_get_contents("views/capacitacion/lms_malla_clas_cursos/row_listado_lms_curso.html");
                $row_curso= str_replace("{NOMBRE_CURSO}",$cur->nombre,$row_curso);
                $row_curso = str_replace("{CODIGO_PROGRAMA}",$id_programa,$row_curso);
                //echo $cur->inactivo;
                if($cur->inactivo==="0"){
                    $row_curso= str_replace("{DISPLAY_ACTIVA}","style='display:none;'",$row_curso);
                    $row_curso= str_replace("{DISPLAY_DESACTIVA}","",$row_curso);
                    $row_curso= str_replace("{DOT}","<span class='mt-action-dot bg-green'></span>",$row_curso);
                    //echo "<br> ".$cur->id_curso." ".$cur->inactivo;
                }elseif($cur->inactivo=="1"){
                    $row_curso= str_replace("{DISPLAY_ACTIVA}","",$row_curso);
                    $row_curso= str_replace("{DISPLAY_DESACTIVA}","style='display:none;'",$row_curso);
                    $row_curso= str_replace("{DOT}","<span class='mt-action-dot bg-red'></span>",$row_curso);
                    //echo "<br> ".$cur->id_curso." ".$cur->inactivo;
                }
            //    exit();
            if($cur->imagen<>''){
        $img_curso="../front/img/".$cur->imagen;
                    $imagencurso="<img src='".$img_curso."' width='50'>";
            } else {
        $imagencurso="";
            }
                $row_curso= str_replace("{URL_IMAGES}",$imagencurso,$row_curso);
                $row_curso= str_replace("{CODIGO_CURSO}",$cur->id_curso,$row_curso);
                $row_curso= str_replace("{ID_EMPRESA}",$id_empresa,$row_curso);
                $row_curso= str_replace("{ID_CLASIFICACION}",$clasif->id_clasificacion,$row_curso);
                $row_curso= str_replace("{ID_MALLA}",$unico->id,$row_curso);
                $row_curso= str_replace("{TIPO_CURSO}",$cur->nombre_modalidad,$row_curso);
                $row_curso= str_replace("{DATOS_PARAMETROS}",$cur->descripcion,$row_curso);
                $row_curso= str_replace("{OBJETO_NOMBRE}","",$row_curso);
                $row_curso= str_replace("{OBJETO_DESCRIPCION}","",$row_curso);
                $row_curso= str_replace("{OBJETO_TITULO_CIERRE}","",$row_curso);
                $row_curso= str_replace("{OBJETO_TEXTO_CIERRE}","",$row_curso);
                //$row_curso= str_replace("{OBJETO_URL}","",$row_curso);
                //busca siguieten id objeto y evaluacion
                $siguienteOBJ_array=BuscaSiguienteObjeto($cur->id_curso);
                $siguienteEva_array=BuscaSiguienteEvaluacion();
                $max_orden=0;
                $max_evaluacion=0;
                $max_orden        =$siguienteOBJ_array[0]->MaxOrden+1;
                $max_evaluacion    =$siguienteEva_array[0]->MaxEval+1;
                $id_objeto_sugerido=$cur->id_curso."m".$max_orden;
                $id_objeto_evaluacion=$max_evaluacion;
                $url_archivo_sugerido=$url_objetos."/".$cur->id_curso."m".$max_orden."";
                ////echo "$url_archivo_sugerido=$url_objetos $cur->id_curso $max_orden";
                //if (!file_exists($carpeta)) { mkdir($url_archivo_sugerido, 0777, true);    }
                $row_curso= str_replace("{OBJETO_URL}",$url_archivo_sugerido,$row_curso);
                $row_curso= str_replace("{ID_OBJETO_SUGERIDO}",$id_objeto_sugerido,$row_curso);
                $row_curso= str_replace("{ID_OBJETO_SUGERIDO_EVALUACION}",$id_objeto_sugerido,$row_curso);
                $row_curso= str_replace("{ID_OBJETO_EVALUACION}",$id_objeto_evaluacion,$row_curso);
                $row_curso= str_replace("{URL_OBJETO_ARCHIVO}",$url_archivo_sugerido,$row_curso);
                $row_curso= str_replace("{OBJETO_ORDEN}",$max_orden,$row_curso);
                $objetos_por_curso=TraeObjetosDadoCursoEmpresa($cur->id_curso, $id_empresa);
                $html_objetos="";
                foreach($objetos_por_curso as $obj){
                    if($obj->tipo_objeto=="3"){$tipo="Módulo";}
                    if($obj->tipo_objeto=="5"){$tipo="Evaluación";}
                    $url="";

                    //Get the first character using substr.
$firstCharacter = substr($obj->url, 0, 4);
if($firstCharacter=="http"){
     $url=$obj->url;

}   else {
  $url="../front/".$obj->url."";
}
 if($obj->preguntas_aleatorias>0){$preg_aleatorias=$obj->preguntas_aleatorias." aleatorias";}  else {$preg_aleatorias="Todo el Banco de Preguntas";}
                    if($obj->tipo_objeto=="3"){$url="<a href='".$url."' class='btn btn-info btn-xs' target='_blank'>Ver Contenido</a>";} else {$url="";}
                    if($obj->tipo_objeto=="5"){
                    if($obj->idmoodle==1){$recalcular_txt="SI";}
                    if($obj->idmoodle==2){$recalcular_txt="NO";}
                    if($obj->urlmoodle==1){$distribuir_txt="Normal";}
                    if($obj->urlmoodle==2){$distribuir_txt="Aleatoria";}
                    if($obj->urlmoodle==3){$distribuir_txt="Aleatoria con ultima fija";}
                    if($obj->linkabrir==1){$vernota_txt="SI";}
                    if($obj->linkabrir==2){$vernota_txt="NO";}
                    if($obj->fecha_inicio<>''){$fecha_inicio=$obj->fecha_inicio;} else {$fecha_inicio="";}
                    if($obj->hora_inicio<>''){$hora_inicio=$obj->hora_inicio;} else {$hora_inicio="";}
                    if($obj->fecha_termino<>''){$fecha_termino=$obj->fecha_termino;} else {$fecha_termino="";}
                    if($obj->hora_termino<>''){$hora_termino=$obj->hora_termino;} else {$hora_termino="";}
                    $activacion="";
                    if($fecha_inicio=='' and $hora_inicio==''){$activacion=" Activo todo el tiempo";}
                    if($obj->fecha_termino=='' and $obj->hora_termino==''){$desactivacion="";}

                    /*$url="
                                        <span class='mt-action-dot bg-green'></span> ID_Evaluacion: ".$obj->id_evaluacion."
                                        <br><span class='mt-action-dot bg-green'></span> Banco Preguntas: ".$obj->numpreg."
                                        <br><span class='mt-action-dot bg-green'></span> Preguntas Validas: ".$obj->numpregValidas."
                                        <br><span class='mt-action-dot bg-green'></span> Preguntas a Realizar: ".$preg_aleatorias."



                                        <br><span class='mt-action-dot bg-green'></span> Nota Aprobaci&oacute;n: ".$obj->nota_aprobacion."%
                                        <br><span class='mt-action-dot bg-green'></span> Intentos: ".$obj->intentos_trivia."
                                        <br><span class='mt-action-dot bg-green'></span> Recalculo notas: ".$recalcular_txt."
                                        <br><span class='mt-action-dot bg-green'></span> Distribuci&oacute;n opciones: ".$distribuir_txt."
                                        <br><span class='mt-action-dot bg-green'></span> Ver nota al terminar: ".$vernota_txt."
                                        <br><span class='mt-action-dot bg-green'></span> Duraci&oacute;n: ".$obj->currentorg."
                                        <br><span class='mt-action-dot bg-green'></span> Activaci&oacute;n: ".$fecha_inicio." ".$hora_inicio."".$activacion."
                                         ".$fecha_termino." ".$hora_termino."";
                    }*/
					$url="
                                        <span class='mt-action-dot bg-green'></span> ID_Evaluacion: ".$obj->id_evaluacion."
                                        <br><span class='mt-action-dot bg-green'></span> Banco Preguntas: ".$obj->numpreg."
                                        <br><span class='mt-action-dot bg-green'></span> Preguntas a Realizar: ".$preg_aleatorias."
                                        <br><span class='mt-action-dot bg-green'></span> Nota Aprobaci&oacute;n: ".$obj->nota_aprobacion."%
                                        <br><span class='mt-action-dot bg-green'></span> Intentos: ".$obj->intentos_trivia."
                                        ";
                    }
                    //echo $obj->tipo_objeto." - ".$obj->id."<br>";
                    $row_objetos=file_get_contents("views/capacitacion/lms_malla_clas_cursos/row_listado_lms_objeto.html");
                    if($obj->tipo_objeto=="3"){
                        $row_objetos= str_replace("{DATA_TARGET_EDITA_MODULO}","Edita_{CODIGO_OBJETO}",$row_objetos);
                    }else if($obj->tipo_objeto=="5"){
                        $row_objetos= str_replace("{DATA_TARGET_EDITA_MODULO}","Edita_Eval_{CODIGO_OBJETO}",$row_objetos);
                    }
                    //Replaces para el EDITAR
                    $row_objetos= str_replace("{NOMBRE_OBJETO}",$obj->titulo,$row_objetos);
                    $row_objetos= str_replace("{DESCRIPCION_OBJETO}",$obj->descripcion,$row_objetos);
                    $row_objetos= str_replace("{VALUE_NUMERO_INTENTO_".$obj->intentos_trivia."}","selected='selected'",$row_objetos);
                    $row_objetos= str_replace("{PREGUNTAS_ALEATORIAS}",$obj->preguntas_aleatorias,$row_objetos);
                    $row_objetos= str_replace("{NOTA_APROBACION}",$obj->nota_aprobacion,$row_objetos);
                    $row_objetos= str_replace("{DURACION_VIDEO_EDIT}",$obj->duracion_video,$row_objetos);
                    $row_objetos= str_replace("{TIEMPO_TOTAL}",$obj->currentorg,$row_objetos);
                    $row_objetos= str_replace("{FECHA_INICIO}",$obj->fecha_inicio,$row_objetos);
                    $row_objetos= str_replace("{FECHA_TERMINO}",$obj->fecha_termino,$row_objetos);
                    $row_objetos= str_replace("{HORA_INICIO}",$obj->hora_inicio,$row_objetos);
                    $row_objetos= str_replace("{HORA_TERMINO}",$obj->hora_termino,$row_objetos);
                    $row_objetos= str_replace("{OBJETO_TITULO_CIERRE}",$obj->titulo_principal,$row_objetos);
                    $row_objetos= str_replace("{OBJETO_TEXTO_CIERRE}",$obj->bajada_principal,$row_objetos);
                    $row_objetos= str_replace("{ID_MALLA}",$unico->id,$row_objetos);
                    $row_objetos= str_replace("{CODIGO_CURSO}",$obj->id_curso,$row_objetos);
                    $row_objetos= str_replace("{CODIGO_PROGRAMA}",$id_programa,$row_objetos);
                    $row_objetos= str_replace("{SELECTED_".$obj->tipo_objeto."-".$obj->extension_objeto."}","selected='selected'",$row_objetos);
                    $row_objetos= str_replace("{DATOS_PARAMETROS_OBJETO}","".$url,$row_objetos);
                    $row_objetos= str_replace("{CODIGO_OBJETO}",$obj->id,$row_objetos);
                    $row_objetos= str_replace("{TIPO_OBJETO_txt}",utf8_decode($tipo),$row_objetos);
                    $row_objetos= str_replace("{ORDEN_OBJETO}",$obj->orden,$row_objetos);
                    $row_objetos= str_replace("{TIPO_OBJETO}",$obj->n,$row_objetos);
                    $row_objetos= str_replace("{RUT}",$rut,$row_objetos);
                    $row_objetos= str_replace("{ID_OBJETO}",$obj->id,$row_objetos);
                        if($rut){
                        $row_objetos= str_replace("{ACCION2}","",$row_objetos);
                        //Verifico si este objeto eta o no finalizado
                        $objeto_finalizado=ObjetoFinalizadoDadoIdYRut($rut, $obj->id);
                        if($objeto_finalizado){
                            $row_objetos= str_replace("{ACCION}",file_get_contents("views/capacitacion/lms_malla_clas_cursos/row_aprobado.html"),$row_objetos);
                            if($objeto_finalizado[0]->nota===0 or $objeto_finalizado[0]->nota>0){
                                $row_objetos= str_replace("{NOTA}","<span class='label label-sm label-warning lms_text_white_sm'>Nota: ".$objeto_finalizado[0]->nota."%</span>",$row_objetos);
                            $row_objetos= str_replace("{RESETEAR}","<span id='bloqueResetear_{ID_OBJETO}_{RUT}'><span onclick='Resetear_Eval{ID_OBJETO}_{RUT}();'
                            class='btn btn-danger btn-sm'>Resetear Evaluaci&oacute;n</span></span><br><br>",$row_objetos);
                            } else {
                                $row_objetos= str_replace("{NOTA}","",$row_objetos);
                                $row_objetos= str_replace("{RESETEAR}","",$row_objetos);
                            }
                        }else{
                            $row_objetos= str_replace("{ACCION}",file_get_contents("views/capacitacion/lms_malla_clas_cursos/row_pendiente.html"),$row_objetos);
                        }
                    }else{
                        $row_objetos= str_replace("{ACCION}","",$row_objetos);
                    }
                    $row_objetos= str_replace("{RUT}",$rut,$row_objetos);
                    $row_objetos= str_replace("{ID_OBJETO}",$obj->id,$row_objetos);
                    $row_objetos= str_replace("{NOMBRE_OBJETO}",$obj->titulo,$row_objetos);
                    $row_objetos= str_replace("{TIPO_OBJETO}",$obj->nombre,$row_objetos);
                    if($obj->tipo_objeto=="5"){
                        if($obj->id_evaluacion){
                            $row_objetos= str_replace("{ACCION2}","<a href='?sw=viewEval&idEval=".$obj->id_evaluacion."&programa={ID_PROGRAMA}' class='btn btn-primary btn-xs'>Gestionar Banco Preguntas</a><br>",$row_objetos);
                            //$row_objetos= str_replace("{ACCION3}","
                            //<a href='?sw=Download_Respuestas_Eval&idEval=".$obj->id_evaluacion."&ido=".Encodear3($obj->id)."&idc=".Encodear3($obj->id_curso)."' class='btn btn-link btn-sm'>Descargar Respuestas</a> <br>
                            //<a href='?sw=ActualizarNotasEval&idEval=".$obj->id_evaluacion."&ido=".Encodear3($obj->id)."&idc=".Encodear3($obj->id_curso)."' class='btn btn-link btn-sm'>ReCalcular Nota</a>
                            //",$row_objetos);
							$row_objetos= str_replace("{ACCION3}","
                            <br><a href='?sw=Download_Respuestas_Eval&idEval=".$obj->id_evaluacion."&ido=".Encodear3($obj->id)."&idc=".Encodear3($obj->id_curso)."' class='btn btn-link btn-sm'>Descargar Respuestas</a> <br>
                            ",$row_objetos);
$row_objetos= str_replace("{ACCION4}","",$row_objetos);
} else {
//no tiene evaluacion
                        $row_objetos= str_replace("{ACCION2}","",$row_objetos);
                        $row_objetos= str_replace("{ACCION3}","",$row_objetos);
$arreglo_evaluaciones=BuscaEvaluaciones($id_empresa);
foreach($arreglo_evaluaciones as $arreglo_evaluacion){
    $opcion_evaluaciones.="<option value='".$arreglo_evaluacion->id."'>(".$arreglo_evaluacion->id.") ".$arreglo_evaluacion->nombre_evaluacion."</option>";
}
$row_objetos= str_replace("{ACCION4}","
<form class='form-horizontal' method='POST' name='UpdateEvaluacion' id='UpdateEvaluacion' action='?sw=vista_mallas_clasificaciones_cursos_objetos&programa=".$id_programa."&id_objeto=".$obj->id."'>
<select name='id_evaluacion' id='id_evaluacion' class='form-control'>".$opcion_evaluaciones."</select>
<button type='submit' class='btn btn-primary btn-xs'>Asignar Banco Preguntas</button></form>
",$row_objetos);
                        }
                        $row_objetos= str_replace("{ACCION5}","
<button type='button' class='btn btn-link btn-sm'
        data-toggle='modal'
        data-id_malla='{ID_MALLA}'
        data-target='#EliminarPreg_{ID_OBJETO}'>
            Eliminar Pregunta
</button>
                        ",$row_objetos);
//busco Preguntas de Evaluacion
$arreglo_preguntas_objeto=BuscaPreguntasDadaEvaluacion($obj->id_evaluacion, $id_empresa);
//print_r($arreglo_preguntas_objeto);
foreach ($arreglo_preguntas_objeto as $preguntaunica){
    $options_preguntas.="<option selected value='".$preguntaunica->id."'>".($preguntaunica->pregunta)."</option>";
}
                        $row_objetos= str_replace("{OPTION_PREGUNTAS_DE_OBJETO}",$options_preguntas,$row_objetos);
                        $row_objetos= str_replace("{ID_EVALUACION_OBJETO}",$obj->id_evaluacion,$row_objetos);
                    }else{
                        $row_objetos= str_replace("{ACCION2}","",$row_objetos);
                        $row_objetos= str_replace("{ACCION3}","",$row_objetos);
                        $row_objetos= str_replace("{ACCION4}","",$row_objetos);
                        $row_objetos= str_replace("{ACCION5}","",$row_objetos);
                    }
                    $row_objetos= str_replace("{RUT}",$rut,$row_objetos);
                    $row_objetos= str_replace("{ID_OBJETO}",$obj->id,$row_objetos);
                    $html_objetos.=$row_objetos;
                }
                $row_curso = str_replace("{CANTIDAD_OBJETOS}",count($objetos_por_curso),$row_curso);
                $row_curso = str_replace("{ROW_LISTADO_OBJETOS}",$html_objetos,$row_curso);
                $total_html_cursos.=$row_curso;
            }
            $row_clasificacion = str_replace("{CANTIDAD_CURSOS}",count($cursos),$row_clasificacion);
            $row_clasificacion = str_replace("{ROW_CURSOS_POR_CLASIFICACION}",$total_html_cursos,$row_clasificacion);
            $total_clasif.=$row_clasificacion;
        }
        $row = str_replace("{ROW_LISTADO_CLASIFICACION_POR_MALLA}",$total_clasif,$row);
        $total_mallas.=$row;
    }
    if($mallas){
        $PRINCIPAL = str_replace("{ROW_LISTADO_MALLAS}",($total_mallas),$PRINCIPAL);
    } else {
        $PRINCIPAL = str_replace("{ROW_LISTADO_MALLAS}","",$PRINCIPAL);
    }
    $mallas=TraeMallasEmpresa($id_empresa);
    foreach($mallas as $malla){
        if($id_malla==$malla->id){
            $option_mallas.='<option selected value="'.$malla->id.'">'.$malla->nombre.'</option>';
        }else{
            $option_mallas.='<option value="'.$malla->id.'">'.$malla->nombre.'</option>';
        }
    }
    $programas=TraeProgramasBBDDPorEmpresaElearning($id_empresa);
    //print_r($programas);
    foreach($programas as $programa){
        if($id_programa==$programa->id_programa){
            $option_programas.='<option selected value="'.$programa->id_programa.'">'.$programa->nombre_programa.'</option>';
        }else{
            $option_programas.='<option value="'.$programa->id_programa.'">'.$programa->nombre_programa.'</option>';
        }
    }
//busca id malla sugerido
$malla_orden=1;
//check
$existeMalla=1;
while($existeMalla>=1) {
 //Aumentamos $i en uno
    $id_malla_sugerido=$id_programa."m".$malla_orden;
    $existeMalla=VerSiExisteMalla($id_malla_sugerido);
    if($existeMalla>=1)    {$malla_orden++;}
}
$id_malla_sugerido=$id_programa."m".$malla_orden;
    $PRINCIPAL = str_replace("{CODIGO_PROGRAMA}",$id_programa,$PRINCIPAL);
    $PRINCIPAL = str_replace("{ID_MALLA_SUGERIDO}",$id_malla_sugerido,$PRINCIPAL);
$ArregloMallas=BuscaMallaPrograma($id_programa,$id_empresa);
foreach($ArregloMallas as $ArregloMalla){
    $opcion_mallas_de_programa.="<option value='".$ArregloMalla->id_malla."'> ".($ArregloMalla->malla)."  (".$ArregloMalla->id_malla.")</option>";
}
$ArregloClasificaciones=BuscaClasificacionPrograma($id_programa,$id_empresa);
foreach($ArregloClasificaciones as $ArregloClasificacion){
    $opcion_clasificacion_de_programa.="<option value='".$ArregloClasificacion->id_clasificacion."'> ".($ArregloClasificacion->clasificacion)."  (".$ArregloClasificacion->id_clasificacion.")</option>";
}
$ArregloCursos=BuscaCursoPrograma($id_programa,$id_empresa);
foreach($ArregloCursos as $ArregloCurso){
    $opcion_cursos_de_programa.="<option value='".$ArregloCurso->id_curso."'> ".($ArregloCurso->curso)."  (".$ArregloCurso->id_curso.")</option>";
}
// Mallas, Clasificaciones, Cursos
$PRINCIPAL= str_replace("{SELECT_MALLAS}","
<select name='id_malla' id='id_malla' class='form-control'>".$opcion_mallas_de_programa."</select>",$PRINCIPAL);
$PRINCIPAL= str_replace("{SELECT_CLASIFICACION}","
<select name='id_clasificacion' id='id_clasificacion' class='form-control'>".$opcion_clasificacion_de_programa."</select>",$PRINCIPAL);
$PRINCIPAL= str_replace("{SELECT_CURSOS}","
<select name='id_curso' id='id_curso' class='form-control'>".$opcion_cursos_de_programa."</select>",$PRINCIPAL);
    $PRINCIPAL = str_replace("{MALLAS}",($option_mallas),$PRINCIPAL);
    $PRINCIPAL = str_replace("{PROGRAMAS_ELEARNING}",($option_programas),$PRINCIPAL);
    $PRINCIPAL = str_replace("{RUT_COLABORADOR}",$rut,$PRINCIPAL);
    return($PRINCIPAL);
}
function crear_boton_orden($url,$total,$anterior,$tabla,$campo){
    $btn="";
    if ($anterior==1){
    $orden=$anterior+1;
    $btn='<a href="'.$url.'&total='.$total.'&orden_anterior='.$anterior.'&orden='.$orden.'&tabla='.$tabla.'&campo='.$campo.'" class="pull-right"><i class="fa fa-fw fa-arrow-down"></i></a>';
    }else if($total==$anterior){
    $orden=$anterior-1;
    $btn='<a href="'.$url.'&total='.$total.'&orden_anterior='.$anterior.'&orden='.$orden.'&tabla='.$tabla.'&campo='.$campo.'" class="pull-right"><i class="fa fa-fw fa-arrow-up"></i></a>';
    }else{
    $bajar=$anterior-1;
    $subir=$anterior+1;
    $btn='<a href="'.$url.'&total='.$total.'&orden_anterior='.$anterior.'&orden='.$subir.'&tabla='.$tabla.'&campo='.$campo.'" class="pull-right"><i class="fa fa-fw fa-arrow-down"></i></a>';
    $btn.='<a href="'.$url.'&total='.$total.'&orden_anterior='.$anterior.'&orden='.$bajar.'&tabla='.$tabla.'&campo='.$campo.'" class="pull-right"><i class="fa fa-fw fa-arrow-up"></i></a>';
    }
    return $btn;
}

function lista_documentos_fn($html,  $id_empresa, $idcategoria, $filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $nombre_audiencia, $descripcion_audiencia, $campos_filtros, $id_documento, $filtro_creador, $filtro_mes_ano){
	


    
	$html = str_replace("{NUMERO_PERSONAS}",		$arreglo[7],			$html);
	$html = str_replace("{EXCLUIR}",				$excluir,				$html);
    $html = str_replace("{NOMBRE_AUDIENCIA}",		$nombre_audiencia,		$html);
    $html = str_replace("{DESCRIPCION_AUDIENCIA}",	$descripcion_audiencia,	$html);

    $lista_fc=lista_documentos_data($id_empresa, $filtro_creador, $filtro_mes_ano);
    foreach($lista_fc as $unico){
	

					$num_colaboradores=Audiencia_Sql(Decodear3($unico->sqlquery));
					
					if($_SESSION["admin_"] =="control_gestion"){
					
									$row=file_get_contents("views/incentivos/row_documentos_read.html");

					
					
					} else {
						
									$row=file_get_contents("views/incentivos/row_documentos.html");
	
					}
                    $row = str_replace("{NOMBRE_DOCUMENTO}",                    ($unico->nombre),$row);
                    $row = str_replace("{DESCRIPCION_DOCUMENTO}",               ($unico->descripcion),$row);
                    $row = str_replace("{FILENAME}",               				($unico->filename),$row);
                    $row = str_replace("{FILENAME_ENC}",               			"docs/".($unico->filename_enc),$row);				
                    $row = str_replace("{FECHA}",               			($unico->fecha),$row);
                    $row = str_replace("{ID_DOC}",               			($unico->id),$row);
                    $row = str_replace("{CREADOR}",               			($unico->autor),$row);
                    $row = str_replace("{FECHA_CREACION}",               	($unico->fecha_creacion),$row);

					
					$row = str_replace("{FORMULARIO_EDITAR}",       			"
					
					
					
					
					<form name='form_".$unico->id.">
						<input type='text' name='id_audiencia' id='id_audiencia' value='".$unico->id."'>
						<input type='submit' class='btn btn-primary btn-sm pull-right flat' value='Editar Audiencia' style='margin-top: 10px;margin-right: 10px;font-size: 14px; width: 150px;'>
					</form>
					
					",$row);

					$total_html.=$row;
                }

				///print_r($row5);
    
	$html = str_replace("{VISTA_AGRUPACION_CAMPO1}",	$row1,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO2}",	$row2,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO3}",	$row3,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO4}",	$row4,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO5}",	$row5,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO6}",	$row6,	$html);

    $html = str_replace("{CADENA_FILTRO}",			$campos_filtros,	$html);
    $html = str_replace("{ID_AUDIENCIA_EDIT}",		$id_audiencia,		$html);
	
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Lista de Documentos",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
	
    return($html);
}
function lista_notificaciones_creacion_fn($html,  $id_empresa, $idcategoria, $filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $nombre_audiencia, $descripcion_audiencia, $campos_filtros, $id_documento, $filtro_creador, $filtro_mes_ano){
	


    
	$html = str_replace("{NUMERO_PERSONAS}",		$arreglo[7],			$html);
	$html = str_replace("{EXCLUIR}",				$excluir,				$html);
    $html = str_replace("{NOMBRE_AUDIENCIA}",		$nombre_audiencia,		$html);
    $html = str_replace("{DESCRIPCION_AUDIENCIA}",	$descripcion_audiencia,	$html);

    $lista_fc=lista_notificaciones_creacion_data($id_empresa, $filtro_creador, $filtro_mes_ano);
    foreach($lista_fc as $unico){
						
					$row=file_get_contents("views/incentivos/row_notificaciones_creacion.html");
                    $row = str_replace("{ASUNTO}",                    		($unico->asunto),$row);
                    $row = str_replace("{TITULO}",               			($unico->titulo),$row);
                    $row = str_replace("{TEXTO}",               			($unico->texto),$row);
                    $row = str_replace("{FECHA}",               			($unico->fecha),$row);
                    $row = str_replace("{ID_NOTIFICACION}",               	($unico->id),$row);
                    $row = str_replace("{CREADOR}",               			($unico->autor),$row);
                    $row = str_replace("{FECHA_CREACION}",               	($unico->fecha_creacion),$row);
					$row = str_replace("{FORMULARIO_EDITAR}",       			"
					
					
					
					
					<form name='form_".$unico->id.">
						<input type='text' name='id_audiencia' id='id_audiencia' value='".$unico->id."'>
						<input type='submit' class='btn btn-primary btn-sm pull-right flat' value='Editar Notificaciones' style='margin-top: 10px;margin-right: 10px;font-size: 14px; width: 150px;'>
					</form>
					
					",$row);

					$total_html.=$row;
                }

				///print_r($row5);
    
	$html = str_replace("{VISTA_AGRUPACION_CAMPO1}",	$row1,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO2}",	$row2,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO3}",	$row3,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO4}",	$row4,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO5}",	$row5,	$html);
    $html = str_replace("{VISTA_AGRUPACION_CAMPO6}",	$row6,	$html);

    $html = str_replace("{CADENA_FILTRO}",			$campos_filtros,	$html);
    $html = str_replace("{ID_AUDIENCIA_EDIT}",		$id_audiencia,		$html);
	
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Lista de Tipos de Notificaciones",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
	
    return($html);
}

function lista_noti_fn($html,  $id_empresa, $idcategoria, $filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $nombre_audiencia, $descripcion_audiencia, $campos_filtros, $id_documento){
    
	$html = str_replace("{NUMERO_PERSONAS}",		$arreglo[7],			$html);
	$html = str_replace("{EXCLUIR}",				$excluir,				$html);
    $html = str_replace("{NOMBRE_AUDIENCIA}",		$nombre_audiencia,		$html);
    $html = str_replace("{DESCRIPCION_AUDIENCIA}",	$descripcion_audiencia,	$html);


//TIPOS DE NOTIFICACIONES

$array_noti	=	lista_notificaciones_creacion_options_data($id_empresa,$filtro_creador, $filtro_mes_ano);

foreach ($array_noti as $unico){
	$options_notificaciones.="<option value='".$unico->id."'>".($unico->titulo)."</option>";
}



    $lista_fc=lista_noti_fns_data($id_empresa);
	//print_r($lista_fc);
	
    foreach($lista_fc as $unico){
		
		
		
                    $row=file_get_contents("views/incentivos/row_notificaciones.html");
                    $row = str_replace("{ID_ENC}",           				Encodear3($unico->id),$row);
					
$row = str_replace("{ID_PUBLICACION}",           		($unico->id),$row);
$row = str_replace("{OPTIONS_TIPO_NOTIFICACIONES}",     ($options_notificaciones),$row);

					$row = str_replace("{NOMBRE_PUBLICACION}",           	($unico->nombre),$row);
                    $row = str_replace("{DESCRIPCION_PUBLICACION}",      	($unico->descripcion),$row);
                    $row = str_replace("{FECHA_INICIO}",               		($unico->fecha_inicio),$row);
                    $row = str_replace("{FECHA_TERMINO}",               	($unico->fecha_termino),$row);

                    $row = str_replace("{DOCUMENTO}",               		($unico->documento),$row);
                    $row = str_replace("{TEXTO_ADICIONAL}",               	($unico->texto_adicional),$row);
					$no_envios=$unico->num_colaboradores-$unico->num_notificaciones;
					if($no_envios<0){$no_envios=0;}
					
					$row = str_replace("{NUM_COLABORADORES}",               ($unico->num_colaboradores),$row);
                    $row = str_replace("{NUM_ENVIOS}",               		($unico->num_notificaciones),$row);
                    $row = str_replace("{NUM_POR_ENVIAR}",               	($no_envios),$row);

if($no_envios>0){
$boton_enviar="	

<input type='hidden' id='id_publicacion' name='id_publicacion' value='".Encodear3($unico->id)."'>
<input type='submit' value='Enviar' class='btn btn-info'>

			";
} else {
	
$boton_enviar="	<small>[ NOTIFICACIONES ENVIADAS ]</small>
					";	
}
					$row = str_replace("{ID_PUBLICACION}",               	($unico->id),$row);
					$row = str_replace("{BOTON_ENVIAR}",  $boton_enviar ,$row);
 
					$total_html.=$row;
                }
    
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Notificaciones",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
	
    return($html);
}
function lista_talent($html,  $id_empresa, $idcategoria){
    $lista_fc=lista_talent_data($id_empresa);
    foreach($lista_fc as $unico){
                    $row=file_get_contents("views/talent/row_talent.html");
                    $row = str_replace("{ID}",                    ($unico->id_cargo),$row);
                    $row = str_replace("{CARGO}",                ($unico->cargo),$row);
                    $row = str_replace("{NIVEL_ESPERADO}",                ($unico->nivel_esperado),$row);
                    $row = str_replace("{POSTULANTES}",            ($unico->postulantes),$row);
                    $cuenta_respondidos=0;
                    $CuentaRespuestas=Talent_buscarespuestas($unico->id_cargo,$unico->nivel_esperado, $id_empresa);
                    foreach ($CuentaRespuestas as $unicoRes){
                    //echo "<br><br>";
                    //print_r($unicoRes);
                        if($unicoRes->cuenta>0){
                            $cuenta_respondidos++;
                        }
                    }
                    $row = str_replace("{CONTESTADOS}",            $cuenta_respondidos,$row);
                    $pendientes=$unico->postulantes-$cuenta_respondidos;
                    $row = str_replace("{PENDIENTES}",            ($pendientes),$row); 
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Talent Assessment Vista Cargos",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_gestion_usuarios_licencias($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_gestion_usuarios_metaspivote($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_tbl_mc_carrera_interna($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_tbl_mc_tramo_desempeno($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_tbl_mc_bac($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_tbl_mc_potencial_relacionados($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_gestion_usuarios_cd($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);
		$cuenta_dotacion_2021=ControlDotacion2021_data();
		$cuenta_dotacion_cero_2021=ControlDotacion2021_cero_data();
		
		
    $html = str_replace("{CONTROL_DOTACION_2021}",$cuenta_dotacion_2021,$html);
    $html = str_replace("{CONTROL_DOTACION_CERO_2021}",$cuenta_dotacion_cero_2021,$html);

    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_gestion_usuarios_dotacion_opciones($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_gestion_usuarios_ubicaciones($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_gestion_dotacion_dia_21($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

	$options_regimen=ControlDotacion2021_Options_Select_Regimen_Motivo_data();
	foreach($options_regimen as $unico2){
		$options_regimen_motivo.="<option value='".($unico2->regimen_actual)."-".($unico2->motivo_actual)."'>".($unico2->regimen_actual)."-".($unico2->motivo_actual)."</option>";
	}


$html = str_replace("{options_regimen_motivo}",$options_regimen_motivo,$html);

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
} 

function lista_fn_tbl_mc_poliza($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_fn_tbl_contingencia_colaborador_retornado_2021($html,  $id_empresa, $temporal_actualizar, $procesar){
    //$emb_embajadores=lista_emb_embajadores_data($id_empresa);
  $totalE_html="";
  $totalN_html="";

    if($temporal_actualizar<>''){
        //echo "<br>temporales";

        $Temporal_todos         =BuscaTotalUsuariosTemporales($id_empresa, "TODOS");
        foreach($Temporal_todos as $unico){
            $usuarios_temporales++;
        }

        $Temporal_nuevos        =BuscaTotalUsuariosTemporales($id_empresa, "NUEVOS");
        foreach($Temporal_nuevos as $unico){
            $usuarios_temporales_nuevos++;
            $row    = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $row    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$row);
            $row    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$row);
            $row    = str_replace("{CARGO}",               ($unico->cargo),$row);
            $row    = str_replace("{EMAIL}",               ($unico->email),$row);
            $totalN_html.=$row;

        }

        $Temporal_noencontrados =BuscaTotalUsuariosTemporales($id_empresa, "NOENCONTRADOS");
        foreach($Temporal_noencontrados as $unico){
            $usuarios_temporales_eliminados++;
            $rowe   = file_get_contents("views/usuarios_gestion/row_usuarios.html");
            $rowe    = str_replace("{RUT_COMPLETO}",        ($unico->rut_completo),$rowe);
            $rowe    = str_replace("{NOMBRE_COMPLETO}",     ($unico->nombre_completo),$rowe);
            $rowe    = str_replace("{CARGO}",               ($unico->cargo),$rowe);
            $rowe    = str_replace("{EMAIL}",               ($unico->email),$rowe);
            $totalE_html.=$rowe;

        }

    }   else {
        //echo "<br>NO&nbsp;temporales";
    }

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);

if($usuarios_temporales>0){$txt_temporales="<div class='col-lg-12 col-md-12 alert alert-info'> Usuarios Ingresados en Base Temporal: $usuarios_temporales</div>";} else {$txt_temporales="";}
if($usuarios_temporales_nuevos>0){$txt_temporalesN="<br><div class='col-lg-12 col-md-12 alert alert-success'> Usuarios Nuevos $usuarios_temporales_nuevos</div> ";} else {$txt_temporalesN="";}
if($usuarios_temporales_eliminados>0){$txt_temporalesE="<br><div class='col-lg-12 col-md-12 alert alert-danger'>Usuarios a Eliminar $usuarios_temporales_eliminados</div>";} else {$txt_temporalesE="";}

if($usuarios_temporales>0){
    $btn_procesar="<center><a href='?sw=actualizacion_usuarios&procesar=1' class='btn btn-info btn-sm'>Procesar Base Actual y Realizar Actualización</a></center>";
} else {
    $btn_procesar="";
}

if($procesar=="1")   {
     $actualizacion_realizada="<center><div class='alert alert-success'>Actualizacion Realizada</div></center>";
        truncate_tbl_usuario($id_empresa);
		BorraDuplicados($tipo, $id_empresa);
     //lee desde tbl_usuario_temporal
      usuario_temporal_lee($id_empresa) ;

 



}   else {
    $actualizacion_realizada="";
}
    $html = str_replace("{ACTUALIZACION_REALIZADA}",$actualizacion_realizada,$html);

    $html = str_replace("{TITULO_TOTAL_LISTA_TODOS}",$txt_temporales,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_NUEVOS}",$txt_temporalesN,$html);
    $html = str_replace("{TITULO_TOTAL_LISTA_ELIMINADOS}",$txt_temporalesE,$html);

    $html = str_replace("{PROCESAR}",$btn_procesar,$html);


    $html = str_replace("{TOTAL_LISTA_TODOS}",$usuarios_temporales,$html);
    $html = str_replace("{TOTAL_LISTA_NUEVOS}",$usuarios_temporales_nuevos,$html);
    $html = str_replace("{TOTAL_LISTA_ELIMINADOS}",$usuarios_temporales_eliminados,$html);


    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_actualizacion_carreras($html,  $id_empresa, $temporal_actualizar, $procesar){
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);
    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_actualizacion_instituciones($html,  $id_empresa, $temporal_actualizar, $procesar){
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);
    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_actualizacion_sucursales($html,  $id_empresa, $temporal_actualizar, $procesar){
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);
    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_fn_download_datos_academicos($html,  $id_empresa, $temporal_actualizar, $procesar){
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{LISTA_NUEVOS}",$totalN_html,$html);
    $html = str_replace("{LISTA_ELIMINADOS}",$totalE_html,$html);
    $html = str_replace("{TITULO}","Actualización de Usuarios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_beneficios($html,  $id_empresa, $idcategoria){
    $form1=lista_beneficios_data_form($id_empresa, "id_form1");
    //print_r($form1);
    //exit();
    foreach($form1 as $unico){
                    
					$row=file_get_contents("views/beneficios/row_beneficios.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 					$no_vistos=$unico->solicitudes-$unico->visto;
					 						//echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-warning'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-warning'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-

                    $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 /*foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 }*/

                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);
                    $row = str_replace("{PENDIENTES}",          		$array_solicitudes[0]->pendiente,$row);
                    $row = str_replace("{EN_PROCESO}",          		$array_solicitudes[0]->enproceso,$row);
                    $row = str_replace("{CERRADAS}",          			$array_solicitudes[0]->validado,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                      $row = str_replace("{ID_FORM}",                      ($unico->id_form1),$row);
                 
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);

                    $total_html.=$row;
			}
			
    $form2=lista_beneficios_data_form($id_empresa, "id_form2");
    //print_r($form1);
    foreach($form2 as $unico){
                    
					$row=file_get_contents("views/beneficios/row_beneficios.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 $no_vistos=$unico->solicitudes-$unico->visto;
					 						//echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					// $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
                $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);

					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{ID_FORM}",                      ($unico->id_form2),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre_formulario),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);

        $row = str_replace("{PENDIENTES}",          		$array_solicitudes[0]->pendiente,$row);
        $row = str_replace("{EN_PROCESO}",          		$array_solicitudes[0]->enproceso,$row);
        $row = str_replace("{CERRADAS}",          			$array_solicitudes[0]->validado,$row);
                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                    
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
			}			
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Beneficios Bch",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    //echo "fin";
    return($html);
}

function lista_beneficios_validacion($html,  $id_empresa, $idcategoria, $id_form){
   $lista_becav=lista_beneficios_validacion_data($idcategoria, $id_empresa, $id_form,"","","");
   		//print_r($lista_becav);
			//echo "idcategoria $idcategoria";
    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
		
                    RFBeneficiosBecasVisto($unico->id);
		
                    $row=file_get_contents("views/beneficios/row_lista_beneficios.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
                    
                    $row = str_replace("{NOMBRE}",        ($unico->nombre),$row);
                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",        ($unico->division),$row);
                    $row = str_replace("{NOMBRE_FORMULARIO}",        ($unico->nombre_formulario),$row);
                    $row = str_replace("{FECHA}",        (fechaCastellano($unico->fecha)),$row);

					$Cel=BuscaDatosUsuarioCelEmailAdmin($unico->rut);
                    $row = str_replace("{CELULAR}",        ($Cel[0]->celular),$row);

										$FORM_SUBE_NUEVO_DOCUMENTO="
												<form name='subirArchivo_".$unico->id."' id='subirArchivo_".$unico->id."' action='?sw=beneficios' method='post' enctype='multipart/form-data'>
						        			
						        			<div>Subir Archivo (.pdf)</div>
						        			<input type='file' name='archivo' id='archivo' class='form form-control' required>
						        			
						        			<br><div>Tipo Archivo</div>
						        			<select name='tipo_archivo' id='tipo_archivo' class='form form-control' required>
						        				<option value=''></option>
						        				<option value='archivo1'>archivo1</option>
						        				<option value='archivo2'>archivo2</option>
						        				<option value='archivo3'>archivo3</option>
						        				<option value='archivo4'>archivo4</option>
						        				<option value='archivo5'>archivo5</option>
						        				<option value='archivo6'>archivo6</option>
						        				<option value='archivo7'>archivo7</option>
						        				<option value='archivo8'>archivo8</option>
						        				<option value='archivo9'>archivo9</option>
						        				<option value='archivo10'>archivo10</option>
						        			</select>
						        			<input type='hidden' name='idl' id='idl' value='".$unico->id."'>
						        			
						        			<br>
						        			<center>
						        				<input type='submit' value='Guardar' class='btn btn-info'>
						        			</center>
						        			
						        		</form>											
										";
										
                    $row = str_replace("{SUBE_NUEVO_DOCUMENTO}",        $FORM_SUBE_NUEVO_DOCUMENTO,$row);


                    $documentacion="";

                    if($unico->ficha_postulacion<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->ficha_postulacion).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_notas<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->pago_arancel<>'')        	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->pago_arancel).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_carga<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->concentracion_notas<>'')     {$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->licencia_edmedia<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->boletinpsu<>'')              {$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->boletinpsu).'" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_egreso<>'')      {$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_egreso).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_acredita<>'')	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info" target="_blank">Documento</a><br><br>';}
                    if($unico->vivienda_foto_escritura<>'')	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_foto_escritura).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_cedula<>'')			{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_cedula).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_residencia<>'')		{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_residencia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_matrimonio<>'')		{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_matrimonio).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    
                    
                    $verifica_archivo1=explode(".",$unico->archivo1);
                    $verifica_archivo2=explode(".",$unico->archivo2);
                    $verifica_archivo3=explode(".",$unico->archivo3);
                    $verifica_archivo4=explode(".",$unico->archivo4);
                    $verifica_archivo5=explode(".",$unico->archivo5);
                    
                    $verifica_archivo6=explode(".",$unico->archivo6);
                    $verifica_archivo7=explode(".",$unico->archivo7);
                    $verifica_archivo8=explode(".",$unico->archivo8);
                    $verifica_archivo9=explode(".",$unico->archivo9);
                    $verifica_archivo10=explode(".",$unico->archivo10);
                    
                    if($verifica_archivo1[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo1).'" target="_blank" class="btn btn-info" target="_blank">Documento 1</a><br><br>';}
                    if($verifica_archivo2[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo2).'" target="_blank" class="btn btn-info" target="_blank">Documento 2</a><br><br>';}
                    if($verifica_archivo3[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo3).'" target="_blank" class="btn btn-info" target="_blank">Documento 3</a><br><br>';}
                    if($verifica_archivo4[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo4).'" target="_blank" class="btn btn-info" target="_blank">Documento 4</a><br><br>';}
                    if($verifica_archivo5[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo5).'" target="_blank" class="btn btn-info" target="_blank">Documento 5</a><br><br>';}

                    if($verifica_archivo6[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo6).'" target="_blank" class="btn btn-info" target="_blank">Documento 6</a><br><br>';}
                    if($verifica_archivo7[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo7).'" target="_blank" class="btn btn-info" target="_blank">Documento 7</a><br><br>';}
                    if($verifica_archivo8[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo8).'" target="_blank" class="btn btn-info" target="_blank">Documento 8</a><br><br>';}
                    if($verifica_archivo9[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo9).'" target="_blank" class="btn btn-info" target="_blank">Documento 9</a><br><br>';}
                    if($verifica_archivo10[1]<>'')						    {$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo10).'" target="_blank" class="btn btn-info" target="_blank">Documento 10</a><br><br>';}
										
										//tipo worfklow
										$bloque_validacion_="";

										if($unico->tipo_workflow=="1003"){
																										// Check admin val1
																										
																										if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>							<em>".($unico->comentarios_validacion)."</em>

<br>		<br>																									
<a class='btn btn-link' role='button' data-toggle='collapse' href='#collapseExample".$unico->id."' aria-expanded='false' aria-controls='collapseExample".$unico->id."' style='    float: right;'>
   modificar
</a>

<div class='collapse' id='collapseExample".$unico->id."'>
  <div class='well'>																											
														<div class='alert alert-warning'>
																											<form action='?sw=beneficios_validacion' method='post' name=''>
																											<label>Acción</label><br>
																												<select name='validacion' class='form form-control'>
																													<option value=''></option>
																													<option value='Validado'>Validar</option>
																													<option value='Rechazado_edicion'>Rechazado para Editar</option>
																													<option value='Rechazado'>Rechazar Definitivamente</option>
																												</select>	<br>
																												<label>Comentarios</label><br>
																												<input type='text' name='comentarios' class='form form-control'>
																												<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
																												<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
																												<input type='hidden' name='id_form' value='".$id_form."' class='form form-control'>
																												<input type='hidden' name='val' value='validacion1' class='form form-control'>
																												<input type='submit' class='btn btn-info' value='Guardar Validacion'>
																											</form>	
																										</div>																											
																	</div>												
														</div>															
																											
																											";				}
																										elseif($unico->validacion1=="Rechazado_edicion"){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>	<em>".($unico->comentarios_validacion)."</em>
<br>	<br>
<a class='btn btn-link' role='button' data-toggle='collapse' href='#collapseExample".$unico->id."' aria-expanded='false' aria-controls='collapseExample".$unico->id."' style='    float: right;'>
   modificar
</a>

<div class='collapse' id='collapseExample".$unico->id."'>
  <div class='well'>
																											
<div class='alert alert-warning'>
																											<form action='?sw=beneficios_validacion' method='post' name=''>
																											<label>Acción</label><br>
																												<select name='validacion' class='form form-control'>
																													<option value=''></option>
																													<option value='Validado'>Validar</option>
																													<option value='Rechazado_edicion'>Rechazado para Editar</option>
																													<option value='Rechazado'>Rechazar Definitivamente</option>
																												</select>	<br>
																												<label>Comentarios</label><br>
																												<input type='text' name='comentarios' class='form form-control'>
																												<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
																												<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
																												<input type='hidden' name='id_form' value='".$id_form."' class='form form-control'>
																												<input type='hidden' name='val' value='validacion1' class='form form-control'>
																												<input type='submit' class='btn btn-info' value='Guardar Validacion'>
																											</form>	
																										</div>																											
												</div>	
	</div>																													
																											";				}
																										elseif($unico->validacion1=="Rechazado"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>							<em>".($unico->comentarios_validacion)."</em>
																											
<br><br>
<a class='btn btn-link' role='button' data-toggle='collapse' href='#collapseExample".$unico->id."' aria-expanded='false' aria-controls='collapseExample".$unico->id."' style='    float: right;'>
  modificar
</a>

<div class='collapse' id='collapseExample".$unico->id."'>
  <div class='well'>
  

																											
																					
																						<div class='alert alert-warning'>
																											<form action='?sw=beneficios_validacion' method='post' name=''>
																											<label>Acción</label><br>
																												<select name='validacion' class='form form-control'>
																													<option value=''></option>
																													<option value='Validado'>Validar</option>
																													<option value='Rechazado_edicion'>Rechazado para Editar</option>
																													<option value='Rechazado'>Rechazar Definitivamente</option>
																												</select>	<br>
																												<label>Comentarios</label><br>
																												<input type='text' name='comentarios' class='form form-control'>
																												<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
																												<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
																												<input type='hidden' name='id_form' value='".$id_form."' class='form form-control'>
																												<input type='hidden' name='val' value='validacion1' class='form form-control'>
																												<input type='submit' class='btn btn-info' value='Guardar Validacion'>
																											</form>	
																										</div>	

  </div>
</div>																																																				
																											
																											";				}
																				else {
																										$bloque_validacion_1="
																										<div class='alert alert-warning'>
																											<form action='?sw=beneficios_validacion' method='post' name=''>
																											<label>Acción</label><br>
																												<select name='validacion' class='form form-control'>
																													<option value=''></option>
																													<option value='Validado'>Validar</option>
																													<option value='Rechazado_edicion'>Rechazado para Editar</option>
																													<option value='Rechazado'>Rechazar Definitivamente</option>
																												</select>	<br>
																												<label>Comentarios</label><br>
																												<input type='text' name='comentarios' class='form form-control'>
																												<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
																												<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
																												<input type='hidden' name='id_form' value='".$id_form."' class='form form-control'>
																												<input type='hidden' name='val' value='validacion1' class='form form-control'>
																												<input type='submit' class='btn btn-info' value='Guardar Validacion'>
																											</form>	
																										</div>";
																				}


																$bloque_validacion_=$bloque_validacion_1;

										}



	if($unico->tipo_workflow=="1008"){
		
		//echo "<h1>a</h1>unico->validacion1  ".$unico->validacion1." unico->validacion2 ".$unico->validacion2;
												// Check admin val1
																										
																										if($unico->validacion1=="Validado" and  $unico->validacion2==""){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>							<em>".($unico->comentarios_validacion)."</em>
																											


<div class='alert alert-warning'>
																											<form action='?sw=beneficios_validacion' method='post' name='form2'>
																											<label>Acción</label><br>
																												<select name='validacion' class='form form-control'>
																													<option value=''></option>
																													<option value='Ganador'>Ganador</option>
																													<option value='NoGanador'>No Ganador</option>
																												</select>	<br>
																												<label>Comentarios</label><br>
																												<input type='text' name='comentarios' class='form form-control'>
																												<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
																												<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
																												<input type='hidden' name='id_form' value='".$id_form."' class='form form-control'>
																												<input type='hidden' name='val' value='validacion1' class='form form-control'>
																												<input type='submit' class='btn btn-info' value='Guardar Validacion'>
																											</form>	
																										</div>
																											
																											
																											
																											";				}
																										elseif($unico->validacion1=="Rechazado_edicion" and  $unico->validacion2==""){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>	<em>".($unico->comentarios_validacion)."</em>";				}
																										elseif($unico->validacion1=="Rechazado" and  $unico->validacion2==""){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>							<em>".($unico->comentarios_validacion)."</em>";				}

												// Check admin val2
																				

																										elseif($unico->validacion1=="Ganador" ){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Ganador</div>							<em>".($unico->comentarios_validacion)."</em>";				}
																										elseif($unico->validacion1=="NoGanador"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>No Ganador</div>	<em>".($unico->comentarios_validacion)."</em>";				}

																				
																				
																				else {
																										$bloque_validacion_1="
																										<div class='alert alert-warning'>
																											<form action='?sw=beneficios_validacion' method='post' name='form1'>
																											<label>Acción</label><br>
																												<select name='validacion' class='form form-control'>
																													<option value=''></option>
																													<option value='Validado'>Validar</option>
																													<option value='Rechazado_edicion'>Rechazado para Editar</option>
																													<option value='Rechazado'>Rechazar Definitivamente</option>
																												</select>	<br>
																												<label>Comentarios</label><br>
																												<input type='text' name='comentarios' class='form form-control'>
																												<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
																												<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
																												<input type='hidden' name='id_form' value='".$id_form."' class='form form-control'>
																												<input type='hidden' name='val' value='validacion1' class='form form-control'>
																												<input type='submit' class='btn btn-info' value='Guardar Validacion'>
																											</form>	
																										</div>
																										

																									
																										
																										
																										";
																				}


																$bloque_validacion_=$bloque_validacion_1;

										}

										$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);

										$id_enc=Encodear3($unico->id);
										$botones_documentacion='';

										$botones_validacion='';
										//echo $botones_documentacion;

										$tipo="";
										if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

										$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
										$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

										$fecha_inicio    =$unico->fecha_inicio;
										$fecha_termino   =$unico->fecha_termino;
										$dia1            =$unico->dia;
										$dia2            =$unico->dia2;
										$fecha_nacimiento=$unico->fecha_nac;
										$anexo           =$unico->anexo;
										$celular         =$unico->num_celular;
										$cargo           =$unico->cargo;
										$mundo           =$unico->mundo;

										$datos="";

$datos.="<form action='?sw=beneficios_validacion' method='post' name='".$unico->id."' id='".$unico->id."'>";

										if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form);
											
											$datos.="<strong> ".$NombreCampo."</strong><br>
											<input type='text' name='idc01' value='".$unico->idc01."' class='form form-control'><br>";}
												
										if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc02' value='".$unico->idc02."' class='form form-control'><br>";}

										if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc03' value='".$unico->idc03."' class='form form-control'><br>";}

										if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc04' value='".$unico->idc04."' class='form form-control'><br>";}

										if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc05' value='".$unico->idc05."' class='form form-control'><br>";}

										if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc06' value='".$unico->idc06."' class='form form-control'><br>";}

										if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc07' value='".$unico->idc07."' class='form form-control'><br>";}

										if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc08' value='".$unico->idc08."' class='form form-control'><br>";}

										if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc09' value='".$unico->idc09."' class='form form-control'><br>";}

										if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc10' value='".$unico->idc10."' class='form form-control'><br>";}

										if($unico->idc11<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc11", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc11' value='".$unico->idc11."' class='form form-control'><br>";}

										if($unico->idc12<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc12", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc12' value='".$unico->idc12."' class='form form-control'><br>";}

										if($unico->idc13<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc13", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc13' value='".$unico->idc13."' class='form form-control'><br>";}

										if($unico->idc14<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc14", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc14' value='".$unico->idc14."' class='form form-control'><br>";}

										if($unico->idc15<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc15", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc15' value='".$unico->idc15."' class='form form-control'><br>";}

										if($unico->idc16<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc16", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc16' value='".$unico->idc16."' class='form form-control'><br>";}

										if($unico->idc17<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc17", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc17' value='".$unico->idc17."' class='form form-control'><br>";}

										if($unico->idc18<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc18", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc18' value='".$unico->idc18."' class='form form-control'><br>";}

										if($unico->idc19<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc19", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc19' value='".$unico->idc19."' class='form form-control'><br>";}

										if($unico->idc20<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc20", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc20' value='".$unico->idc20."' class='form form-control'><br>";}

										if($unico->idc21<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc21", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc21' value='".$unico->idc21."' class='form form-control'><br>";}

										if($unico->idc22<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc22", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc22' value='".$unico->idc22."' class='form form-control'><br>";}
if($unico->idc23<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc23", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc23' value='".$unico->idc23."' class='form form-control'><br>";}
if($unico->idc24<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc24", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc24' value='".$unico->idc24."' class='form form-control'><br>";}
if($unico->idc25<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc25", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc25' value='".$unico->idc25."' class='form form-control'><br>";}
if($unico->idc26<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc26", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc26' value='".$unico->idc26."' class='form form-control'><br>";}
if($unico->idc27<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc27", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc27' value='".$unico->idc27."' class='form form-control'><br>";}

if($unico->idc28<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc28", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc28' value='".$unico->idc28."' class='form form-control'><br>";}
if($unico->idc29<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc29", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc29' value='".$unico->idc29."' class='form form-control'><br>";}
if($unico->idc30<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc30", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc30' value='".$unico->idc30."' class='form form-control'><br>";}
if($unico->idc31<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc31", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc31' value='".$unico->idc31."' class='form form-control'><br>";}
if($unico->idc32<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc32", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc32' value='".$unico->idc32."' class='form form-control'><br>";}
if($unico->idc33<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc33", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc33' value='".$unico->idc33."' class='form form-control'><br>";}
if($unico->idc34<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc34", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc34' value='".$unico->idc34."' class='form form-control'><br>";}
if($unico->idc35<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc35", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc35' value='".$unico->idc35."' class='form form-control'><br>";}
if($unico->idc36<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc36", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc36' value='".$unico->idc36."' class='form form-control'><br>";}
if($unico->idc37<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc37", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc37' value='".$unico->idc37."' class='form form-control'><br>";}
if($unico->idc38<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc38", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc38' value='".$unico->idc38."' class='form form-control'><br>";}
if($unico->idc39<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc39", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc39' value='".$unico->idc39."' class='form form-control'><br>";}
if($unico->idc40<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc40", $unico->id_form);
$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc40' value='".$unico->idc40."' class='form form-control'><br>";}

        if($unico->idc41<>""){ $NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc41", $unico->id_form);$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc41' value='".$unico->idc41."' class='form form-control'><br>";}
        if($unico->idc42<>""){ $NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc42", $unico->id_form);$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc42' value='".$unico->idc42."' class='form form-control'><br>";}
        if($unico->idc43<>""){ $NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc43", $unico->id_form);$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc43' value='".$unico->idc43."' class='form form-control'><br>";}
        if($unico->idc44<>""){ $NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc44", $unico->id_form);$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc44' value='".$unico->idc44."' class='form form-control'><br>";}
        if($unico->idc45<>""){ $NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc45", $unico->id_form);$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc45' value='".$unico->idc45."' class='form form-control'><br>";}
        if($unico->idc46<>""){ $NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc46", $unico->id_form);$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc46' value='".$unico->idc46."' class='form form-control'><br>";}
        if($unico->idc47<>""){ $NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc47", $unico->id_form);$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc47' value='".$unico->idc47."' class='form form-control'><br>";}

										$datos.="

										<input type='hidden' name='id' value=".$idcategoria.">
										<input type='hidden' name='id_form' value=".$id_form.">
										<input type='hidden' name='id_update' value=".$unico->id.">
										<input type='submit' value='editar' class='btn btn-link pull-right'>
										<input type='hidden' name='admin_edit' value='1'>

										</form>
										<br><br>
										<a href='?sw=beneficios_validacion&novigente=".$unico->id."'  onclick='return confirm(\"Esta seguro de eliminar este item?\")' class='btn btn-link pull-right'>eliminar</a>
										";

										$row = str_replace("{DATOS}",        ($datos),$row);

										$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

										if($unico->validacionok=='1'){
										        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
										}

										if($unico->validacionok=='3'){
										        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
										}


										$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

										if($unico->documentacionok=='1'){
										        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
										}

										if($unico->documentacionok=='3'){
										        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
										}





    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
    $botones_documentacionBK.='<br>
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	$botones_documentacion.='<br>
	<a 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a  
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	
	$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{ESTADO_FINAL}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }
                
                
                $form=dataFullForm_nombre($id_form);
                
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Beneficios",$html);

    $html = str_replace("{FORM}",($form),$html);

    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=beneficios" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);
$html = str_replace("{ID_FORM_DOWNLOAD}",    $id_form,$html);
    return($html);
}
function lista_beneficios_historicos($html,  $id_empresa, $idcategoria){
    $form1=lista_beneficios_historicos_data_form($id_empresa, "id_form1");
    //print_r($form1);
    //exit();
    foreach($form1 as $unico){
                    
					$row=file_get_contents("views/beneficios/row_beneficios_historicos.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 					$no_vistos=$unico->solicitudes-$unico->visto;
					 						//echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-warning'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-warning'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 				
					 	
					 	
					 }
					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);

                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_PROCESO}",          		$num_proceso,$row);
                    $row = str_replace("{CERRADAS}",          			$num_cerrados,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                      $row = str_replace("{ID_FORM}",                      ($unico->id_form1),$row);
                 
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
			}
			
    $form2=lista_beneficios_historicos_data_form($id_empresa, "id_form2");
    //print_r($form1);
    foreach($form2 as $unico){
                    
					$row=file_get_contents("views/beneficios/row_beneficios_historicos.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 					$no_vistos=$unico->solicitudes-$unico->visto;
					 						//echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 				
					 	
					 	
					 }
					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{ID_FORM}",                      ($unico->id_form2),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre_formulario),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);

                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_PROCESO}",          		$num_proceso,$row);
                    $row = str_replace("{CERRADAS}",          			$num_cerrados,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                    
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
			}			
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Beneficios Bch",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}

function lista_beneficios_validacion_historicos($html,  $id_empresa, $idcategoria, $id_form){
   $lista_becav=lista_beneficios_validacion_historicos_data($idcategoria, $id_empresa, $id_form);
   		//print_r($lista_becav);
			//echo "idcategoria $idcategoria";

    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
		
										//RFBeneficiosBecasVisto($unico->id);
		
                    $row=file_get_contents("views/beneficios/row_lista_beneficios_historicos.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
                    
                    $row = str_replace("{NOMBRE}",        ($unico->nombre),$row);
                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",        ($unico->division),$row);
                    $row = str_replace("{NOMBRE_FORMULARIO}",        ($unico->nombre_formulario),$row);
                    $row = str_replace("{FECHA}",        (fechaCastellano($unico->fecha)),$row);




                    $documentacion="";

                    if($unico->ficha_postulacion<>'')    	{$documentacion.='<a href="'.utf8_decode($unico->ficha_postulacion).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_notas<>'')    	{$documentacion.='<a href="'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->pago_arancel<>'')        	{$documentacion.='<a href="'.utf8_decode($unico->pago_arancel).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_carga<>'')    	{$documentacion.='<a href="'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->concentracion_notas<>'')   {$documentacion.='<a href="'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->licencia_edmedia<>'')    	{$documentacion.='<a href="'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->boletinpsu<>'')            {$documentacion.='<a href="'.utf8_decode($unico->boletinpsu).'" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_egreso<>'')    {$documentacion.='<a href="'.utf8_decode($unico->certificado_egreso).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_acredita<>'')	{$documentacion.='<a href="'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info" target="_blank">Documento</a><br><br>';}
                    if($unico->vivienda_foto_escritura<>'')		{$documentacion.='<a href="'.utf8_decode($unico->vivienda_foto_escritura).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_cedula<>'')				{$documentacion.='<a href="'.utf8_decode($unico->vivienda_cedula).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_residencia<>'')		{$documentacion.='<a href="'.utf8_decode($unico->vivienda_residencia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_matrimonio<>'')		{$documentacion.='<a href="'.utf8_decode($unico->vivienda_matrimonio).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    
                    
                    $verifica_archivo1=explode(".",$unico->archivo1);
                    $verifica_archivo2=explode(".",$unico->archivo2);
                    $verifica_archivo3=explode(".",$unico->archivo3);
                    $verifica_archivo4=explode(".",$unico->archivo4);
                    $verifica_archivo5=explode(".",$unico->archivo5);
                    
                    
                    
                    if($verifica_archivo1[1]<>'')							{$documentacion.='<a href="'.utf8_decode($unico->archivo1).'" target="_blank" class="btn btn-info" target="_blank">Documento 1</a><br><br>';}
                    if($verifica_archivo2[1]<>'')							{$documentacion.='<a href="'.utf8_decode($unico->archivo2).'" target="_blank" class="btn btn-info" target="_blank">Documento 2</a><br><br>';}
                    if($verifica_archivo3[1]<>'')							{$documentacion.='<a href="'.utf8_decode($unico->archivo3).'" target="_blank" class="btn btn-info" target="_blank">Documento 3</a><br><br>';}
                    if($verifica_archivo4[1]<>'')							{$documentacion.='<a href="'.utf8_decode($unico->archivo4).'" target="_blank" class="btn btn-info" target="_blank">Documento 4</a><br><br>';}
                    if($verifica_archivo5[1]<>'')							{$documentacion.='<a href="'.utf8_decode($unico->archivo5).'" target="_blank" class="btn btn-info" target="_blank">Documento 5</a><br><br>';}
										
										//tipo worfklow
										$bloque_validacion_="";

								

										$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);

										$id_enc=Encodear3($unico->id);
										$botones_documentacion='';

										$botones_validacion='';
										//echo $botones_documentacion;

										$tipo="";
										if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

										$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
										$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

										$fecha_inicio    =$unico->fecha_inicio;
										$fecha_termino   =$unico->fecha_termino;
										$dia1            =$unico->dia;
										$dia2            =$unico->dia2;
										$fecha_nacimiento=$unico->fecha_nac;
										$anexo           =$unico->anexo;
										$celular         =$unico->num_celular;
										$cargo           =$unico->cargo;
										$mundo           =$unico->mundo;

										$datos="";

$datos.="<form action='?sw=beneficios_validacion' method='post' name='".$unico->id."' id='".$unico->id."'>";

										if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form);
											
											$datos.="<strong> ".$NombreCampo."</strong><br>
											<input type='text' name='idc01' value='".$unico->idc01."' class='form form-control'>";}
												
										if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc02' value='".$unico->idc02."' class='form form-control'>";}

										if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc03' value='".$unico->idc03."' class='form form-control'>";}

										if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc04' value='".$unico->idc04."' class='form form-control'>";}

										if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc05' value='".$unico->idc05."' class='form form-control'>";}

										if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc06' value='".$unico->idc06."' class='form form-control'>";}

										if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc07' value='".$unico->idc07."' class='form form-control'>";}

										if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc08' value='".$unico->idc08."' class='form form-control'>";}

										if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc09' value='".$unico->idc09."' class='form form-control'>";}

										if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc10' value='".$unico->idc10."' class='form form-control'>";}

										if($unico->idc11<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc11", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc11' value='".$unico->idc11."' class='form form-control'>";}

										if($unico->idc12<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc12", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc12' value='".$unico->idc12."' class='form form-control'>";}

										if($unico->idc13<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc13", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc13' value='".$unico->idc13."' class='form form-control'>";}

										if($unico->idc14<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc14", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc14' value='".$unico->idc14."' class='form form-control'>";}

										if($unico->idc15<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc15", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc15' value='".$unico->idc15."' class='form form-control'>";}

										if($unico->idc16<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc16", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc16' value='".$unico->idc16."' class='form form-control'>";}

										if($unico->idc17<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc17", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc17' value='".$unico->idc17."' class='form form-control'>";}

										if($unico->idc18<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc18", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc18' value='".$unico->idc18."' class='form form-control'>";}

										if($unico->idc19<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc19", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc19' value='".$unico->idc19."' class='form form-control'>";}

										if($unico->idc20<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc20", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc20' value='".$unico->idc20."' class='form form-control'>";}

										if($unico->idc21<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc21", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc21' value='".$unico->idc21."' class='form form-control'>";}


										$datos.="



										
										<br><br>
										
										";

										$row = str_replace("{DATOS}",        ($datos),$row);

										$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

										if($unico->validacionok=='1'){
										        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
										}

										if($unico->validacionok=='3'){
										        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
										}


										$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

										if($unico->documentacionok=='1'){
										        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
										}

										if($unico->documentacionok=='3'){
										        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
										}





    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
    $botones_documentacionBK.='<br>
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	$botones_documentacion.='<br>
	<a 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a  
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	
	$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{ESTADO_FINAL}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }
                
                
                $form=dataFullForm_nombre($id_form);
                
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Beneficios",$html);

    $html = str_replace("{FORM}",($form),$html);

    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=beneficios" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);
$html = str_replace("{ID_FORM_DOWNLOAD}",    $id_form,$html);
    return($html);
}
function lista_beneficios_agendamiento($html,  $id_empresa, $idcategoria){
   $lista_becav=lista_beneficios_agendamiento_data($idcategoria, $id_empresa);
    //print_r($lista_becav);
    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
	
					
					
                    $row=file_get_contents("views/beneficios/row_lista_beneficios_agendamiento.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    
                    $row = str_replace("{RUT}",    ($unico->ocupada),$row);
                    $row = str_replace("{NOMBRE}",        ($unico->nombre_completo),$row);
                    

                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",        ($unico->division),$row);
                    
                    $row = str_replace("{Fecha}",        (fechaCastellano($unico->fecha_inicio))."<br>".$unico->fecha_inicio,$row);
                    $row = str_replace("{Hora}",        ($unico->hora_inicio),$row);
                    
                    $row = str_replace("{Modalidad}",        ($unico->modalidad),$row);
                   
                    $Evento=Beneficios_Agenda_2020_VistaEvento($unico->id_evento);
 					if($Evento[0]->agenda=="Show Room Vestuario Corporativo"){continue;}

                    $row = str_replace("{Agenda}",        			($Evento[0]->agenda),$row);
                    
                    
                    
                    $row = str_replace("{Especialista}",        ($Evento[0]->especialista),$row);

                    


//tipo worfklow
$bloque_validacion_="";
if($unico->tipo_workflow=="1003"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="Rechazado_edicion"){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion1=="Rechazado"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>";				}
else {
						$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
}

						if($unico->validacion2=="Validado"){							$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion2=="Rechazado_edicion"){	$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion2=="Rechazado"){					$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
else {
						$bloque_validacion_2="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion2' class='form form-control'>
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
			}
						$bloque_validacion_=$bloque_validacion_1."<br>".$bloque_validacion_2;

}



if($unico->tipo_workflow=="1004"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="Rechazado_edicion"){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion1=="Rechazado"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {						
						
												$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
  				} 				
  				
  				
  				
  					if($unico->validacion2=="Validado"){		$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion2=="Rechazado_edicion"){	$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion2=="Rechazado"){					$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {			
						$bloque_validacion_2="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion2' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
						} 
						
  					if($unico->validacion3=="Ganador"){		$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Ganador</div>";				}
						elseif($unico->validacion3=="Rechazado_edicion"){	$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>No Ganador</div>";				}
						elseif($unico->validacion3=="No Ganador"){					$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>No Ganador</div>";				}
						else {								
						$bloque_validacion_3="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠳 Ganador</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Ganador'>Ganador</option>
										<option value='No_Ganador'>No_Ganador</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion3' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
						$bloque_validacion_=$bloque_validacion_1."<br>".$bloque_validacion_2."<br>".$bloque_validacion_3;
}


if($unico->tipo_workflow=="1005"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="Rechazado_edicion"){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion1=="Rechazado"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {							
												$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
					
						if($unico->validacion2=="Validado"){							$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion2=="Rechazado_edicion"){	$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion2=="Rechazado"){					$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {						
					
						$bloque_validacion_2="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion2' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
					
						if($unico->validacion3=="Validado"){							$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠳 Administrador</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion3=="Rechazado_edicion"){	$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠳 Administrador</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion3=="Rechazado"){					$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠳 Administrador</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {						
						$bloque_validacion_3="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion3' class='form form-control'>
								
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
					
					
								if($unico->validacion4=="Validado"){							$bloque_validacion_4="<label style='padding-left: 15px;'><strong>Validaci󮠴 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion4=="Rechazado_edicion"){	$bloque_validacion_4="<label style='padding-left: 15px;'><strong>Validaci󮠴 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion4=="Rechazado"){					$bloque_validacion_4="<label style='padding-left: 15px;'><strong>Validaci󮠴 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {			
						$bloque_validacion_4="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion4' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
						}
						$bloque_validacion_=$bloque_validacion_1."<br>".$bloque_validacion_2."<br>".$bloque_validacion_3."<br>".$bloque_validacion_4;			
}


$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);



$id_enc=Encodear3($unico->id);
$botones_documentacion='';

$botones_validacion='';
//echo $botones_documentacion;

$tipo="";
if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

$fecha_inicio    =$unico->fecha_inicio;
$fecha_termino   =$unico->fecha_termino;
$dia1            =$unico->dia;
$dia2            =$unico->dia2;
$fecha_nacimiento=$unico->fecha_nac;
$anexo           =$unico->anexo;
$celular         =$unico->num_celular;
$cargo           =$unico->cargo;
$mundo           =$unico->mundo;
$datos="";


// POR CADA CAMPO CON RESPUESTA VOY CREANDO LISTA


if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc01)."<br>";}

if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc02)."<br>";}

if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc03)."<br>";}

if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc04)."<br>";}

if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc05)."<br>";}

if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc06)."<br>";}

if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc07)."<br>";}

if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc08)."<br>";}

if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc09)."<br>";}

if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc10)."<br>";}



                    $row = str_replace("{DATOS}",        ($datos),$row);

$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->validacionok=='1'){
        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->validacionok=='3'){
        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}


$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->documentacionok=='1'){
        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->documentacionok=='3'){
        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}





    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
    $botones_documentacionBK.='<br>
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	$botones_documentacion.='<br>
	<a 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a  
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	
	$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{DOCUMENTACION_OK}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Beneficios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=beneficios" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);

    return($html); 
}

function lista_beneficios_fichas_sociales($html,  $id_empresa, $idcategoria){
    $form1=lista_beneficios_data_fichas_sociales_form($id_empresa, "id_form1");
   // print_r($form1);
   // exit();
    
    
    foreach($form1 as $unico){
                    
					$row=file_get_contents("views/beneficios/row_beneficios_ficha_social.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 					$no_vistos=$unico->solicitudes-$unico->visto;
					 						//echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-warning'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-warning'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 				
					 	
					 	
					 }
					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{ID_FORM_FICHA}",           ($unico->id),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);

                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_PROCESO}",          		$num_proceso,$row);
                    $row = str_replace("{CERRADAS}",          			$num_cerrados,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                      $row = str_replace("{ID_FORM}",                      ($unico->id_form1),$row);
                 
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
			}
			
	
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Beneficios Bch",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_beneficios_validacion_ficha_social($html,  $id_empresa, $idcategoria, $id_form){
   $lista_becav=lista_beneficios_validacion_ficha_social_data($idcategoria, $id_empresa, $id_form);
   			//print_r($lista_becav);
			//echo "idcategoria $idcategoria";

    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
		
										//RFBeneficiosBecasVisto($unico->id);
		
                    $row=file_get_contents("views/beneficios/row_lista_beneficios_ficha_social.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{ID_FORM}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
                    
                    $row = str_replace("{NOMBRE}",        ($unico->nombre),$row);
                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",        ($unico->division),$row);
                    $row = str_replace("{NOMBRE_FORMULARIO}",        ($unico->nombre_formulario),$row);
                    $row = str_replace("{FECHA}",        (fechaCastellano($unico->fecha)),$row);




                    $documentacion="";

                    if($unico->ficha_postulacion<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->ficha_postulacion).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_notas<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->pago_arancel<>'')        	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->pago_arancel).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_carga<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->concentracion_notas<>'')   {$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->licencia_edmedia<>'')    	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->boletinpsu<>'')            {$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->boletinpsu).'" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_egreso<>'')    {$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_egreso).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_acredita<>'')	{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info" target="_blank">Documento</a><br><br>';}
                    if($unico->vivienda_foto_escritura<>'')		{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_foto_escritura).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_cedula<>'')				{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_cedula).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_residencia<>'')		{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_residencia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_matrimonio<>'')		{$documentacion.='<a href="../beneficios/front/'.utf8_decode($unico->vivienda_matrimonio).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    
                    
                    $verifica_archivo1=explode(".",$unico->archivo1);
                    $verifica_archivo2=explode(".",$unico->archivo2);
                    $verifica_archivo3=explode(".",$unico->archivo3);
                    $verifica_archivo4=explode(".",$unico->archivo4);
                    $verifica_archivo5=explode(".",$unico->archivo5);
                    
                    
                    
                    if($verifica_archivo1[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo1).'" target="_blank" class="btn btn-info" target="_blank">Documento 1</a><br><br>';}
                    if($verifica_archivo2[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo2).'" target="_blank" class="btn btn-info" target="_blank">Documento 2</a><br><br>';}
                    if($verifica_archivo3[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo3).'" target="_blank" class="btn btn-info" target="_blank">Documento 3</a><br><br>';}
                    if($verifica_archivo4[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo4).'" target="_blank" class="btn btn-info" target="_blank">Documento 4</a><br><br>';}
                    if($verifica_archivo5[1]<>'')							{$documentacion.='<a href="../beneficios/front/docs/'.utf8_decode($unico->archivo5).'" target="_blank" class="btn btn-info" target="_blank">Documento 5</a><br><br>';}
										
									

										$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);

										$id_enc=Encodear3($unico->id);
										$botones_documentacion='';

										$botones_validacion='';
										//echo $botones_documentacion;

										$tipo="";
										if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

										$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
										$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

										$fecha_inicio    =$unico->fecha_inicio;
										$fecha_termino   =$unico->fecha_termino;
										$dia1            =$unico->dia;
										$dia2            =$unico->dia2;
										$fecha_nacimiento=$unico->fecha_nac;
										$anexo           =$unico->anexo;
										$celular         =$unico->num_celular;
										$cargo           =$unico->cargo;
										$mundo           =$unico->mundo;

										$datos="";

										$datos.="<form action='?sw=beneficios_validacion' method='post' name='".$unico->id."' id='".$unico->id."'>";

										if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form);
											
											$datos.="<strong> ".$NombreCampo."</strong><br>
											<input type='text' name='idc01' value='".$unico->idc01."' class='form form-control'>";}
												
										if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc02' value='".$unico->idc02."' class='form form-control'>";}

										if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc03' value='".$unico->idc03."' class='form form-control'>";}

										if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc04' value='".$unico->idc04."' class='form form-control'>";}

										if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc05' value='".$unico->idc05."' class='form form-control'>";}

										if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc06' value='".$unico->idc06."' class='form form-control'>";}

										if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc07' value='".$unico->idc07."' class='form form-control'>";}

										if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc08' value='".$unico->idc08."' class='form form-control'>";}

										if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc09' value='".$unico->idc09."' class='form form-control'>";}

										if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc10' value='".$unico->idc10."' class='form form-control'>";}

										if($unico->idc11<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc11", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc11' value='".$unico->idc11."' class='form form-control'>";}

										if($unico->idc12<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc12", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc12' value='".$unico->idc12."' class='form form-control'>";}

										if($unico->idc13<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc13", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc13' value='".$unico->idc13."' class='form form-control'>";}

										if($unico->idc14<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc14", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc14' value='".$unico->idc14."' class='form form-control'>";}

										if($unico->idc15<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc15", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc15' value='".$unico->idc15."' class='form form-control'>";}

										if($unico->idc16<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc16", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc16' value='".$unico->idc16."' class='form form-control'>";}

										if($unico->idc17<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc17", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc17' value='".$unico->idc17."' class='form form-control'>";}

										if($unico->idc18<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc18", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc18' value='".$unico->idc18."' class='form form-control'>";}

										if($unico->idc19<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc19", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc19' value='".$unico->idc19."' class='form form-control'>";}

										if($unico->idc20<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc20", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc20' value='".$unico->idc20."' class='form form-control'>";}

										if($unico->idc21<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc21", $unico->id_form);
											$datos.="<strong> ".$NombreCampo."</strong><br><input type='text' name='idc21' value='".$unico->idc21."' class='form form-control'>";}


										$datos.="

										<input type='hidden' name='id' value=".$idcategoria.">
										<input type='hidden' name='id_form' value=".$unico->id.">
										<input type='hidden' name='id_update' value=".$unico->id.">
										<input type='submit' value='editar' class='btn btn-link pull-right'>
										<input type='hidden' name='admin_edit' value='1'>

										</form>
										<br><br>
										<a href='?sw=beneficios_validacion&novigente=".$unico->id."'  onclick='return confirm(\"Esta seguro de eliminar este item?\")' class='btn btn-link pull-right'>eliminar</a>
										";

										$row = str_replace("{DATOS}",        ($datos),$row);

										$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

										if($unico->validacionok=='1'){
										        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
										}

										if($unico->validacionok=='3'){
										        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
										}


										$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

										if($unico->documentacionok=='1'){
										        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
										}

										if($unico->documentacionok=='3'){
										        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
										}





								    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
								    $botones_documentacionBK.='<br>
									<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
									class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
									
									<br><br>
									
									<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
									class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
									';
									
									
									$botones_documentacion.='<br>
									<a 
									class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
									
									<br><br>
									
									<a  
									class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
									';
									
									
									
									$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{ESTADO_FINAL}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }
                
                
    $form=dataFullForm_nombre($id_form);
                
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Ficha",$html);

    $html = str_replace("{FORM}",($form),$html);

    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=beneficios" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);
    $html = str_replace("{ID_FORM_DOWNLOAD}",    $id_form,$html);
    return($html); 
}
function beneficios_agendamiento_v2($html,  $id_empresa, $idcategoria){
   $lista_becav=lista_beneficios_agendamiento_v2_data($idcategoria, $id_empresa);
    //print_r($lista_becav);
    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
	
					
					
                    $row=file_get_contents("views/beneficios/row_lista_beneficios_agendamiento.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    
                    $row = str_replace("{RUT}",    ($unico->ocupada),$row);
                    $row = str_replace("{NOMBRE}",        ($unico->nombre_completo),$row);
                    

                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",        ($unico->division),$row);
                    
                    $row = str_replace("{Fecha}",        (fechaCastellano($unico->fecha_inicio)),$row);
                    $row = str_replace("{Hora}",        ($unico->hora_inicio),$row);
                    
                    $row = str_replace("{Modalidad}",        ($unico->modalidad),$row);
                   
                    $Evento=Beneficios_Agenda_2020_VistaEvento($unico->id_evento);
 										if($Evento[0]->agenda<>"Show Room Vestuario Corporativo"){continue;}

                    $row = str_replace("{Agenda}",        			($Evento[0]->agenda),$row);
                    
                    
                    
                    $row = str_replace("{Especialista}",        ($Evento[0]->especialista),$row);

                    


//tipo worfklow
$bloque_validacion_="";
if($unico->tipo_workflow=="1003"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="Rechazado_edicion"){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion1=="Rechazado"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>";				}
else {
						$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
}

						if($unico->validacion2=="Validado"){							$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion2=="Rechazado_edicion"){	$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion2=="Rechazado"){					$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
else {
						$bloque_validacion_2="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion2' class='form form-control'>
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
			}
						$bloque_validacion_=$bloque_validacion_1."<br>".$bloque_validacion_2;

}



if($unico->tipo_workflow=="1004"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="Rechazado_edicion"){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion1=="Rechazado"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {						
						
												$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
  				} 				
  				
  				
  				
  					if($unico->validacion2=="Validado"){		$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion2=="Rechazado_edicion"){	$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion2=="Rechazado"){					$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {			
						$bloque_validacion_2="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion2' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
						} 
						
  					if($unico->validacion3=="Ganador"){		$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Ganador</div>";				}
						elseif($unico->validacion3=="Rechazado_edicion"){	$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>No Ganador</div>";				}
						elseif($unico->validacion3=="No Ganador"){					$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>No Ganador</div>";				}
						else {								
						$bloque_validacion_3="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠳 Ganador</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Ganador'>Ganador</option>
										<option value='No_Ganador'>No_Ganador</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion3' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
						$bloque_validacion_=$bloque_validacion_1."<br>".$bloque_validacion_2."<br>".$bloque_validacion_3;
}


if($unico->tipo_workflow=="1005"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="Rechazado_edicion"){	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion1=="Rechazado"){					$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {							
												$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
					
						if($unico->validacion2=="Validado"){							$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion2=="Rechazado_edicion"){	$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion2=="Rechazado"){					$bloque_validacion_2="<label style='padding-left: 15px;'><strong>Validaci󮠲 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {						
					
						$bloque_validacion_2="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion2' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
					
						if($unico->validacion3=="Validado"){							$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠳 Administrador</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion3=="Rechazado_edicion"){	$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠳 Administrador</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion3=="Rechazado"){					$bloque_validacion_3="<label style='padding-left: 15px;'><strong>Validaci󮠳 Administrador</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {						
						$bloque_validacion_3="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
							<label>Validaci󮠱 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='Rechazado_edicion'>Rechazado para Editar</option>
									<option value='Rechazado'>Rechazar Definitivamente</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion3' class='form form-control'>
								
								<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
					}
					
					
								if($unico->validacion4=="Validado"){							$bloque_validacion_4="<label style='padding-left: 15px;'><strong>Validaci󮠴 Especialista</strong></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion4=="Rechazado_edicion"){	$bloque_validacion_4="<label style='padding-left: 15px;'><strong>Validaci󮠴 Especialista</strong></label><div class='alert alert-warning'>Rechazo para Editar</div>";				}
						elseif($unico->validacion4=="Rechazado"){					$bloque_validacion_4="<label style='padding-left: 15px;'><strong>Validaci󮠴 Especialista</strong></label><div class='alert alert-danger'>Rechazado</div>";				}
						else {			
						$bloque_validacion_4="
						<div class='alert alert-warning'>
							<form action='?sw=beneficios_validacion' method='post' name=''>
								<label>Validaci󮠲 Especialista</label><br>
									<select name='validacion' class='form form-control'>
										<option value=''></option>
										<option value='Validado'>Validar</option>
										<option value='Rechazado_edicion'>Rechazado para Editar</option>
										<option value='Rechazado'>Rechazar Definitivamente</option>
									</select>	<br>
								<label>Comentarios</label><br>
									<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								
								<input type='hidden' name='val' value='validacion4' class='form form-control'>
									
									<input type='submit' class='btn btn-info' value='Guardar Validaci󮧾
							</form>	
						</div>";
						}
						$bloque_validacion_=$bloque_validacion_1."<br>".$bloque_validacion_2."<br>".$bloque_validacion_3."<br>".$bloque_validacion_4;			
}


$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);



$id_enc=Encodear3($unico->id);
$botones_documentacion='';

$botones_validacion='';
//echo $botones_documentacion;

$tipo="";
if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

$fecha_inicio    =$unico->fecha_inicio;
$fecha_termino   =$unico->fecha_termino;
$dia1            =$unico->dia;
$dia2            =$unico->dia2;
$fecha_nacimiento=$unico->fecha_nac;
$anexo           =$unico->anexo;
$celular         =$unico->num_celular;
$cargo           =$unico->cargo;
$mundo           =$unico->mundo;
$datos="";


// POR CADA CAMPO CON RESPUESTA VOY CREANDO LISTA


if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc01)."<br>";}

if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc02)."<br>";}

if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc03)."<br>";}

if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc04)."<br>";}

if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc05)."<br>";}

if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc06)."<br>";}

if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc07)."<br>";}

if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc08)."<br>";}

if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc09)."<br>";}

if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc10)."<br>";}



                    $row = str_replace("{DATOS}",        ($datos),$row);

$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->validacionok=='1'){
        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->validacionok=='3'){
        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}


$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->documentacionok=='1'){
        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->documentacionok=='3'){
        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}





    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
    $botones_documentacionBK.='<br>
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	$botones_documentacion.='<br>
	<a 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a  
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	
	$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{DOCUMENTACION_OK}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Beneficios",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=beneficios" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);

    return($html);
}
function lista_solicitudes_uniformes($html,  $id_empresa, $segmento, $post){
    $lista=lista_solicitudes_uniformes_data($id_empresa,$_SESSION["seg"], $post);
    foreach($lista as $unico){

					$row=file_get_contents("views/uniformes/row_beneficios.html");
          $tipo=""; 
          
          if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
          
          	$Usu						= TraeDatosUsuario($unico->rut);	
          
           	$no_vistos=$unico->solicitudes-$unico->visto;
					 
						 if($no_vistos>0){
							 if($no_vistos==1){
							 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevo</span>";
							 } else {
								 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevos</span>"; 
							 }
						 } else {
							 $nuevo="";
						 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Uniformes_BarridoSolicitudes($unico->rut, $id_empresa);
					 
					 $num_pendientes=0; $num_enconfeccion=0; $num_despachados=0; $num_prendas=0;
					 
					 foreach ($array_solicitudes as $unico_sol){
					 				
					 				if($unico_sol->estado=="Pendiente" or $unico_sol->estado=="" ){
					 					$num_pendientes++;
					 				}
					 				if($unico_sol->estado=="En Confeccion"){
					 					$num_enconfeccion++;
					 				}
					 				if($unico_sol->estado=="Despachado"){
					 					$num_despachados++;
					 				}
					 				if($unico_sol->estado=="Recibida Disconforme"){
					 					$num_recibida_disconforme++;
					 				}
					 				if($unico_sol->estado=="Recibida Conforme"){
					 					$num_recibida_conforme++;
					 				}					 				

					 				$num_prendas++;
					 	
					 	
					 }
					 
					 $nombre_persona=$Usu[0]->rut." ".$Usu[0]->nombre_completo."
					 <br>Cui: ".$Usu[0]->local.", Direcci󮺠".$Usu[0]->ubicacion."
					 <br>Anexo: ".$Usu[0]->anexo.", ".$Usu[0]->email;
					 
                    $row = str_replace("{ID}",                      ($unico->rut),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($nombre_persona),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);


                    $row = str_replace("{NUM_PRENDAS}",          		$num_prendas,$row);
                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_CONFECCION}",          	$num_enconfeccion,$row);
                    $row = str_replace("{DESPACHADAS}",          		$num_despachados,$row);

                    $row = str_replace("{DISCONFORME}",          		$num_recibida_disconforme,$row);
                    $row = str_replace("{CONFORME}",          			$num_recibida_conforme,$row);


                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                    
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Solicitudes Vestuario Corporativo ".$_SESSION["seg"],$html);
    
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_solicitudes_uniformes_validacion($html,  $id_empresa, $rut_col){
   $lista_becav=lista_uniformes_validacion_data($rut_col, $id_empresa);
   //print_r($lista_becav);

	$Usu						= TraeDatosUsuario($rut_col);	

//echo "idcategoria $idcategoria";

    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
		
										//RFBeneficiosBecasVisto($unico->id);
		
                    $row=file_get_contents("views/uniformes/row_lista_beneficios.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
                    
                    if($unico->maternal=="1"){
                    	$maternal="<span class='badge badge-info' style='color:#fff'>Prenda maternal</span>";
                    } else {
                    	$maternal="";
                    }
                    
                    $row = str_replace("{NOMBRE_PRENDA}",   ($unico->prenda),$row);
                    $row = str_replace("{SEGMENTO}",        ($unico->segmento_prenda),$row);
                    $row = str_replace("{TEMPORADA}",       ($unico->temporada_prenda),$row);
                    $row = str_replace("{MATERNAL}",        ($maternal),$row);
                    
                    $row = str_replace("{TALLA}",       ($unico->talla),$row);

                    
                    $row = str_replace("{NOMBRE}",        ($unico->nombre),$row);
                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",        ($unico->division),$row);
                    if($unico->estado<>""){
                    	$estado=$unico->estado;
                    } else {
                    	$estado="Pendiente";
                    }
                    $row = str_replace("{ESTADO_PRENDA}",        ($estado),$row);

                   
                    
                    $row = str_replace("{FECHA}",        (fechaCastellano($unico->fecha)),$row);
                    $documentacion="";
                    if($unico->ficha_postulacion<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->ficha_postulacion).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_notas<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->pago_arancel<>'')        {$documentacion.='<a href="../front/'.utf8_decode($unico->pago_arancel).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_carga<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->concentracion_notas<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->licencia_edmedia<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->boletinpsu<>'')            {$documentacion.='<a href="../front/'.utf8_decode($unico->boletinpsu).'" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_egreso<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_egreso).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_acredita<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info" target="_blank">Documento</a><br><br>';}

                    if($unico->vivienda_foto_escritura<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_foto_escritura).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_cedula<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_cedula).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_residencia<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_residencia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_matrimonio<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_matrimonio).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}


//tipo worfklow
$bloque_validacion_="";
if($unico->tipo_workflow=="1003"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="En_Espera")				{	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>En Espera</div>
							
							
<div class='alert alert-warning'>
							<form action='?sw=chileactivo_validacion' method='post' name=''>
							<label>Validacion 1 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='En_Espera'>En Espera</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								<input type='submit' class='btn btn-info' value='Guardar'>
							</form>	
						</div>							
							
							";				}						
						else {
						$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=chileactivo_validacion' method='post' name=''>
							<label>Validacion 1 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='En_Espera'>En Espera</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								<input type='submit' class='btn btn-info' value='Guardar'>
							</form>	
						</div>";
						}

						$bloque_validacion_=$bloque_validacion_1;

}




$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);



$id_enc=Encodear3($unico->id);
$botones_documentacion='';

$botones_validacion='';
//echo $botones_documentacion;

$tipo="";
if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

$fecha_inicio    =$unico->fecha_inicio;
$fecha_termino   =$unico->fecha_termino;
$dia1            =$unico->dia;
$dia2            =$unico->dia2;
$fecha_nacimiento=$unico->fecha_nac;
$anexo           =$unico->anexo;
$celular         =$unico->num_celular;
$cargo           =$unico->cargo;
$mundo           =$unico->mundo;
$datos="";


// POR CADA CAMPO CON RESPUESTA VOY CREANDO LISTA


if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc01)."<br>";}

if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc02)."<br>";}

if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc03)."<br>";}

if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc04)."<br>";}

if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc05)."<br>";}

if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc06)."<br>";}

if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc07)."<br>";}

if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc08)."<br>";}

if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc09)."<br>";}

if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc10)."<br>";}



                    $row = str_replace("{DATOS}",        ($datos),$row);

$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->validacionok=='1'){
        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->validacionok=='3'){
        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}


$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->documentacionok=='1'){
        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->documentacionok=='3'){
        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}





    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
    $botones_documentacionBK.='<br>
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	$botones_documentacion.='<br>
	<a 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a  
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	
	$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{DOCUMENTACION_OK}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }

    $html = str_replace("{rut_col}",$rut_col,$html);

    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Solicitudes Vestuario Corporativo ".$_SESSION["seg"],$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=uniformes_solicitudes" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);

    return($html);
}
function lista_solicitudes_chileactivo($html,  $id_empresa, $idcategoria){
    $lista=lista_solicitudes_chileactivo_data($id_empresa);
    //print_r($emb_olas);
    foreach($lista as $unico){
                    
					$row=file_get_contents("views/chileactivo/row_beneficios.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 $no_vistos=$unico->solicitudes-$unico->visto;
					 //echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 				
					 	
					 	
					 }
					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);

                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_PROCESO}",          		$num_proceso,$row);
                    $row = str_replace("{CERRADAS}",          			$num_cerrados,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                    
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Solicitudes ChileActivo",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_solicitudes_chileactivo_validacion($html,  $id_empresa, $idcategoria){
   $lista_becav=lista_chileactivo_validacion_data($idcategoria, $id_empresa);

    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
		
					RFBeneficiosBecasVisto($unico->id);
                    $row=file_get_contents("views/chileactivo/row_lista_beneficios.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
										$CelEmailPart=BuscaDatosUsuarioCelEmailAdmin($unico->rut);
                    $row = str_replace("{NOMBRE}",       ($unico->nombre),$row);
                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",     ($unico->division),$row);
                    $row = str_replace("{FECHA}",        (fechaCastellano($unico->fecha)),$row);
                    $documentacion="";
                    if($unico->ficha_postulacion<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->ficha_postulacion).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_notas<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->pago_arancel<>'')        {$documentacion.='<a href="../front/'.utf8_decode($unico->pago_arancel).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_carga<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->concentracion_notas<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->licencia_edmedia<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->boletinpsu<>'')            {$documentacion.='<a href="../front/'.utf8_decode($unico->boletinpsu).'" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_egreso<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_egreso).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_acredita<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info" target="_blank">Documento</a><br><br>';}

                    if($unico->vivienda_foto_escritura<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_foto_escritura).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_cedula<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_cedula).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_residencia<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_residencia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_matrimonio<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_matrimonio).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}


//tipo worfklow
$bloque_validacion_="";
if($unico->tipo_workflow=="1003"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="En_Espera")				{	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>En Espera</div>
							
							
<div class='alert alert-warning'>
							<form action='?sw=chileactivo_validacion' method='post' name=''>
							<label>Validacion 1 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='En_Espera'>En Espera</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								<input type='submit' class='btn btn-info' value='Guardar'>
							</form>	
						</div>							
							
							";				}						
						else {
						$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=chileactivo_validacion' method='post' name=''>
							<label>Validacion 1 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='En_Espera'>En Espera</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								<input type='submit' class='btn btn-info' value='Guardar'>
							</form>	
						</div>";
						}

						$bloque_validacion_=$bloque_validacion_1;

}




$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);



$id_enc=Encodear3($unico->id);
$botones_documentacion='';

$botones_validacion='';
//echo $botones_documentacion;

$tipo="";
if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

$fecha_inicio    =$unico->fecha_inicio;
$fecha_termino   =$unico->fecha_termino;
$dia1            =$unico->dia;
$dia2            =$unico->dia2;
$fecha_nacimiento=$unico->fecha_nac;
$anexo           =$unico->anexo;
$celular         =$unico->num_celular;
$cargo           =$unico->cargo;
$mundo           =$unico->mundo;
$datos="";


// POR CADA CAMPO CON RESPUESTA VOY CREANDO LISTA


if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc01)."<br>";}

if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc02)."<br>";}

if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc03)."<br>";}

if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc04)."<br>";}

if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc05)."<br>";}

if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc06)."<br>";}

if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc07)."<br>";}

if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc08)."<br>";}

if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc09)."<br>";}

if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc10)."<br>";}

if($unico->archivo1<>""){	
	$datos.="<strong>Boleta Gastos</strong>: <a href='https://www.masconectadosbch.cl/chileactivo/front/docs/".$unico->archivo1."' class='btn btn-link' target='_blank'>Ver Documento</a><br>";}
        if($unico->archivo2<>""){
            $datos.="<strong>Boleta Gastos 2</strong>: <a href='https://www.masconectadosbch.cl/chileactivo/front/docs/".$unico->archivo1."' class='btn btn-link' target='_blank'>Ver Documento</a><br>";}
        if($unico->archivo3<>""){
            $datos.="<strong>Boleta Gastos 3</strong>: <a href='https://www.masconectadosbch.cl/chileactivo/front/docs/".$unico->archivo1."' class='btn btn-link' target='_blank'>Ver Documento</a><br>";}


                    $row = str_replace("{DATOS}",        ($datos),$row);

$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->validacionok=='1'){
        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->validacionok=='3'){
        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}


$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->documentacionok=='1'){
        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->documentacionok=='3'){
        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}





    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
    $botones_documentacionBK.='<br>
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	$botones_documentacion.='<br>
	<a 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a  
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	
	$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{DOCUMENTACION_OK}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }
        $html = str_replace("{LISTA}",$total_html,$html);
        $html = str_replace("{TITULO}","Solicitudes Chileactivo",$html);
        $html = str_replace("{BTN}","Nueva Pregunta",$html);
        $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
        $html = str_replace("{BTN_VOLVER}",'<a href="?sw=chileactivo_solicitudes" class="btn btn-info">< Volver</a>',$html);
        $html = str_replace("{COLUMNA}",'Pregunta',$html);
        $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);
        $html = str_replace("{ID_BENEFICIO_ENC}",    Encodear3($idcategoria),$html);

    return($html);
}
function lista_solicitudes_chileactivo_v2($html,  $id_empresa, $idcategoria){
    $lista=lista_solicitudes_chileactivo_data_v2($id_empresa);
    //print_r($emb_olas);
    foreach($lista as $unico){
                    
					$row=file_get_contents("views/chileactivo/row_beneficios.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 $no_vistos=$unico->solicitudes-$unico->visto;
					 //echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 				
					 	
					 	
					 }
					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);

                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_PROCESO}",          		$num_proceso,$row);
                    $row = str_replace("{CERRADAS}",          			$num_cerrados,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                    
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Solicitudes Talleres Online",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html); 
}
function lista_solicitudes_chileactivo_inscripcion_validacion($html,  $id_empresa, $idcategoria){
   $lista_becav=lista_chileactivo_inscripcion_validacion_data($idcategoria, $id_empresa);
		//print_r($lista_becav);
   

//echo "idcategoria $idcategoria";

    foreach($lista_becav as $unico){
        //echo "<br>ho<br>";
        //print_r($unico);
		
										//RFBeneficiosBecasVisto($unico->id);
		
                    $row=file_get_contents("views/chileactivo/row_lista_inscripciones.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);


	$Usu						= TraeDatosUsuario($unico->rut);	                    
                    $row = str_replace("{NOMBRE}",        ($Usu[0]->nombre_completo),$row);
                    $row = str_replace("{CARGO}",       	($Usu[0]->cargo),$row);
                    $row = str_replace("{EMAIL}",        	($Usu[0]->email),$row);
                    $row = str_replace("{DIVISION}",      ($Usu[0]->division),$row);
                    
                    $row = str_replace("{ACCION}",        ($unico->tipo),$row);
                   $boton_doc="<a href='https://www.masconectadosbch.cl/chileactivo/front/docs/".$unico->documento."' target='_blank' class='' >Ver Documento</a>";
                    $row = str_replace("{DOCUMENTO}",        ($boton_doc),$row);
                    $row = str_replace("{MOTIVO}",        	($unico->motivo),$row);
                    
                    
                    
                    $row = str_replace("{FECHA}",        (fechaCastellano($unico->fecha)),$row);
                    $documentacion="";
                    if($unico->ficha_postulacion<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->ficha_postulacion).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_notas<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->pago_arancel<>'')        {$documentacion.='<a href="../front/'.utf8_decode($unico->pago_arancel).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_carga<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_carga).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->concentracion_notas<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->concentracion_notas).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->licencia_edmedia<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->licencia_edmedia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->boletinpsu<>'')            {$documentacion.='<a href="../front/'.utf8_decode($unico->boletinpsu).'" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_egreso<>'')    {$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_egreso).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->certificado_acredita<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->certificado_acredita).'" target="_blank" class="btn btn-info" target="_blank">Documento</a><br><br>';}

                    if($unico->vivienda_foto_escritura<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_foto_escritura).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_cedula<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_cedula).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_residencia<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_residencia).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}
                    if($unico->vivienda_matrimonio<>''){$documentacion.='<a href="../front/'.utf8_decode($unico->vivienda_matrimonio).'" target="_blank" class="btn btn-info" target="_blank">Documento </a><br><br>';}


//tipo worfklow
$bloque_validacion_="";
if($unico->tipo_workflow=="1003"){
						// Check admin val1
						
						if($unico->validacion1=="Validado"){							$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-success'>Validado</div>";				}
						elseif($unico->validacion1=="En_Espera")				{	$bloque_validacion_1="<label style='padding-left: 15px;'></label><div class='alert alert-warning'>En Espera</div>";				}						
						else {
						$bloque_validacion_1="
						<div class='alert alert-warning'>
							<form action='?sw=chileactivo_validacion' method='post' name=''>
							<label>Validacion 1 Administrador</label><br>
								<select name='validacion' class='form form-control'>
									<option value=''></option>
									<option value='Validado'>Validar</option>
									<option value='En_Espera'>En Espera</option>
								</select>	<br>
								<label>Comentarios</label><br>
								<input type='text' name='comentarios' class='form form-control'>
								<input type='hidden' name='id_bene' value='".$unico->id."' class='form form-control'>
								<input type='hidden' name='id' value='".$idcategoria."' class='form form-control'>
								<input type='hidden' name='val' value='validacion1' class='form form-control'>
								<input type='submit' class='btn btn-info' value='Guardar'>
							</form>	
						</div>";
						}

						$bloque_validacion_=$bloque_validacion_1;

}




$row = str_replace("{WORKFLOW_FORMULARIO}",        ($bloque_validacion_),$row);



$id_enc=Encodear3($unico->id);
$botones_documentacion='';

$botones_validacion='';
//echo $botones_documentacion;

$tipo="";
if($unico->tipo_wf=="SI"){$tipo="REQUIERE_VALIDACION_JEFATURA";}

$row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);
$row = str_replace("{TIPO_WORKFLOW}",       "",$row);

$fecha_inicio    =$unico->fecha_inicio;
$fecha_termino   =$unico->fecha_termino;
$dia1            =$unico->dia;
$dia2            =$unico->dia2;
$fecha_nacimiento=$unico->fecha_nac;
$anexo           =$unico->anexo;
$celular         =$unico->num_celular;
$cargo           =$unico->cargo;
$mundo           =$unico->mundo;
$datos="";


// POR CADA CAMPO CON RESPUESTA VOY CREANDO LISTA


if($unico->idc01<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc01", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc01)."<br>";}

if($unico->idc02<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc02", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc02)."<br>";}

if($unico->idc03<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc03", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc03)."<br>";}

if($unico->idc04<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc04", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc04)."<br>";}

if($unico->idc05<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc05", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc05)."<br>";}

if($unico->idc06<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc06", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc06)."<br>";}

if($unico->idc07<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc07", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc07)."<br>";}

if($unico->idc08<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc08", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc08)."<br>";}

if($unico->idc09<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc09", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc09)."<br>";}

if($unico->idc10<>""){	$NombreCampo=BeneficiosBuscaNombreCampoIdCampo("idc10", $unico->id_form1);
	$datos.="<strong>".$NombreCampo."</strong>: ".($unico->idc10)."<br>";}



                    $row = str_replace("{DATOS}",        ($datos),$row);

$botones_validacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->validacionok=='1'){
        $botones_validacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->validacionok=='3'){
        $botones_validacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}


$botones_documentacionok='<span class="badge badge-warning">PENDIENTE</span> ';

if($unico->documentacionok=='1'){
        $botones_documentacionok='<span class="badge badge-success">VALIDADO</span> ';
}

if($unico->documentacionok=='3'){
        $botones_documentacionok='<span class="badge badge-danger">RECHAZADO</span> ';
}





    //$botones_documentacion.='<span class="badge badge-danger">RECHAZADO</span><br><br>';
    $botones_documentacionBK.='<br>
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=1&id='.$idcategoria.'" 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a href="?sw=beneficios_validacion&idenc='.$id_enc.'&d=2&id='.$idcategoria.'" 
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	$botones_documentacion.='<br>
	<a 
	class="btn btn-success btn-sm" onclick="Valida'.$unico->id.'();">Validar</a>
	
	<br><br>
	
	<a  
	class="btn btn-danger btn-sm" onclick="Rechaza'.$unico->id.'();">Rechazar</a> 
	';
	
	
	
	$estado_final_beneficio=Beneficios_Busca_Estado($unico->id, $unico->tipo_workflow);


                    $row = str_replace("{DOCUMENTACION}",           ($documentacion),$row);
                    $row = str_replace("{VALIDACION_JEFE}",         ($botones_validacionok),$row);
                    $row = str_replace("{DOCUMENTACION_OK}",         ($estado_final_beneficio),$row);

                    $row = str_replace("{VALIDACION_FINAL}",        ($botones_documentacion),$row);
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Socios Chileactivo",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=chileactivo_solicitudes" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);

    return($html);
}
function lista_solicitudes_chileactivo_v3($html,  $id_empresa, $idcategoria){
    $lista=lista_solicitudes_chileactivo_data_v3($id_empresa);
    //print_r($emb_olas);
    foreach($lista as $unico){
                    
					$row=file_get_contents("views/chileactivo/row_beneficios_desinscripcion.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 $no_vistos=$unico->solicitudes-$unico->visto;
					 //echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 				
					 	
					 	
					 }
					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre),$row);
                    $row = str_replace("{DESINSCRIPCIONES}",        ($unico->desinscripciones),$row);
                    $row = str_replace("{CATEGORIA}",          			($unico->categoria),$row);

                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_PROCESO}",          		$num_proceso,$row);
                    $row = str_replace("{CERRADAS}",          			$num_cerrados,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                    
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Solicitudes Talleres Online",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}
function lista_solicitudes_chileactivo_desinscripcion($html,  $id_empresa, $idcategoria){
 
 			$lista=lista_chileactivo_desinscripcion_data($idcategoria, $id_empresa);
 			//print_r($lista);
			foreach($lista as $unico){
			 	
	                  $row=file_get_contents("views/chileactivo/row_lista_beneficios_desinscripciones.html");
                    $row = str_replace("{ID_BENEFICIO}",    $idcategoria,$row);
                    $row = str_replace("{ID}",    ($unico->id),$row);
                    $row = str_replace("{RUT}",    ($unico->rut),$row);
                    
                    $row = str_replace("{NOMBRE}",        ($unico->nombre),$row);
                    $row = str_replace("{CARGO}",        ($unico->cargo),$row);
                    $row = str_replace("{EMAIL}",        ($unico->email),$row);
                    $row = str_replace("{DIVISION}",        ($unico->division),$row);		 	

                    $row = str_replace("{FECHA}",        ($unico->fecha),$row);		 	
                    $row = str_replace("{BENEFICIO}",        ($unico->beneficio),$row);		 	

                    $row = str_replace("{TIPO_WORKFLOW}",       "",$row);		 	
                    $row = str_replace("{DATOS}",        ($unico->idc01),$row);		 	
                    $row = str_replace("{DOCUMENTACION}",        ($unico->idc02),$row);		 	

			 	
			}
			
    $html = str_replace("{LISTA}",$row,$html);
    $html = str_replace("{TITULO}","Solicitudes Chileactivo",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'<a href="?sw=chileactivo_solicitudes_v3" class="btn btn-info">< Volver</a>',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    $html = str_replace("{ID_BENEFICIO}",    $idcategoria,$html);

    return($html);			
}
function lista_solicitudes_chileactivo_v4($html,  $id_empresa, $idcategoria){
    $lista=lista_solicitudes_chileactivo_data_v4($id_empresa);
    //print_r($emb_olas);
    foreach($lista as $unico){
                    
					$row=file_get_contents("views/chileactivo/row_beneficios.html");
                    $tipo=""; 
                    if($unico->validacionjefe=="SI"){$tipo="REQUIERE VALIDACION JEFE";}
                     //echo "<br>tipo $tipo tipo valida ".$unico->validacionjefe;
					 $no_vistos=$unico->solicitudes-$unico->visto;
					 //echo "no visto $no_vistos.";
					 
					 if($no_vistos>0){
						 if($no_vistos==1){
						 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevo</span>";
						 } else {
							 $nuevo="<span class='badge badge-danger'>".$no_vistos." nuevos</span>";
						 }
					 } else {
						 $nuevo="";
					 }
					 
					 
					 $num_cerrados=0;
					 $num_proceso=0;
					 $num_pendientes=0;
					 //por cada beneficio, hago una barrido por cada solicitudes-$unico-
					 $array_solicitudes=Beneficios_BarridoSolicitudes($unico->id_beneficios, $id_empresa);
					 foreach ($array_solicitudes as $unico_sol){
					 				$val=Beneficios_Busca_Estado_Solo_Data($unico_sol->id, $unico->tipo_workflow);
					 				if($val=="Pendiente"){
					 					$num_pendientes++;
					 				}
					 				if($val=="En Proceso"){
					 					$num_proceso++;
					 				}
					 				if($val=="Cerrado"){
					 					$num_cerrados++;
					 				}
					 				
					 	
					 	
					 }
					 
					 
					 
                    $row = str_replace("{ID}",                      ($unico->id_beneficios),$row);
                    $row = str_replace("{TIPO}",                    ($unico->nombre_tipo_workflow),$row);
                    $row = str_replace("{NOMBRE}",                  ($unico->nombre),$row);
                    $row = str_replace("{SOLICITUDES}",             ($unico->solicitudes),$row);
                    $row = str_replace("{APROBADOS",          			($unico->validacion1),$row);

                    $row = str_replace("{PENDIENTES}",          		$num_pendientes,$row);
                    $row = str_replace("{EN_PROCESO}",          		$num_proceso,$row);
                    $row = str_replace("{CERRADAS}",          			$num_cerrados,$row);

                    $row = str_replace("{PENDIENTE}",          			($unico->validacion2),$row);
                    $row = str_replace("{RECHAZADOS_MODIFICACION}",         	 	($unico->validacion3),$row);
                    $row = str_replace("{RECHAZADOS}",          		($unico->validacion4),$row);
                    
					
                    $row = str_replace("{NUEVO}",         ($nuevo),$row);

					
					
                    $row = str_replace("{ACCIONJEFE}",         ($unico->validacionjefeaccion),$row);
                    $row = str_replace("{PENDIENTESJEFE}",         ($pendientes_jefe),$row);
                    $row = str_replace("{ACCIONADMIN}",         ($unico->validacionadmin),$row);
                    $row = str_replace("{PENDIENTESADMIN}",         ($pendientes_admin),$row);
					
                    $total_html.=$row;
                }
    $html = str_replace("{LISTA}",$total_html,$html);
    $html = str_replace("{TITULO}","Solicitudes Talleres Online",$html);
    $html = str_replace("{BTN}","Nueva Pregunta",$html);
    $html = str_replace("{BTN_A}","?sw=admin_biblio&n=fc",$html);
    $html = str_replace("{BTN_VOLVER}",'',$html);
    $html = str_replace("{COLUMNA}",'Pregunta',$html);
    return($html);
}


?>