<?php

function Insert_tbl_reportes_online_reportes_automaticos_init($email,$reporte,$fecha, $rut, $get, $post) {
global $c_host, $c_user, $c_pass, $c_db;
$database = new database($c_host, $c_user, $c_pass);
$database->setDb($c_db);
$get_array	= json_encode($get);
$post_array	= json_encode($post);
$sql = "
INSERT INTO tbl_reportes_online_reportes_automaticos (email,reporte,fecha,rut, get_array, post_array)
VALUES ('$email', '$reporte', '$fecha','$rut','$get_array','$post_array')";
//echo $sql;exit();
$database->setquery($sql);
$database->query();
$database->lastInsertId();

return $database->lastInsertId();

}

function reportes_online_reportes_automaticos_iniciados_no_realizados(){
global $c_host, $c_user, $c_pass, $c_db;
$database = new database($c_host, $c_user, $c_pass);
$database->setDb($c_db);
$sql = "select * from tbl_reportes_online_reportes_automaticos where iniciado is NULL and realizado is NULL order by id limit 1";
$database->setquery($sql);
$database->query();
$cod = $database->listObjects();
return $cod;

}

function Update_tbl_reportes_online_reportes_automaticos_enproceso($id) {
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    $sql = "
	UPDATE tbl_reportes_online_reportes_automaticos set iniciado='INICIADO' where id='$id'	";
    $database->setquery($sql);
    $database->query();
}
function Reporte_tbl_reportes_online_reportes_automaticos_id($id) {
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    $sql = "select * from tbl_reportes_online_reportes_automaticos where id='$id'";
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod;
}
function Update_tbl_reportes_online_reportes_automaticos($url_file, $id) {
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    $sql = "
	UPDATE tbl_reportes_online_reportes_automaticos set realizado='REALIZADO', url_file='$url_file' where id='$id'	";
    //echo $sql;
    $database->setquery($sql);
    $database->query();
}

function InsertaTblLmsCron_2021($texto) {
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    $hoy=date("Y-m-d");
    $hora=date("H:i:s");
    $sql = 				"INSERT INTO tbl_lms_cron (parte,fecha,hora)
									VALUES 
								('Cron Reportes Online Data ".$texto."', '$hoy', '$hora');";
    $database->setquery($sql);
    $database->query();
}
function UsuarioAdminUsuarioRutEmpresa2022($rut){


    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    $sql = "select h.* from tbl_admin h where h.user='$rut'";
    //echo "<br>".$sql;
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();

    if($cod[0]->email==""){
        $sql1 = "select h.* from tbl_usuario h where h.rut='$rut'";
        //echo "<br>".$sql1;
        $database->setquery($sql1);
        $database->query();
        $cod = $database->listObjects();        
    }
    
    return $cod;

}

function notificaciones_email_new_2022($id_notificacion_automatica){
    global $c_host, $c_user, $c_pass, $c_db;
    $database = new database($c_host, $c_user, $c_pass);
    $database->setDb($c_db);
    $sql = "select * from tbl_notificaciones_email where id_notificacion_automatica='$id_notificacion_automatica'";
    //echo "<br>$sql";
    $database->setquery($sql);
    $database->query();
    $cod = $database->listObjects();
    return $cod;
}

?>