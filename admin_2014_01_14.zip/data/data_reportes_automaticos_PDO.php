<?php

function Insert_tbl_reportes_online_reportes_automaticos_init($email, $reporte, $fecha, $rut, $get, $post) {
    $connexion = new DatabasePDO();
    $get_array = json_encode($get);
    $post_array = json_encode($post);
    $sql = "INSERT INTO tbl_reportes_online_reportes_automaticos (email, reporte, fecha, rut, get_array, post_array)
            VALUES (:email, :reporte, :fecha, :rut, :get_array, :post_array)";
    $connexion->query($sql);
    $connexion->bind(':email', $email);
    $connexion->bind(':reporte', $reporte);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':get_array', $get_array);
    $connexion->bind(':post_array', $post_array);
    $connexion->execute();
    return $connexion->lastInsertId();
}

function reportes_online_reportes_automaticos_iniciados_no_realizados() {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_reportes_automaticos WHERE iniciado IS NULL AND realizado IS NULL ORDER BY id LIMIT 1";
    $connexion->query($sql);
    return $connexion->resultset();
}

function Update_tbl_reportes_online_reportes_automaticos_enproceso($id) {
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_reportes_online_reportes_automaticos SET iniciado='INICIADO' WHERE id=:id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

function Reporte_tbl_reportes_online_reportes_automaticos_id($id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_reportes_automaticos WHERE id=:id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    return $connexion->resultset();
}

function Update_tbl_reportes_online_reportes_automaticos($url_file, $id) {
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_reportes_online_reportes_automaticos SET realizado='REALIZADO', url_file=:url_file WHERE id=:id";
    $connexion->query($sql);
    $connexion->bind(':url_file', $url_file);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

function InsertaTblLmsCron_2021($texto) {
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $hora = date("H:i:s");
    $sql = "INSERT INTO tbl_lms_cron (parte, fecha, hora) VALUES (:parte, :fecha, :hora)";
    $connexion->query($sql);
    $connexion->bind(':parte', "Cron Reportes Online Data ".$texto);
    $connexion->bind(':fecha', $hoy);
    $connexion->bind(':hora', $hora);
    $connexion->execute();
}

function UsuarioAdminUsuarioRutEmpresa2022($rut) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_admin h WHERE h.user=:rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    if ($cod[0]->email == "") {
        $sql1 = "SELECT h.* FROM tbl_usuario h WHERE h.rut=:rut";
        $connexion->query($sql1);
        $connexion->bind(':rut', $rut);
        $cod = $connexion->resultset();
    }

    return $cod;
}

function notificaciones_email_new_2022($id_notificacion_automatica) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_notificaciones_email WHERE id_notificacion_automatica=:id_notificacion_automatica";
    $connexion->query($sql);
    $connexion->bind(':id_notificacion_automatica', $id_notificacion_automatica);
    return $connexion->resultset();
}


?>