<?php


    function elimina_duplicacion_email_2022(){
        $connexion = new DatabasePDO();

        $hoy = date("Y-m-d");
        $sql = "select rut, email, count(*) from tbl_usuario
    where email <> '' and email<>'.'  and email is not null
    group by email having count(*) > 1";

        $connexion->query($sql);
        $cod = $connexion->resultset();
        foreach ($cod as $unico){

            $sql2="select id, rut, email, vigencia_descripcion from tbl_usuario where email=:email order by vigencia_descripcion Desc limit 1";
            $connexion->query($sql2);
            $connexion->bind(':email', $unico->email);
            $cod2 = $connexion->resultset();

            foreach ($cod2 as $unico2){
                $sql3="delete  from tbl_usuario where id=:id";
                $connexion->query($sql3);
                $connexion->bind(':id', $unico2->id);
                $connexion->execute();
            }
        }
        $connexion->query($sql);
        $connexion->execute();
    }


function nombre_categoria_reco_admin($categoria, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT categoria FROM tbl_reconoce_categorias WHERE id_categoria = :categoria AND id_empresa = :id_empresa LIMIT 1";

    $connexion->query($sql);
    $connexion->bind(':categoria', $categoria);
    $connexion->bind(':id_empresa', $id_empresa);

    $cod = $connexion->resultset();
    return $cod[0]->categoria;
}
function select_turnos_data_admin()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.rut as RUT_COLABORADOR,
            u.nombre_completo as NOMBRE_COLABORADOR,
            u.cargo as CARGO_COLABORADOR,
            u.c1 as DIVISION_COLABORADOR,
            u.c4 as CUI_COLABORADOR,
            h.fecha as FECHA_TURNO,
            h.modalidad as MODALIDAD_TURNO,
            h.rut_jefe as RUT_JEFE,
            j.nombre_completo as NOMBRE_JEFE,
            j.cargo as CARGO_JEFE,
            h.fecha_registro as FECHA_REGISTRO_JEFE
            from tbl_turnos_diarios h
            inner join tbl_reportes_online_usuario u on u.rut=h.rut
            left join tbl_reportes_online_usuario j on j.rut=h.rut_jefe";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function Rec_Inserta_Reconocimiento_admin($rut_remitente, $rut_destinatario, $id_categoria, $categoria, $fecha, $hora, $id_empresa, $tipo, $puntos, $mensaje, $cui, $estado, $cbox1,$rut_jefatura,$division,$cargo,$area,$local,$departamento,$region)
{
    
    //echo "<br><br>$rut_remitente, $rut_destinatario, $id_categoria, categoria $categoria, $fecha, $hora, $id_empresa, $tipo, $puntos, $mensaje, $cui, $estado, $cbox1,$rut_jefatura,$division,$cargo,$area,$local,$departamento,$region";exit();
    $connexion = new DatabasePDO();

    $mensaje = ($mensaje);
    $categoria = utf8_decode($categoria);

    if ($tipo == "GRACIAS") {
        $puntos = "0";
    }

    $sql = "INSERT INTO tbl_reconoce_gracias (rut_remitente,rut_destinatario,id_categoria,categorita,fecha,hora,id_empresa,tipo,puntos,mensaje,estado,cui,rut_jefatura,division, cargo, area, local,departamento, region, comentarios )
            VALUES (:rut_remitente, :rut_destinatario, :id_categoria, :categoria, :fecha, :hora, :id_empresa, :tipo, :puntos, :mensaje, :estado, :cui, :rut_jefatura, :division, :cargo, :area, :local, :departamento, :region, :cbox1)";
    //echo "<br>$sql<br>";

    $connexion->query($sql);
    $connexion->bind(':rut_remitente', $rut_remitente);
    $connexion->bind(':rut_destinatario', $rut_destinatario);
    $connexion->bind(':id_categoria', $id_categoria);
    $connexion->bind(':categoria', $categoria);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo', $tipo);
    $connexion->bind(':puntos', $puntos);
    $connexion->bind(':mensaje', $mensaje);
    $connexion->bind(':estado', $estado);
    $connexion->bind(':cui', $cui);
    $connexion->bind(':rut_jefatura', $rut_jefatura);
    $connexion->bind(':division', $division);
    $connexion->bind(':cargo', $cargo);
    $connexion->bind(':area', $area);
    $connexion->bind(':local', $local);
    $connexion->bind(':departamento', $departamento);
    $connexion->bind(':region', $region);
    $connexion->bind(':cbox1', $cbox1);

    $connexion->execute();

    $sql = "SELECT id FROM tbl_reconoce_gracias WHERE rut_remitente=:rut_remitente AND rut_destinatario=:rut_destinatario AND id_empresa=:id_empresa ORDER BY id DESC LIMIT 1";

    $connexion->query($sql);
    $connexion->bind(':rut_remitente', $rut_remitente);
    $connexion->bind(':rut_destinatario', $rut_destinatario);
    $connexion->bind(':id_empresa', $id_empresa);

    $cod = $connexion->resultset();
    return $cod[0]->id;
}

function BecasUpdateDocumentacionMontoValidado($rut, $monto_validado_matricula, $monto_validado_arancel)
{
    $connexion = new DatabasePDO();

    $sql = "UPDATE tbl_becas
            SET monto_validado_matricula = :monto_validado_matricula, monto_validado_arancel = :monto_validado_arancel
            WHERE rut = :rut";

    $connexion->query($sql);
    $connexion->bind(':monto_validado_matricula', $monto_validado_matricula);
    $connexion->bind(':monto_validado_arancel', $monto_validado_arancel);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
}

function lista_becas_becas_full_data($id_empresa) {
    $connexion = new DatabasePDO();
    
    $sql = "SELECT h.*, (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.rut) AS nombre
            FROM tbl_becas h
            WHERE h.id_empresa = :id_empresa
            ORDER BY (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.rut)";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function DatosPremios($idcanje, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.id_premio, 
            (SELECT premio FROM tbl_premios WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa) as premio,
            (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.rut) as nombre_completo,
            (SELECT email FROM tbl_usuario WHERE rut = h.rut) as email
            FROM tbl_premios_canje h WHERE h.id = :idcanje AND h.id_empresa = :id_empresa";

    $connexion->query($sql);
    $connexion->bind(':idcanje', $idcanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}
function Puntos_Query_Descarga($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.rut,
            h.id_premio as id_item,
            (SELECT premio FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) as Item,
            (SELECT premio_descripcion FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) as ItemDescripcion,
            (SELECT id_dimension FROM tbl_premios WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa LIMIT 1) as id_dimension,
            (SELECT dimension FROM tbl_premios_dimension WHERE id_dimension = (SELECT id_dimension FROM tbl_premios WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa LIMIT 1) AND dimension <> '' LIMIT 1) as Dimension,
            (SELECT segmento FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) as Segmento,
            (SELECT puntos FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) as Puntos,
            h.fecha as fechasolicitud,
            h.hora as horasolicitud,
            h.puntos as puntos,
            h.fecha_texto as fechaUso,
            h.hora_inicio as HoraInicioUso,
            h.hora_termino as HoraTerminoUso,
            h.estadovalidacion,
            h.despacho,
            h.fecha_despacho,
            h.entrega,
            h.fecha_entrega
            FROM tbl_premios_canje h
            WHERE h.id_empresa = :id_empresa
            ORDER BY h.id DESC, h.fecha DESC, h.hora DESC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}
function Puntos_Query_Descarga_fechas($fecha_inicio, $fecha_termino, $id_empresa) {
    $qfi = "";
    $qft = "";

    if ($fecha_inicio <> '') { $qfi = " AND h.fecha >= :fecha_inicio";}

    if ($fecha_termino <> '') { $qft = " AND h.fecha <= :fecha_termino";}

    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*,
        (SELECT premio FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) AS Item,
        (SELECT premio_descripcion FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) AS ItemDescripcion,
        (SELECT id_dimension FROM tbl_premios WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa LIMIT 1) AS id_dimension,
        (SELECT dimension FROM tbl_premios_dimension WHERE id_dimension = (SELECT id_dimension FROM tbl_premios WHERE id_premio = h.id_premio AND id_empresa = h.id_empresa LIMIT 1) AND dimension <> '' LIMIT 1) AS Dimension,
        (SELECT segmento FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) AS Segmento,
        (SELECT puntos FROM tbl_premios WHERE id_premio = h.id_premio LIMIT 1) AS Puntos,
        h.fecha AS fechasolicitud,
        h.hora AS horasolicitud,
        h.fecha_texto AS fechaUso,
        h.hora_inicio AS HoraInicioUso,
        h.hora_termino AS HoraTerminoUso
        FROM tbl_premios_canje h
        WHERE h.id_empresa = :id_empresa
        $qfi
        $qft
        ORDER BY h.id DESC, h.fecha DESC, h.hora DESC";

    $connexion->query($sql);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}
function RechazaPuntosPremiosJefe($id_beneficiocanje, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "UPDATE tbl_premios_puntos_usuarios_jefe_entregados SET puntos = '0' WHERE id = :id_beneficiocanje AND id_empresa = :id_empresa";

    $connexion->query($sql);
    $connexion->bind(':id_beneficiocanje', $id_beneficiocanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function ValidaPuntosPremios($id_beneficiocanje, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "update tbl_premios_canje set estadovalidacion='1'
            where id=:id_beneficiocanje and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_beneficiocanje', $id_beneficiocanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function RechazaPuntosPremios($id_beneficiocanje, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "update tbl_premios_canje set estadovalidacion='3', puntos='0'
            where id=:id_beneficiocanje and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_beneficiocanje', $id_beneficiocanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function ValidaPuntosPremiosDespachos($id_beneficiocanje, $valida, $id_empresa) {
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $sql = "update tbl_premios_canje set despacho=:valida, fecha_despacho=:fecha
            where id=:id_beneficiocanje and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':valida', $valida);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':id_beneficiocanje', $id_beneficiocanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function ValidaPuntosPremiosDespachosDeshacer($id_beneficiocanje, $valida, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "update tbl_premios_canje set despacho='', fecha_despacho=''
            where id=:id_beneficiocanje and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_beneficiocanje', $id_beneficiocanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function ValidaPuntosPremiosEntregas($id_beneficiocanje, $valida, $id_empresa) {
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $sql = "update tbl_premios_canje set entrega=:valida, fecha_entrega=:fecha
            where id=:id_beneficiocanje and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':valida', $valida);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':id_beneficiocanje', $id_beneficiocanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function ValidaPuntosPremiosDeshacer($id_beneficiocanje, $valida, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "update tbl_premios_canje set entrega='', fecha_entrega=''
            where id=:id_beneficiocanje and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_beneficiocanje', $id_beneficiocanje);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function ListaBchNuevasClavesRutTemp() {
    $connexion = new DatabasePDO();
    $sql = "select h.* from rut_temp h where h.clave is null";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_puntos_canjes_despachos_data($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        select h.*,
        (select premio from tbl_premios where id_premio=h.id_premio) as premio,
        (select dimension from tbl_premios where id_premio=h.id_premio) as dimension
        from tbl_premios_canje h
        where h.id_empresa=:id_empresa and h.estadovalidacion='1' 
        and h.fecha>'2019-06-01'
        and h.fecha_despacho is NULL
        and (select id_dimension from tbl_premios where id_premio=h.id_premio)<>'bch_tl'
        order by h.id DESC
        ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}
function lista_puntos_canjes_entregas_data($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        select h.*,
        (select premio from tbl_premios where id_premio=h.id_premio) as premio,
        (select dimension from tbl_premios where id_premio=h.id_premio) as dimension
        from tbl_premios_canje h
        where h.id_empresa=:id_empresa and h.estadovalidacion='1' 
        and h.fecha_entrega is NULL
        and (select id_dimension from tbl_premios where id_premio=h.id_premio)<>'bch_tl'
        and h.fecha>'2019-06-01' order by h.id DESC
        ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}
function lista_puntos_canjes_entregas_data_cdr($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        select h.*,
        (select premio from tbl_premios where id_premio=h.id_premio) as premio,
        (select dimension from tbl_premios where id_premio=h.id_premio) as dimension,
        (select id_dimension from tbl_premios where id_premio=h.id_premio) as id_dimension
        from tbl_premios_canje h
        where h.id_empresa=:id_empresa and h.estadovalidacion='1'
        and h.fecha>'2019-06-01'
        and h.fecha_entrega is NULL
        and (select id_dimension from tbl_premios where id_premio=h.id_premio)<>'bch_tl'
        and  (select id_dimension from tbl_premios where id_premio=h.id_premio)='bch_vj'
        order by h.id DESC
        ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}
function lista_puntos_canjes_data($id_empresa, $fecha_inicio, $fecha_termino, $limit) {
    $connexion = new DatabasePDO();

    $qFi = ""; $qTe = "";

    if ($fecha_inicio <> "") { $qFi = " and h.fecha>='$fecha_inicio' "; }
    if ($fecha_termino <> "") { $qTe = " and h.fecha<='$fecha_termino' "; }

    $sql = "
        select h.*,
        (select premio from tbl_premios where id_premio=h.id_premio and id_empresa=h.id_empresa limit 1) as premio,
        (select id_dimension from tbl_premios where id_premio=h.id_premio and id_empresa=h.id_empresa limit 1) as id_dimension,
        (select dimension from tbl_premios_dimension where id_dimension=(select id_dimension from tbl_premios where id_premio=h.id_premio and id_empresa=h.id_empresa limit 1) and dimension<>'' limit 1) as dimension
        from tbl_premios_canje h
        where h.id_empresa=:id_empresa
        $qFi
        $qTe
        order by h.id DESC
        $limit
        ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}
function canje_update_fulldata_canje($id_empresa){

    $connexion = new DatabasePDO();
    $sql_canje = "SELECT h.* FROM tbl_premios_canje h WHERE (h.rut_completo IS NULL OR h.rut_completo='') AND h.fecha>='2019-01-01' AND h.id_empresa=:id_empresa";
    $connexion->query($sql_canje);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod_canje = $connexion->resultset();

    $count_total_loop = count($cod_canje);
    ini_set('output_buffering', 0);
    ini_set('zlib.output_compression', 0);
    if (!ob_get_level()) {
        ob_start();
    } else {
        ob_end_clean();
        ob_start();
    }

    foreach ($cod_canje as $unico_canje) {
        $cuenta_loop++;
        echo "<center><span style='position: absolute;z-index:$current;background:#36C6D3; padding:10px; color:#FFF'>Actualizando $cuenta_loop de $count_total_loop Registros</span></center>";
        flush();
        ob_flush();

        $Usu = TraeDatosUsuario($unico_canje->rut);
        $sql_usu = "UPDATE tbl_premios_canje
            SET rut_completo=:rut_completo,
            nombre_completo=:nombre_completo,
            cargo=:cargo,
            division=:division,
            gerencia=:gerencia,
            unidad_negocio=:unidad_negocio,
            ubicacion=:ubicacion,
            sucursal=:sucursal,
            id_gerencia=:id_gerencia,
            mundo=:mundo
            WHERE rut=:rut";
        $connexion->query($sql_usu);
        $connexion->bind(':rut_completo', $Usu[0]->rut_completo);
        $connexion->bind(':nombre_completo', $Usu[0]->nombre_completo);
        $connexion->bind(':cargo', $Usu[0]->cargo);
        $connexion->bind(':division', $Usu[0]->division);
        $connexion->bind(':gerencia', $Usu[0]->gerencia);
        $connexion->bind(':unidad_negocio', $Usu[0]->unidad_negocio);
        $connexion->bind(':ubicacion', $Usu[0]->ubicacion);
        $connexion->bind(':sucursal', $Usu[0]->sucursal);
        $connexion->bind(':id_gerencia', $Usu[0]->id_gerencia);
        $connexion->bind(':mundo', $Usu[0]->mundo);
        $connexion->bind(':rut', $unico_canje->rut);
        $connexion->execute();

        $jefe = $unico_canje->rut_jefe;

        $UsuJ = TraeDatosUsuario($jefe);
        $sql_usuJ = "UPDATE tbl_premios_canje
            SET rut_completo_jefe=:rut_completo_jefe,
            nombre_completo_jefe=:nombre_completo_jefe,
            cargo_jefe=:cargo_jefe
            WHERE rut=:rut";
        $connexion->query($sql_usuJ);
        $connexion->bind(':rut_completo_jefe', $UsuJ[0]->rut_completo);
        $connexion->bind(':nombre_completo_jefe', $UsuJ[0]->nombre_completo);
        $connexion->bind(':cargo_jefe', $UsuJ[0]->cargo);
        $connexion->bind(':rut', $unico_canje->rut);
        $connexion->execute();
    }
    return $cod;
}
function lista_asignacion_usuarios_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
        SUM(puntos) AS recibidos,
        (SELECT SUM(puntos) FROM tbl_premios_canje WHERE rut=h.rut) AS entregados,
        (SUM(puntos) - (SELECT SUM(puntos) FROM tbl_premios_canje WHERE rut=h.rut)) AS saldo
        FROM tbl_premios_puntos_usuarios h
        WHERE h.id_empresa=:id_empresa
        GROUP BY h.rut";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_puntos_stock_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
        (SELECT dimension FROM tbl_premios_dimension WHERE id_dimension=h.id_dimension AND dimension<>'' LIMIT 1) AS TextoDim,
        (SELECT COUNT(id) FROM tbl_premios_canje WHERE id_premio=h.id_premio AND id_empresa=h.id_empresa AND estadovalidacion<>'3') AS canjeados
        FROM tbl_premios h
        WHERE h.id_empresa=:id_empresa
        ORDER BY h.id_dimension, h.premio";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function logadmininsert($rut, $accion, $get_var, $post_var, $descripion, $fecha, $hora) {
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    
    $vardump_get_2 = '';
    foreach ($get_var as $unico) {
        $vardump_get_2 .= $unico . ",";
    }
    $vardump_post_2 = '';
    foreach ($post_var as $unico) {
        $vardump_post_2 .= $unico . ",";
    }

    $sql = "INSERT INTO tbl_admin_log (rut, accion, get_var, post_var, descripcion, fecha, hora)
        VALUES (:rut, :accion, :get_var, :post_var, :descripcion, :fecha, :hora)";
    $connexion->query($sql);
    $connexion->bind(':rut', $_SESSION["admin_"]);
    $connexion->bind(':accion', $accion);
    $connexion->bind(':get_var', $vardump_get_2);
    $connexion->bind(':post_var', $vardump_post_2);
    $connexion->bind(':descripcion', $descripion);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':hora', $hora);
    $connexion->execute();
}
function borrapremiocanje($id, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_premios WHERE id = :id AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function actualizadim()
{
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_premios
            SET dimension = (SELECT dimension FROM tbl_premios_dimension WHERE id_dimension = tbl_premios.id_dimension AND dimension <> '' LIMIT 1)
            WHERE dimension IS NULL";
    $connexion->query($sql);
    $connexion->execute();
}
function UsuarioAdminRutEmpresa2020($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_admin h WHERE h.user = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $datos = $connexion->resultset();
    return $datos;
}
function BuscaEmpresaUserRut($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT home FROM tbl_admin_perfiles WHERE id = h.acceso) AS home_admin FROM tbl_admin h WHERE h.user = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function UpdateLmsReportes2020()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_lms_reportes h WHERE h.rut_completo IS NULL";
    $connexion->query($sql);
    $cod = $connexion->resultset();

    foreach ($cod as $unico) {
        $Usu = TraeDatosUsuario($unico->rut);

        $sql1 = "UPDATE tbl_lms_reportes SET rut_completo = :rut_completo WHERE id = :id";
        $connexion->query($sql1);
        $connexion->bind(':rut_completo', $Usu[0]->rut_completo);
        $connexion->bind(':id', $unico->id);
        $connexion->execute();

        $relLmsMallaCurso = Updatelms0202_busca_rel_malla_curso($unico->id_curso, $unico->id_malla);

        $sql2 = "UPDATE tbl_lms_reportes 
                 SET 
                 id_foco = :id_foco,
                 id_clasificacion = :id_clasificacion
                 WHERE id = :id";
        $connexion->query($sql2);
        $connexion->bind(':id_foco', $relLmsMallaCurso[0]->id_foco);
        $connexion->bind(':id_clasificacion', $relLmsMallaCurso[0]->id_clasificacion);
        $connexion->bind(':id', $unico->id);
        $connexion->execute();

        $Array_Fechas = Updatelms2020_sinFecha($unico->rut, $unico->id_curso);

        $sql3 = "UPDATE tbl_lms_reportes 
                 SET fecha_inicio = :fecha_inicio, fecha_termino = :fecha_termino
                 WHERE id = :id";
        $connexion->query($sql3);
        $connexion->bind(':fecha_inicio', $Array_Fechas[0]->FI);
        $connexion->bind(':fecha_termino', $Array_Fechas[0]->FT);
        $connexion->bind(':id', $unico->id);
        $connexion->execute();

        $Array_InsUsu = Updatelms0202_busca_Fecha_inscriocion_curso($unico->rut, $unico->id_curso);

        $sql4 = "UPDATE tbl_lms_reportes 
                 SET fecha_inscripcion = :fecha_inscripcion
                 WHERE id = :id";
        $connexion->query($sql4);
        $connexion->bind(':fecha_inscripcion', $Array_InsUsu[0]->fecha);
        $connexion->bind(':id', $unico->id);
        $connexion->execute();
    }

    $sql5 = "UPDATE tbl_lms_reportes SET fecha_inicio = '0000-00-00' WHERE fecha_inicio IS NULL";
    $connexion->query($sql5);
    $connexion->execute();

    $sql6 = "UPDATE tbl_lms_reportes SET fecha_termino = '0000-00-00' WHERE fecha_termino IS NULL";
    $connexion->query($sql6);
    $connexion->execute();
    return $cod;
}
function TraeDatosUsuario($rut)
{
    $connexion = new DatabasePDO();
    $rut = preg_replace("/[^0-9]/", "", $rut);
    $sql = "SELECT * FROM tbl_usuario WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function PerfilAdmin($id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_admin_perfiles WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}
function VerificaTipoDePerfilAdminAcceso($user){
    $connexion = new DatabasePDO();
    $sql = "SELECT tbl_admin.*, tbl_admin_perfiles.template FROM tbl_admin INNER JOIN tbl_admin_perfiles ON tbl_admin_perfiles.id = tbl_admin.acceso WHERE tbl_admin.user = :user";
    $connexion->query($sql);
    $connexion->bind(':user', $user);
    $cod = $connexion->resultset();
    return $cod;
}
function TiposReportesPorEmpresa($id_empresa, $tipo_reporte) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes WHERE id_empresa = :id_empresa AND tipo_reporte = :tipo_reporte";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo_reporte', $tipo_reporte);
    $cod = $connexion->resultset();
    return $cod;
}
function DatosUsuarioAdmin($rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_admin WHERE user = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function ListaBchSinClavesEncodeada($id_empresa){
  /*  $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT clave_encodeada FROM tbl_clave WHERE rut = h.rut) AS clave FROM tbl_usuario h WHERE h.id_empresa = :id_empresa AND (SELECT clave_encodeada FROM tbl_clave WHERE rut = h.rut) IS NULL";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;*/
}
function BuscaTotalUsuariosTemporales($id_empresa, $tipo){
    $connexion = new DatabasePDO();

    if($tipo == "TODOS"){
        $sql = "SELECT h.* FROM tbl_usuario_temporal h WHERE h.id_empresa = :id_empresa";
    }
    elseif($tipo == "NUEVOS"){
        $sql = "SELECT h.*, (SELECT rut FROM tbl_usuario WHERE rut = h.rut) AS Rut FROM tbl_usuario_temporal h WHERE h.id_empresa = :id_empresa AND (SELECT rut FROM tbl_usuario WHERE rut = h.rut) IS NULL";
    }
    elseif($tipo == "NOENCONTRADOS"){
        $sql = "SELECT h.*, (SELECT rut FROM tbl_usuario_temporal WHERE rut = h.rut) AS Rut FROM tbl_usuario h WHERE h.id_empresa = :id_empresa AND h.vigencia_descripcion = '' AND (SELECT rut FROM tbl_usuario_temporal WHERE rut = h.rut) IS NULL";
    }
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function reportes_online_cron_data($id_empresa){
    $connexion = new DatabasePDO();

		$sqlUpdate_1_1 = "	update tbl_lms_reportes set resultado='-'  where resultado is null";
		//echo "<br>-->$sqlUpdate_1_1";
		$connexion->query($sqlUpdate_1_1);
		$connexion->execute();

		$sql_usuarioPrueba="delete h.* from tbl_lms_reportes h where h.rut='12345';";
		$connexion->query($sql_usuarioPrueba);
		$connexion->execute();
		
		$sql_usuarioPrueba=" delete h.* from tbl_lms_reportes h where h.rut='id';";
		$connexion->query($sql_usuarioPrueba);
		$connexion->execute();
	  
 		$sql_2="select h.* from tbl_lms_reportes h where h.modalidadcurso is null or h.modalidadcurso ='';";
		$connexion->query($sql_2);
		$cod_2 = $connexion->resultset();
	
	  //echo "<br>Count 2 Modalidad Nula o Vacia: ".count($cod_2);
	  foreach ($cod_2 as $unico){
	  	
		$sql_2_1="select h.modalidad from tbl_lms_curso h where h.id='".$unico->id_curso."'";
		$connexion->query($sql_2_1);
		$cod_2_1 = $connexion->resultset();	 	
		$sqlUpdate_1_1 = "	update tbl_lms_reportes set modalidadcurso='".$cod_2_1[0]->modalidad."' where id='".$unico->id."'";
		$connexion->query($sqlUpdate_1_1);
		$connexion->execute();			
	    			
	  }

		$sql_3="SELECT h.*  FROM tbl_lms_reportes h WHERE (h.estado='NO_INICIADO') AND h.avance='5'; ";
		$connexion->query($sql_3);
		$cod_3 = $connexion->resultset();	
    
  foreach ($cod_3 as $unico){
  	
		$sqlUpdate_1_1 = "	update tbl_lms_reportes set avance='0' 	where rut='".$unico->rut."' and id_curso='".$unico->id_curso."'";
		$connexion->query($sqlUpdate_1_1);
		$connexion->execute();				
 			
  }

 		$sql_2="SELECT h.* FROM tbl_lms_reportes h WHERE (h.estado IS NULL OR h.estado='') AND h.modalidadcurso = '1'		order by h.fecha_inicio DESC;";
    	$connexion->query($sql_2);
		$cod_2 = $connexion->resultset();
	
   // echo "<br>Count 3 Estado Nulo o Vacio: ".count($cod_2);
  foreach ($cod_2 as $unico){
  			$sql_2_1="SELECT h.* FROM tbl_inscripcion_cierre h WHERE h.rut='".$unico->rut."' and h.id_curso='".$unico->id_curso."' and id_empresa='".$unico->id_empresa."'";
     			$connexion->query($sql_2_1);
				$cod_2_1 = $connexion->resultset();
				
     			if($cod_2_1[0]->avance>0 and $cod_2_1[0]->avance<100){
     				$avance=$cod_2_1[0]->avance;
     				$estado="EN_PROCESO";
     			} else {
     				$avance="0";
     				$estado="NO_INICIADO";
     			}
 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set avance='".$avance."', estado='".$estado."' where id='".$unico->id."'";
    			$connexion->query($sqlUpdate_1_1);
				$connexion->execute();	
  }

 		$sql_2="SELECT h.* FROM tbl_lms_reportes h WHERE (h.estado='EN_PROCESO') AND (h.avance='100'  or h.avance='0') AND h.modalidadcurso = '1';";
         		$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();

	
    //echo "<br>Count 4 avance 100 y Proceso: ".count($cod_2);
  foreach ($cod_2 as $unico){
  			$sql_2_1="SELECT h.* FROM tbl_inscripcion_cierre h WHERE h.rut='".$unico->rut."' and h.id_curso='".$unico->id_curso."' and id_empresa='".$unico->id_empresa."'";
     			$connexion->query($sql_2_1);
				$cod_2_1 = $connexion->resultset();
				
     			echo "<br>$sql_2_1<br>";print_r($cod_2_1);
     			if($cod_2_1[0]->avance>0){
     				
     				$estado=$cod_2_1[0]->estado_descripcion;
     			} else {
     				$avance="0";
     				$estado="NO_INICIADO";
     			}
 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set estado='".$estado."' where id='".$unico->id."'";
    			$database->setquery($sqlUpdate_1_1);	$database->query();    			
  }

 		$sql_2="SELECT h.* FROM tbl_lms_reportes h WHERE h.avance <> '100' AND (h.estado = 'APROBADO' or h.estado = 'REPROBADO') AND h.modalidadcurso = '1' ;";
         		$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();
   // echo "<br>Count 5 Avance <>100 y Aprobado Reprobado: ".count($cod_2);
  foreach ($cod_2 as $unico){
  			$sql_2_1="SELECT h.* FROM tbl_inscripcion_cierre h WHERE h.rut='".$unico->rut."' and h.id_curso='".$unico->id_curso."' and id_empresa='".$unico->id_empresa."'";
     			$connexion->query($sql_2_1);
				$cod_2_1 = $connexion->resultset();				
     			echo "<br>$sql_2_1<br>";print_r($cod_2_1);
     			if($cod_2_1[0]->avance>0){
     				
     				$estado="EN_PROCESO";
     			} else {
     				$avance="0";
     				$estado="NO_INICIADO";
     			}
 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set estado='".$estado."' where id='".$unico->id."'";
    			$connexion->query($sqlUpdate_1_1);
				$connexion->execute();	
  }

		$hoy=date("Y-m-d");
		
 		$sql_2="SELECT h.*, 
				(select id from tbl_lms_reportes where rut=h.rut and id_curso=h.id_curso) as IdReportes,
				(select avance from tbl_lms_reportes where rut=h.rut and id_curso=h.id_curso) as Avance,
				(select estado from tbl_lms_reportes where rut=h.rut and id_curso=h.id_curso) as Estado,
				(select avance from tbl_inscripcion_cierre where rut=h.rut and id_curso=h.id_curso and id_empresa='$id_empresa' order by avance limit 1) as AvanceCierre,
				(select estado_descripcion from tbl_inscripcion_cierre where rut=h.rut and id_curso=h.id_curso and id_empresa='$id_empresa' order by avance limit 1) as EstadoCierre,
				(select nota from tbl_inscripcion_cierre where rut=h.rut and id_curso=h.id_curso and id_empresa='$id_empresa' order by avance limit 1) as notaCierre


				FROM tbl_objetos_finalizados h WHERE h.fecha='$hoy'
				and h.id_curso<>'' and h.rut<>'' ";
       			$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();	
	
    //echo "<br><br>Num Objetos Finalizados Hoy: ".count($cod_2)."<br>";

foreach ($cod_2 as $unico){
	
	 if($unico->Avance=="100" and ($unico->Estado=="APROBADO" OR $unico->Estado=="REPROBADO")){
		continue;
	 }	else {
		//echo "<br> ".$unico->rut." id curso ".$unico->id_curso. " Avance: ".$unico->Avance. " Estado: ".$unico->Estado." avance Cierre ".$unico->AvanceCierre." Estado Cierre ".$unico->EstadoCierre;
		
		if($unico->AvanceCierre=="100" and $unico->EstadoCierre=="APROBADO"){
			//echo "<h3>update tbl_lms_reportes set avance='".$unico->AvanceCierre."', estado='".$unico->EstadoCierre."', resultado='".$unico->notaCierre."' where id='".$unico->IdReportes."'</h3>";
			$sql_update="update tbl_lms_reportes set avance='".$unico->AvanceCierre."', estado='".$unico->EstadoCierre."', resultado='".$unico->notaCierre."' where id='".$unico->IdReportes."'";
			    $connexion->query($sql_update);
				$connexion->execute();	
		}
		
		if($unico->AvanceCierre==$unico->Avance){
			//echo " - Not Updated";
		}
		
		if($unico->AvanceCierre>$unico->Avance and $unico->AvanceCierre<>"100"){
			//echo "<h3>update tbl_lms_reportes set avance='".$unico->AvanceCierre."', estado='EN_PROCESO' where id='".$unico->IdReportes."'</h3>";
			$sql_update="update tbl_lms_reportes set avance='".$unico->AvanceCierre."', estado='EN_PROCESO' where id='".$unico->IdReportes."'";
			    $connexion->query($sql_update);
				$connexion->execute();			
		}

	}
	$cuenta_casos_cron++;
}


		$tipo_check="CHECK 35";
		$texto1="$tipo_check select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)>0	and (h.fecha_inicio='0000-00-00' or h.fecha_inicio is null);";
		$sql_1="select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)>0 and (h.fecha_inicio='0000-00-00' or h.fecha_inicio is null);";	
	       		$connexion->query($sql_1);
				$cod_1 = $connexion->resultset();
  	$texto1="$tipo_check - Count To Fix ".count($cod_1);	
 		$sql_2="select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)>0 and (h.fecha_inicio='0000-00-00' or h.fecha_inicio is null)";
   	       		$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();
  foreach ($cod_2 as $unico){
  			$sql_2_1="select min(fecha) as min from tbl_objetos_finalizados where rut='".$unico->rut."' and id_curso='".$unico->id_curso."'";
     			$connexion->query($sql_2_1);
				$cod_2_1 = $connexion->resultset();				

 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set fecha_inicio='". $cod_2_1[0]->min."'
 		   	 	 where  rut='".$unico->rut."' and id_curso='".$unico->id_curso."' ";
    			$connexion->query($sqlUpdate_1_1);
				$connexion->execute();					 
    			
  }
		$sql_1="select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)>0 and (h.fecha_inicio='0000-00-00' or h.fecha_inicio is null);";
       			$connexion->query($sql_1);
				$cod_1 = $connexion->resultset();	
		$sql_1=str_replace("'",'"',$sql_1);
		$texto1="$tipo_check - Count Not Fixed  ".count($cod_1)." ".$sql_1;

$tipo_check="CHECK 36";
		$texto1="$tipo_check select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)='100' and (h.fecha_termino='0000-00-00' or h.fecha_termino is null);";
		$sql_1=" select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)='100' and (h.fecha_termino='0000-00-00' or h.fecha_termino is null);";	
       			$connexion->query($sql_1);
				$cod_1 = $connexion->resultset();	
  	$texto1="$tipo_check - Count To Fix ".count($cod_1);		 
 		$sql_2=" select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)='100' and (h.fecha_termino='0000-00-00' or h.fecha_termino is null);";
           		$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();	
  foreach ($cod_2 as $unico){
  			$sql_2_1="select max(fecha) as max from tbl_objetos_finalizados where rut='".$unico->rut."' and id_curso='".$unico->id_curso."'";
     			$connexion->query($sql_2_1);
				$cod_2_1 = $connexion->resultset();					

 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set fecha_termino='". $cod_2_1[0]->max."'
 		   	 	 where  rut='".$unico->rut."' and id_curso='".$unico->id_curso."' ";
    			$connexion->query($sqlUpdate_1_1);
				$connexion->execute();				 
    			
  }
		$sql_1=" select h.* from tbl_lms_reportes h where h.modalidadcurso='1' and round(h.avance)='100' and (h.fecha_termino='0000-00-00' or h.fecha_termino is null);";
         		$connexion->query($sql_1);
				$cod_1 = $connexion->resultset();	
	$sql_1=str_replace("'",'"',$sql_1);
		$texto1="$tipo_check - Count Not Fixed  ".count($cod_1)." ".$sql_1;



 		$sql_2="select h.*, 
						(select count(id) from tbl_objeto where id_curso=h.id_curso and tipo_objeto='5' and (cm='' or cm is null) ) as numEvaluaciones
						  from tbl_lms_reportes h 
						where (select count(id) from tbl_objeto where id_curso=h.id_curso and tipo_objeto='5' and (cm='' or cm is null) )='0'
						group by h.id_curso	";
           		$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();		
  foreach ($cod_2 as $unico){

 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set resultado='-'
 		   	 	 where  id_curso='".$unico->id_curso."' ";
 		   	 	 //echo "<h1>$sqlUpdate_1_1</h1><br>";
    			$connexion->query($sqlUpdate_1_1);
				$connexion->execute();					 
    			
  }
	
	$sql_2="select h.* from tbl_lms_reportes h where h.avance='100' and h.resultado='-' and h.estado='REPROBADO'
						";
           		$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();		
  foreach ($cod_2 as $unico){

 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set estado='APROBADO'
 		   	 	 where  id_curso='".$unico->id_curso."' and rut='".$unico->rut."'";
 		   	 	 //echo "<h1>$sqlUpdate_1_1</h1><br>";
    			$connexion->query($sqlUpdate_1_1);
				$connexion->execute();					 
    			
  }

$tipo_check="CHECK 40";
	
 		$sql_2="SELECT 	h.*, round(h.resultado) AS nota,
	( 		SELECT			nota_aprobacion		FROM			tbl_objeto		WHERE			id_curso = h.id_curso		AND cm <> 'DIAGNOSTICO'
		AND nota_aprobacion > 0		LIMIT 1	) AS nota_aprobacion,
	(		SELECT			estado		FROM			tbl_lms_reportes		WHERE			rut = h.rut		AND id_curso = h.id_curso
	) AS estadoReportes,
	(		SELECT			count(id)		FROM			tbl_objeto		WHERE			id_curso = h.id_curso	) AS Objetos,
	(		SELECT			count(id)		FROM			tbl_objetos_finalizados		WHERE			rut = h.rut		AND id_curso = h.id_curso
	) AS ObjetosFinalizados
FROM
	tbl_lms_reportes h
WHERE
	h.avance = '100' AND h.fecha_inicio >= '2021-01-01' AND round(h.resultado) >= (	SELECT		nota_aprobacion	FROM		tbl_objeto	WHERE
		id_curso = h.id_curso	AND nota_aprobacion > 0	LIMIT 1)
AND h.estado = 'REPROBADO' AND (	SELECT		nota_aprobacion	FROM		tbl_objeto	WHERE		id_curso = h.id_curso	AND cm is null	AND nota_aprobacion > 0
	LIMIT 1) > 0;";
    
	           	$connexion->query($sql_2);
				$cod_2 = $connexion->resultset();	
  foreach ($cod_2 as $unico){

 		   	 	$sqlUpdate_1_1 = "	update tbl_lms_reportes set estado='APROBADO'
 		   	 	 where  rut='".$unico->rut."' and id_curso='".$unico->id_curso."' ";
    			$connexion->query($sqlUpdate_1_1);
				$connexion->execute();				 
    			
  }
}

function reportes_online_trae_c1c2c3c4($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_c1_c2_c3_c4 WHERE id_empresa = :id_empresa";
    //echo $sql;exit();
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_groupby_c1c2c3c4($c)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT $c as dato FROM tbl_reportes_online_usuario WHERE $c <> '' GROUP BY $c ORDER BY $c";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lista_cursos_programa_data($id_empresa, $tipo_groupby)
{
    $connexion = new DatabasePDO();
    if ($tipo_groupby == "Curso") {
        $sql = "SELECT id_curso as id, curso as nombre FROM tbl_reportes_online_curso WHERE curso <> '' AND inactivo = '0' GROUP BY id_curso ORDER BY curso";
    } elseif ($tipo_groupby == "Programa") {
        $sql = "SELECT h.id_programa as id, h.programa as nombre, (SELECT id_empresa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa)
        FROM tbl_reportes_online_curso h WHERE h.programa <> '' AND inactivo = '0'
        AND (SELECT id_empresa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa) = '$id_empresa' GROUP BY h.id_programa ORDER BY h.programa";
        
    } elseif ($tipo_groupby == "ProgramaDetalle") {
        $sql = "SELECT h.id_programa as id, h.programa as nombre, (SELECT id_empresa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa)
        FROM tbl_reportes_online_curso h WHERE h.programa <> '' AND inactivo = '0'
        AND (SELECT id_empresa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa) = '$id_empresa' GROUP BY h.id_programa ORDER BY h.programa";
        
    } elseif ($tipo_groupby == "Agrupaciones") {
        $sql = "SELECT h.* FROM tbl_reportes_online_agrupaciones h GROUP BY h.id_agrupacion";
    }
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_busca_programas_dado_idCurso($id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_curso WHERE id_curso = :id_curso AND inactivo = '0'";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_ListaCursoDadoIdAgrupacion($id_agrupacion)
{
    $connexion = new DatabasePDO();
    $sql = "
    SELECT h.*, (SELECT curso FROM tbl_reportes_online_curso WHERE id_curso = h.id_curso LIMIT 1) as nombre_curso
    FROM tbl_reportes_online_agrupaciones h WHERE h.id_agrupacion = :id_agrupacion";
    $connexion->query($sql);
    $connexion->bind(':id_agrupacion', $id_agrupacion);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_Insert_agrupacion_data($id_agrupacion, $nombre_agrupacion, $id_curso)
{
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $nombre_agrupacion = utf8_decode($nombre_agrupacion);
    $sql = "INSERT INTO tbl_reportes_online_agrupaciones (nombre, id_curso, id_agrupacion)
    VALUES (:nombre_agrupacion, :id_curso, :id_agrupacion)";
    $connexion->query($sql);
    $connexion->bind(':nombre_agrupacion', $nombre_agrupacion);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_agrupacion', $id_agrupacion);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reporte_solo_obligatorio($id_curso, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT fecha_inicio, fecha_termino, fecha_inscripcion, avance, resultado, estado FROM tbl_lms_reportes WHERE id_curso = :id_curso AND rut = :rut AND curso_opcional = '0'";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reporte_v2($id_curso, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id, fecha_inicio, fecha_termino, fecha_inscripcion, avance, resultado, estado, curso_opcional FROM tbl_lms_reportes WHERE id_curso = :id_curso AND rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reporte_v3($id_curso, $rut, $incluye_or, $incluye_or_id_curso2, $incluye_or_id_curso3, $incluye_or_id_curso4)
{
    $connexion = new DatabasePDO();
    if ($incluye_or !== "") {
        $sql = "SELECT id, fecha_inicio, fecha_termino, fecha_inscripcion, avance, resultado, estado, curso_opcional, id_curso FROM tbl_lms_reportes WHERE rut = :rut AND (id_curso = :incluye_or_id_curso2 OR id_curso = :incluye_or_id_curso3 OR id_curso = :incluye_or_id_curso4 OR id_curso = :id_curso) ORDER BY ROUND(avance) DESC, ROUND(resultado) DESC, estado ASC LIMIT 1";
        $connexion->bind(':incluye_or_id_curso2', $incluye_or_id_curso2);
        $connexion->bind(':incluye_or_id_curso3', $incluye_or_id_curso3);
        $connexion->bind(':incluye_or_id_curso4', $incluye_or_id_curso4);
    } else {
        $sql = "SELECT id, fecha_inicio, fecha_termino, fecha_inscripcion, avance, resultado, estado, curso_opcional, id_curso FROM tbl_lms_reportes WHERE id_curso = :id_curso AND rut = :rut";
    }
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_onlines_usuarios_detalle_agrupaciones($row_query_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_cursos_usuarios_detalle WHERE id > 0 AND ($row_query_curso) GROUP BY rut";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_onlines_usuarios_detalle_agrupaciones_v2($id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_cursos_usuarios_detalle WHERE id > 0 AND id_curso = :id_curso GROUP BY rut";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_onlines_usuarios_detalle_agrupaciones_v2_activas($id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM rel_lms_rut_id_curso_id_inscripcion WHERE id > 0 AND id_curso = :id_curso AND opcional = '0' AND activa = '1' GROUP BY rut";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_onlines_usuarios_detalle_agrupaciones_rut_v2($id_curso, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_cursos_usuarios_detalle WHERE id > 0 AND id_curso = :id_curso AND rut = :rut GROUP BY rut";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_usuarios_detalle_actividades_agrupaciones($rut, $id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reporte_actividades_full WHERE rut = :rut AND id_curso = :id_curso";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lista_usuarios_data()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT rut FROM tbl_reportes_online_usuario LIMIT 5";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_maxAgrupacion()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT MAX(id_agrupacion) AS idMax FROM tbl_reportes_online_agrupaciones";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    $idMax = $cod[0]->idMax + 1;
    return $idMax;
}
function reportes_online_c1_c2_c3_c4($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT campo1, campo2, campo3, campo4 FROM tbl_empresa WHERE id = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    $campos[1] = $cod[0]->campo1;
    $campos[2] = $cod[0]->campo2;
    $campos[3] = $cod[0]->campo3;
    $campos[4] = $cod[0]->campo4;
    return $campos;
}
function reportes_online_curso_dado_idcurso($id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_curso WHERE id_curso = :id_curso";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_curso_dado_idcursorut($id_curso, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_cursos_usuarios_detalle WHERE id_curso = :id_curso AND rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_inscripcion_dado_idcurso_rut($rut, $id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM rel_lms_rut_id_curso_id_inscripcion 
            WHERE id_curso = :id_curso AND rut = :rut 
            ORDER BY fecha_termino_inscripcion DESC 
            LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_curso_dado_programa($id_programa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_curso WHERE id_programa = :id_programa";
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_usuario_rut($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_usuario WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_usuario_rut_v2($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_usuario WHERE rut = :rut
            AND (c1 = 'Division Consumo' OR c1 = 'Division Comercial' OR c1 = 'Division Neg. Especiales' OR c1 = 'Division Grandes Empresas')";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_usuario_rut_idCurso_lmsReportes($rut, $id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_reportes WHERE rut = :rut AND id_curso = :id_curso";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reportes_dado_id_agrupacion_v2($id_agrupacion)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_agrupaciones WHERE id > 0 LIMIT 1";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_usuarios_activos($divisiones)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_reportes_online_usuario WHERE id > 0";
    if ($divisiones !== "") {
        $sql .= " AND $divisiones";
    }
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_usuarios_activos_contrato($divisiones)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT *
            FROM tbl_usuario
            WHERE id > 0
            AND (tipo_contrato = 'CDCON00001' OR tipo_contrato = 'CDCON00002')
            AND vigencia_descripcion = ''";
    if ($divisiones !== "") {
        $sql .= " $divisiones";
    }
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reportes_dado_id_agrupacion($id_agrupacion){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_reportes_online_agrupaciones h WHERE h.id_agrupacion = :id_agrupacion LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_agrupacion', $id_agrupacion);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reportes_dado_id_agrupacion_cursos_activos(){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_curso, (SELECT nombre FROM tbl_lms_curso WHERE id = h.id_curso) AS nombre_curso FROM rel_lms_rut_id_curso_id_inscripcion h WHERE h.activa = '1' AND h.opcional = '0' GROUP BY h.id_curso";
    $cod = $connexion->query($sql)->resultset();
    return $cod;
}
function reportes_online_lms_reportes_dado_id_curso($id_curso){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_lms_reportes h WHERE h.id_curso = :id_curso " . $_SESSION["c1h"] . " " . $_SESSION["c2h"] . " " . $_SESSION["c3h"] . " " . $_SESSION["c4h"];
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reportes_dado_rut($rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_lms_reportes h WHERE h.rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_lms_reportes_dado_completo(){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_lms_reportes h WHERE h.id > 0 AND modalidadcurso = '1' " . $_SESSION["c1h"] . " " . $_SESSION["c2h"] . " " . $_SESSION["c3h"] . " " . $_SESSION["c4h"] . "";
    //echo $sql; exit();
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function reportes_online_Malla_dado_id_curso_rut_programa($rut, $id_curso, $id_programa){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_malla FROM tbl_inscripcion_usuarios h WHERE h.id_curso = :id_curso AND h.rut = :rut AND id_empresa = :id_empresa LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $_SESSION["id_empresa"]);
    $cod = $connexion->resultset();
    return $cod[0]->id_malla;
}
function reportes_online_nombremalla($id_malla){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.nombre FROM tbl_lms_malla h WHERE h.id = :id_malla LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_malla', $id_malla);
    $cod = $connexion->resultset();
    return $cod[0]->nombre;
}
function reportes_online_lms_reportes_dado_id_programa($id_programa){
    $connexion = new DatabasePDO();
    $sql = "
        select h.rut, h.id_curso, round(avg(h.avance)) as avance,
        if(h.resultado='-','',round(avg(h.resultado))) as resultado,
        h.estado,
        (select inactivo from tbl_reportes_online_curso where id_curso=h.id_curso and id_programa=h.id_programa) as inactivo

        from tbl_lms_reportes h where h.id_programa=:id_programa
        and (select inactivo from tbl_reportes_online_curso where id_curso=h.id_curso and id_programa=h.id_programa)='0'

        ".$_SESSION["c1h"]." 
        ".$_SESSION["c2h"]." 
        ".$_SESSION["c3h"]." 
        ".$_SESSION["c4h"]." 

        group by h.rut, h.id_curso

        order by h.rut
    ";
    //echo $sql; exit();
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $cod = $connexion->resultset();
    return $cod;		
}
function reportes_online_lms_reportes_consolidado_dado_id_programa($id_programa){
    $connexion = new DatabasePDO();
    $sql = "
        select h.*

        from tbl_reportes_online_cursos_usuarios_detalle h where h.id_programa=:id_programa
        and curso_opcional='0'
        ".$_SESSION["c1h"]." 
        ".$_SESSION["c2h"]." 
        ".$_SESSION["c3h"]." 
        ".$_SESSION["c4h"]." 

        order by h.rut;
    ";
    //echo "<br>".$sql."<br>";
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $cod = $connexion->resultset();
    return $cod;		
}
function reportes_online_lms_reportes_consolidado_cuenta_cursos_dado_id_programa($id_programa, $rut){
    $connexion = new DatabasePDO();
    $sql = "
        select count(h.id) as cuenta_cursos_max

        from tbl_reportes_online_cursos_usuarios_detalle h 
        where h.id_programa=:id_programa
        and curso_opcional='0'
        and rut=:rut
    ";
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->cuenta_cursos_max;		
}
function reportes_online_lms_reportes_consolidado_fechas_dado_id_programa($tipo_fecha, $tipoMinMax, $id_programa, $rut, $tipoProgCurso){
    $connexion = new DatabasePDO();
    $sql = "
        select $tipoMinMax($tipo_fecha) as fecha

        from tbl_lms_reportes where 
        rut=:rut and $tipoProgCurso=:id_programa and $tipo_fecha<>'0000-00-00'
    ";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_programa', $id_programa);
    $cod = $connexion->resultset();
    return $cod[0]->fecha;		
}
function reportes_online_lms_reportes_busca_avance_resultado_dado_rut_id_curso($rut, $id_curso){
    $connexion = new DatabasePDO();
    $sql = "
        select h.rut, h.id_curso, round(avg(h.avance)) as avance,
        if(h.resultado='-','-',round(avg(h.resultado))) as resultado,
        h.fecha_inicio,
        h.fecha_termino,
        (select inactivo from tbl_reportes_online_curso where id_curso=h.id_curso and id_programa=h.id_programa) as inactivo

        from tbl_lms_reportes h where 
        h.rut=:rut and h.id_curso=:id_curso
        and (select inactivo from tbl_reportes_online_curso where id_curso=h.id_curso and id_programa=h.id_programa)='0'
    ";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;		
}
function Otas_2022_Insert_Tbl_inscripcion_usuario_reportes($id_inscripcion, $id_curso, $id_empresa, $fecha, $id_malla){
    $connexion = new DatabasePDO();
	
	$Ruts = BuscaRutPorIdInscripcion_2022($id_inscripcion);
	
	foreach ($Ruts as $unico) {
        $Aprobados_continue = BuscaEstaAvanceRutCurso_2022($unico->rut, $id_curso);
        if ($Aprobados_continue > 0) {
            continue;
        }

        $sql = "INSERT INTO tbl_inscripcion_usuarios (id_inscripcion, rut, id_curso, id_empresa, fecha, id_malla)
        VALUES (:id_inscripcion, :rut, :id_curso, :id_empresa, :fecha, :id_malla)";
        
        $connexion->query($sql);
        $connexion->bind(':id_inscripcion', $id_inscripcion);
        $connexion->bind(':rut', $unico->rut);
        $connexion->bind(':id_curso', $id_curso);
        $connexion->bind(':id_empresa', $id_empresa);
        $connexion->bind(':fecha', $fecha);
        $connexion->bind(':id_malla', $id_malla);
        $connexion->execute();
    }
}
function Otas_2022_lista_participantes_por_ota_data($id_inscripcion, $table, $vigencia_usuarios){
    $connexion = new DatabasePDO();
    
    if ($vigencia_usuarios == "Vigentes") {
        $query_adicional = " and (select rut from tbl_reportes_online_usuario where rut = h.rut) <> '' ";
    } else {
        $query_adicional = "";
    }
    $sql = "SELECT * FROM $table h WHERE h.id > 0 $query_adicional AND h.id_inscripcion = :id_inscripcion $query_adicional";
        
    $connexion->query($sql);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;        
}
function Otas_2022_check_por_ota($id_inscripcion, $table, $vigencia_usuarios){
    $connexion = new DatabasePDO();
    
    if ($vigencia_usuarios == "Vigentes") {
        $query_adicional = " and (select rut from tbl_reportes_online_usuario where rut = h.rut) <> '' ";
    } else {
        $query_adicional = "";
    }
    $sql = "SELECT COUNT(h.id) as cuenta FROM $table h WHERE h.id > 0 $query_adicional AND h.id_inscripcion = :id_inscripcion $query_adicional";
        
    $connexion->query($sql);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;            
}
function Otas_2022_checkUserVigente($rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_reportes_online_usuario h WHERE h.rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function Otas_2022_checkUserVigenteTblusuario($rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_usuario WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function Otas_2022_Lista_Otas_Activas_data($PRINCIPAL, $id_empresa, $filtro, $activa){
    $connexion = new DatabasePDO();
    $Query = "";
    if($activa == "Activa"){
        $Query = " WHERE activa = '1'";
    }
    elseif($activa == "Inactiva"){
        $Query = " WHERE activa = '0'";
    }
    $sql = "SELECT * FROM rel_lms_id_curso_id_inscripcion" . $Query . " ORDER BY fecha_termino_inscripcion DESC";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function Otas_2022_Lista_Otas_Activas_Groupby_ota_data($PRINCIPAL, $id_empresa, $filtro, $activa){
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $Query = "";
    if($activa == "Activa"){
        $Query = " WHERE activa = '1'";
    }
    elseif($activa == "Inactiva"){
        $Query = " WHERE activa = '0'";
    }
    elseif($activa == "Futura"){
        $Query = " WHERE activa = '0' AND fecha_inicio_inscripcion > '$hoy'";
    }
    elseif($activa == "Pasada"){
        $Query = " WHERE activa = '0' AND fecha_termino_inscripcion < '$hoy'";
    }
    $sql = "SELECT * FROM rel_lms_id_curso_id_inscripcion" . $Query . " GROUP BY id_inscripcion ORDER BY fecha_termino_inscripcion DESC";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function Otas_2022_cuenta_multimalla_Otas_Activas_data($id_inscripcion){
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(id) AS cuenta FROM rel_lms_id_curso_id_inscripcion WHERE id_inscripcion = :id_inscripcion";
    $connexion->query($sql);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}
function Otas_2022_visualiza_multimalla_Otas_Activas_data($id_inscripcion){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT nombre FROM tbl_lms_malla WHERE id=h.id_malla) AS malla
        FROM rel_lms_id_curso_id_inscripcion h
        WHERE h.id_inscripcion=:id_inscripcion ";
    $connexion->query($sql);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $cod = $connexion->resultset();
    return $cod;
}
function Gestion_Ota_2022_BuscaDatos_IdImparticion_data($id_imparticion)
{
    $connexion = new DatabasePDO();
    $sql = " SELECT h.*
        FROM rel_lms_id_curso_id_inscripcion h
        WHERE h.id_inscripcion=:id_imparticion ";
    $connexion->query($sql);
    $connexion->bind(':id_imparticion', $id_imparticion);
    $cod = $connexion->resultset();
    return $cod;
}
function Gestion_Ota_2022_BuscaDatos_Update_IdImparticion_data($id, $id_inscripcion, $fecha_termino_nueva){
    $connexion = new DatabasePDO();
    $sql = "UPDATE rel_lms_id_curso_id_inscripcion SET fecha_termino_inscripcion=:fecha_termino_nueva WHERE id=:id";
    $connexion->query($sql);
    $connexion->bind(':fecha_termino_nueva', $fecha_termino_nueva);
    $connexion->bind(':id', $id);
    $connexion->execute();
    
    $sql = "UPDATE rel_lms_rut_id_curso_id_inscripcion SET fecha_termino_inscripcion=:fecha_termino_nueva WHERE id_inscripcion=:id_inscripcion";
    $connexion->query($sql);
    $connexion->bind(':fecha_termino_nueva', $fecha_termino_nueva);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->execute();
}
//GESTION OTA // CRON INSCRIPCION RESETEO
//cron_tbl_lms_rut_id_inscripcion_reset_inscripcion
function Cron_inscripcion_reseteo_lee_tbl_lms_rut_id_inscripcion_reset_inscripcion_data()
{
    $connexion = new DatabasePDO();
    $sql = "
        SELECT h.*, 
        (SELECT rut FROM tbl_usuario WHERE rut=h.rut) AS rut_vigente,
        (SELECT id_curso FROM tbl_inscripcion_curso WHERE codigo_inscripcion=h.id_inscripcion_nueva) AS id_curso_vigente,
        (SELECT COUNT(id_curso) FROM rel_lms_id_curso_id_inscripcion WHERE id_inscripcion=h.id_inscripcion_nueva) AS Id_curso_vigente_rel_lms,
        (SELECT id_curso FROM rel_lms_id_curso_id_inscripcion WHERE id_inscripcion=h.id_inscripcion_nueva LIMIT 1) AS Id_curso_vigente_rel_lms,
        (SELECT fecha_inicio_inscripcion FROM rel_lms_id_curso_id_inscripcion WHERE id_inscripcion=h.id_inscripcion_nueva AND id_curso=h.id_curso LIMIT 1) AS fecha_inicio_inscripcion,
        (SELECT fecha_termino_inscripcion FROM rel_lms_id_curso_id_inscripcion WHERE id_inscripcion=h.id_inscripcion_nueva AND id_curso=h.id_curso LIMIT 1) AS fecha_termino_inscripcion,
        (SELECT rut_ejecutivo FROM rel_lms_id_curso_id_inscripcion WHERE id_inscripcion=h.id_inscripcion_nueva AND id_curso=h.id_curso LIMIT 1) AS rut_ejecutivo,
        (SELECT activa FROM rel_lms_id_curso_id_inscripcion WHERE id_inscripcion=h.id_inscripcion_nueva AND id_curso=h.id_curso LIMIT 1) AS activa
        FROM tbl_lms_rut_id_inscripcion_reset_inscripcion h
        WHERE h.realizado='0'
    ";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function Cron_inscripcion_reseteo_lee_tbl_lms_reportes_aprobado_data($rut, $id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_lms_reportes WHERE rut = :rut AND id_curso = :id_curso AND estado = 'APROBADO' LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}
function Cron_inscripcion_reseteo_deleteFull($rut, $id_curso)
{
    $connexion = new DatabasePDO();

    $sql = "UPDATE tbl_lms_reportes SET estado = 'NO_INICIADO', avance = '0', resultado = '', puntos = '0', medallas = '0', fecha_inicio = '0000-00-00', fecha_termino = '0000-00-00' WHERE rut = :rut AND id_curso = :id_curso";
    $connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
    
    $sql = "DELETE FROM tbl_objetos_finalizados WHERE rut = :rut AND id_curso = :id_curso";
    $connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();

	$sql="delete  FROM tbl_inscripcion_cierre WHERE rut = '".$rut."' and  id_curso = '".$id_curso."'; ";
  	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_capsulas_rating WHERE rut = '".$rut."' and  id_modulo LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_evaluaciones_respuestas_intentos WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_evaluaciones_respuestas WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_evaluaciones_sesion WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_evaluaciones_intentos WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_evaluaciones_asociacion_preguntas_usuario WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_reporte_actividades_full WHERE rut = '".$rut."' and  cod_modulo LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_lms_reportes_full WHERE rut = '".$rut."' and  id_curso = '".$id_curso."'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_json_ext WHERE rut = '".$rut."' and  id_curso = '".$id_curso."'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_enc_elearning_respuestas  WHERE rut = '".$rut."' and  id_curso = '".$id_curso."' ; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_logs_navegacion WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_objeto_estado_diario WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%'; ";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
	
	$sql="delete  FROM tbl_objetos_nofinalizados WHERE rut = '".$rut."' and  id_objeto LIKE '%".$id_curso."%';	";
	$connexion->query($sql);     $connexion->bind(':rut', $rut);    $connexion->bind(':id_curso', $id_curso);    $connexion->execute();
}
function Cron_inscripcion_reseteo_delete_Insert($rut, $id_curso, $id_inscripcion, $fecha_inicio_inscripcion, $fecha_termino_inscripcion, $rut_ejecutivo, $activa)
{
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO rel_lms_rut_id_curso_id_inscripcion (rut, id_curso, id_inscripcion, fecha_inicio_inscripcion, fecha_termino_inscripcion, rut_ejecutivo, activa)
            VALUES (:rut, :id_curso, :id_inscripcion, :fecha_inicio_inscripcion, :fecha_termino_inscripcion, :rut_ejecutivo, :activa)";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->bind(':fecha_inicio_inscripcion', $fecha_inicio_inscripcion);
    $connexion->bind(':fecha_termino_inscripcion', $fecha_termino_inscripcion);
    $connexion->bind(':rut_ejecutivo', $rut_ejecutivo);
    $connexion->bind(':activa', $activa);
    $connexion->execute();
}
function Cron_tbl_lms_rut_id_inscripcion_reset_inscripcion_update($id)
{
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_lms_rut_id_inscripcion_reset_inscripcion SET realizado = '1' WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
    echo "<br>$sql<hr>";
}
function CheckOtaParticipante_2022($rut, $id_inscripcion, $id_curso)
{
    $connexion = new DatabasePDO();
    
    $sql1 = "SELECT id_inscripcion as dato FROM tbl_inscripcion_usuarios WHERE rut = :rut AND id_inscripcion = :id_inscripcion";
    $connexion->query($sql1);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $cod1 = $connexion->resultset();
    
    $sql2 = "SELECT id_inscripcion as dato FROM tbl_inscripcion_usuarios WHERE rut = :rut AND id_curso = :id_curso LIMIT 1";
    $connexion->query($sql2);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod2 = $connexion->resultset();
    
    $sql3 = "SELECT id_malla as dato FROM tbl_inscripcion_usuarios WHERE rut = :rut AND id_inscripcion = :id_inscripcion";
    $connexion->query($sql3);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $cod3 = $connexion->resultset();
    
    $sql4 = "SELECT id_malla as dato FROM rel_lms_malla_persona WHERE rut = :rut AND id_malla = :id_malla";
    $connexion->query($sql4);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_malla', $cod3[0]->dato);
    $cod4 = $connexion->resultset();
    
    $sql5 = "SELECT avance as dato FROM tbl_lms_reportes WHERE rut = :rut AND id_curso = :id_curso";
    $connexion->query($sql5);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod5 = $connexion->resultset();
    
    $sql6 = "SELECT id_malla as dato FROM tbl_inscripcion_usuarios WHERE rut = :rut AND id_curso = :id_curso";
    $connexion->query($sql6);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod6 = $connexion->resultset();
    
    $arreglo[1] = $cod1[0]->dato;
    $arreglo[2] = $cod2[0]->dato;
    $arreglo[3] = $cod3[0]->dato;
    $arreglo[4] = $cod4[0]->dato;
    $arreglo[5] = $cod5[0]->dato;
    $arreglo[6] = $cod6[0]->dato;
    
    return $arreglo;
}
function BuscaEstaAvanceRutCurso_2022($rut, $id_curso){
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_lms_reportes where rut=:rut and id_curso=:id_curso and estado='APROBADO'";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}
function BuscaNombreMalla_2022($id_malla){
    $connexion = new DatabasePDO();
    $sql = "SELECT nombre FROM tbl_lms_malla where id=:id_malla";
    $connexion->query($sql);
    $connexion->bind(':id_malla', $id_malla);
    $cod = $connexion->resultset();
    return $cod[0]->nombre;
}
function BuscaRutPorIdInscripcion_2022($id_inscripcion){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM `rel_lms_rut_id_curso_id_inscripcion` WHERE `id_inscripcion` = :id_inscripcion";
    $connexion->query($sql);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $cod = $connexion->resultset();
    return $cod;
}
function Updatelms0202_busca_rel_malla_curso($id_curso, $id_malla)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* from rel_lms_malla_curso h where h.id_curso=:id_curso and h.id_malla=:id_malla";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_malla', $id_malla);
    $cod = $connexion->resultset();
    return $cod;
}
function Updatelms2020_sinFecha($rut, $id_curso){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
        (select fecha from tbl_objetos_finalizados where rut=h.rut and id_curso=h.id_curso order by fecha ASC limit 1) as FI,  
        (select fecha from tbl_objetos_finalizados where rut=h.rut and id_curso=h.id_curso order by fecha DESC limit 1) as FT
        from tbl_lms_reportes h 
        where h.rut=:rut 
        and h.id_curso=:id_curso";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;    
}
function Updatelms0202_busca_Fecha_inscriocion_curso($rut, $id_curso)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.fecha from tbl_inscripcion_usuarios h where h.rut=:rut and h.id_curso=:id_curso limit 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function faq_2023_data(){
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $sql = "select * from tbl_admin_faq where id_empresa='78'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function recofullactualiza2020(){
    $connexion = new DatabasePDO();
   
    $sql = "SELECT h.* FROM tbl_reconoce_gracias_full h WHERE h.zona IS NULL ORDER BY fecha DESC, hora DESC";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    foreach ($cod as $unico) {
        $rut_remitente = $unico->rut_remitente;
        $Rem = TraeDatosUsuario($rut_remitente);
        
        $rut_destinatario = $unico->rut_destinatario;
        $Dest = TraeDatosUsuario($rut_destinatario);
        
        $rut_jefatura = $Dest[0]->jefe;
        $Jefe = TraeDatosUsuario($rut_jefatura);
        
        $sql_2 = "UPDATE tbl_reconoce_gracias_full
            SET zona = '".$Dest[0]->zona."', seccion = '', glosa_cui = '".$Dest[0]->unidad_negocio."', 
            nombre_destinatario = '".$Dest[0]->nombre_completo."',  
            zona_remitente = '".$Rem[0]->zona."', seccion_remitente = '', glosa_cui_remitente = '".$Rem[0]->unidad_negocio."', 
            nombre_jefatura = '".$Jefe[0]->nombre_completo."'
            WHERE id = '".$unico->id."'";
        
        $connexion->query($sql_2);
    }
    return $cod;    
}
function reco_reconocer_full_2020_data($tipo){
    $connexion = new DatabasePDO();
   
    if ($tipo == "AMONESTACION") { $jTIPO = " AND tipo = 'AMONESTACION' "; } 
	elseif ($tipo == "RECONOCIMIENTO") { $jTIPO = " AND tipo <> 'AMONESTACION' "; } 
	else { $jTIPO = " ";  }

    $Adm = DatosUsuarioAdmin($_SESSION["user_"]);
    if ($Adm[0]->filtro_division_personas == "1") {
        $jDivision = " AND division <> 'Division Personas y Organizacion'";
    } else {
        $jDivision = " ";
    }
  
    $sql = "SELECT * FROM tbl_reconoce_gracias_full WHERE id > 0 $jTIPO $jDivision ORDER BY fecha DESC, hora DESC";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function Amonestaciones_Buscar_Rut($rut_col, $id_empresa){
    $connexion = new DatabasePDO();
   
    $jTIPO = " AND (tipo = 'AMONESTACION' OR tipo = 'GRACIAS' OR tipo = 'COLABORACION' OR tipo = 'RECONOCIMIENTO') ";
    $Adm = DatosUsuarioAdmin($_SESSION["user_"]);
    if ($Adm[0]->filtro_division_personas == "1") {
        $jDivision = " AND division <> 'Division Personas y Organizacion'";
    } else { $jDivision = " "; }
    $sql = "SELECT * FROM tbl_reconoce_gracias_full WHERE id > 0 $jTIPO $jDivision AND rut_destinatario = '$rut_col' AND id_empresa = '$id_empresa' ORDER BY fecha DESC, hora DESC";
		
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function Amonestacion_Update_Id($accion, $id_amon_full, $tipo_amonestacion, $mensaje)
{
    $connexion = new DatabasePDO();

    if ($accion == "Actualizar") {
        $tipo_amonestacion = utf8_decode($tipo_amonestacion);
        $mensaje = utf8_decode($mensaje);

        $sql = "UPDATE tbl_reconoce_gracias_full 
                SET categorita = :tipo_amonestacion, id_categoria = :tipo_amonestacion, mensaje = :mensaje, rut_update = :user
                WHERE id = :id_amon_full";

        $connexion->query($sql);
        $connexion->bind(':tipo_amonestacion', $tipo_amonestacion);
        $connexion->bind(':mensaje', $mensaje);
        $connexion->bind(':user', $_SESSION["user_"]);
        $connexion->bind(':id_amon_full', $id_amon_full);
    } elseif ($accion == "Eliminar") {
        $sql = "UPDATE tbl_reconoce_gracias_full SET id_empresa = '99', rut_update = :user WHERE id = :id_amon_full";

        $connexion->query($sql);
        $connexion->bind(':user', $_SESSION["user_"]);
        $connexion->bind(':id_amon_full', $id_amon_full);
    }

    $connexion->execute();
}
function downloadudemyreportes()
{
    $connexion = new DatabasePDO();

    $sql = "SELECT h.user_email, 
            (SELECT rut FROM tbl_usuario WHERE email = h.user_email) AS rut_completo,
            (SELECT nombre_completo FROM tbl_usuario WHERE email = h.user_email) AS nombre_completo,
            (SELECT cargo FROM tbl_usuario WHERE email = h.user_email) AS cargo,
            (SELECT division FROM tbl_usuario WHERE email = h.user_email) AS division,
            h.course_id AS id_curso, 
            (SELECT curso_titulo FROM udemy_courses WHERE curso_codigo = h.course_id) AS curso,
            (SELECT curso_categoria FROM udemy_courses WHERE curso_codigo = h.course_id) AS categoria,
            (SELECT curso_subcategoria FROM udemy_courses WHERE curso_codigo = h.course_id) AS curso_subcategoria,
            h.user_role AS tipo_perfil,
            h.completion_ratio AS avance,
            h.num_video_consumed_minutes AS minutos_realizados,
            h.course_duration AS minutos_total_curso
            FROM udemy_user_activity_by_course h
            GROUP BY h.user_email, h.course_id";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function Lista_fc_eventos_data($id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*
            FROM tbl_postulables h
            WHERE h.id_empresa = :id_empresa AND YEAR(h.fecha) = YEAR(NOW())
            ORDER BY h.id_dimension, h.nombre";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function FC_Edit_data($id, $modalidad, $ficha, $institucion, $region, $dimension, $invisible, $id_empresa) {
    $connexion = new DatabasePDO();
    
    $nombre = utf8_decode($nombre);
    $descripcion = utf8_decode($descripcion);

    $sql = "UPDATE tbl_postulables
            SET modalidad=:modalidad,ficha=:ficha,dato4=:institucion,region=:region,dimension=:dimension,invisible=:invisible
            WHERE id=:id AND id_empresa=:id_empresa";

    $connexion->query($sql);
    $connexion->bind(':modalidad', $modalidad);
    $connexion->bind(':ficha', $ficha);
    $connexion->bind(':institucion', $institucion);
    $connexion->bind(':region', $region);
    $connexion->bind(':dimension', $dimension);
    $connexion->bind(':invisible', $invisible);
    $connexion->bind(':id', $id);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function lista_formacion_continua_data($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*,
                (SELECT COUNT(id) FROM tbl_postulaciones WHERE id_empresa=h.id_empresa AND id_postulable=h.id_postulable) AS postulantes,
                (SELECT COUNT(id) FROM tbl_postulaciones WHERE id_empresa=h.id_empresa AND id_postulable=h.id_postulable AND jefeok='SI') AS jefeok,
                (SELECT COUNT(id) FROM tbl_postulaciones WHERE id_empresa=h.id_empresa AND id_postulable=h.id_postulable AND (jefeok='NO' OR jefeok='NO_POR_FECHA')) AS jefeno,
                (SELECT COUNT(id) FROM tbl_postulaciones WHERE id_empresa=h.id_empresa AND id_postulable=h.id_postulable AND validacionok='SI') AS validados,
                (SELECT COUNT(id) FROM tbl_postulaciones WHERE id_empresa=h.id_empresa AND id_postulable=h.id_postulable AND validacionok='NO') AS rechazados
            FROM tbl_postulables h
            WHERE h.id_empresa=:id_empresa AND h.id_tipo='streaming' AND YEAR(h.fecha) = YEAR(NOW())
            ORDER BY h.dimension, h.nombre, h.fecha DESC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function TraeUsuarioBecas($idenc, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT rut, nombre_beca FROM tbl_becas WHERE id=:idenc";
    $connexion->query($sql);
    $connexion->bind(':idenc', $idenc);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function lista_formacion_continua_validacion_data($idcategoria, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_postulaciones h
            WHERE h.id_empresa=:id_empresa AND h.id_postulable=:idcategoria";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':idcategoria', $idcategoria);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function FC_NombrePostulable($id_postulable, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT nombre FROM tbl_postulables WHERE id_postulable = :id_postulable AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_postulable', $id_postulable);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->nombre;
}
function FC_DescripcionPostulable($id_postulable, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT descripcion FROM tbl_postulables WHERE id_postulable = :id_postulable AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_postulable', $id_postulable);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->descripcion;
}
function FC_actualizaEstado($idFC, $id_tipo, $v, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_postulaciones SET jefeok = :v WHERE id = :idFC AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':v', $v);
    $connexion->bind(':idFC', $idFC);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function DescargaTodasFCXLS_iD($id_empresa, $id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
            (SELECT dimension FROM tbl_postulables WHERE id_postulable = h.id_postulable AND id_empresa = h.id_empresa) AS curso,
            (SELECT nombre FROM tbl_postulables WHERE id_postulable = h.id_postulable AND id_empresa = h.id_empresa) AS evento,
            (SELECT descripcion FROM tbl_postulables WHERE id_postulable = h.id_postulable AND id_empresa = h.id_empresa) AS descripcion
            FROM tbl_postulaciones h
            WHERE h.id_empresa = :id_empresa
            AND h.id_postulable = :id
            ORDER BY h.fecha DESC, h.hora DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}
function DescargaTodasFCXLS($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
            (SELECT dimension FROM tbl_postulables WHERE id_postulable = h.id_postulable AND id_empresa = h.id_empresa) AS curso,
            (SELECT nombre FROM tbl_postulables WHERE id_postulable = h.id_postulable AND id_empresa = h.id_empresa) AS evento,
            (SELECT descripcion FROM tbl_postulables WHERE id_postulable = h.id_postulable AND id_empresa = h.id_empresa) AS descripcion
            FROM tbl_postulaciones h
            WHERE h.id_empresa = :id_empresa
            AND h.id_postulable <> ''
            AND YEAR(h.fecha) = YEAR(NOW())
            ORDER BY h.fecha DESC, h.hora DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_notificaciones_a_buscar_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT tipoenvio, COUNT(id) AS cuenta FROM tbl_notificaciones_pendientes WHERE id_empresa = :id_empresa GROUP BY tipoenvio";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_notificaciones_a_buscar_data_detalle($id_empresa, $tipoenvio) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_notificaciones_pendientes WHERE id_empresa = :id_empresa AND tipoenvio = :tipoenvio";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipoenvio', $tipoenvio);
    $cod = $connexion->resultset();
    return $cod;
}
function Notificaciones_crea_not_automaticas($tipoenvio, $nombre, $rut, $fecha_envio, $id_empresa, $to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, $subtitulo1, $texto1, $url, $texto_url, $texto2, $texto3, $texto4, $logo, $tipomensaje, $key, $template) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_notificaciones_automaticas (
        tipoenvio, nombre, rut, fecha_envio, id_empresa, hacia,
        nombreto, desde, nombrefrom, tipo, asunto,
        titulo1, subtitulo1, texto1, url, texto_url, texto2,
        texto3, texto4, logo, tipomensaje, clave, template
    ) VALUES (
        :tipoenvio, :nombre, :rut, :fecha_envio, :id_empresa, :to,
        :nombreto, :from, :nombrefrom, :tipo, :subject,
        :titulo1, :subtitulo1, :texto1, :url, :texto_url, :texto2,
        :texto3, :texto4, :logo, :tipomensaje, :key, :template )";
    $connexion->query($sql);
    $connexion->bind(':tipoenvio', $tipoenvio);
    $connexion->bind(':nombre', $nombre);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha_envio', $fecha_envio);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':to', $to);
    $connexion->bind(':nombreto', $nombreto);
    $connexion->bind(':from', $from);
    $connexion->bind(':nombrefrom', $nombrefrom);
    $connexion->bind(':tipo', $tipo);
    $connexion->bind(':subject', $subject);
    $connexion->bind(':titulo1', $titulo1);
    $connexion->bind(':subtitulo1', $subtitulo1);
    $connexion->bind(':texto1', $texto1);
    $connexion->bind(':url', $url);
    $connexion->bind(':texto_url', $texto_url);
    $connexion->bind(':texto2', $texto2);
    $connexion->bind(':texto3', $texto3);
    $connexion->bind(':texto4', $texto4);
    $connexion->bind(':logo', $logo);
    $connexion->bind(':tipomensaje', $tipomensaje);
    $connexion->bind(':key', $key);
    $connexion->bind(':template', $template);
    $connexion->execute();
}
function DeleteFullTbltbl_notificaciones_pendientes() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_notificaciones_pendientes";
    $connexion->query($sql);
    $connexion->execute();
}
function InsertNotificacionesPendientes($tipoenvio, $nombre, $rut, $fecha_envio, $id_empresa,$to, $nombreto, $from, $nombrefrom, $tipo, $subject, $titulo1, 
	$subtitulo1, $texto1, $url, $texto_url, $texto2, $texto3, $texto4, $logo, $tipomensaje, $key, $template) {

    $nombre = utf8_decode($nombre);
    $nombreto = utf8_decode($nombreto);
    $nombrefrom = utf8_decode($nombrefrom);
    $subject = utf8_decode($subject);
    $titulo1 = utf8_decode($titulo1);
    $subtitulo1 = utf8_decode($subtitulo1);
    $texto1 = utf8_decode($texto1);
    $texto_url = ($texto_url);
    $texto2 = ($texto2);
    $texto3 = ($texto3);
    $texto4 = ($texto4);

    $connexion = new DatabasePDO();
    $sql = "select id from tbl_notificaciones_pendientes where rut=:rut and fecha_envio=:fecha_envio and tipoenvio=:tipoenvio and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha_envio', $fecha_envio);
    $connexion->bind(':tipoenvio', $tipoenvio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();


    if ($cod[0]->id > 0) {
    } else {
    $sql = "
    INSERT INTO tbl_notificaciones_pendientes

    (`tipoenvio`,`nombre`,`rut`,`fecha_envio`,`id_empresa`, `hacia`,`nombreto`,`desde`,`nombrefrom`,`tipo`,`asunto`,`titulo1`,
	`subtitulo1`,`texto1`,`url`,`texto_url`, `texto2`,`texto3`,`texto4`,`logo`,`tipomensaje`,`clave`,`template`)

    VALUES (:tipoenvio,:nombre,:rut,:fecha_envio,:id_empresa,:to,:nombreto,:from,:nombrefrom,:tipo,:subject,:titulo1,:subtitulo1,:texto1,:url,:texto_url,
                :texto2,:texto3,:texto4,:logo,:tipomensaje,:key,:template)";

        if ($to != '' ) {
        	if($to<>"."){
            $connexion->query($sql);
            $connexion->bind(':tipoenvio', $tipoenvio);
            $connexion->bind(':nombre', $nombre);
            $connexion->bind(':rut', $rut);
            $connexion->bind(':fecha_envio', $fecha_envio);
            $connexion->bind(':id_empresa', $id_empresa);
            $connexion->bind(':to', $to);
            $connexion->bind(':nombreto', $nombreto);
            $connexion->bind(':from', $from);
            $connexion->bind(':nombrefrom', $nombrefrom);
            $connexion->bind(':tipo', $tipo);
            $connexion->bind(':subject', $subject);
            $connexion->bind(':titulo1', $titulo1);
            $connexion->bind(':subtitulo1', $subtitulo1);
            $connexion->bind(':texto1', $texto1);
            $connexion->bind(':url', $url);
            $connexion->bind(':texto_url', $texto_url);
            $connexion->bind(':texto2', $texto2);
            $connexion->bind(':texto3', $texto3);
            $connexion->bind(':texto4', $texto4);
            $connexion->bind(':logo', $logo);
            $connexion->bind(':tipomensaje', $tipomensaje);
            $connexion->bind(':key', $key);
            $connexion->bind(':template', $template);
            $connexion->execute();
          }
        }
    }
}
function Not_cursosElearningObligatoriosPendientes($id_programa,$id_empresa) {

    $connexion = new DatabasePDO();

    if($id_programa<>''){$queryprograma=" and h.id_programa=:id_programa ";} else {$queryprograma="";}

    $sql = "select h.rut, h.id_curso, h.avance,
	(select fecha from tbl_inscripcion_usuarios where rut=h.rut and id_curso=h.id_curso order by fecha DESC limit 1 ) as FechaInscripcion,
	(select jefe from tbl_usuario where rut=h.rut) as Jefe
	from tbl_lms_reportes h
	where h.avance<>100

	AND ( SELECT modalidad FROM tbl_lms_curso WHERE id = h.id_curso) <> 2
	AND ( ( ( SELECT opcional FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa order by id DESC LIMIT 1 )  IS NULL )
	OR (( SELECT opcional FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa order by id DESC LIMIT 1  ) = 0 ))
	AND ( (SELECT inactivo FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa order by id DESC LIMIT 1  ) IS NULL )
	AND ((SELECT opcional from rel_lms_malla_persona where rut=h.rut and id_malla=h.id_malla order by id DESC limit 1 )='' OR
	(SELECT opcional from rel_lms_malla_persona where rut=h.rut and id_malla=h.id_malla order by id DESC limit 1 ) is NULL	)
	$queryprograma
 	and h.curso_opcional=0
	and h.id_empresa=:id_empresa
	and (select email from tbl_usuario where rut=h.rut)<>'' ";

    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function Ausentismo_rut($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_usuario_ausentismo WHERE rut = :rut AND nro_dias >= '30'";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}

function Not_listacursosElearningObligatoriosPendientes($rut, $id_programa, $id_empresa)
{
    $connexion = new DatabasePDO();
    if ($id_programa !== '') {
        $queryprograma = "AND h.id_programa = :id_programa";
    } else {
        $queryprograma = "";
    }

    $sql = "
        SELECT
            h.rut,
            (SELECT nombre FROM tbl_lms_curso WHERE id = h.id_curso) AS nombre_curso,
            (SELECT nombre_programa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa) AS nombre_programa
        FROM
            tbl_lms_reportes h
        WHERE
            h.avance <> 100 AND
            (SELECT modalidad FROM tbl_lms_curso WHERE id = h.id_curso) <> 2 AND
            (
                (
                    (SELECT opcional FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa ORDER BY id DESC LIMIT 1) IS NULL
                ) OR
                (
                    (SELECT opcional FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa ORDER BY id DESC LIMIT 1) = 0
                )
            ) AND
            (
                (SELECT inactivo FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa ORDER BY id DESC LIMIT 1) IS NULL
            ) AND
            (
                (
                    SELECT opcional FROM rel_lms_malla_persona WHERE rut = h.rut AND id_malla = h.id_malla ORDER BY id DESC LIMIT 1
                ) = '' OR
                (
                    SELECT opcional FROM rel_lms_malla_persona WHERE rut = h.rut AND id_malla = h.id_malla ORDER BY id DESC LIMIT 1
                ) IS NULL
            ) AND
            h.id_empresa = :id_empresa
            $queryprograma AND
            h.rut = :rut
    ";

    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function notificaciones_email_lista_notificaciones_data($id_empresa, $id_instancia, $tipo_instancia)
{
    $connexion = new DatabasePDO();
    if ($id_instancia !== "" && $tipo_instancia !== "") {
        if ($tipo_instancia == "Concurso") {
            $sql = "SELECT * FROM tbl_notificaciones_email WHERE id_empresa = :id_empresa AND id_concurso = :id_instancia ORDER BY id DESC";
        }
    } else {
        $sql = "SELECT * FROM tbl_notificaciones_email WHERE id_empresa = :id_empresa ORDER BY id DESC";
    }

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_instancia', $id_instancia);
    $cod = $connexion->resultset();
    return $cod;
}

function notificaciones_email_notificaciones_usuarios_envios($id, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "
        SELECT
            h.*,
            (
                SELECT COUNT(id) FROM tbl_notificaciones_email_nomina WHERE id_notificacion = h.id
            ) AS usuarios,
            (
                SELECT COUNT(id) FROM tbl_notificaciones_email_rut_envios WHERE id_notificacion = h.id
            ) AS emails_enviados
        FROM
            tbl_notificaciones_email h
        WHERE
            h.id_empresa = :id_empresa AND
            id = :id
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}

function notificaciones_email_notificaciones_Save_data($id, $nombre, $subject, $titulo, $texto, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_notificaciones_email WHERE id_empresa = :id_empresa AND id = :id ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    $id = $cod[0]->id;
    $nombre = utf8_decode($nombre);
    $subject = utf8_decode($subject);
    $titulo = utf8_decode($titulo);
    $texto = utf8_decode($texto);

    if ($id > 0) {
        $sql = "UPDATE tbl_notificaciones_email SET nombre = :nombre, subject = :subject, titulo = :titulo, texto = :texto WHERE id = :id AND id_empresa = :id_empresa";
    } else {
        $sql = "INSERT INTO tbl_notificaciones_email (nombre, subject, titulo, texto, id_empresa) VALUES (:nombre, :subject, :titulo, :texto, :id_empresa)";
    }

    $connexion->query($sql);
    $connexion->bind(':nombre', $nombre);
    $connexion->bind(':subject', $subject);
    $connexion->bind(':titulo', $titulo);
    $connexion->bind(':texto', $texto);
    $connexion->bind(':id', $id);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}


function TraeEncuestasLBEmpresa($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT nombre FROM tbl_enc_elearning WHERE id = h.id_encuesta) AS bancopreguntas,
                (SELECT COUNT(id) FROM tbl_nomina_encuesta WHERE id_encuesta = h.id_encuesta) AS usuarios
            FROM tbl_enc_elearning_medicion h
            WHERE h.id_empresa = :id_empresa
            ORDER BY h.id DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function EncuestasLBListaBancoPreguntas_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_enc_elearning WHERE id_empresa = :id_empresa ORDER BY id DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function notificaciones_email_descargar_usuarios_data($id_empresa, $id_notificacion) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_notificaciones_email_nomina WHERE id_notificacion = :id_notificacion AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_notificacion', $id_notificacion);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function listarEmpresaSubidaUsuarios($idEmpresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_empresa_subida_usuarios WHERE id_empresa = :id_empresa ORDER BY id ASC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $idEmpresa);
    $cod = $connexion->resultset();
    return $cod;
}

function ReporteFullRespuestas_Cron($fecha_inicial_check){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*
            FROM tbl_enc_elearning_respuestas h
            WHERE h.fecha >= :fecha_inicial_check AND h.nombre IS NULL";
    $connexion->query($sql);
    $connexion->bind(':fecha_inicial_check', $fecha_inicial_check);
    $cod = $connexion->resultset();

    foreach ($cod as $unico) {
        reset($Enc_Res_Fecha);      $Enc_Res_Fecha = array();
        reset($Enc_Res_Respuesta);  $Enc_Res_Respuesta = array();
        reset($Enc_Res_Comentario); $Enc_Res_Comentario = array();
        reset($Rating);             $Rating = array();
        reset($Full);               $Full = array();
        reset($RelCurso);           $RelCurso = array();
        reset($Ins);                $Ins = array();
        reset($Perfil_Usu);         $Perfil_Usu = array();
        reset($UsuJ);               $UsuJ = array();
        reset($Usu);                $Usu = array();

        $Perfil_Usu = "";

        $Usu = TraeDatosUsuario($unico->rut);
        $UsuJ = TraeDatosUsuario($Usu[0]->jefe);
        $Perfil_Usu = Bch_2020_Perfil_Usuario_ADMIN($unico->rut);

        //datos_usuario
        $rut = $Usu[0]->rut;
        $nombre = $Usu[0]->nombre_completo;
        $perfil = $Perfil_Usu;
        $glosa_cargo = $Usu[0]->cargo;
        $fecha_ingreso = $Usu[0]->familia_cargo; //fecha indenmizacion
        $division = $Usu[0]->division;
        $area = $Usu[0]->area;
        $departamento = $Usu[0]->departamento;
        $zona = $Usu[0]->zona;
        $seccion = $Usu[0]->centro_costo;
        $cod_unidad = $Usu[0]->local;
        $unidad = $Usu[0]->unidad_negocio;
        $oficina = $Usu[0]->servicio;
        $region = $Usu[0]->regional;
        $empresa = $Usu[0]->nombre_empresa_holding;
        $rut_jefe = $UsuJ[0]->rut_completo;
        $nombre_jefe = $UsuJ[0]->nombre_completo;

        Update_Enc_Elearning_Respuestas_ADMIN($unico->id, $nombre,
            $perfil, $glosa_cargo, $fecha_ingreso, $division, $area,
            $departamento, $zona, $seccion, $cod_unidad, $unidad, $oficina, $region,
            $empresa, $rut_jefe, $nombre_jefe);
    }
}

function Bch_2020_Perfil_Usuario_ADMIN($rut)
{
    $connexion = new DatabasePDO();
    
    $esjefe = rutesjefe_2020_v2Admin($rut);

    if ($esjefe[0]->cuenta > 0) {
        $Jefe = "Jefe";
    } else {
        $Jefe = "No Jefe";
    }

    $EsVulnerable = Bch_2020_Check_Contigencia_Vulnerable_Admin($rut);

    if ($EsVulnerable > 0) {
        $subperfil = "Vulnerable";
    } else {
        $arreglo_usu = Bch_2020_Check_Area_DeptoAdmin($rut);

        if (
            $arreglo_usu[0]->area == "Gerencia Sucursales Metropolitana" ||
            $arreglo_usu[0]->area == "Gerencia Sucursales Regionales" ||
            $arreglo_usu[0]->area == "Gerencia Red Edwards y Bca.Privada" ||
            $arreglo_usu[0]->area == "Gerencia Banca Privada" ||
            $arreglo_usu[0]->area == "Gerencia Sucursales BCH" ||
            $arreglo_usu[0]->area == "Red Sucursales Consumo"
        ) {
            $subperfil = "Red";
        } elseif ($arreglo_usu[0]->departamento == "Subgcia. Banca Telefonica Pers.") {
            $subperfil = "Contact Center";
        } else {
            $subperfil = "Resto Banco";
        }
    }

    if ($rut == "12345") {
        $subperfil = "Red";
        $Jefe = "Jefe";
    }

    if ($rut == "12888860") {
        $subperfil = "Red";
        $Jefe = "Jefe";
    }

    if ($rut == "13403288") {
        $subperfil = "Red";
        $Jefe = "No Jefe";
    }

    $perfil = "$subperfil $Jefe";

    if ($rut == "10008") {
        $perfil = "Full";
    }

    if ($rut == "10009") {
        $perfil = "Semi_Full";
    }

    return $perfil;
}

function rutesjefe_2020_v2Admin($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(id) as cuenta FROM tbl_usuario WHERE jefe = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function Bch_2020_Check_Contigencia_Vulnerable_Admin($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.status FROM tbl_contingencia_2020 h WHERE h.rut = :rut ORDER BY h.id DESC LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    if (utf8_encode($cod[0]->status) == "No Trabajando / Permiso extraordinario , mayores 65 años, enfermedad riesgo o caso social" || $cod[0]->status == "'No Trabajando / otro motivo'") {
        $vulnerable = "1";
    } else {
        $vulnerable = "";
    }

    if ($rut == "7647930") {
        // print_r($cod[0]->status);

        // echo "Vulnerable $vulnerable";
    }

    return $vulnerable;
}

function Bch_2020_Check_Area_DeptoAdmin($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT area, departamento FROM tbl_usuario WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    // echo "<br>aca";
    return $cod;
}

function Update_Enc_Elearning_Respuestas_ADMIN($id, $nombre, $perfil, $glosa_cargo, $fecha_ingreso, $division, $area, $departamento, $zona, $seccion, $cod_unidad, $unidad, $oficina, $region, $empresa, $rut_jefe, $nombre_jefe)
{
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_enc_elearning_respuestas 
            SET 
            nombre = :nombre,
            perfil = :perfil,
            glosa_cargo = :glosa_cargo,
            fecha_ingreso = :fecha_ingreso,
            division = :division,
            area = :area,
            departamento = :departamento,
            zona = :zona,
            seccion = :seccion,
            cod_unidad = :cod_unidad,
            unidad = :unidad,
            oficina = :oficina,
            region = :region,
            empresa = :empresa,
            rut_jefe = :rut_jefe,
            nombre_jefe = :nombre_jefe    
            WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':nombre', $nombre);
    $connexion->bind(':perfil', $perfil);
    $connexion->bind(':glosa_cargo', $glosa_cargo);
    $connexion->bind(':fecha_ingreso', $fecha_ingreso);
    $connexion->bind(':division', $division);
    $connexion->bind(':area', $area);
    $connexion->bind(':departamento', $departamento);
    $connexion->bind(':zona', $zona);
    $connexion->bind(':seccion', $seccion);
    $connexion->bind(':cod_unidad', $cod_unidad);
    $connexion->bind(':unidad', $unidad);
    $connexion->bind(':oficina', $oficina);
    $connexion->bind(':region', $region);
    $connexion->bind(':empresa', $empresa);
    $connexion->bind(':rut_jefe', $rut_jefe);
    $connexion->bind(':nombre_jefe', $nombre_jefe);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();

    // print_r($cod);
    return $cod;
}

function notificaciones_email_envios_usuarios($id_notificacion, $tipo, $id_empresa) {
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");

    if ($tipo == "envio_nuevos") {
        $jq = " and (select count(id) from tbl_notificaciones_email_rut_envios where rut=h.rut and id_notificacion=h.id_notificacion)='0'";
    } else {
        $jq = "";
    }

    $sql = "
    select h.*, 
    (select count(id) from tbl_notificaciones_email_rut_envios where rut=h.rut and id_notificacion=h.id_notificacion) as envio
    from tbl_notificaciones_email_nomina h where h.id_notificacion=:id_notificacion
    $jq";
    
    $connexion->query($sql);
    $connexion->bind(':id_notificacion', $id_notificacion);
    $cod = $connexion->resultset();
    return $cod;
}

function notificaciones_email_notificaciones_data($id_notificacion, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select h.* from tbl_notificaciones_email h where h.id_empresa=:id_empresa and h.id=:id_notificacion";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_notificacion', $id_notificacion);
    $cod = $connexion->resultset();
    return $cod;
}

function notificaciones_email_ActualizoEstadoEnvioCorreoPorProceso($rut, $id_notificacion, $id_empresa) {
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora = date("H:i:s");
    $sql = "insert into tbl_notificaciones_email_rut_envios (id_notificacion, rut, id_empresa, fecha_envio) VALUES (:id_notificacion, :rut, :id_empresa, :fecha)";
    $connexion->query($sql);
    $connexion->bind(':id_notificacion', $id_notificacion);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fecha', $fecha);
    $connexion->execute();
}

function Not_buscaNotificacionesEnvioHoyEstadoNull($fecha, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select h.* from tbl_notificaciones_automaticas h where h.fecha_envio=:fecha and h.estado is NULL";
    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $cod = $connexion->resultset();
    return $cod;
}

function Not_Actualiza_estado($id, $estado) {
    $connexion = new DatabasePDO();
    $sql = "update tbl_notificaciones_automaticas set estado=:estado where id=:id";
    $connexion->query($sql);
    $connexion->bind(':estado', $estado);
    $connexion->bind(':id', $id);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function listarNotificacionesUsuarios_Pendientes($id_empresa) {
    $connexion = new DatabasePDO();
    $orderBy = "";
    if (strlen($order) > 0) {
        $orderBy = "order by " . $order;
    }
    $sql = "select * from tbl_notificaciones_usuarios where id_empresa=:id_empresa and estado is NULL";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFullTbl($table, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM $table WHERE id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    //$cod = $connexion->resultset();
    //return $cod;
}

function BuscaNombreNotificacion($codigo, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select nombre from tbl_notificaciones where codigo=:codigo and id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':codigo', $codigo);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod[0]->nombre;
}

function notificaciones_insert_asignacion($rut, $fecha, $id_notificacion, $notificacion, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "insert into tbl_notificaciones_usuarios (rut, fecha_envio, id_notificacion, notificacion, id_empresa) values (:rut, :fecha, :id_notificacion, :notificacion, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':id_notificacion', $id_notificacion);
    $connexion->bind(':notificacion', $notificacion);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}

function DatosCursoDadoId($id_curso, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_lms_curso WHERE id=:id_curso AND id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function Ota_Duplicado_PreInscripcion_usuarios_2022($id_inscripcion, $rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM rel_lms_rut_id_curso_id_inscripcion WHERE rut=:rut AND id_inscripcion=:id_inscripcion LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}

function Ota_Duplicado_PreInscripcion_MismoCurso_OtaYaActiva_usuarios_2022($id_inscripcion, $id_curso, $rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM rel_lms_rut_id_curso_id_inscripcion WHERE rut=:rut AND id_curso=:id_curso AND activa='1' LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}

function Ota_Duplicado_Inscripcion_usuarios_2022($id_inscripcion, $id_curso, $rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_inscripcion_usuarios WHERE rut=:rut AND id_inscripcion=:id_inscripcion LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}

function Ota_BuscaEstadoCurso_2022($id_curso, $rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_lms_reportes WHERE rut=:rut AND id_curso=:id_curso AND estado='APROBADO' LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod[0]->id;
}

function InsertaInscribeOtaRut_2022($rut, $id_empresa, $id_inscripcion, $id_curso, $id_malla, $fecha_inicio_inscripcion, $fecha_termino_inscripcion,
    $opcional, $rut_ejecutivo, $id_programa, $id_foco, $modalidad, $numero_horas, $inscripcion_futura)
{
    $connexion = new DatabasePDO();

    $sql1 = "INSERT INTO rel_lms_rut_id_curso_id_inscripcion
                (rut, id_curso, id_inscripcion, fecha_inicio_inscripcion, fecha_termino_inscripcion,
                id_empresa, opcional, activa, rut_ejecutivo)
                VALUES
                (:rut, :id_curso, :id_inscripcion, :fecha_inicio_inscripcion, :fecha_termino_inscripcion,
                :id_empresa, :opcional, '1', :rut_ejecutivo)";
    $connexion->query($sql1);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->bind(':fecha_inicio_inscripcion', $fecha_inicio_inscripcion);
    $connexion->bind(':fecha_termino_inscripcion', $fecha_termino_inscripcion);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':opcional', $opcional);
    $connexion->bind(':rut_ejecutivo', $rut_ejecutivo);
    $connexion->execute();

    $hoy = date("Y-m-d");
    $sql2 = "INSERT INTO tbl_inscripcion_usuarios
                (id_inscripcion, rut, id_curso, id_empresa, fecha, id_malla) VALUES
                (:id_inscripcion, :rut, :id_curso, :id_empresa, :fecha, :id_malla)";
    $connexion->query($sql2);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fecha', $hoy);
    $connexion->bind(':id_malla', $id_malla);
    if ($inscripcion_futura != "1") {
        $connexion->execute();
    }

    if ($opcional == "1") {
        $opcional_malla = "1";
    } else {
        $opcional_malla = "";
    }

    $sql3 = "INSERT INTO rel_lms_malla_persona
                (id_malla, rut, id_empresa, opcional) VALUES
                (:id_malla, :rut, :id_empresa, :opcional_malla)";
    $connexion->query($sql3);
    $connexion->bind(':id_malla', $id_malla);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':opcional_malla', $opcional_malla);
    if ($inscripcion_futura != "1") {
        $connexion->execute();
    }

    $sql4 = "SELECT id FROM tbl_lms_reportes WHERE rut = :rut AND id_curso = :id_curso LIMIT 1";
    $connexion->query($sql4);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->execute();
    $cod = $connexion->resultset();

    if ($cod[0]->id > 0) {
        $sql5 = "UPDATE tbl_lms_reportes
                    SET estado = 'NO_INICIADO',
                    avance = '0',
                    resultado = '',
                    puntos = '0',
                    medallas = '0',
                    fecha_inicio = '0000-00-00',
                    fecha_termino = '0000-00-00',
                    fecha_inscripcion = :fecha_inscripcion,
                    id_malla = :id_malla
                    WHERE rut = :rut AND id_curso = :id_curso";
        if ($inscripcion_futura != "1") {
            $connexion->query($sql5);
            $connexion->bind(':fecha_inscripcion', $hoy);
            $connexion->bind(':id_malla', $id_malla);
            $connexion->execute();
        }
    } else {
        $sql6 = "INSERT INTO tbl_lms_reportes
                    (rut, id_foco, id_curso, avance, id_empresa,
                    id_programa, id_malla, modalidadcurso, curso_opcional,
                    numero_horas, estado, fecha_inscripcion, id_inscripcion)
                    VALUES
                    (:rut, :id_foco, :id_curso, '0', :id_empresa,
                    :id_programa, :id_malla, :modalidad, :opcional,
                    :numero_horas, 'NO_INICIADO', :fecha_inscripcion, :id_inscripcion)";
        if ($inscripcion_futura != "1") {
            $connexion->query($sql6);
            $connexion->bind(':rut', $rut);
            $connexion->bind(':id_foco', $id_foco);
            $connexion->bind(':id_curso', $id_curso);
            $connexion->bind(':id_empresa', $id_empresa);
            $connexion->bind(':id_programa', $id_programa);
            $connexion->bind(':id_malla', $id_malla);
            $connexion->bind(':modalidad', $modalidad);
            $connexion->bind(':opcional', $opcional);
            $connexion->bind(':numero_horas', $numero_horas);
            $connexion->bind(':fecha_inscripcion', $hoy);
            $connexion->bind(':id_inscripcion', $id_inscripcion);
            $connexion->execute();
        }
    }
}

function InsertUpdateReporteOnlineDetalle($rut, $id_curso, $curso, $id_malla, $malla, $id_programa, $programa, $malla_opcional, $curso_opcional, $id_inscripcion_activa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT rut FROM tbl_reportes_online_cursos_usuarios_detalle WHERE rut = :rut AND id_curso = :id_curso";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();

    if (!empty($cod)) {

    } else {
        $sql1 = "INSERT INTO tbl_reportes_online_cursos_usuarios_detalle (rut, id_curso, curso, id_malla, malla, id_programa, programa, malla_opcional, curso_opcional, id_inscripcion_activa) VALUES (:rut, :id_curso, :curso, :id_malla, :malla, :id_programa, :programa, :malla_opcional, :curso_opcional, :id_inscripcion_activa)";
        $connexion->query($sql1);
        $connexion->bind(':rut', $rut);
        $connexion->bind(':id_curso', $id_curso);
        $connexion->bind(':curso', $curso);
        $connexion->bind(':id_malla', $id_malla);
        $connexion->bind(':malla', $malla);
        $connexion->bind(':id_programa', $id_programa);
        $connexion->bind(':programa', $programa);
        $connexion->bind(':malla_opcional', $malla_opcional);
        $connexion->bind(':curso_opcional', $curso_opcional);
        $connexion->bind(':id_inscripcion_activa', $id_inscripcion_activa);
        $connexion->execute();
    }
}

function ota_induccion_automatizacion_2022()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_automatizacion_inscripcion";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Ota_Induccion_Automatizacion_usuarios_2022($query)
{
    $connexion = new DatabasePDO();
    $sql = $query;
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Ota_Busca_InscripcionUsuarios_LogEmail($rut, $id_malla, $id_notificacion_email)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(h.id) AS cuenta_otas, (SELECT fecha FROM tbl_log_emails WHERE rut = h.rut AND tipo = :id_notificacion_email) AS fecha_notificacion FROM tbl_inscripcion_usuarios h WHERE rut = :rut AND id_malla = :id_malla";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_malla', $id_malla);
    $connexion->bind(':id_notificacion_email', $id_notificacion_email);
    $cod = $connexion->resultset();
    return $cod;
}

function DatosMalla_2022($id)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_malla WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}

function capsulas_likes_data()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT titulo FROM tbl_objeto WHERE id = h.id_modulo) AS modulo, (SELECT id_curso FROM tbl_objeto WHERE id = h.id_modulo) AS id_curso, (SELECT nombre FROM tbl_lms_curso WHERE id = (SELECT id_curso FROM tbl_objeto WHERE id = h.id_modulo)) AS Curso FROM tbl_capsulas_rating h";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function TraeEvaluacionesPorEmpresa($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT id FROM tbl_objeto WHERE id_evaluacion = h.id LIMIT 1) AS id_objeto, (SELECT id_curso FROM tbl_objeto WHERE id_evaluacion = h.id LIMIT 1) AS id_curso, (SELECT nombre FROM tbl_lms_curso WHERE id = (SELECT id_curso FROM tbl_objeto WHERE id_evaluacion = h.id LIMIT 1)) AS nombre_curso, (SELECT id FROM tbl_lms_curso WHERE id = (SELECT id_curso FROM tbl_objeto WHERE id_evaluacion = h.id LIMIT 1)) AS id_id_curso, (SELECT COUNT(id) FROM tbl_evaluaciones_preguntas WHERE evaluacion = h.id) AS num_preguntas FROM tbl_evaluaciones h WHERE id_empresa = :id_empresa ORDER BY h.id DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function traeCursosPorEvaluaciones($id_empresa, $id_evaluacion) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_curso, (SELECT nombre FROM tbl_lms_curso WHERE id=h.id_curso) AS nombre FROM tbl_objeto h WHERE h.id_evaluacion=:id_evaluacion AND h.id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_evaluacion', $id_evaluacion);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function Datos_curso($id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_curso WHERE id=:id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}

function Datos_objeto($id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_objeto WHERE id=:id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaPreguntaDadaEvaluacion($idEval) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT orden FROM tbl_evaluaciones_alternativas WHERE id_grupo_alternativas=h.id_grupo_alternativas AND correcta=1 LIMIT 1) AS correcta, (SELECT alternativa FROM tbl_evaluaciones_alternativas WHERE id_grupo_alternativas=h.id_grupo_alternativas AND correcta=1 LIMIT 1) AS Altcorrecta FROM tbl_evaluaciones_preguntas h WHERE h.evaluacion = :idEval";
    $connexion->query($sql);
    $connexion->bind(':idEval', $idEval);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaObjetosEval_IDeEval($id_eval) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_objeto h WHERE h.id_evaluacion = :id_eval";
    $connexion->query($sql);
    $connexion->bind(':id_eval', $id_eval);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaUsuariosRespondieronEval($id_objeto, $arreglo) {
    $connexion = new DatabasePDO();
    $queryObj = "";
    if ($arreglo == 1) {
        foreach ($id_objeto as $unico) {
            $cuentaj++;
            $queryObj .= " h.id_objeto=:unico";
            if ($cuentaj < count($id_objeto)) {
                $queryObj .= " OR ";
            }
        }
    } else {
        $queryObj .= " h.id_objeto=:id_objeto";
    }
    $sql = "SELECT h.*, (SELECT rut_completo FROM tbl_usuario WHERE rut=h.rut) AS rut_completo, (SELECT nombre_completo FROM tbl_usuario WHERE rut=h.rut) AS nombre_completo, (SELECT cargo FROM tbl_usuario WHERE rut=h.rut) AS cargo, (SELECT gerencia FROM tbl_usuario WHERE rut=h.rut) AS gerencia, (SELECT gerenciaR2 FROM tbl_usuario WHERE rut=h.rut) AS gerenciaR2, (SELECT gerenciaR3 FROM tbl_usuario WHERE rut=h.rut) AS gerenciaR3, (SELECT email FROM tbl_usuario WHERE rut=h.rut) AS email, (SELECT nota FROM tbl_objetos_finalizados WHERE id_objeto=h.id_objeto AND rut=h.rut AND nota<>'' ORDER BY fecha DESC LIMIT 1) AS nota, (SELECT nota_aprobacion FROM tbl_objeto WHERE id=h.id_objeto LIMIT 1) AS nota_aprobacion FROM tbl_evaluaciones_respuestas h WHERE $queryObj GROUP BY h.rut ORDER BY h.fecha, h.hora, h.rut";
    $connexion->query($sql);
    if ($arreglo == 1) {
        foreach ($id_objeto as $unico) {
            $connexion->bind(':unico', $unico);
        }
    } else {
        $connexion->bind(':id_objeto', $id_objeto);
    }
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaUsuariosRespondieronEvalSinRespuestas($id_objeto, $arreglo) {
    $connexion = new DatabasePDO();
    
    if ($arreglo == 1) {
        $queryObj = "";
        $queryObj_ = "";
        $cuentaj = 0;
        
        foreach ($id_objeto as $unico) {
            $cuentaj++;
            $queryObj .= " id_objeto='" . $unico . "' ";
            $queryObj_ .= " id_objeto='" . $unico . "' ";
            
            if ($cuentaj < count($id_objeto)) {
                $queryObj .= " or ";
                $queryObj_ .= " or ";
            }
        }
    } else {
        $queryObj = " id_objeto='" . $id_objeto . "' ";
        $queryObj_ = " id='" . $id_objeto . "' ";
    }
    
    $sql = "
        SELECT h.*,
            (SELECT rut_completo FROM tbl_usuario WHERE rut=h.rut) AS rut_completo,
            (SELECT nombre_completo FROM tbl_usuario WHERE rut=h.rut) AS nombre_completo,
            (SELECT cargo FROM tbl_usuario WHERE rut=h.rut) AS cargo,
            (SELECT gerencia FROM tbl_usuario WHERE rut=h.rut) AS gerencia,
            (SELECT gerenciaR2 FROM tbl_usuario WHERE rut=h.rut) AS gerenciaR2,
            (SELECT gerenciaR3 FROM tbl_usuario WHERE rut=h.rut) AS gerenciaR3,
            (SELECT email FROM tbl_usuario WHERE rut=h.rut) AS email,
            '' AS nota,
            '' AS nota_aprobacion
        FROM tbl_inscripcion_usuarios h
        WHERE h.id_curso = (SELECT id_curso FROM tbl_objeto WHERE $queryObj_)
            AND (SELECT COUNT(id) FROM tbl_evaluaciones_respuestas WHERE $queryObj AND rut=h.rut) = '0'
        ORDER BY h.fecha, h.hora, h.rut";
    
    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    return $cod;
}

function listarRegistrosTablaGlobalFiltro($tableName, $filterName, $filterValue, $order) {
    $connexion = new DatabasePDO();
    $orderBy = "";
    
    if (strlen($order) > 0) {
        $orderBy = "ORDER BY " . $order;
    }
    
    $sql = "SELECT * FROM $tableName WHERE $filterName = '$filterValue' $orderBy";
    
    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    return $cod;
}

function nombreEvaL($idEval) {
    $connexion = new DatabasePDO();
    $sql = "SELECT nombre_evaluacion FROM tbl_evaluaciones WHERE id = '$idEval'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    return $cod;
}

function buscarRegistroTablaGlobalFiltro($tableName, $filterName, $filterValue) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM $tableName WHERE $filterName = $filterValue";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    return $cod;
}

function truncarTablaGlobal($tableName) {
    $connexion = new DatabasePDO();
    $sql = "TRUNCATE TABLE $tableName";
    $connexion->query($sql);
}

function buscarMaxValueTablaGlobal($campo, $abrev, $tableName) {
    $connexion = new DatabasePDO();
    $sql = "SELECT MAX($campo) $abrev FROM $tableName";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    return $cod;
}

function insertarRegistroTablaGlobal($tableName, $camposNames, $camposValues) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO $tableName ($camposNames) VALUES (" . utf8_decode($camposValues) . ")";
    $connexion->query($sql);
}

function buscarRegistroTablaGlobalFiltros($tableName, array $filterNames, array $filterValues) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM $tableName WHERE ";
    
    for ($i = 0; $i < count($filterNames); $i++) {
        if ($i == 0) {
            $sql .= $filterNames[$i] . " = " . $filterValues[$i];
        } else {
            $sql .= " AND " . $filterNames[$i] . " = " . $filterValues[$i];
        }
    }
    
    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    return $cod;
}

function insertarPreguntaAlternativaTmp($valuesPreg, array $arrValuesAlter, $correcta) {
    $connexion = new DatabasePDO();
    $errorInsertar = "";

    $sql = "INSERT INTO tbl_evaluaciones_preguntas_tmp (id,id_evaluacion,id_grupo_alternativas,id_empresa,orden,tipo,pregunta,accion, refuerzo1, refuerzo2)
            VALUES(" . ($valuesPreg) . ")";
    $connexion->query($sql);

    for ($x = 0; $x < count($arrValuesAlter); $x++) {
        $alterCorrecta = 0;
        if ($correcta == ($x + 1)) {
            $alterCorrecta = 1;
        }
        $arrValuesAlter[$x] = str_replace("{CORRECTA}", $alterCorrecta, $arrValuesAlter[$x]);
        $sql = "INSERT INTO tbl_evaluaciones_alternativas_tmp (id,id_grupo_alternativas,id_empresa,orden,correcta,alternativa,accion)
                VALUES(" . $arrValuesAlter[$x] . ")";

        $connexion->query($sql);
    }
}

function listarRegistrosTablaGlobalFiltros($tableName, array $filterNames, array $filterValues, $order) {
    $connexion = new DatabasePDO();
    $orderBy = "";
    if (strlen($order) > 0) {
        $orderBy = "ORDER BY " . $order;
    }
    $sql = "SELECT * FROM $tableName WHERE ";
    for ($i = 0; $i < count($filterNames); $i++) {
        if ($i == 0) {
            $sql .= $filterNames[$i] . " = " . $filterValues[$i];
        } else {
            $sql .= " AND " . $filterNames[$i] . " = " . $filterValues[$i];
        }
    }
    $sql .= " $orderBy";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function ListadoDePreguntasDadaEvaluacionOrdenadas($id_evaluacion) {
    $connexion = new DatabasePDO();
    $sql = "SELECT tbl_evaluaciones_preguntas.*, tbl_evaluaciones_tipo_preguntas.tipo as tipo_pregunta
                FROM tbl_evaluaciones_preguntas
                INNER JOIN tbl_evaluaciones_tipo_preguntas
                ON tbl_evaluaciones_tipo_preguntas.id = tbl_evaluaciones_preguntas.tipo
                WHERE evaluacion = :id_evaluacion ORDER BY orden ASC";
    $connexion->query($sql);
    $connexion->bind(':id_evaluacion', $id_evaluacion);
    $cod = $connexion->resultset();
    return $cod;
}

function VerificoPreguntaEnTablaPReguntasTmp($id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_evaluaciones_preguntas_tmp WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}

function EliminoPreguntayalternativasDadoIdPregunta($id_pregunta, $id_grupo_alternativas) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_evaluaciones_alternativas WHERE id_grupo_alternativas = :id_grupo_alternativas";
    $connexion->query($sql);
    $connexion->bind(':id_grupo_alternativas', $id_grupo_alternativas);
    $connexion->execute();

    $sql = "DELETE FROM tbl_evaluaciones_preguntas WHERE id = :id_pregunta";
    $connexion->query($sql);
    $connexion->bind(':id_pregunta', $id_pregunta);
    $connexion->execute();
}

function TraigoAernativasDadoIdGrupoAlternativaV2($id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_evaluaciones_alternativas WHERE id_grupo_alternativas = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}

function VerificoSiAlterativaEstEnTmp($id) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_evaluaciones_alternativas_tmp WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();
    return $cod;
}

function EliminoAlternativasDadoIdPregunta($id_alternativa) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_evaluaciones_alternativas WHERE id = :id_alternativa";
    $connexion->query($sql);
    $connexion->bind(':id_alternativa', $id_alternativa);
    $connexion->execute();
}

function actualizarRegistroTablaGlobalFiltro($tableName, $camposValues, $filterName, $filterValue) {
    $connexion = new DatabasePDO();
    $sql = "UPDATE $tableName SET " . utf8_decode($camposValues) . " WHERE $filterName = :filterValue";
    $connexion->query($sql);
    $connexion->bind(':filterValue', $filterValue);
    $connexion->execute();
}

function ListadoDePreguntasDadaEvaluacion($id_evaluacion) {
    $connexion = new DatabasePDO();
    $sql = "SELECT tbl_evaluaciones_preguntas.*, tbl_evaluaciones_tipo_preguntas.tipo AS tipo_pregunta
            FROM tbl_evaluaciones_preguntas
            INNER JOIN tbl_evaluaciones_tipo_preguntas
            ON tbl_evaluaciones_tipo_preguntas.id = tbl_evaluaciones_preguntas.tipo
            WHERE evaluacion = :id_evaluacion";
    $connexion->query($sql);
    $connexion->bind(':id_evaluacion', $id_evaluacion);
    $cod = $connexion->resultset();
    return $cod;
}

function EVALUACION_DatosPregunta($id_pregunta) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_evaluaciones_preguntas WHERE id = :id_pregunta";
    $connexion->query($sql);
    $connexion->bind(':id_pregunta', $id_pregunta);
    $cod = $connexion->resultset();
    return $cod;
}

function EVALUACION_EliminaPreguntasAlternativas($id_pregunta, $id_grupo_alternativas) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_evaluaciones_preguntas WHERE id = :id_pregunta";
    $connexion->query($sql);
    $connexion->bind(':id_pregunta', $id_pregunta);
    $connexion->execute();

    $sql = "DELETE FROM tbl_evaluaciones_alternativas WHERE id_grupo_alternativas = :id_grupo_alternativas";
    $connexion->query($sql);
    $connexion->bind(':id_grupo_alternativas', $id_grupo_alternativas);
    $connexion->execute();
}

function EVALUACION_ActualizoORdenPreguntas($orden, $id_evaluacion) {
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_evaluaciones_preguntas SET orden = orden - 1 WHERE orden > :orden AND evaluacion = :id_evaluacion";
    $connexion->query($sql);
    $connexion->bind(':orden', $orden);
    $connexion->bind(':id_evaluacion', $id_evaluacion);
    $connexion->execute();
}

function InsertaEvaluacionDesdeAdmin($nombre_evaluacion, $id_empresa, $id_curso, $id_objeto) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_evaluaciones (nombre_evaluacion, id_empresa, id_objeto, id_curso) VALUES (:nombre_evaluacion, :id_empresa, :id_curso, :id_objeto)";
    $connexion->query($sql);
    $connexion->bind(':nombre_evaluacion', $nombre_evaluacion);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();
}

function data_rel_id_inscripcion_curso_groupby_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_curso, 
                (SELECT nombre FROM tbl_lms_curso WHERE id = h.id_curso) AS curso,
                h.id_programa,
                (SELECT nombre_programa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa) AS programa,
                h.id_malla,
                (SELECT nombre FROM tbl_lms_malla WHERE id = h.id_malla) AS malla
            FROM rel_lms_id_curso_id_inscripcion h
            GROUP BY h.id_curso";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function data_rel_id_inscripcion_curso_groupby_id_curso_data($id_curso, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*
            FROM rel_lms_rut_id_curso_id_inscripcion h 
            WHERE h.id_curso = :id_curso
            GROUP BY h.id_inscripcion";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}

function data_rel_progra_malla_por_curso_lista($id_curso, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "
SELECT
    h.*,
    (
        SELECT
            nombre
        FROM
            tbl_lms_malla
        WHERE
            id = h.id_malla
        AND id_empresa = :id_empresa
    ) AS malla,
    (
        SELECT
            nombre_programa
        FROM
            tbl_lms_programas_bbdd
        WHERE
            id_programa = h.id_programa
        AND id_empresa = :id_empresa
        AND inactivo IS NULL
    ) AS programa,
    CONCAT(
        (
            SELECT
                nombre_programa
            FROM
                tbl_lms_programas_bbdd
            WHERE
                id_programa = h.id_programa
            AND id_empresa = :id_empresa
            AND inactivo IS NULL
        ),
        ' - ',
        (
            SELECT
                nombre
            FROM
                tbl_lms_malla
            WHERE
                id = h.id_malla
            AND id_empresa = :id_empresa
        )
    ) AS GroupBy,
    CONCAT(
        (
            SELECT
                id_programa
            FROM
                tbl_lms_programas_bbdd
            WHERE
                id_programa = h.id_programa
            AND id_empresa = :id_empresa
            AND inactivo IS NULL
        ),
        ';',
        (
            SELECT
                id
            FROM
                tbl_lms_malla
            WHERE
                id = h.id_malla
            AND id_empresa = :id_empresa
        )
    ) AS IdGroupBy
FROM
    rel_lms_malla_curso h
WHERE
    h.id_curso = :id_curso
AND id_empresa = :id_empresa
AND inactivo = '0'
AND (
    SELECT
        nombre_programa
    FROM
        tbl_lms_programas_bbdd
    WHERE
        id_programa = h.id_programa
    AND id_empresa = :id_empresa
    AND inactivo IS NULL
) <> ''
AND (
    SELECT
        nombre
    FROM
        tbl_lms_malla
    WHERE
        id = h.id_malla
    AND id_empresa = :id_empresa
) <> ''
GROUP BY
    CONCAT(
        (
            SELECT
                nombre_programa
            FROM
                tbl_lms_programas_bbdd
            WHERE
                id_programa = h.id_programa
            AND id_empresa = :id_empresa
            AND inactivo IS NULL
        ),
        ';',
        (
            SELECT
                nombre
            FROM
                tbl_lms_malla
            WHERE
                id = h.id_malla
            AND id_empresa = :id_empresa
        )
    )
ORDER BY
    CONCAT(
        (
            SELECT
                nombre_programa
            FROM
                tbl_lms_programas_bbdd
            WHERE
                id_programa = h.id_programa
            AND id_empresa = :id_empresa
            AND inactivo IS NULL
        ),
        ';',
        (
            SELECT
                nombre
            FROM
                tbl_lms_malla
            WHERE
                id = h.id_malla
            AND id_empresa = :id_empresa
        )
    )";

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function data_rel_id_inscripcion_rut_curso_lista_por_idcurso_idinscripcion_data($id_curso, $id_inscripcion, $rut_colaborador, $id_empresa)
{
    $connexion = new DatabasePDO();

    if ($id_curso <> "") {
        $sql = "SELECT h.* FROM rel_lms_rut_id_curso_id_inscripcion h WHERE h.id_curso=:id_curso ORDER BY id DESC";
    } elseif ($id_inscripcion <> "") {
        $sql = "SELECT h.* FROM rel_lms_rut_id_curso_id_inscripcion h WHERE h.id_inscripcion=:id_inscripcion ORDER BY id DESC";
    } elseif ($rut_colaborador <> "") {
        $sql = "SELECT h.* FROM rel_lms_rut_id_curso_id_inscripcion h WHERE h.rut=:rut_colaborador ORDER BY id DESC";
    } else {
        // $sql = "SELECT h.* FROM rel_lms_rut_id_curso_id_inscripcion h ORDER BY id DESC LIMIT 100000";
        // $sql = "SELECT h.* FROM rel_lms_rut_id_curso_id_inscripcion h ORDER BY id DESC LIMIT 1";
    }

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->bind(':rut_colaborador', $rut_colaborador);
    $cod = $connexion->resultset();
    return $cod;
}

function decisiontree_admin_groupbyRut($id_curso)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*
        FROM tbl_decisiontree_visto h
        WHERE id_curso=:id_curso
        GROUP BY h.rut";

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}

function decisiontree_admin_groupbyPasos($id_curso)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*
        FROM tbl_decisiontree h
        WHERE id_curso=:id_curso
        ORDER BY h.paso";

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}

function TraeUsuarioRut($rut)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_usuario WHERE rut = :rut";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}

function decisiontree_admin_Detalle_RutIdCurso($id_curso, $rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
                (SELECT totalpasos FROM tbl_decisiontree WHERE id_curso=:id_curso AND paso=h.paso) AS totalpasos,
                (SELECT tipopaso FROM tbl_decisiontree WHERE id_curso=:id_curso AND paso=h.paso) AS tipopaso,
                (SELECT nombrepaso FROM tbl_decisiontree WHERE id_curso=:id_curso AND paso=h.paso) AS nombrepaso,
                (SELECT opcion1 FROM tbl_decisiontree WHERE id_curso=:id_curso AND paso=h.paso) AS opcion1,
                (SELECT opcion2 FROM tbl_decisiontree WHERE id_curso=:id_curso AND paso=h.paso) AS opcion2,
                (SELECT opcion3 FROM tbl_decisiontree WHERE id_curso=:id_curso AND paso=h.paso) AS opcion3,
                (SELECT opcion4 FROM tbl_decisiontree WHERE id_curso=:id_curso AND paso=h.paso) AS opcion4
            FROM tbl_decisiontree_visto h
            WHERE id_curso=:id_curso AND h.rut=:rut";
    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod;
}

function ReporteFull_Duplicados_data($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT rut, id_inscripcion, id_curso, asistencia, evaluacion, COUNT(*) AS c
            FROM tbl_lms_reportes_full
            WHERE status<>'Presencial'
            GROUP BY rut, id_curso
            HAVING c > 1";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function BorraDuplicacionesReporteFull($rut, $id_inscripcion, $id_curso, $asistencia, $evaluacion)
{
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_lms_reportes_full
            WHERE rut=:rut AND id_inscripcion=:id_inscripcion AND id_curso=:id_curso
            ORDER BY evaluacion ASC, asistencia ASC LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_inscripcion', $id_inscripcion);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->execute();
}

function REL_MALLA_CURSO_trarCamposSubidaParaReporte($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_empresa_subida_usuarios WHERE id_empresa=:id_empresa AND filtro_reporte='1'";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function TraigoValoresDadoCampoPorEmpreas($campo, $id_empresa, $arreglo_post)
{
    $campos_subida = REL_MALLA_CURSO_trarCamposSubidaParaReporte($id_empresa);
    $total_campos = 0;
    foreach ($campos_subida as $camp) {
        if ($campo == $camp->campo) {
            continue;
        }
        if (count($arreglo_post[$camp->campo]) > 0 && $arreglo_post[$camp->campo][0] != '0') {
            $total_campos++;
            if ($total_campos >= 2) {
                $filtros_campos_dinamicos .= " AND ";
            }
            $total = count($arreglo_post[$camp->campo]);
            $filtros_campos_dinamicos .= " ( ";
            for ($i = 1; $i <= $total; $i++) {
                if ($i >= 2) {
                    $filtros_campos_dinamicos .= " OR ";
                }
                $filtros_campos_dinamicos .= " tbl_usuario." . $camp->campo . "='" . $arreglo_post[$camp->campo][$i - 1] . "'";
            }
            $filtros_campos_dinamicos .= " ) ";
        }
    }
    if ($filtros_campos_dinamicos) {
        $filtros_campos_dinamicos = " AND ($filtros_campos_dinamicos)";
    }
    $filtro_audiencias = FiltroPerfiladoAudiencias($_SESSION["admin_"], $id_empresa, $tipo);
    $connexion = new DatabasePDO();
    $sql = "SELECT DISTINCT($campo) AS valor
            FROM tbl_usuario
            WHERE id_empresa=:id_empresa
            AND $campo IS NOT NULL
            AND $campo <>''
            $filtro_audiencias
            $filtros_campos_dinamicos
            ORDER BY $campo";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}


function TraeFocosPorEmpresa($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT tbl_lms_foco.* FROM tbl_lms_foco LEFT JOIN rel_lms_malla_curso ON rel_lms_malla_curso.id_foco=tbl_lms_foco.codigo_foco
            WHERE tbl_lms_foco.id_empresa = :id_empresa 
            GROUP BY codigo_foco
            ORDER BY tbl_lms_foco.descripcion ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function TRaeDatosRelADminPerfil($id_empresa, $rut, $tipo_filtro) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM rel_admin_rut_perfil WHERE rut = :rut AND id_empresa = :id_empresa AND tipo_filtro = :tipo_filtro";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo_filtro', $tipo_filtro);
    $cod = $connexion->resultset();

    return $cod;
}

function TraeProgramasGlobales($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_programas_bbdd WHERE id_empresa = :id_empresa AND tipo = 'GLOBAL' ORDER BY nombre_programa ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function TraeProgramasElearning($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_programas_bbdd WHERE id_empresa = :id_empresa AND (tipo <> 'GLOBAL' OR tipo IS NULL OR tipo = '') ORDER BY nombre_programa ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function TraeMallasReportesFull($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_malla WHERE id_empresa = :id_empresa ORDER BY nombre";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function TraeCursosReportesFull($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_curso WHERE id_empresa = :id_empresa ORDER BY nombre";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function TraeCursosReportesFullAsc($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_lms_curso WHERE id_empresa = :id_empresa ORDER BY id ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function TraeImparticionesReportesFull($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_inscripcion_curso WHERE id_empresa = :id_empresa ORDER BY id ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function buscaUltimaFechaFull(){
    $connexion = new DatabasePDO();
    $sql = "SELECT fecha_actualizacion_reporte FROM tbl_lms_reportes_full WHERE fecha_actualizacion_reporte <> '0000-00-00' ORDER BY fecha_actualizacion_reporte DESC LIMIT 1";

    $connexion->query($sql);
    $cod = $connexion->resultset();

    return $cod[0]->fecha_actualizacion_reporte;
}

function Reportes_Express_Programa($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_programa, (SELECT nombre_programa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa) AS programa FROM tbl_lms_reportes h WHERE h.id_programa <> '' AND h.id_programa <> 'bch_histor' AND (SELECT inactivo FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa) IS NULL AND id_empresa = :id_empresa GROUP BY h.id_programa ORDER BY (SELECT nombre_programa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa)";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function ReportesAutomaticosBuscaUltimasFechas($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.fecha FROM tbl_lms_reportes_full_files h WHERE h.id_empresa = :id_empresa GROUP BY h.fecha ORDER BY h.fecha DESC LIMIT 12";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function ReportesAutomaticosBuscaLineas($fecha, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_lms_reportes_full_files h WHERE h.fecha = :fecha AND h.id_empresa = :id_empresa ORDER BY nombre";
    $connexion->query($sql);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function lms_reportes_full_excel_data($id_empresa, $id_foco, $id_programa, $id_programa_elearning, $id_malla, $id_curso, $tipo_filtro, $imparticion, $ejecutivo, $modalidad, $fecha_inicio, $fecha_termino, $estado) {
    $connexion = new DatabasePDO();
    if ($id_foco != "0") { $QueryIdFoco = " AND h.id_foco = :id_foco "; } else { $QueryIdFoco = ""; }
    if ($id_programa != "0") { $QueryIdPrograma = " AND h.id_programa_global = :id_programa "; } else { $QueryIdPrograma = ""; }
    if ($id_programa_elearning != "0") { $QueryId_programa_elearning = " AND h.id_programa = :id_programa_elearning "; } else { $QueryId_programa_elearning = ""; }
    if ($id_malla != "0") { $QueryIdMalla = " AND h.id_malla = :id_malla "; } else { $QueryIdMalla = ""; }
    if ($id_curso != "0") { $QueryIdCurso = " AND h.id_curso = :id_curso "; } else { $QueryIdCurso = ""; }
    if ($imparticion != "0") { $QueryIdImparticion = " AND h.id_inscripcion = :imparticion "; } else { $QueryIdImparticion = ""; }
    if ($ejecutivo != "0") { $QueryEjecutivo = " AND h.rut_ejecutivo = :id_curso "; } else { $QueryEjecutivo = ""; }
    if ($modalidad != "0") { $QueryModalidad = " AND h.status = :modalidad "; } else { $QueryModalidad = ""; }
    if ($fecha_inicio != "") {
        $fecha_inicio = $fecha_inicio . "-01";
        $QueryFecha_inicio = " AND h.fecha_inicio >= :fecha_inicio ";
    } else { $QueryFecha_inicio = ""; }
    if ($fecha_termino != "") {
        $fecha_termino = $fecha_termino . "-31";
        $QueryFecha_termino = " AND h.fecha_termino <= :fecha_termino ";
    } else { $QueryFecha_termino = ""; }
    if ($estado != "0") {
        if ($estado == "FINALIZADO") { $QEstado = " AND h.asistencia = '100%' "; }
        if ($estado == "EN_PROCESO") { $QEstado = " AND h.asistencia <> '100%' AND h.asistencia = '0%' "; }
        if ($estado == "NO_INICIADO") { $QEstado = " AND h.asistencia = '0%' "; }
        $QueryEstado = $QEstado;
    } else { $QueryEstado = ""; }
    $sql = "SELECT h.* FROM tbl_lms_reportes_full h WHERE h.id > 0
            $QueryIdFoco
            $QueryIdPrograma
            $QueryId_programa_elearning
            $QueryIdMalla
            $QueryIdCurso
            $QueryIdImparticion
            $QueryEjecutivo
            $QueryModalidad
            $QueryFecha_inicio
            $QueryFecha_termino
            $QueryEstado
            ORDER BY h.nombre";
    $connexion->query($sql);
    $connexion->bind(':id_foco', $id_foco);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_programa_elearning', $id_programa_elearning);
    $connexion->bind(':id_malla', $id_malla);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':imparticion', $imparticion);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':modalidad', $modalidad);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $cod = $connexion->resultset();
    return $cod;
}

function UsuarioVigente($rut)
{
    $connexion = new DatabasePDO();
    
    $sql_usuarios_novigentes = "SELECT id FROM tbl_usuario WHERE rut = :rut AND vigencia = '0'";
    $connexion->query($sql_usuarios_novigentes);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    
    return $cod[0]->id;
}

function Check2020_Reportes_IdProgramaNull_data($id_empresa){

$connexion = new DatabasePDO();

    
$sql="
select h.* ,
(select vigencia_descripcion from tbl_usuario where rut=h.rut  order by id DESC limit 1) as Vigencia,
(select vigencia from tbl_usuario where rut=h.rut  order by id DESC limit 1) as VigenciaRut,
(select estado from tbl_lms_reportes where rut=h.rut and id_curso=h.id_curso  order by id DESC limit 1) as EstadoReportes

from tbl_inscripcion_usuarios h 

where h.id_curso<>''
and h.id_malla<>'bch_histor'
and h.id_empresa='$id_empresa'

and ((select vigencia_descripcion from tbl_usuario where rut=h.rut  order by id DESC limit 1)='' or
			(select vigencia_descripcion from tbl_usuario where rut=h.rut  order by id DESC limit 1 ) is NULL		)
and (select estado from tbl_lms_reportes where rut=h.rut and id_curso=h.id_curso  order by id DESC limit 1) is NULL
order by (select vigencia from tbl_usuario where rut=h.rut) ;";

	$connexion->query($sql);
    $cod = $connexion->resultset();

    foreach ($cod as $unico)
    {
		$sql_verifica = "select * from tbl_lms_reportes where rut='".$unico->rut."' and id_curso='".$unico->id_curso."' ";
		$connexion->query($sql);
		$cod_verifica = $connexion->resultset();
		
		if($cod_verifica[0]->id>0){
			
		}else{
			$sql11 = "insert into tbl_lms_reportes (rut, id_curso, id_malla, id_empresa)
			VALUES ('".$unico->rut."', '".$unico->id_curso."', '".$unico->id_malla."', '".$unico->id_empresa."')";
	
		    $connexion->query($sql11);
			$connexion->execute();
			
		}
		

    }

    $sql = "
select h.*, 
	(select id_malla from tbl_inscripcion_usuarios where rut=h.rut and id_curso=h.id_curso order by id DESC limit 1) as IdMalla,

	(select id_programa from rel_lms_malla_curso where id_curso=h.id_curso and id_malla=(select id_malla from tbl_inscripcion_usuarios where rut=h.rut and id_curso=h.id_curso order by id DESC limit 1) order by id DESC limit 1) as IdPrograma,
	(select id_clasificacion from rel_lms_malla_curso where id_curso=h.id_curso and id_malla=(select id_malla from tbl_inscripcion_usuarios where rut=h.rut and id_curso=h.id_curso order by id DESC limit 1) order by id DESC limit 1) as IdClasificacion,
	(select id_foco from rel_lms_malla_curso where id_curso=h.id_curso and id_malla=(select id_malla from tbl_inscripcion_usuarios where rut=h.rut and id_curso=h.id_curso order by id DESC limit 1) order by id DESC limit 1) as IdFoco

 from tbl_lms_reportes h where (id_programa is null or id_programa='')
 and (select id from rel_lms_malla_curso where id_curso=h.id_curso and id_malla=h.id_malla) is not null
 
 ;

    ";
    $connexion->query($sql);
    $cod = $connexion->resultset();
  
   $cuenta_loop=0; 
    foreach ($cod as $unico)
    {

		$cuenta_loop++;

		
     		$sql1 = "update tbl_lms_reportes 
     						set 
     							id_malla='".$unico->IdMalla."', 
     							id_foco='".$unico->IdFoco."', 
     							id_clasificacion='".$unico->IdClasificacion."', 
     							id_programa='".$unico->IdPrograma."'
     				
     						where   id='".$unico->id."'";

		    $connexion->query($sql1);
			$connexion->execute();
    }


    $sql3 = "select h.* from tbl_lms_reportes h where (estado is null or estado='');    ";

	$connexion->query($sql3);
    $cod3 = $connexion->resultset();
	
  $cuenta_loop=0;     
    
 foreach ($cod3 as $unico)
    {
 				if($unico->avance=="0"){ $estado="NO_INICIADO";	}

 				if($unico->avance<100 and $unico->avance>0){
 					$estado="EN_PROCESO";
 				}

 
     		$sql4 = "update tbl_lms_reportes set estado='".$estado."' where   id='".$unico->id."'";
							
		    $connexion->query($sql4);
			$connexion->execute();
    }    
    

    $sql7 = "select h.*, 	(select modalidad from tbl_lms_curso where id=h.id_curso) as modalidad
 from tbl_lms_reportes h where (modalidadcurso is null or modalidadcurso='') ";

	$connexion->query($sql7);
    $cod7 = $connexion->resultset();	
    
   $cuenta_loop=0;     
    
 foreach ($cod7 as $unico)
    {
    	
    			$cuenta_loop++;

     		$sql8 = "update tbl_lms_reportes set modalidadcurso='".$unico->modalidad."'	where   id='".$unico->id."'";
			
		    $connexion->query($sql8);
			$connexion->execute();
    }  



 $sql11 = "select h.*	from tbl_lms_reportes h where h.avance>0 and h.avance<100 and h.estado<>'EN_PROCESO'";

	$connexion->query($sql11);
    $cod11 = $connexion->resultset();		

   $cuenta_loop=0;      
     foreach ($cod11 as $unico)
    {
       			$cuenta_loop++;

   $sql12 = "update tbl_lms_reportes set estado='EN_PROCESO' where   id='".$unico->id."'";
							
							
		    $connexion->query($sql12);
			$connexion->execute();	
    	
    }
    
 
$sql13 = "select h.*,
(select nota_aprobacion from tbl_objeto  where id_curso=h.id_curso and nota_aprobacion>0 limit 1) as NotaAprob,
ROUND((select avg(nota) from tbl_objetos_finalizados where rut=h.rut and id_curso=h.id_curso and nota>0)) as NotaProm

 								from tbl_lms_reportes h 
								where h.avance='100' and h.estado='APROBADO' 
AND h.resultado<(select nota_aprobacion from tbl_objeto  where id_curso=h.id_curso and nota_aprobacion>0 limit 1) 
and (select nota_aprobacion from tbl_objeto  where id_curso=h.id_curso and nota_aprobacion>0 limit 1)>0
order by h.resultado";

 
	$connexion->query($sql13);
    $cod13 = $connexion->resultset();		
 
   $cuenta_loop=0;         
     foreach ($cod13 as $unico)
    {
    	
     			$cuenta_loop++;

    if($unico->NotaProm>=$unico->NotaAprob){
    	$estado="APROBADO";
    } else {
    	$estado="REPROBADO";
    }
    	
    	if($unico->NotaProm>$unico->resultado){
    		$resultado=$unico->NotaProm;
    	} else {
    		$resultado=$unico->resultado;
    	}
    	
   $sql14 = "update tbl_lms_reportes set resultado='".$resultado."',estado='".$estado."' where   id='".$unico->id."'";
		
			$connexion->query($sql14);
			$connexion->execute();	
    	
    } 
 

		 $sql9 = "select h.* from tbl_lms_reportes h where h.avance='100' and h.estado='REPROBADO' AND h.resultado>=80 ";

    $connexion->query($sql9);
    $cod9 = $connexion->resultset();	

   $cuenta_loop=0;          
     foreach ($cod9 as $unico)
    {
       			$cuenta_loop++;

		  	
   $sql10 = "update tbl_lms_reportes set estado='APROBADO' where   id='".$unico->id."'";

			$connexion->query($sql10);
			$connexion->execute();				
    	
    }

 $sql15 = "select h.*,
(select nota_aprobacion from tbl_objeto  where id_curso=h.id_curso and nota_aprobacion>0 limit 1) as NotaAprob,
ROUND((select avg(nota) from tbl_objetos_finalizados where rut=h.rut and id_curso=h.id_curso and nota>0)) as NotaProm

 								from tbl_lms_reportes h 
								where h.avance='100' and h.estado='EN_PROCESO'  ";

    $connexion->query($sql15);
    $cod15 = $connexion->resultset();	

   $cuenta_loop=0;          
     foreach ($cod15 as $unico)
    {
       			$cuenta_loop++;
 
		  	if($unico->NotaAprob==""){
		
		   $sql16 = "update tbl_lms_reportes set estado='APROBADO'	where   id='".$unico->id."'";
							
			$connexion->query($sql16);
			$connexion->execute();				
		  		
		  	}
		  	
		  	if($unico->NotaAprob>0 and $unico->NotaProm>=$unico->NotaAprob){
		
		   $sql16 = "update tbl_lms_reportes set estado='APROBADO'	where   id='".$unico->id."'";
							
							
			$connexion->query($sql16);
			$connexion->execute();
			
		  		
		  	}
    	
    }



$sql_17="select h.*, 

ROUND((select nota from tbl_inscripcion_cierre where rut=h.rut and id_curso=h.id_curso and id_empresa='$id_empresa' order by nota DESC limit 1)) as nota,
ROUND((select avg(nota) from tbl_objetos_finalizados where rut=h.rut and id_curso=h.id_curso and nota<>'')) as avg_obj_finalizados,
ROUND((select nota_aprobacion from tbl_objeto  where id_curso=h.id_curso and nota_aprobacion>0 limit 1)) as NotaAprob

 from tbl_lms_reportes h where h.estado='REPROBADO'

and 

ROUND((select nota from tbl_inscripcion_cierre where rut=h.rut and id_curso=h.id_curso and id_empresa='78' order by nota DESC limit 1))>=ROUND((select nota_aprobacion from tbl_objeto  where id_curso=h.id_curso and nota_aprobacion>0 limit 1)) ";

    $connexion->query($sql_17);
    $cod17 = $connexion->resultset();		
 
      foreach ($cod17 as $unico)
    {
    	
		   $sql18 = "update tbl_lms_reportes 
     						set 
     							estado='APROBADO',
     							resultado='".$unico->nota."' 
     						where   id='".$unico->id."'";
							//echo "<br>$sql8"; 
							
			$connexion->query($sql18);
			$connexion->execute();	    	
    	
    	
    }
 
 
$sql_18=
"SELECT h.*, (select id from rel_lms_malla_curso where id_curso=h.id_curso and id_malla=h.id_malla) as RelMallaCurso FROM tbl_lms_reportes h 
WHERE  (select id from rel_lms_malla_curso where id_curso=h.id_curso and id_malla=h.id_malla) is NULL
and h.curso_opcional='0'
";


    $connexion->query($sql_18);
    $cod18 = $connexion->resultset();		
 
      foreach ($cod18 as $unico)
    {
    	
		   $sql19 = "update tbl_lms_reportes 
     						set 
     							id_malla='".$unico->id_malla."_bk_hist'
     						
     						where   id='".$unico->id."'";
							//echo "<br>$sql19"; 
							
			$connexion->query($sql19);
			$connexion->execute();		    	
    	
    	}
   
        return $cod; 
}

function ObtieneDatosProgramasPorEmpresa($id_programa, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT tbl_lms_programas_bbdd.* FROM tbl_lms_programas_bbdd WHERE id_programa = :id_programa AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function Reportes_Express_Resultado($id_programa, $fecha_inicio, $fecha_termino, $rut_col) {
    $connexion = new DatabasePDO();
    if ($fecha_inicio !== "") {
        $QFI = " AND h.fecha_inicio >= :fecha_inicio";
        $connexion->bind(':fecha_inicio', $fecha_inicio);
    } else {
        $QFI = "";
    }

    if ($fecha_termino !== "") {
        $QFT = " AND h.fecha_termino >= :fecha_termino";
        $connexion->bind(':fecha_termino', $fecha_termino);
    } else {
        $QFT = "";
    }

    if ($id_programa !== "") {
        $QPro = " AND h.id_programa = :id_programa";
        $connexion->bind(':id_programa', $id_programa);
    } else {
        $QPro = "";
    }

    if ($rut_col !== "") {
        $QRUT = " AND h.rut = :rut_col";
        $connexion->bind(':rut_col', $rut_col);
    } else {
        $QRUT = "";
    }

    $sql = "
        SELECT
            h.rut, h.rut_completo, h.nombre, h.cargo, h.email, h.c1, h.c2, h.c3, h.c4, h.id_programa,
            (SELECT nombre_empresa_holding FROM tbl_usuario WHERE rut = h.rut) AS nombre_empresa_holding,
            (SELECT nombre_programa FROM tbl_lms_programas_bbdd WHERE id_programa = h.id_programa) AS programa,
            h.id_malla,
            (SELECT nombre FROM tbl_lms_malla WHERE id = h.id_malla) AS malla,
            h.id_curso,
            (SELECT nombre FROM tbl_lms_curso WHERE id = h.id_curso) AS curso,
            h.avance AS avance_asistencia, h.resultado AS resultado_evaluacion, h.fecha_inicio, h.fecha_termino,
            IF(h.curso_opcional = '0', 'OBLIGATORIO', 'OPCIONAL') AS curso_opcional,
            h.estado, h.fecha_inscripcion, h.jefe,
            (SELECT nombre_empresa_holding FROM tbl_usuario WHERE rut = h.rut) AS nombre_empresa_holding,
            (SELECT vigencia_descripcion FROM tbl_usuario WHERE rut = h.rut) AS vigencia_descripcion,
            (SELECT respuesta FROM tbl_enc_elearning_respuestas WHERE rut = h.rut AND id_curso = h.id_curso AND id_pregunta = 'bch4' LIMIT 1) AS Evaluacion_Satistaccion,
            (SELECT comentario FROM tbl_enc_elearning_respuestas WHERE rut = h.rut AND id_curso = h.id_curso AND id_pregunta = 'bch4' LIMIT 1) AS Comentario_Satisfaccion,
            (SELECT fecha_desde FROM tbl_usuario_ausentismo WHERE rut = h.rut) AS fecha_desde,
            (SELECT fecha_hasta FROM tbl_usuario_ausentismo WHERE rut = h.rut) AS fecha_hasta,
            (SELECT tipo_ausentismo FROM tbl_usuario_ausentismo WHERE rut = h.rut) AS tipo_ausentismo
        FROM tbl_lms_reportes h
        WHERE h.id > 0
            AND (
                (SELECT vigencia_descripcion FROM tbl_usuario WHERE rut = h.rut) IS NULL
                OR (SELECT vigencia_descripcion FROM tbl_usuario WHERE rut = h.rut) = ''
            )
            AND h.rut <> ''
            AND h.id_programa <> 'bch_histor'
            $QPro
            $QRUT
            $QFI
            $QFT";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lms_reportes_full_excel_solocurso_data($id_empresa, $id_foco, $id_programa, $id_programa_elearning, $id_malla, $id_curso, $tipo_filtro, $imparticion, $ejecutivo, $modalidad, $fecha_inicio, $fecha_termino, $estado) {
    $connexion = new DatabasePDO();

    if ($id_foco != "0") {
        $QueryIdFoco = " and h.id_foco=:id_foco";
        $connexion->bind(':id_foco', $id_foco);
    } else {
        $QueryIdFoco = "";
    }

    if ($id_programa != "0") {
        $QueryIdPrograma = " and h.id_programa_global=:id_programa";
        $connexion->bind(':id_programa', $id_programa);
    } else {
        $QueryIdPrograma = "";
    }

    if ($id_programa_elearning != "0") {
        $QueryId_programa_elearning = " and h.id_programa=:id_programa_elearning";
        $connexion->bind(':id_programa_elearning', $id_programa_elearning);
    } else {
        $QueryId_programa_elearning = "";
    }

    if ($id_malla != "0") {
        $QueryIdMalla = " and h.id_malla=:id_malla";
        $connexion->bind(':id_malla', $id_malla);
    } else {
        $QueryIdMalla = "";
    }

    if ($id_curso != "0") {
        $QueryIdCurso = " and h.id_curso=:id_curso";
        $connexion->bind(':id_curso', $id_curso);
    } else {
        $QueryIdCurso = "";
    }

    if ($imparticion != "0") {
        $QueryIdImparticion = " and h.id_inscripcion=:imparticion";
        $connexion->bind(':imparticion', $imparticion);
    } else {
        $QueryIdImparticion = "";
    }

    if ($ejecutivo != "0") {
        $QueryEjecutivo = " and h.rut_ejecutivo=:ejecutivo";
        $connexion->bind(':ejecutivo', $ejecutivo);
    } else {
        $QueryEjecutivo = "";
    }

    if ($modalidad != "0") {
        $QueryModalidad = " and h.status=:modalidad";
        $connexion->bind(':modalidad', $modalidad);
    } else {
        $QueryModalidad = "";
    }

    if ($fecha_inicio != "") {
        $fecha_inicio = $fecha_inicio . "-01";
        $QueryFecha_inicio = " and h.fecha_inicio>=:fecha_inicio";
        $connexion->bind(':fecha_inicio', $fecha_inicio);
    } else {
        $QueryFecha_inicio = "";
    }

    if ($fecha_termino != "") {
        $fecha_termino = $fecha_termino . "-31";
        $QueryFecha_termino = " and h.fecha_termino<=:fecha_termino";
        $connexion->bind(':fecha_termino', $fecha_termino);
    } else {
        $QueryFecha_termino = "";
    }

    if ($estado != "0") {
        if ($estado == "FINALIZADO") {
            $QEstado = " and h.asistencia='100%'";
        } elseif ($estado == "EN_PROCESO") {
            $QEstado = " and h.asistencia<>'100%' and h.asistencia='0%'";
        } elseif ($estado == "NO_INICIADO") {
            $QEstado = " and h.asistencia='0%'";
        }
        $QueryEstado = $QEstado;
    } else {
        $QueryEstado = "";
    }

    $sql = "
        SELECT h.*
        FROM tbl_lms_reportes_full h
        WHERE h.id>0
        $QueryIdFoco
        $QueryIdPrograma
        $QueryId_programa_elearning
        $QueryIdMalla
        $QueryIdCurso
        $QueryIdImparticion
        $QueryEjecutivo
        $QueryModalidad
        $QueryFecha_inicio
        $QueryFecha_termino
        $QueryEstado
        GROUP BY h.id_curso
        ORDER BY h.curso
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lms_reportes_full_excel_filtro_rut_data($id_empresa, $id_foco, $id_programa, $id_programa_elearning, $id_malla, $id_curso, $tipo_filtro, $imparticion, $ejecutivo, $modalidad, $fecha_inicio, $fecha_termino, $estado) {
    $connexion = new DatabasePDO();

    if ($id_foco != "0") {
        $QueryIdFoco = " and h.id_foco=:id_foco";
        $connexion->bind(':id_foco', $id_foco);
    } else {
        $QueryIdFoco = "";
    }

    if ($id_programa != "0") {
        $QueryIdPrograma = " and h.id_programa_global=:id_programa";
        $connexion->bind(':id_programa', $id_programa);
    } else {
        $QueryIdPrograma = "";
    }

    if ($id_programa_elearning != "0") {
        $QueryId_programa_elearning = " and h.id_programa=:id_programa_elearning";
        $connexion->bind(':id_programa_elearning', $id_programa_elearning);
    } else {
        $QueryId_programa_elearning = "";
    }

    if ($id_malla != "0") {
        $QueryIdMalla = " and h.id_malla=:id_malla";
        $connexion->bind(':id_malla', $id_malla);
    } else {
        $QueryIdMalla = "";
    }

    if ($id_curso != "0") {
        $QueryIdCurso = " and h.id_curso=:id_curso";
        $connexion->bind(':id_curso', $id_curso);
    } else {
        $QueryIdCurso = "";
    }

    if ($imparticion != "0") {
        $QueryIdImparticion = " and h.id_inscripcion=:imparticion";
        $connexion->bind(':imparticion', $imparticion);
    } else {
        $QueryIdImparticion = "";
    }

    if ($ejecutivo != "0") {
        $QueryEjecutivo = " and h.rut_ejecutivo=:ejecutivo";
        $connexion->bind(':ejecutivo', $ejecutivo);
    } else {
        $QueryEjecutivo = "";
    }

    if ($modalidad != "0") {
        $QueryModalidad = " and h.status=:modalidad";
        $connexion->bind(':modalidad', $modalidad);
    } else {
        $QueryModalidad = "";
    }

    if ($fecha_inicio != "") {
        $fecha_inicio = $fecha_inicio . "-01";
        $QueryFecha_inicio = " and h.fecha_inicio>=:fecha_inicio";
        $connexion->bind(':fecha_inicio', $fecha_inicio);
    } else {
        $QueryFecha_inicio = "";
    }

    if ($fecha_termino != "") {
        $fecha_termino = $fecha_termino . "-31";
        $QueryFecha_termino = " and h.fecha_termino<=:fecha_termino";
        $connexion->bind(':fecha_termino', $fecha_termino);
    } else {
        $QueryFecha_termino = "";
    }

    if ($estado != "0") {
        if ($estado == "FINALIZADO") {
            $QEstado = " and h.asistencia='100%'";
        } elseif ($estado == "EN_PROCESO") {
            $QEstado = " and h.asistencia<>'100%' and h.asistencia='0%'";
        } elseif ($estado == "NO_INICIADO") {
            $QEstado = " and h.asistencia='0%'";
        }
        $QueryEstado = $QEstado;
    } else {
        $QueryEstado = "";
    }

    $sql = "
        SELECT h.*
        FROM tbl_lms_reportes_full h
        WHERE h.id>0
        $QueryIdFoco
        $QueryIdPrograma
        $QueryId_programa_elearning
        $QueryIdMalla
        $QueryIdCurso
        $QueryIdImparticion
        $QueryEjecutivo
        $QueryModalidad
        $QueryFecha_inicio
        $QueryFecha_termino
        $QueryEstado
        GROUP BY h.rut
        ORDER BY h.nombre
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lms_reportes_full_excel_solocurso_rut_data($id_empresa, $id_foco, $id_programa, $id_programa_elearning, $id_malla, $id_curso, $tipo_filtro, $imparticion, $ejecutivo, $modalidad, $fecha_inicio, $fecha_termino, $estado, $rut) {
    $connexion = new DatabasePDO();

    if ($id_foco != "0")                {$QueryIdFoco = " and h.id_foco=:id_foco ";}                          else { $QueryIdFoco = "";}
    if ($id_programa != "0")            {$QueryIdPrograma = " and h.id_programa_global=:id_programa ";}       else { $QueryIdPrograma = "";}
    if ($id_programa_elearning != "0")  {$QueryId_programa_elearning = " and h.id_programa=:id_programa_elearning ";} else { $QueryId_programa_elearning = "";}
    if ($id_malla != "0")               {$QueryIdMalla = " and h.id_malla=:id_malla ";}                       else { $QueryIdMalla = "";}
    if ($id_curso != "0")               {$QueryIdCurso = " and h.id_curso=:id_curso ";}                       else { $QueryIdCurso = "";}
    if ($imparticion != "0")            {$QueryIdImparticion    = " and h.id_inscripcion=:id_imparticion ";}     else { $QueryIdImparticion = "";}
    if ($ejecutivo != "0")              {$QueryEjecutivo        = " and h.rut_ejecutivo=:rut_ejecutivo ";}         else { $QueryEjecutivo = "";}
    if ($modalidad != "0")              {$QueryModalidad        = " and h.status=:modalidad ";}               else { $QueryModalidad = "";}
    if ($fecha_inicio != "")            {$fecha_inicio=$fecha_inicio."-01";
                                         $QueryFecha_inicio     = " and h.fecha_inicio>=:fecha_inicio ";}          else { $QueryFecha_inicio = "";}
    if ($fecha_termino != "")           {$fecha_termino=$fecha_termino."-31";
                                        $QueryFecha_termino    = " and h.fecha_termino<=:fecha_termino ";}         else { $QueryFecha_termino = "";}
    if ($estado != "0")                 {

        if($estado=="FINALIZADO")   { $QEstado=" and h.asistencia='100%'  ";}
        if($estado=="EN_PROCESO")   { $QEstado=" and h.asistencia<>'100%'   and h.asistencia='0%'  ";}
        if($estado=="NO_INICIADO")  { $QEstado=" and h.asistencia='0%'  ";}

        $QueryEstado           = $QEstado;} else { $QueryEstado = "";}

    $sql = "
            select h.* from tbl_lms_reportes_full h where h.id>0
              $QueryIdFoco
              $QueryIdPrograma
              $QueryId_programa_elearning
              $QueryIdMalla
              $QueryIdCurso
              $QueryIdImparticion
              $QueryEjecutivo
              $QueryModalidad
              $QueryFecha_inicio
              $QueryFecha_termino
              $QueryEstado
              and h.rut=:rut  and h.id_curso=:id_curso
            group by h.id_curso
            order by h.curso
    ";

    $connexion->query($sql);
    $connexion->bind(':id_foco', $id_foco);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_programa_elearning', $id_programa_elearning);
    $connexion->bind(':id_malla', $id_malla);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_imparticion', $imparticion);
    $connexion->bind(':rut_ejecutivo', $ejecutivo);
    $connexion->bind(':modalidad', $modalidad);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->bind(':rut', $rut);

    $cod = $connexion->resultset();
    return $cod;
}

function lms_reportes_full_excel_rut_data($id_empresa, $id_foco, $id_programa, $id_programa_elearning, $id_malla, $id_curso, $tipo_filtro, $imparticion, $ejecutivo, $modalidad, $fecha_inicio, $fecha_termino, $estado, $rut) {
    $connexion = new DatabasePDO();

    if ($id_foco != "0")                {$QueryIdFoco = " and h.id_foco=:id_foco ";}                          else { $QueryIdFoco = "";}
    if ($id_programa != "0")            {$QueryIdPrograma = " and h.id_programa_global=:id_programa ";}       else { $QueryIdPrograma = "";}
    if ($id_programa_elearning != "0")  {$QueryId_programa_elearning = " and h.id_programa=:id_programa_elearning ";} else { $QueryId_programa_elearning = "";}
    if ($id_malla != "0")               {$QueryIdMalla = " and h.id_malla=:id_malla ";}                       else { $QueryIdMalla = "";}
    if ($id_curso != "0")               {$QueryIdCurso = " and h.id_curso=:id_curso ";}                       else { $QueryIdCurso = "";}
    if ($imparticion != "0")            {$QueryIdImparticion    = " and h.id_inscripcion=:id_imparticion ";}     else { $QueryIdImparticion = "";}
    if ($ejecutivo != "0")              {$QueryEjecutivo        = " and h.rut_ejecutivo=:rut_ejecutivo ";}         else { $QueryEjecutivo = "";}
    if ($modalidad != "0")              {$QueryModalidad        = " and h.status=:modalidad ";}               else { $QueryModalidad = "";}
    if ($fecha_inicio != "")            {$fecha_inicio=$fecha_inicio."-01";
                                         $QueryFecha_inicio     = " and h.fecha_inicio>=:fecha_inicio ";}          else { $QueryFecha_inicio = "";}
    if ($fecha_termino != "")           {$fecha_termino=$fecha_termino."-31";
                                        $QueryFecha_termino    = " and h.fecha_termino<=:fecha_termino ";}         else { $QueryFecha_termino = "";}
    if ($estado != "0")                 {

        if($estado=="FINALIZADO")   { $QEstado=" and h.asistencia='100%'  ";}
        if($estado=="EN_PROCESO")   { $QEstado=" and h.asistencia<>'100%' and h.asistencia='0%'  ";}
        if($estado=="NO_INICIADO")  { $QEstado=" and h.asistencia='0%'  ";}

        $QueryEstado           = $QEstado;} else { $QueryEstado = "";}

    $sql = "
            select h.* from tbl_lms_reportes_full h where h.id>0
              $QueryIdFoco
              $QueryIdPrograma
              $QueryId_programa_elearning
              $QueryIdMalla
              $QueryIdCurso
              $QueryIdImparticion
              $QueryEjecutivo
              $QueryModalidad
              $QueryFecha_inicio
              $QueryFecha_termino
              $QueryEstado
               and h.rut=:rut
              order by h.nombre
    ";

    $connexion->query($sql);
    $connexion->bind(':id_foco', $id_foco);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_programa_elearning', $id_programa_elearning);
    $connexion->bind(':id_malla', $id_malla);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_imparticion', $imparticion);
    $connexion->bind(':rut_ejecutivo', $ejecutivo);
    $connexion->bind(':modalidad', $modalidad);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->bind(':rut', $rut);

    $cod = $connexion->resultset();
    return $cod;
}

function Reportes_Express_Resultado_v2($id_programa, $fecha_inicio, $fecha_termino, $rut_col)
{
    $connexion = new DatabasePDO();
    
    if ($fecha_inicio <> "") {
        $QFI = " and h.fecha_inicio>='$fecha_inicio' ";
    } else {
        $QFI = "  ";
    }
    
    if ($fecha_termino <> "") {
        $QFT = " and h.fecha_termino>='$fecha_termino' ";
    } else {
        $QFT = "  ";
    }
    
    if ($id_programa <> "") {
        $QPro = " and h.id_programa='$id_programa'";
    } else {
        $QPro = "";
    }
    
    if ($rut_col <> "") {
        $QRUT = " and h.rut='$rut_col'";
    } else {
        $QRUT = "";
    }
    
    $sql = "
        select
        h.rut,h.rut_completo,h.nombre,h.cargo,h.email,h.c1,h.c2,h.c3,h.c4,h.id_programa,
        (select nombre_empresa_holding from tbl_usuario where rut=h.rut) as nombre_empresa_holding,
        
        (SELECT nombre_programa from tbl_lms_programas_bbdd where id_programa=h.id_programa)as programa,
        h.id_malla,
        (SELECT nombre from tbl_lms_malla where id=h.id_malla) as malla,
        h.id_curso,
        (SELECT nombre from tbl_lms_curso where id=h.id_curso) as curso,
        h.avance as avance_asistencia, h.resultado as resultado_evaluacion, h.fecha_inicio, h.fecha_termino,
        IF(h.curso_opcional='0','OBLIGATORIO','OPCIONAL') as curso_opcional,
        h.estado,h.fecha_inscripcion,h.jefe,
        (select nombre_empresa_holding from tbl_usuario where rut=h.rut) as nombre_empresa_holding,
        (select vigencia_descripcion from tbl_usuario where rut=h.rut) as vigencia_descripcion,
        (SELECT respuesta from tbl_enc_elearning_respuestas where rut=h.rut and id_curso=h.id_curso and id_pregunta='bch4' limit 1) as Evaluacion_Satistaccion,
        (SELECT comentario from tbl_enc_elearning_respuestas where rut=h.rut and id_curso=h.id_curso and id_pregunta='bch4' limit 1) as Comentario_Satisfaccion,
        (select fecha_desde from tbl_usuario_ausentismo where rut=h.rut) as fecha_desde,
        (select fecha_hasta from tbl_usuario_ausentismo where rut=h.rut) as fecha_hasta,
        (select tipo_ausentismo from tbl_usuario_ausentismo where rut=h.rut) as tipo_ausentismo
        
        from tbl_lms_reportes h
        
        WHERE
        
        h.id>0
        
        and 
        (
            (select vigencia_descripcion from tbl_usuario where rut=h.rut)='' 
                or 
            (select vigencia_descripcion from tbl_usuario where rut=h.rut) is null
        )
        
        and h.rut<>''
        and h.id_programa<>'bch_histor'
        
        $QPro
        $QRUT
        $QFI
        $QFT
    ";
    
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lms_integracion_lista_programas_ADMIN($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT 
        h.rut, h.rut_completo, h.nombre as nombre_completo, h.cargo as cargo, h.email as email, h.c1 as division,
        h.id_curso, (SELECT nombre FROM tbl_lms_curso WHERE id=h.id_curso) as curso,
        h.id_programa, (SELECT nombre_programa FROM tbl_lms_programas_bbdd WHERE id_programa=h.id_programa) as programa,
        h.avance, h.resultado as nota, 
        (SELECT modalidad FROM tbl_lms_curso WHERE id=h.id_curso) as modalidad,
        h.estado as estado,
        h.curso_opcional as curso_opcional
        FROM tbl_lms_reportes h 
        WHERE h.rut = :rut
        AND h.id_programa <> 'bch_histor'
        AND (SELECT modalidad FROM tbl_lms_curso WHERE id=h.id_curso) = '1'
        ORDER BY h.curso_opcional, (SELECT modalidad FROM tbl_lms_curso WHERE id=h.id_curso), (SELECT nombre FROM tbl_lms_curso WHERE id = h.id_curso)";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}

function data_rel_id_inscripcion_curso_rut_unico_limit_ultima_data($rut, $id_curso)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT id_inscripcion FROM rel_lms_rut_id_curso_id_inscripcion WHERE rut = :rut AND id_curso = :id_curso ORDER BY fecha_inicio_inscripcion DESC LIMIT 1";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();

    return $cod[0]->id_inscripcion;
}

function reportes_online_lms_reporte($id_curso, $rut)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT fecha_inicio, fecha_termino, avance, resultado, estado FROM tbl_lms_reportes WHERE id_curso = :id_curso AND rut = :rut";

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();

    return $cod;
}

function VerificoCursoPorEmpresa($id_curso, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_lms_curso WHERE id = :id_curso AND id_empresa = :id_empresa";

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function lista_becas_data($id_empresa) {
    $connexion = new DatabasePDO();

    $tbl_becas = $_SESSION["tbl_becas"];

    $sql = "
        SELECT h.*,
        (SELECT COUNT(id) FROM $tbl_becas WHERE id_empresa = h.id_empresa AND tipo_beca = h.tipo_beca) AS postulantes,
        (SELECT COUNT(id) FROM $tbl_becas WHERE id_empresa = h.id_empresa AND tipo_beca = h.tipo_beca AND documentacionok = '1') AS documentacion_ok,
        (SELECT COUNT(id) FROM $tbl_becas WHERE id_empresa = h.id_empresa AND tipo_beca = h.tipo_beca AND validacionjefe1 = '1') AS validacionjefe_1,
        (SELECT COUNT(id) FROM $tbl_becas WHERE id_empresa = h.id_empresa AND tipo_beca = h.tipo_beca AND validacionjefe2 = '1') AS validacionjefe_2
        FROM $tbl_becas h
        WHERE h.id_empresa = :id_empresa
        GROUP BY h.tipo_beca";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function DescargaTodasBecas_CSV_DataXLS($id_empresa, $id_tipo) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*
        FROM " . $_SESSION["tbl_becas"] . " h
        WHERE
        h.id_empresa = :id_empresa
        AND h.tipo_beca = :id_tipo
        AND h.nombre_beca <> ''
        ORDER BY h.fecha DESC, h.hora DESC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_tipo', $id_tipo);
    $cod = $connexion->resultset();

    return $cod;
}

function lista_becas_validacion_data($idcategoria, $id_empresa) {
    $connexion = new DatabasePDO();

    if ($_SESSION["rut_col"] != "") {
        $Jquery = " AND h.rut = :rut";
    } else {
        $Jquery = "";
    }

    $tbl_becas = $_SESSION["tbl_becas"];

    $sql = "SELECT h.*, 
        (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.rut) AS nombre,
        (SELECT cargo FROM tbl_usuario WHERE rut = h.rut) AS cargo,
        (SELECT division FROM tbl_usuario WHERE rut = h.rut) AS division
        FROM $tbl_becas h
        WHERE h.id_empresa = :id_empresa
        $Jquery
        AND h.tipo_beca = :idcategoria";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':idcategoria', $idcategoria);
    if ($_SESSION["rut_col"] != "") {
        $connexion->bind(':rut', $_SESSION["rut_col"]);
    }
    $cod = $connexion->resultset();

    return $cod;
}

function BecasUpdateDocumentacionTipoRut($rut, $tipo, $archivo)
{
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_becas SET $tipo = :archivo WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':archivo', $archivo);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
}
function BecasUpdateDocumentacionTipo($idenc, $tipo, $validacion_doc, $fecha)
{
    $connexion = new DatabasePDO();

    $sql = "UPDATE tbl_becas
            SET $tipo = :validacion_doc
            WHERE id = :idenc";

    $connexion->query($sql);
    $connexion->bind(':validacion_doc', $validacion_doc);
    $connexion->bind(':idenc', $idenc);
    $connexion->execute();

    $sql1 = "UPDATE tbl_becas
             SET usuario_validador = :user
             WHERE id = :idenc";

    $connexion->query($sql1);
    $connexion->bind(':user', $_SESSION["user"]); // Assuming $_SESSION["user"] contains the user value
    $connexion->bind(':idenc', $idenc);
    $connexion->execute();

 
}
function TraeMedicionesPorEmpresa($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT COUNT(id) FROM tbl_enc_elearning_preg WHERE id_encuesta = h.id) AS num_preguntas FROM tbl_enc_elearning h WHERE id_empresa = :id_empresa ORDER BY h.id DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function MP_SaveNuevaMedicion_data($nombre_evaluacion, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_enc_elearning ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod2 = $connexion->resultset();
    $id_nuevo = $cod2[0]->id + 1;
    $sql = "INSERT INTO tbl_enc_elearning (id, nombre, id_empresa) VALUES (:id_nuevo, :nombre_evaluacion, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':id_nuevo', $id_nuevo);
    $connexion->bind(':nombre_evaluacion', utf8_decode($nombre_evaluacion));
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
}

function MP_SaveNuevaEncuesta_data($nombre_evaluacion, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_enc_elearning ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod2 = $connexion->resultset();
    $id_nuevo = $cod2[0]->id + 1;
    $sql = "INSERT INTO tbl_enc_elearning (id, nombre, id_empresa) VALUES (:id_nuevo, :nombre_evaluacion, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':id_nuevo', $id_nuevo);
    $connexion->bind(':nombre_evaluacion', utf8_decode($nombre_evaluacion));
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
}

function MP_SaveEditNuevaEncuesta_data($nombre_evaluacion, $id_evaluacion, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_enc_elearning ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod2 = $connexion->resultset();
    $id_nuevo = $cod2[0]->id + 1;
    $sql = "UPDATE tbl_enc_elearning SET nombre = :nombre_evaluacion WHERE id = :id_evaluacion AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':nombre_evaluacion', utf8_decode($nombre_evaluacion));
    $connexion->bind(':id_evaluacion', $id_evaluacion);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
}

function MP_SaveNuevaEncuesta_dataMed($nombre_medicion, $banco_preguntas, $tipo_medicion, $descripcion_medicion, $datos_medicion, $imagen_medicion, $footer_medicion, $id_empresa, $imagen_back)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_enc_elearning_medicion ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod2 = $connexion->resultset();
    $id_nuevo = $cod2[0]->id + 1;
    $sql = "INSERT INTO tbl_enc_elearning_medicion (id, nombre, descripcion, id_empresa, tipo_medicion, id_encuesta, fecha1, fecha2, fecha3, titulo, bajada_titulo, footer1, footer2, footerfinal, bajada_subtitulo, bajada_texto, imagensuperior, imageninferior, imagenlogo) VALUES (:id_nuevo, :nombre_medicion, :descripcion_medicion, :id_empresa, :tipo_medicion, :banco_preguntas, :fecha1, :fecha2, :fecha3, :nombre_medicion, :descripcion_medicion, :footer_medicion, '', '', '', 'x', :imagen_medicion, :imagen_back, '')";
    $connexion->query($sql);
    $connexion->bind(':id_nuevo', $id_nuevo);
    $connexion->bind(':nombre_medicion', utf8_decode($nombre_medicion));
    $connexion->bind(':descripcion_medicion', utf8_decode($descripcion_medicion));
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo_medicion', $tipo_medicion);
    $connexion->bind(':banco_preguntas', $banco_preguntas);
    $connexion->bind(':fecha1', $fecha1);
    $connexion->bind(':fecha2', $fecha2);
    $connexion->bind(':fecha3', $fecha3);
    $connexion->bind(':footer_medicion', utf8_decode($footer_medicion));
    $connexion->bind(':imagen_medicion', utf8_decode($imagen_medicion));
    $connexion->bind(':imagen_back', $imagen_back);
    $connexion->execute();
    $cod = $connexion->resultset();
}

function MP_SaveNuevaEncuestaAdmin_dataMed($usuario_user, $usuario_clave, $usuario_name, $acceso, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_admin ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod2 = $connexion->resultset();
    $id_nuevo = $cod2[0]->id + 1;
    $sql = "INSERT INTO tbl_admin (user, pass, nombre, acceso, id_empresa) VALUES (:usuario_user, :usuario_clave, :usuario_name, :acceso, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':usuario_user', $usuario_user);
    $connexion->bind(':usuario_clave', $usuario_clave);
    $connexion->bind(':usuario_name', utf8_decode($usuario_name));
    $connexion->bind(':acceso', $acceso);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
}

function MP_SaveNuevaMedicion_dataMed($nombre_medicion, $banco_preguntas, $tipo_medicion, $fecha1, $fecha2, $fecha3, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_enc_elearning_medicion ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod2 = $connexion->resultset();
    $id_nuevo = $cod2[0]->id + 1;
    $sql = "INSERT INTO tbl_enc_elearning_medicion (id, nombre, id_empresa, tipo_medicion, id_encuesta, fecha1, fecha2, fecha3) VALUES (:id_nuevo, :nombre_medicion, :id_empresa, :tipo_medicion, :banco_preguntas, :fecha1, :fecha2, :fecha3)";
    $connexion->query($sql);
    $connexion->bind(':id_nuevo', $id_nuevo);
    $connexion->bind(':nombre_medicion', utf8_decode($nombre_medicion));
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo_medicion', $tipo_medicion);
    $connexion->bind(':banco_preguntas', $banco_preguntas);
    $connexion->bind(':fecha1', $fecha1);
    $connexion->bind(':fecha2', $fecha2);
    $connexion->bind(':fecha3', $fecha3);
    $connexion->execute();
    $cod = $connexion->resultset();
}

function TraigoTotalPreguntasMedicionPorEval($id_evaluacion) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_enc_elearning_preg WHERE id_encuesta = :id_evaluacion";
    $connexion->query($sql);
    $connexion->bind(':id_evaluacion', $id_evaluacion);
    $cod = $connexion->resultset();
    return $cod;
}

function EvaluacionesInsertaPreguntaMedicion($pregunta, $tipo, $evaluacion, $orden, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_enc_elearning_preg (id_encuesta, id_pregunta, pregunta, id_empresa, tipo) VALUES (:evaluacion, :orden, :pregunta, :id_empresa, :tipo)";
    $connexion->query($sql);
    $connexion->bind(':evaluacion', $evaluacion);
    $connexion->bind(':orden', $orden);
    $connexion->bind(':pregunta', $pregunta);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo', $tipo);
    $connexion->execute();
}

function EvaluacionesInsertaPreguntaEncuestaLB($id_encuesta, $id_pregunta, $pregunta, $id_empresa, $tipo, $alt1, $alt2, $alt3, $alt4, $alt5, $alt6, $alt7, $alt8, $alt9, $alt10, $alt11, $alt12, $alt13, $alt14, $alt15, $alt16, $alt17, $alt18, $alt19, $alt20, $niv1, $niv2, $linkpregunta, $linkopcion, $orde_de_pregunta, $id_seccion, $Obligatoria) {
    $connexion = new DatabasePDO();
    if ($niv1 != '') {
        $alt1 = $niv1;
    }
    if ($niv2 != '') {
        $alt2 = $niv2;
    }
    $sql = "INSERT INTO tbl_enc_elearning_preg (id_encuesta, id_pregunta, pregunta, id_empresa, tipo, dimension, alt1, alt2, alt3, alt4, alt5, alt6, alt7, alt8, alt9, alt10, dimension_descripcion, descripcion_pregunta, alt11, alt12, alt13, alt14, alt15, alt16, alt17, alt18, alt19, alt20, linkpregunta, linkopcion, id_seccion, obligatoria) VALUES (:id_encuesta, :orde_de_pregunta, :pregunta, :id_empresa, :tipo, :dimension, :alt1, :alt2, :alt3, :alt4, :alt5, :alt6, :alt7, :alt8, :alt9, :alt10, :dimension_descripcion, :descripcion_pregunta, :alt11, :alt12, :alt13, :alt14, :alt15, :alt16, :alt17, :alt18, :alt19, :alt20, :linkpregunta, :linkopcion, :id_seccion, :Obligatoria)";
    $connexion->query($sql);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $connexion->bind(':orde_de_pregunta', $orde_de_pregunta);
    $connexion->bind(':pregunta', $pregunta);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo', $tipo);
    $connexion->bind(':dimension', $dimension);
    $connexion->bind(':alt1', $alt1);
    $connexion->bind(':alt2', $alt2);
    $connexion->bind(':alt3', $alt3);
    $connexion->bind(':alt4', $alt4);
    $connexion->bind(':alt5', $alt5);
    $connexion->bind(':alt6', $alt6);
    $connexion->bind(':alt7', $alt7);
    $connexion->bind(':alt8', $alt8);
    $connexion->bind(':alt9', $alt9);
    $connexion->bind(':alt10', $alt10);
    $connexion->bind(':dimension_descripcion', $dimension_descripcion);
    $connexion->bind(':descripcion_pregunta', $descripcion_pregunta);
    $connexion->bind(':alt11', $alt11);
    $connexion->bind(':alt12', $alt12);
    $connexion->bind(':alt13', $alt13);
    $connexion->bind(':alt14', $alt14);
    $connexion->bind(':alt15', $alt15);
    $connexion->bind(':alt16', $alt16);
    $connexion->bind(':alt17', $alt17);
    $connexion->bind(':alt18', $alt18);
    $connexion->bind(':alt19', $alt19);
    $connexion->bind(':alt20', $alt20);
    $connexion->bind(':linkpregunta', $linkpregunta);
    $connexion->bind(':linkopcion', $linkopcion);
    $connexion->bind(':id_seccion', $id_seccion);
    $connexion->bind(':Obligatoria', $Obligatoria);
    $connexion->execute();
}

function DatosMedicionAdminUsers($idMed, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT nombre FROM tbl_enc_elearning WHERE id = h.id_encuesta) AS bancopreguntas, (SELECT COUNT(id) FROM tbl_nomina_encuesta WHERE id_encuesta = h.id_encuesta) AS usuarios, (SELECT COUNT(id) FROM tbl_nomina_encuesta_editor WHERE id_encuesta = h.id_encuesta AND perfil = 'editor') AS editores, (SELECT COUNT(id) FROM tbl_nomina_encuesta_editor WHERE id_encuesta = h.id_encuesta AND perfil = 'visualizador') AS visualizadores FROM tbl_enc_elearning_medicion h WHERE h.id_empresa = :id_empresa AND id = :idMed";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':idMed', $idMed);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_Encuestas_Tipo_Usuario($id_empresa, $id_encuesta, $tipo_usuario) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_nomina_encuesta WHERE id_encuesta = :id_encuesta AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function Truncate_Encuesta_Usuario($id_encuesta) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_nomina_encuesta WHERE id_encuesta = :id_encuesta";
    $connexion->query($sql);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $connexion->execute();
}

function Inserta_Nueva_Encuesta_Usuario_Tipo($rut, $id_encuesta, $id_empresa) {
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $hora  = date("H:i:s");
    $sql   = "INSERT INTO tbl_nomina_encuesta (rut, id_encuesta, id_empresa) VALUES (:rut, :id_encuesta, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}

function DatosMedicionAdmin($idMed) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_enc_elearning_medicion WHERE id = :idMed ORDER BY id DESC";
    $connexion->query($sql);
    $connexion->bind(':idMed', $idMed);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaUsuariosRespondieronEncLBSinUsuario_CadaLineaRespuesta($idMed) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_enc_elearning_respuestas h WHERE h.id_medicion = :idMed";
    $connexion->query($sql);
    $connexion->bind(':idMed', $idMed);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaPreguntasIdPregunta($id_pregunta, $id_encuesta) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_enc_elearning_preg WHERE id_pregunta = :id_pregunta AND id_encuesta = :id_encuesta";
    $connexion->query($sql);
    $connexion->bind(':id_pregunta', $id_pregunta);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $cod = $connexion->resultset();
    return $cod;
}

function encuestas_busca_idultimomasunodos() {
    $connexion = new DatabasePDO();
    $sql = "SELECT MAX(id) AS maximo FROM tbl_enc_elearning";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaMediciones_UnicaData($id_empresa, $idmed) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_enc_elearning_medicion h WHERE id = :idmed AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':idmed', $idmed);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_tbl_enc_elearning_medicion($id, $nombre, $descripcion, $id_empresa, $tipo_medicion, $id_encuesta, $footerfinal) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_enc_elearning_medicion (id, nombre, descripcion, id_empresa, tipo_medicion, id_encuesta, footerfinal) VALUES (:id, :nombre, :descripcion, :id_empresa, :tipo_medicion, :id_encuesta, :footerfinal)";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->bind(':nombre', $nombre);
    $connexion->bind(':descripcion', $descripcion);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo_medicion', $tipo_medicion);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $connexion->bind(':footerfinal', $footerfinal);
    $connexion->execute();
}

function Insert_tbl_enc_elearning($id, $nombre, $descripcion, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_enc_elearning (id, nombre, descripcion, id_empresa) VALUES (:id, :nombre, :descripcion, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->bind(':nombre', $nombre);
    $connexion->bind(':descripcion', $descripcion);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}

function Trae_Preguntas_Grafico($id_encuesta, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_enc_elearning_preg WHERE id_encuesta = :id_encuesta AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_tbl_enc_elearning_preg($id_encuesta, $id_pregunta, $pregunta, $id_empresa, $tipo, $dimension, $alt1, $alt2, $alt3, $alt4, $alt5, $alt6, $alt7, $alt8, $alt9, $alt10, $dimension_descripcion, $descripcion_pregunta, $linkpregunta, $linkopcion, $alt11, $alt12, $alt13, $alt14, $alt15, $alt16, $alt17, $alt18, $alt19, $alt20) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_enc_elearning_preg (id_encuesta, id_pregunta, pregunta, id_empresa, tipo, dimension, alt1, alt2, alt3, alt4, alt5, alt6, alt7, alt8, alt9, alt10, dimension_descripcion, descripcion_pregunta, linkpregunta, linkopcion, alt11, alt12, alt13, alt14, alt15, alt16, alt17, alt18, alt19, alt20) VALUES (:id_encuesta, :id_pregunta, :pregunta, :id_empresa, :tipo, :dimension, :alt1, :alt2, :alt3, :alt4, :alt5, :alt6, :alt7, :alt8, :alt9, :alt10, :dimension_descripcion, :descripcion_pregunta, :linkpregunta, :linkopcion, :alt11, :alt12, :alt13, :alt14, :alt15, :alt16, :alt17, :alt18, :alt19, :alt20)";
    $connexion->query($sql);
    $connexion->bind(':id_encuesta', $id_encuesta);
    $connexion->bind(':id_pregunta', $id_pregunta);
    $connexion->bind(':pregunta', $pregunta);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':tipo', $tipo);
    $connexion->bind(':dimension', $dimension);
    $connexion->bind(':alt1', $alt1);
    $connexion->bind(':alt2', $alt2);
    $connexion->bind(':alt3', $alt3);
    $connexion->bind(':alt4', $alt4);
    $connexion->bind(':alt5', $alt5);
    $connexion->bind(':alt6', $alt6);
    $connexion->bind(':alt7', $alt7);
    $connexion->bind(':alt8', $alt8);
    $connexion->bind(':alt9', $alt9);
    $connexion->bind(':alt10', $alt10);
    $connexion->bind(':dimension_descripcion', $dimension_descripcion);
    $connexion->bind(':descripcion_pregunta', $descripcion_pregunta);
    $connexion->bind(':linkpregunta', $linkpregunta);
    $connexion->bind(':linkopcion', $linkopcion);
    $connexion->bind(':alt11', $alt11);
    $connexion->bind(':alt12', $alt12);
    $connexion->bind(':alt13', $alt13);
    $connexion->bind(':alt14', $alt14);
    $connexion->bind(':alt15', $alt15);
    $connexion->bind(':alt16', $alt16);
    $connexion->bind(':alt17', $alt17);
    $connexion->bind(':alt18', $alt18);
    $connexion->bind(':alt19', $alt19);
    $connexion->bind(':alt20', $alt20);
    $connexion->execute();
}

function BuscaPerfilDeRutAdmin($rut) {
    $connexion = new DatabasePDO();
    $sql = "SELECT acceso FROM tbl_admin WHERE user = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->acceso;
}

function BuscaNombrePerfilDeRutAdmin($rut) {
    $connexion = new DatabasePDO();
    $sql = "SELECT nombre FROM tbl_admin WHERE user = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $cod = $connexion->resultset();
    return $cod[0]->nombre;
}

function lista_publicaciones_fns_categoria_data($categoria, $perfil, $id_empresa, $filtro_temporalidad, $filtro_creador, $filtro_mes_ano) {
    $connexion = new DatabasePDO();
    $query_agrupacion = ($categoria !== "") ? " AND h.agrupacion = :categoria" : "";
    $query_perfil = "";
    $perfil = ($perfil);

    if ($perfil === "") {
        $query_perfil = "";
    }

    if ($perfil === "Control de Gestion") {
        $query_perfil = " AND (h.perfil = '' OR h.perfil IS NULL)";
    }
    
    if ($perfil === "Gestion e Incentivos") {
        $query_perfil = " AND (h.perfil = 'Gestion e Incentivos' OR h.perfil = '' OR h.perfil IS NULL)";
    }

    $hoy = date("Y-m-d");

    switch ($filtro_temporalidad) {
        case "Activo":
            $query_Temporalidad = " AND h.fecha_termino >= :hoy AND h.fecha_inicio <= :hoy";
            break;
        case "Historico":
            $query_Temporalidad = " AND h.fecha_termino < :hoy";
            break;
        case "Futuro":
            $query_Temporalidad = " AND h.fecha_inicio > :hoy";
            break;
        default:
            $query_Temporalidad = "";
            break;
    }

    $query_Creador = ($filtro_creador !== "") ? " AND h.autor = :filtro_creador" : "";
    $query_MesAno = ($filtro_mes_ano !== "") ? " AND EXTRACT(YEAR_MONTH FROM h.fecha_inicio) = :filtro_mes_ano" : "";

    $sql = "
    SELECT h.*,
        (SELECT nombre FROM tbl_audiencia WHERE id = h.id_audiencia) AS audiencia,
        (SELECT sqlquery FROM tbl_audiencia WHERE id = h.id_audiencia) AS sqlquery,
        (SELECT nombre FROM tbl_audiencia_documentos WHERE id = h.id_documento) AS documento,
        (SELECT filename_enc FROM tbl_audiencia_documentos WHERE id = h.id_documento) AS filename_enc,
        (SELECT negocio FROM tbl_audiencia_negocio WHERE id = h.negocio) AS nombre_negocio
    FROM tbl_audiencia_publicaciones h
    WHERE h.id_empresa = :id_empresa
        $query_agrupacion
        $query_perfil
        $query_Creador
        $query_MesAno
        $query_Temporalidad
    ORDER BY h.fecha_inicio DESC
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':categoria', $categoria);
    $connexion->bind(':hoy', $hoy);
    $connexion->bind(':filtro_creador', $filtro_creador);
    $connexion->bind(':filtro_mes_ano', $filtro_mes_ano);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_negocios_data($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_audiencia_negocio ORDER BY negocio ASC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_documentos_data_tipoYear($id_empresa, $filtro_creador, $filtro_mes_ano, $year, $condicion) {
    $connexion = new DatabasePDO();

    if ($filtro_creador !== "") {
        $queryAutor = " AND autor = :filtro_creador";
    } else {
        $queryAutor = "";
    }

    if ($filtro_mes_ano !== "") {
        $queryMesAno = " AND EXTRACT(YEAR_MONTH FROM fecha) = :filtro_mes_ano";
    } else {
        $queryMesAno = "";
    }

    if ($condicion === "NOT_yearactual") {
        $query_date = " AND YEAR(fecha) <> :year";
    } elseif ($condicion === "yearactual") {
        $query_date = " AND YEAR(fecha) = :year";
    }

    $sql = "
        SELECT *
        FROM tbl_audiencia_documentos
        WHERE id_empresa = :id_empresa
        $queryAutor
        $queryMesAno
        $query_date
        ORDER BY nombre ASC
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':filtro_creador', $filtro_creador);
    $connexion->bind(':filtro_mes_ano', $filtro_mes_ano);
    $connexion->bind(':year', $year);
    $cod = $connexion->resultset();
    return $cod;
}

function AUDIENCIA_TotalAudienciasPorempresaOrderDesc($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_audiencia WHERE id_empresa = :id_empresa ORDER BY nombre ASC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_documentos_data($id_empresa, $filtro_creador, $filtro_mes_ano) {
    $connexion = new DatabasePDO();

    if ($filtro_creador !== "") {
        $queryAutor = " AND autor = :filtro_creador";
    } else {
        $queryAutor = "";
    }

    if ($filtro_mes_ano !== "") {
        $queryMesAno = " AND EXTRACT(YEAR_MONTH FROM fecha) = :filtro_mes_ano";
    } else {
        $queryMesAno = "";
    }

    $sql = "
        SELECT *
        FROM tbl_audiencia_documentos
        WHERE id_empresa = :id_empresa
        $queryAutor
        $queryMesAno
        ORDER BY nombre ASC
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':filtro_creador', $filtro_creador);
    $connexion->bind(':filtro_mes_ano', $filtro_mes_ano);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaCreadoresPublicaciones($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*, 
        (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.autor) AS nombre_completo
        FROM tbl_audiencia_publicaciones h
        WHERE h.autor <> ''
        GROUP BY h.autor 
        ORDER BY (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.autor) ASC
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaAnosPublicaciones($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT EXTRACT(YEAR_MONTH FROM fecha_inicio) AS mes_ano
        FROM tbl_audiencia_publicaciones 
        GROUP BY EXTRACT(YEAR_MONTH FROM fecha_inicio) ASC
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaDatosAudiencia($id_audiencia_edit) {
    $connexion = new DatabasePDO();

    $fecha = date("Y-m-d");
    $sql = "SELECT * FROM tbl_audiencia WHERE id = :id_audiencia_edit";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia_edit', $id_audiencia_edit);
    $cod = $connexion->resultset();
    return $cod;
}
function MatrizIncentivos_Lista_campo_data($campo1, $campo2, $campo3, $campo4, $campo5, $campo6, $filtro1, $filtro2, $filtro3, $filtro4, $filtro5, $filtro6, $excluir, $incluir, $id_empresa)
{
    $connexion = new DatabasePDO();
    
    $query_inicio_1 = "";
    $query_filtro_or_1 = "";
    $contador1 = 0;
    $contador_total1 = 0;
    $query_filtro_1 = explode(";", $filtro1);
    
    foreach ($query_filtro_1 as $unico1) { if ($unico1 <> "") { $contador_total1++; } }
    
    foreach ($query_filtro_1 as $unico1) {
        if ($unico1 <> "") {
            $query_filtro_or1 .= "  $campo1 = '$unico1' ";
            $contador_total1 = $contador_total1;
            if ($contador1 < ($contador_total1 - 1)) {
                $query_filtro_or1 .= " or ";
            }
            $contador1++;
        }
    }
    
    if ($query_filtro_or1 <> "") {
        $query_inicio1 = " and ($query_filtro_or1) ";
    }
    
    $sql1 = "SELECT $campo1 as dato FROM tbl_usuario
        WHERE $campo1 <> '' AND id_empresa = :id_empresa
        $query_inicio1
        GROUP BY $campo1 ORDER BY $campo1 ASC";
    
    $connexion->query($sql1);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod1 = $connexion->resultset();
    
    foreach ($query_filtro_2 as $unico2){		if($unico2<>""){$contador_total2++;	}}
	foreach ($query_filtro_2 as $unico2){		if($unico2<>""){
			$query_filtro_or2.="  $campo2 = '$unico2'  ";
			$contador_total2=$contador_total2;
				if($contador2<$contador_total2-1){					
				$query_filtro_or2.=" or ";					}			$contador2++;
		}}
	if($query_filtro_or2<>""){ $query_inicio2=" and ($query_filtro_or2) ";}
	
    $sql2 = "SELECT 	$campo2 as dato FROM 	tbl_usuario
		where $campo2<>'' AND id_empresa = :id_empresa
		$query_inicio1 $query_inicio2
		GROUP by $campo2 ORDER BY $campo2 ASC ";

    $connexion->query($sql2);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod2 = $connexion->resultset();
	
	$query_inicio_3="";	$query_filtro_or_3="";$contador3=0;$contador_total3=0;
	$query_filtro_3=explode(";", $filtro3);
	foreach ($query_filtro_3 as $unico3){		if($unico3<>""){$contador_total3++;	}}
	foreach ($query_filtro_3 as $unico3){		if($unico3<>""){
			$query_filtro_or3.="  $campo3 = '$unico3'  ";
			$contador_total3=$contador_total3;
				if($contador3<$contador_total3-1){					
				$query_filtro_or3.=" or ";					}			$contador3++;
		}}
	if($query_filtro_or3<>""){ $query_inicio3=" and ($query_filtro_or3) ";}	
	
	    $sql3 = "SELECT 	$campo3 as dato FROM 	tbl_usuario
			where $campo3<>'' AND id_empresa=:id_empresa
			$query_inicio1 $query_inicio2 $query_inicio3
			GROUP by $campo3 ORDER BY $campo3 ASC ";
	$connexion->query($sql3);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod3 = $connexion->resultset();
	
	$query_inicio_4="";	$query_filtro_or_4="";$contador4=0;$contador_total4=0;
	$query_filtro_4=explode(";", $filtro4);
	foreach ($query_filtro_4 as $unico4){		if($unico4<>""){$contador_total4++;	}}
	foreach ($query_filtro_4 as $unico4){		if($unico4<>""){
			$query_filtro_or4.="  $campo4 = '$unico4'  ";
			$contador_total4=$contador_total4;
				if($contador4<$contador_total4-1){					
				$query_filtro_or4.=" or ";					}			$contador4++;
		}}
	if($query_filtro_or4<>""){ $query_inicio4=" and ($query_filtro_or4) ";}	

    $sql4 = "SELECT 	$campo4 as dato FROM 	tbl_usuario
			where $campo4<>'' AND id_empresa=:id_empresa
			$query_inicio1 $query_inicio2 $query_inicio3 $query_inicio4
			GROUP by $campo4 ORDER BY $campo4 ASC ";
    $connexion->query($sql4);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod4 = $connexion->resultset();
	
	$query_inicio_5="";	$query_filtro_or_5="";$contador5=0;$contador_total5=0;
	$query_filtro_5=explode(";", $filtro5);
	foreach ($query_filtro_5 as $unico5){		if($unico5<>""){$contador_total5++;	}}
	foreach ($query_filtro_5 as $unico5){		if($unico5<>""){
			$query_filtro_or5.="  $campo5 = '$unico5'  ";
			$contador_total5=$contador_total5;
				if($contador5<$contador_total5-1){					
				$query_filtro_or5.=" or ";					}			$contador5++;
		}}
	if($query_filtro_or5<>""){ $query_inicio5=" and ($query_filtro_or5) ";}		

    $sql5 = "		SELECT 	$campo5 as dato FROM 	tbl_usuario
		where $campo5<>'' AND id_empresa=:id_empresa
		$query_inicio1 $query_inicio2 $query_inicio3 $query_inicio4 $query_inicio5
		GROUP by $campo5 ORDER BY $campo5 ASC ";
	$connexion->query($sql5);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod5 = $connexion->resultset();
	
	$query_inicio_6="";	$query_filtro_or_6="";$contador6=0;$contador_total6=0;
	$query_filtro_6=explode(";", $filtro6);
	foreach ($query_filtro_6 as $unico6){		if($unico6<>""){$contador_total6++;	}}
	foreach ($query_filtro_6 as $unico6){		if($unico6<>""){
			$query_filtro_or6.="  $campo6 = '$unico6'  ";
			$contador_total6=$contador_total6;
				if($contador6<$contador_total6-1){					
				$query_filtro_or6.=" or ";					}			$contador6++;
		}}
	if($query_filtro_or6<>""){ $query_inicio6=" and ($query_filtro_or6) ";}			

    $sql6 = "
		SELECT 	$campo6 as dato FROM 	tbl_usuario
		where $campo6<>'' AND id_empresa=:id_empresa
		$query_inicio1 $query_inicio2 $query_inicio3 $query_inicio4 $query_inicio5 $query_inicio6
		GROUP by $campo6 ORDER BY $campo6 ASC";
	$connexion->query($sql6);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod6 = $connexion->resultset();
	
	$query_inicio_7="";	$query_filtro_or_7="";$contador7=0;$contador_total7=0;
	$query_filtro_7=explode(";", $filtro7);
	foreach ($query_filtro_7 as $unico7){		if($unico7<>""){$contador_total7++;	}}
	foreach ($query_filtro_7 as $unico7){		if($unico7<>""){
			$query_filtro_or7.="  $campo7 = '$unico7'  ";
			$contador_total7=$contador_total7-1;
				if($contador7<$contador_total7){					
				$query_filtro_or7.=" or ";					}			$contador7++;
		}}
	if($query_filtro_or7<>""){ $query_inicio7=" and ($query_filtro_or7) ";}		

    $arreglo[1] = $cod1;
    $arreglo[2] = $cod2;
    $arreglo[3] = $cod3;
    $arreglo[4] = $cod4;
    $arreglo[5] = $cod5;
    $arreglo[6] = $cod6;

    $query_excluir = "";
    $post_excluir = explode(";", $excluir);
    foreach ($post_excluir as $unico) {
        $query_excluir .= "  and rut <> '$unico'";
    }

    $query_incluir = "";
    $post_incluir = explode(";", $incluir);
    foreach ($post_incluir as $unico) {
        $query_incluir .= "  or rut = '$unico' ";
    }

    $sql10 = "
        SELECT count(id) as cuenta FROM tbl_usuario
        WHERE $campo6 <> '' AND id_empresa = :id_empresa
        $query_inicio1 $query_inicio2 $query_inicio3 $query_inicio4 $query_inicio5 $query_inicio6
        $query_excluir $query_incluir
        ORDER BY $campo4 ASC
    ";
    
    $connexion->query($sql10);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod10 = $connexion->resultset();

    $sql11 = "
        SELECT * FROM tbl_usuario
        WHERE $campo6 <> '' AND id_empresa = :id_empresa
        $query_inicio1 $query_inicio2 $query_inicio3 $query_inicio4 $query_inicio5 $query_inicio6
        $query_excluir $query_incluir
        ORDER BY nombre_completo ASC
    ";
    
    $connexion->query($sql11);
    $connexion->bind(":id_empresa", $id_empresa);
    $cod11 = $connexion->resultset();

    $arreglo[7] = $cod10[0]->cuenta;
    $arreglo[8] = $cod10;
    $arreglo[9] = $sql11;

    return $arreglo;
}
function Audiencia_Save_NuevaAudiencia($nombre_audiencia, $descripcion_audiencia, $id_empresa, $sqlquery, $excluir, $incluir, $campos_filtros, $id_audiencia)
{
    $connexion = new DatabasePDO();
    $rut = $_SESSION["user_"];
    $fecha = date("Y-m-d");

    $campos_filtros_enc = Encodear3($campos_filtros);

    $nombre_audiencia = utf8_decode($nombre_audiencia);
    $descripcion_audiencia = utf8_decode($descripcion_audiencia);

    $sql = "select id from tbl_audiencia order by id DESC limit 1";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    $id_next = $cod[0]->id + 1;

    if ($id_audiencia > 0) {
        $sql = "update tbl_audiencia 
                set nombre = :nombre_audiencia,
                    descripcion = :descripcion_audiencia,
                    sqlquery = :sqlquery,
                    excluir = :excluir,
                    incluir = :incluir,
                    fecha = :fecha,
                    campos_filtros = :campos_filtros,
                    campos_filtros_enc = :campos_filtros_enc,
                    editor = :rut,
                    fecha_edicion = :fecha
                where id = :id_audiencia";

        TruncateRutIdAudiencia($id_audiencia);
        Audiencia_Sql($sqlquery, $id_audiencia, $id_empresa);
    } else {
        $sql = "insert into tbl_audiencia 
                (id, nombre, descripcion, id_empresa, sqlquery, excluir, incluir, fecha, campos_filtros, campos_filtros_enc, autor, fecha_creacion) 
                values(:id_next, :nombre_audiencia, :descripcion_audiencia, :id_empresa, :sqlquery, :excluir, :incluir, :fecha, :campos_filtros, :campos_filtros_enc, :rut, :fecha)";
        // AHORA NO GRABA AL MOMENTO; SINO QUE ESPERA CRON
    }
    $connexion->query($sql);
    $connexion->bind(':id_next', $id_next);
    $connexion->bind(':nombre_audiencia', $nombre_audiencia);
    $connexion->bind(':descripcion_audiencia', $descripcion_audiencia);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':sqlquery', $sqlquery);
    $connexion->bind(':excluir', $excluir);
    $connexion->bind(':incluir', $incluir);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':campos_filtros', $campos_filtros);
    $connexion->bind(':campos_filtros_enc', $campos_filtros_enc);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->execute();
}
function TruncateRutIdAudiencia($id_audiencia){
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_audiencia_id_audiencia_rut WHERE id_audiencia = :id_audiencia";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia', $id_audiencia);
    $connexion->execute();
}
function Audiencia_Sql($sqlquery, $id_audiencia, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = $sqlquery;
    $connexion->query($sql);
    $results = $connexion->resultset();
    
    $id_empresa = $_SESSION["id_empresa"];
    
    $insertSql = "INSERT INTO tbl_audiencia_id_audiencia_rut (rut, id_audiencia, id_empresa) VALUES (:rut, :id_audiencia, :id_empresa)";
    
    foreach ($results as $row) {
        $connexion->query($insertSql);
        $connexion->bind(':rut', $row->rut);
        $connexion->bind(':id_audiencia', $id_audiencia);
        $connexion->bind(':id_empresa', $id_empresa);
        $connexion->execute();
    }
    
    return count($results);
}
function lista_audiencia_data($id_empresa, $filtro_creador, $filtro_mes_ano) {
    $connexion = new DatabasePDO();
    
    $queryAutor = "";
    if ($filtro_creador !== "") {
        $queryAutor = "AND h.autor = :filtro_creador";
        $connexion->bind(':filtro_creador', $filtro_creador);
    }
    
    $queryMesAno = "";
    if ($filtro_mes_ano !== "") {
        $queryMesAno = "AND EXTRACT(YEAR_MONTH FROM h.fecha) = :filtro_mes_ano";
        $connexion->bind(':filtro_mes_ano', $filtro_mes_ano);
    }
    
    $sql = "
        SELECT h.*
        FROM tbl_audiencia h
        WHERE h.id_empresa = :id_empresa
        $queryAutor
        $queryMesAno
        ORDER BY h.id DESC    ";
    
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    
    return $cod;
}
function Cuenta_Audiencia_Sql($sqlquery, $id_audiencia, $id_empresa){
    $connexion = new DatabasePDO();
    
    $sql = "SELECT COUNT(id) AS cuenta FROM tbl_audiencia_id_audiencia_rut WHERE id_audiencia = :id_audiencia";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia', $id_audiencia);
    $connexion->execute();
    $cod = $connexion->resultset();
    
    return $cod[0]->cuenta;
}
function DeleteAudienciaFull($id_audiencia_del, $id_empresa)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $sql = "DELETE FROM tbl_audiencia WHERE id = :id_audiencia_del AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia_del', $id_audiencia_del);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();

    $sql = "DELETE FROM tbl_audiencia_id_audiencia_rut WHERE id_audiencia = :id_audiencia_del AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia_del', $id_audiencia_del);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function BuscaAnosAudiencia($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT EXTRACT(YEAR_MONTH FROM fecha) AS mes_ano FROM tbl_audiencia GROUP BY mes_ano ASC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaCreadoresAudiencias($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.autor) AS nombre_completo FROM tbl_audiencia h WHERE h.autor <> '' GROUP BY h.autor ORDER BY nombre_completo ASC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function DescargaAudienciaTodasFCXLS($sql)
{
    $connexion = new DatabasePDO();
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaIdProgramadadoIdCurso($id_curso_sent, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM rel_lms_malla_curso WHERE id_curso = :id_curso_sent AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_curso_sent', $id_curso_sent);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function TraeMallasPorProgramaT($id_empresa, $rut, $id_curso)
{
    $connexion = new DatabasePDO();
    $queryrut = "";
    if ($rut != '') {
        $queryrut = " AND (SELECT id_malla FROM rel_lms_malla_persona WHERE rut = :rut AND id_malla = h.id_malla AND rel_lms_malla_persona.id_empresa = h.id_empresa) = h.id_malla";
    }
    $sql = "SELECT h.*, (SELECT nombre FROM tbl_lms_malla WHERE id = h.id_malla LIMIT 1) AS nombre_malla
        FROM rel_lms_malla_curso h
        WHERE h.id_empresa = :id_empresa AND id_curso = :id_curso
        $queryrut
        AND h.id_curso <> ''
        GROUP BY h.id_malla
        ORDER BY (SELECT nombre FROM tbl_lms_malla WHERE id = h.id_malla LIMIT 1) LIMIT 1";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_curso', $id_curso);
    $cod = $connexion->resultset();
    return $cod;
}
function TraeMallasPorProgramaEmpresaRutSinVacios($id_empresa, $id_programa, $rut) {
    $connexion = new DatabasePDO();

    $queryrut = "";
    if ($rut != '') {
        $queryrut = " and (select id_malla from rel_lms_malla_persona where rut=:rut and id_malla=h.id_malla and rel_lms_malla_persona.id_empresa=h.id_empresa)=h.id_malla";
        $connexion->bind(':rut', $rut);
    }

    $sql = "SELECT h.*, (select nombre from tbl_lms_malla where id=h.id_malla) as nombre_malla
        FROM rel_lms_malla_curso h
        WHERE h.id_programa=:id_programa AND h.id_empresa=:id_empresa
        $queryrut
        AND h.id_curso<>'' AND h.id_clasificacion<>''
        GROUP BY h.id_malla
        ORDER BY (select nombre from tbl_lms_malla where id=h.id_malla)";

    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function TraeNombreUsuario($rut) {
    $connexion = new DatabasePDO();
    $sql = "SELECT nombre_completo FROM tbl_usuario WHERE rut=:rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function CuentaCursosMalla($id, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(*) as total FROM rel_lms_malla_curso WHERE id_malla=:id AND id_empresa=:id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod[0]->total;
}
function TotalClasifSinVacios($id_empresa, $id_malla) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT clasificacion FROM tbl_lms_clasificacion WHERE id_clasificacion=h.id_clasificacion AND id_empresa=h.id_empresa) as nombre,
        (SELECT descripcion FROM tbl_lms_clasificacion WHERE id_clasificacion=h.id_clasificacion AND id_empresa=h.id_empresa) as descripcion,
        (SELECT imagen FROM tbl_lms_clasificacion WHERE id_clasificacion=h.id_clasificacion AND id_empresa=h.id_empresa) as imagen,
        (SELECT opcional FROM tbl_lms_clasificacion WHERE id_clasificacion=h.id_clasificacion AND id_empresa=h.id_empresa) as opcional,
        (SELECT inactivo FROM tbl_lms_clasificacion WHERE id_clasificacion=h.id_clasificacion AND id_empresa=h.id_empresa) as inactivo
        FROM rel_lms_malla_curso h
        WHERE h.id_empresa=:id_empresa AND h.id_malla=:id_malla AND h.id_clasificacion<>''
        GROUP BY h.id_clasificacion
        ORDER BY h.orden_clasificacion ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_malla', $id_malla);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function TotalCursoSinVacios($id_empresa, $id_malla, $id_clasificacion) {
    $connexion = new DatabasePDO();
    $sql = "SELECT
    h.*,(        SELECT            nombre        FROM            tbl_lms_curso        WHERE            id_curso = tbl_lms_curso.id        AND id_empresa = h.id_empresa    )AS nombre,
    (        SELECT            descripcion        FROM            tbl_lms_curso        WHERE            tbl_lms_curso.id = h.id_curso        AND id_empresa = h.id_empresa    )AS descripcion,
    (        SELECT            modalidad        FROM            tbl_lms_curso        WHERE            tbl_lms_curso.id = h.id_curso        AND id_empresa = h.id_empresa    )AS modalidad,
    (        SELECT            tipo        FROM            tbl_lms_curso        WHERE            tbl_lms_curso.id = h.id_curso        AND id_empresa = h.id_empresa    )AS tipo,
    (        SELECT            imagen        FROM            tbl_lms_curso        WHERE            tbl_lms_curso.id = h.id_curso        AND id_empresa = h.id_empresa    )AS imagen,
    (        SELECT            opcional        FROM            tbl_lms_curso        WHERE            tbl_lms_curso.id = h.id_curso        AND id_empresa = h.id_empresa    )AS opcional,
    (        SELECT            inactivo        FROM            tbl_lms_curso        WHERE            tbl_lms_curso.id = h.id_curso        AND id_empresa = h.id_empresa    )AS inactivocurso,
    (        SELECT            modalidad        FROM            tbl_modalidad_curso        WHERE            id = (        SELECT            modalidad        FROM            tbl_lms_curso        WHERE            tbl_lms_curso.id = h.id_curso        AND id_empresa = h.id_empresa    )) as nombre_modalidad
	FROM
		rel_lms_malla_curso h
	WHERE
		h.id_empresa = :id_empresa
	AND h.id_malla = :id_malla
	AND h.id_clasificacion = :id_clasificacion
	and h.id_curso<>''
	GROUP BY
		h.id_curso
	ORDER BY
		h.orden_curso ASC";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_malla', $id_malla);
    $connexion->bind(':id_clasificacion', $id_clasificacion);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaSiguienteObjeto($id_curso) {
    $connexion = new DatabasePDO();
    $sql = "select h.*,
    (select max(orden) from tbl_objeto where id_curso=h.id_curso) as MaxOrden
     from tbl_objeto h where h.id_curso=:id_curso";

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaSiguienteEvaluacion() {
    $connexion = new DatabasePDO();
    $sql = "select max(id) as MaxEval from tbl_evaluaciones";

    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function TraeObjetosDadoCursoEmpresa($id_curso, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT
    tbl_tipo_objeto.nombre,
    tbl_objeto.*,
    (select count(id) from tbl_evaluaciones_preguntas where evaluacion=tbl_objeto.id_evaluacion) as numpreg,
    (select count(id) from tbl_evaluaciones_preguntas where evaluacion=tbl_objeto.id_evaluacion and pregunta<>'') as numpregValidas
	FROM
		tbl_objeto
	left join tbl_tipo_objeto
	on tbl_tipo_objeto.id=tbl_objeto.tipo_objeto
	WHERE
		id_curso = :id_curso
	AND id_empresa = :id_empresa
	order by orden";

    $connexion->query($sql);
    $connexion->bind(':id_curso', $id_curso);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaEvaluaciones($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_evaluaciones WHERE id_empresa = :id_empresa ORDER BY id DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaPreguntasDadaEvaluacion($id_eval, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_evaluaciones_preguntas WHERE evaluacion = :id_eval";
    $connexion->query($sql);
    $connexion->bind(':id_eval', $id_eval);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function TraeMallasEmpresa($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_lms_malla WHERE id_empresa = :id_empresa ORDER BY nombre ASC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function TraeProgramasBBDDPorEmpresaElearning($id_empresa) {
    $connexion = new DatabasePDO();
    
    $sql = "SELECT * FROM tbl_lms_programas_bbdd WHERE id_empresa = :id_empresa AND tipo <> 'GLOBAL' ORDER BY nombre_programa ASC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function VerSiExisteMalla($id_malla_sugerido) {
    $connexion = new DatabasePDO();
    $sql = "SELECT id FROM tbl_lms_malla WHERE id = :id_malla_sugerido";
    $connexion->query($sql);
    $connexion->bind(':id_malla_sugerido', $id_malla_sugerido);
    $connexion->execute();
    $cod = $connexion->resultset();
    $cuenta = count($cod);
    return $cuenta;
}
function BuscaMallaPrograma($id_programa, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_malla, (SELECT nombre FROM tbl_lms_malla WHERE id = h.id_malla) AS malla FROM rel_lms_malla_curso h WHERE h.id_programa = :id_programa AND h.id_empresa = :id_empresa AND h.id_malla <> '' GROUP BY h.id_malla";
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaClasificacionPrograma($id_programa, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_clasificacion, (SELECT clasificacion FROM tbl_lms_clasificacion WHERE id_clasificacion = h.id_clasificacion) AS clasificacion FROM rel_lms_malla_curso h WHERE h.id_programa = :id_programa AND h.id_empresa = :id_empresa AND h.id_clasificacion <> '' GROUP BY h.id_clasificacion";
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaCursoPrograma($id_programa, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.id_curso, (SELECT nombre FROM tbl_lms_curso WHERE id = h.id_curso) AS curso FROM rel_lms_malla_curso h WHERE h.id_programa = :id_programa AND h.id_empresa = :id_empresa AND h.id_curso <> '' GROUP BY h.id_curso";
    $connexion->query($sql);
    $connexion->bind(':id_programa', $id_programa);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaRespuestasUsuarioObjetoIdPregunta($rut, $id_pregunta, $id_objeto, $arreglo) {
    $connexion = new DatabasePDO();
    
    if ($arreglo == 1) {
        $queryObj .= " and ( ";
        foreach ($id_objeto as $unico) {
            $cuentaj++;
            $queryObj .= " h.id_objeto='" . $unico . "'";
            if ($cuentaj < count($id_objeto)) {
                $queryObj .= " or ";
            }
        }
        $queryObj .= " ) ";
    } else {
        $queryObj .= " and h.id_objeto='" . $id_objeto . "' ";
    }

    $sql = "
    SELECT h.*,
    (select orden from tbl_evaluaciones_alternativas where id=h.id_alternativa) as orden,
    (select alternativa from tbl_evaluaciones_alternativas where id=h.id_alternativa) as alternativa
    FROM tbl_evaluaciones_respuestas h
    WHERE
    h.rut = :rut and h.id_pregunta=:id_pregunta $queryObj ";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_pregunta', $id_pregunta);
    $connexion->execute();
    $cod = $connexion->resultset();

    return $cod;
}
function LmsReseteoEvaluacion($id_objeto, $rut) {
    $connexion = new DatabasePDO();
    $sql = "select *  from  tbl_objeto where id=:id_objeto";
    $connexion->query($sql);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();
    $cod = $connexion->resultset();
    $id_evaluacion = $cod[0]->id_evaluacion;

    $sql = "delete FROM tbl_evaluaciones_sesion WHERE rut= :rut AND id_objeto = :id_objeto";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();

    $sql = "delete FROM tbl_evaluaciones_respuestas WHERE rut = :rut AND id_objeto = :id_objeto";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();

    $sql = "delete FROM tbl_objetos_finalizados WHERE rut = :rut AND id_objeto = :id_objeto";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();

    $sql = "delete FROM tbl_evaluaciones_asociacion_preguntas_usuario WHERE rut = :rut AND id_objeto = :id_objeto";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();

    $sql = "delete FROM tbl_evaluaciones_respuestas_intentos WHERE rut = :rut AND id_objeto = :id_objeto";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();

    $sql = "delete FROM tbl_evaluaciones_intentos WHERE rut = :rut AND id_objeto = :id_objeto";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_objeto', $id_objeto);
    $connexion->execute();

    return $cod;
}
function BuscaAnosDocumentos($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "    SELECT 
    EXTRACT( YEAR_MONTH FROM fecha ) as mes_ano 
    FROM tbl_audiencia_documentos
    group by EXTRACT( YEAR_MONTH FROM fecha ) ASC;
    ";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;	
}
function DeleteDocumentoMatriz($id) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_audiencia_documentos WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
}
function InsertDocumentoAudiencia($nombre_documento, $descripcion_documento, $archivo, $archivo_enc, $id_empresa){
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $sql = "INSERT INTO tbl_audiencia_documentos (nombre, descripcion, filename, filename_enc, fecha, autor, id_empresa) 
    VALUES (:nombre, :descripcion, :archivo, :archivo_enc, :fecha, :autor, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':nombre', $nombre_documento);
    $connexion->bind(':descripcion', $descripcion_documento);
    $connexion->bind(':archivo', $archivo);
    $connexion->bind(':archivo_enc', $archivo_enc);
    $connexion->bind(':fecha', $hoy);
    $connexion->bind(':autor', $_SESSION["admin_"]);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
}
function BuscaCreadoresDocumentos($id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
    (SELECT nombre_completo FROM tbl_usuario WHERE rut=h.autor) as nombre_completo
    FROM tbl_audiencia_documentos h
    WHERE h.autor <> ''
    GROUP BY h.autor
    ORDER BY (SELECT nombre_completo FROM tbl_usuario WHERE rut=h.autor) ASC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function InsertPublicacionesDocAudiencia($nombre_publicacion, $descripcion_documento, $id_documento, $id_audiencia, $fecha_inicio, $fecha_termino, $id_empresa, $autor, $fecha_creacion, $categoria, $perfil, $negocio){
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $nombre_publicacion = utf8_decode($nombre_publicacion);
    $descripcion_documento = utf8_decode($descripcion_documento);
    $perfil = utf8_decode($perfil);
    $negocio = ($negocio);
    $sql = "INSERT INTO tbl_audiencia_publicaciones (nombre, descripcion, id_documento, id_audiencia, fecha_inicio, fecha_termino, id_empresa, autor, fecha_creacion, agrupacion, perfil, negocio) 
    VALUES (:nombre_publicacion, :descripcion, :id_documento, :id_audiencia, :fecha_inicio, :fecha_termino, :id_empresa, :autor, :fecha_creacion, :categoria, :perfil, :negocio)";
    $connexion->query($sql);
    $connexion->bind(':nombre_publicacion', $nombre_publicacion);
    $connexion->bind(':descripcion', $descripcion_documento);
    $connexion->bind(':id_documento', $id_documento);
    $connexion->bind(':id_audiencia', $id_audiencia);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':autor', $autor);
    $connexion->bind(':fecha_creacion', $fecha_creacion);
    $connexion->bind(':categoria', $categoria);
    $connexion->bind(':perfil', $perfil);
    $connexion->bind(':negocio', $negocio);
    $connexion->execute();
}
function DeletePublicacionMatriz($id) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_audiencia_publicaciones WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
}
function DeleteNotificacionCreacionMatriz($id) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_notificaciones_creacion WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
}
function Insert_notificaciones_creacion($titulo, $asunto, $texto, $id_empresa){
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $sql = "INSERT INTO tbl_notificaciones_creacion (titulo, asunto, texto, id_empresa, fecha) 
    VALUES (:titulo, :asunto, :texto, :id_empresa, :fecha)";
    $connexion->query($sql);
    $connexion->bind(':titulo', $titulo);
    $connexion->bind(':asunto', $asunto);
    $connexion->bind(':texto', $texto);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':fecha', $hoy);
    $connexion->execute();
}
function lista_notificaciones_creacion_data($id_empresa, $filtro_creador, $filtro_mes_ano) {
    $connexion = new DatabasePDO();
    $queryAutor = ($filtro_creador != "") ? " AND h.autor = :filtro_creador" : "";
    $queryMesAno = ($filtro_mes_ano != "") ? " AND EXTRACT(YEAR_MONTH FROM h.fecha) = :filtro_mes_ano" : "";
    $sql = "SELECT h.*
    FROM tbl_notificaciones_creacion h
    WHERE h.id_empresa = :id_empresa
    $queryAutor
    $queryMesAno
    ORDER BY h.titulo ASC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    if ($filtro_creador != "") {
        $connexion->bind(':filtro_creador', $filtro_creador);
    }
    if ($filtro_mes_ano != "") {
        $connexion->bind(':filtro_mes_ano', $filtro_mes_ano);
    }
    $cod = $connexion->resultset();
    return $cod;
}
function Notificaciones_Creacion_DadoId($id_notificacion, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_notificaciones_creacion WHERE id = :id_notificacion AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_notificacion', $id_notificacion);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function AudienciaPublicacion($id_publicacion_envio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_audiencia_publicaciones WHERE id = :id_publicacion_envio AND id_empresa = :id_empresa";
    $connexion->query($sql);
    $connexion->bind(':id_publicacion_envio', $id_publicacion_envio);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function Audiencia_lista_tbl_audiencia_id_audiencia_rut_sinEnviar($id_audiencia_envio, $id_publicacion, $id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
                (SELECT email FROM tbl_usuario WHERE rut = h.rut) AS email,
                (SELECT COUNT(id) AS cuenta FROM tbl_audiencia_notificaciones WHERE rut = h.rut AND id_publicacion = :id_publicacion) AS cuentaenvio
            FROM tbl_audiencia_id_audiencia_rut h
            WHERE h.id_empresa = :id_empresa 
                AND h.id_audiencia = :id_audiencia_envio 
                AND (SELECT COUNT(id) AS cuenta FROM tbl_audiencia_notificaciones WHERE rut = h.rut AND id_publicacion = :id_publicacion) = 0";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia_envio', $id_audiencia_envio);
    $connexion->bind(':id_publicacion', $id_publicacion);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function AudienciaInsertNotificaciones($rut, $id_publicacion_envio, $id_empresa)
{
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $sql = "INSERT INTO tbl_audiencia_notificaciones (id_publicacion, id_audiencia, rut, fecha, id_empresa)
            VALUES (:id_publicacion_envio, '', :rut, :fecha, :id_empresa)";
    $connexion->query($sql);
    $connexion->bind(':id_publicacion_envio', $id_publicacion_envio);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':fecha', $fecha);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_notificaciones_creacion_options_data($id_empresa, $filtro_creador, $filtro_mes_ano)
{
    $connexion = new DatabasePDO();
    $queryAutor = ($filtro_creador <> "") ? "AND h.autor = :filtro_creador" : "";
    $queryMesAno = ($filtro_mes_ano <> "") ? "AND EXTRACT(YEAR_MONTH FROM h.fecha) = :filtro_mes_ano" : "";
    $sql = "SELECT h.*
            FROM tbl_notificaciones_creacion h
            WHERE h.id_empresa = :id_empresa
                $queryAutor
                $queryMesAno
            ORDER BY h.titulo ASC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    if ($filtro_creador <> "") {
        $connexion->bind(':filtro_creador', $filtro_creador);
    }
    if ($filtro_mes_ano <> "") {
        $connexion->bind(':filtro_mes_ano', $filtro_mes_ano);
    }
    $cod = $connexion->resultset();
    return $cod;
}
function lista_noti_fns_data($id_empresa)
{
    $connexion = new DatabasePDO();
    $year = date("Y");
    $sql = "SELECT h.*,
                (SELECT nombre FROM tbl_audiencia WHERE id = h.id_audiencia) AS audiencia,
                (SELECT nombre FROM tbl_audiencia_documentos WHERE id = h.id_documento) AS documento,
                (SELECT COUNT(rut) FROM tbl_audiencia_id_audiencia_rut WHERE id_audiencia = h.id_audiencia) AS num_colaboradores,
                (SELECT COUNT(id) FROM tbl_audiencia_notificaciones WHERE id_publicacion = h.id) AS num_notificaciones
            FROM tbl_audiencia_publicaciones h
            WHERE h.id_empresa = :id_empresa 
                AND YEAR(h.fecha_inicio) = :year
            ORDER BY h.fecha_inicio DESC";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':year', $year);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_talent_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "
        SELECT h.*,
            (SELECT COUNT(id) FROM tbl_skills_usuarios WHERE id_empresa = h.id_empresa AND id_cargo = h.id_cargo) AS postulantes,
            (SELECT COUNT(id) FROM tbl_skills_resultados WHERE id_empresa = h.id_empresa AND id_cargo = h.id_cargo) AS contestados
        FROM tbl_skills h
        WHERE h.id_empresa = :id_empresa
        GROUP BY h.id_cargo, h.nivel_esperado
        ORDER BY h.cargo
    ";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function Talent_buscarespuestas($id_cargo, $nivel_esperado, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "
        SELECT COUNT(h.id) AS cuenta, h.rut, h.id_skill
        FROM tbl_skills_resultados h
        WHERE h.id_empresa = :id_empresa AND h.id_cargo = :id_cargo AND h.id_nivel_esperado = :nivel_esperado AND h.puntos <> ''
        GROUP BY h.rut
    ";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_cargo', $id_cargo);
    $connexion->bind(':nivel_esperado', $nivel_esperado);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_publicaciones_fns_data($id_empresa) {
    $connexion = new DatabasePDO();
    $year = date("Y");
    $year_ago = $year - 1;
    $sql = "
        SELECT h.*,
            (SELECT nombre FROM tbl_audiencia WHERE id = h.id_audiencia) AS audiencia,
            (SELECT sqlquery FROM tbl_audiencia WHERE id = h.id_audiencia) AS sqlquery,
            (SELECT nombre FROM tbl_audiencia_documentos WHERE id = h.id_documento) AS documento,
            (SELECT filename_enc FROM tbl_audiencia_documentos WHERE id = h.id_documento) AS filename_enc,
            (SELECT negocio FROM tbl_audiencia_negocio WHERE id = h.negocio) AS nombre_negocio
        FROM tbl_audiencia_publicaciones h
        WHERE h.id_empresa = :id_empresa AND (YEAR(h.fecha_creacion) = :year OR YEAR(h.fecha_creacion) = :year_ago)
        ORDER BY h.fecha_inicio DESC
    ";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':year', $year);
    $connexion->bind(':year_ago', $year_ago);
    $cod = $connexion->resultset();
    return $cod;
}
function lista_rut_audiencia_fns_data($id_audiencia) {
    $connexion = new DatabasePDO();
    $sql = "        SELECT h.*
        FROM tbl_audiencia_id_audiencia_rut h
        WHERE h.id_audiencia = :id_audiencia    ";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia', $id_audiencia);
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaNuevosPorAudiencias($id_empresa) {
    $connexion = new DatabasePDO();
    $fecha = date("Y-m-d");
    $sql = "        SELECT h.*, 
            (SELECT COUNT(id) AS cuenta FROM tbl_audiencia_id_audiencia_rut WHERE rut = h.rut) AS num_audiencias
        FROM tbl_usuario h
        WHERE YEAR(h.fecha_ingreso) = '2019' AND (SELECT COUNT(id) FROM tbl_audiencia_id_audiencia_rut WHERE rut = h.rut) > 0
        ORDER BY h.fecha_ingreso DESC	    ";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaAudienciasDado_Rut($rut, $id_empresa){

    $connexion = new DatabasePDO();
    $sql = "        SELECT h.id_audiencia, (SELECT nombre FROM tbl_audiencia WHERE id=h.id_audiencia) AS audiencia  
        FROM tbl_audiencia_id_audiencia_rut h 
        WHERE h.rut = :rut AND h.id_empresa = :id_empresa    ";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
function BuscaRutDuplicadosPorAudiencias($id_empresa){

    $connexion = new DatabasePDO();
    $sql = "        SELECT h.rut, COUNT(id) AS cuenta, (SELECT nombre FROM tbl_audiencia WHERE id=h.id_audiencia) AS audiencia  
        FROM tbl_audiencia_id_audiencia_rut h 
        GROUP BY h.rut HAVING cuenta > 1
        ORDER BY h.rut    ";
    $cod = $connexion->resultset();
    return $cod;		
}
function BuscaPublicacionesDuplicadasAudiencia($id_empresa){

    $connexion = new DatabasePDO();
    $sql = "        SELECT h.id_audiencia, COUNT(id) AS cuenta, h.nombre, (SELECT nombre FROM tbl_audiencia WHERE id=h.id_audiencia) AS audiencia  
        FROM tbl_audiencia_publicaciones h
        GROUP BY h.id_audiencia HAVING cuenta > 1
        ORDER BY h.id_audiencia    ";
    $cod = $connexion->resultset();
    return $cod;		
}
function BuscaPublicacionesdadaAudiencia($id_audiencia, $id_empresa){

    $connexion = new DatabasePDO();
    $sql = "        SELECT h.id_audiencia, h.nombre, (SELECT nombre FROM tbl_audiencia WHERE id=h.id_audiencia) AS audiencia  
        FROM tbl_audiencia_publicaciones h
        WHERE h.id_audiencia = :id_audiencia
        ORDER BY h.id_audiencia    ";
    $connexion->query($sql);
    $connexion->bind(':id_audiencia', $id_audiencia);
    $cod = $connexion->resultset();
    return $cod;		
}
function reco_reconocer_full_2020_data_SL($tipo){

    $connexion = new DatabasePDO();
    if ($tipo == "AMONESTACION") {
        $jTIPO = " AND tipo='AMONESTACION' ";
    } elseif ($tipo == "RECONOCIMIENTO") {
        $jTIPO = " AND tipo<>'AMONESTACION' ";
    } else {
        $jTIPO = " ";
    }

    $Adm = DatosUsuarioAdmin($_SESSION["user_"]);
    if ($Adm[0]->filtro_division_personas == "1") {
        $jDivision = " AND division<>'Division Personas y Organizacion' ";
    } else {
        $jDivision = " ";
    }

    $sql = "        SELECT *
        FROM tbl_reconoce_gracias_full
        WHERE id > 0
        AND seguridad_laboral = 'SI'
        $jDivision
        ORDER BY fecha DESC, hora DESC    ";
    $cod = $connexion->resultset();
    return $cod;
} 
function CopiatblUsuario_Egresados($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT rut FROM tbl_usuario_temporal WHERE rut = h.rut AND vigencia_descripcion = '') AS cuenta FROM tbl_usuario h
            WHERE (SELECT rut FROM tbl_usuario_temporal WHERE rut = h.rut AND vigencia_descripcion = '') IS NULL
            AND (vigencia_descripcion = '' OR vigencia_descripcion IS NULL)";
    $connexion->query($sql);
    $cod = $connexion->resultset();

    foreach ($cod as $unico) {
        $sql2 = "INSERT INTO tbl_usuario_egresados SELECT * FROM tbl_usuario WHERE rut = '" . $unico->rut . "'";
        $connexion->query($sql2);
        $cod2 = $connexion->resultset();
    }

    return $cod;
}
function truncate_tbl_usuario($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_usuario WHERE (vigencia_descripcion = '' OR vigencia_descripcion IS NULL)";
    $connexion->query($sql);
    $cod = $connexion->resultset();

    return $cod;
}
function BorraDuplicados($tipo, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "        SELECT h.*, (SELECT id FROM tbl_usuario WHERE rut = h.rut) AS estaduplicado
        FROM tbl_usuario_temporal h
        WHERE (SELECT id FROM tbl_usuario WHERE rut = h.rut) IS NOT NULL";
    $connexion->query($sql);
    $cod = $connexion->resultset();

    foreach ($cod as $unico) {
        $sql2 = "DELETE FROM tbl_usuario WHERE rut = " . $unico->rut;
        $connexion->query($sql2);
    }
}
function usuario_temporal_lee($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_usuario SELECT * FROM tbl_usuario_temporal";
    $connexion->query($sql);
    $cod = $connexion->resultset();

    return $cod;
}
function cron_tbl_cron_sillas_data() {
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $time = date("H:i:s");
    $sql = "INSERT INTO tbl_cron_sillas (fecha, subida_usuarios, hora) VALUES ('$hoy', '1','$time')";
    $connexion->query($sql);
    $cod = $connexion->resultset();

    return $cod;
}
function fill_contingencia_tbl_cron_sillas_data()
{
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");

    $sql = "
    SELECT h.rut, (SELECT num_rut FROM tbl_contingencia_2021 WHERE num_rut = h.rut) AS contigencia_2021
    FROM tbl_usuario h
    WHERE h.nombre_empresa_holding <> ''
    AND (SELECT num_rut FROM tbl_contingencia_2021 WHERE num_rut = h.rut) IS NULL";
    
    $connexion->query($sql);
    $cod = $connexion->resultset();
    
    foreach ($cod as $unico) {
        $sql2 = "
        INSERT INTO tbl_contingencia_2021 (num_rut)
        VALUES ('".$unico->rut."')";
        
        $connexion->query($sql2);
    }
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}
function Lista_ausentismo_data($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_usuario_ausentismo";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function usuario_insert_usuario_temp(
    $rut,
    $rut_completo,
    $nombre,
    $apaterno,
    $amaterno,
    $nombre_completo,
    $cargo,
    $rut_duplicado,
    $codigo_proceso,
    $id_perfil,
    $id_rol,
    $id_cargo,
    $id_empresa,
    $jefe,
    $dependencia,
    $fecha_ingreso,
    $email,
    $emailBK,
    $negocio,
    $zona,
    $gerencia,
    $area,
    $departamento,
    $local,
    $responsable,
    $telefono,
    $celular,
    $unidad_negocio,
    $id_area,
    $evaluador,
    $perfil_evaluacion,
    $seccion,
    $ubicacion,
    $fecha_nacimiento,
    $genero,
    $nacionalidad,
    $direccion_particular,
    $codigo_escolaridad,
    $codigo_nivel,
    $id_centro_costo,
    $centro_costo,
    $comuna,
    $fecha_antiguedad,
    $tipo_contrato,
    $tramo_sence,
    $dv,
    $empresa_holding,
    $division,
    $porvalidar,
    $idprivado,
    $antiguedad,
    $lider,
    $tallergrupo,
    $mundo,
    $subgerencia,
    $estadocivil,
    $vigencia,
    $id_unidad_negocio,
    $escolaridad,
    $sucursal,
    $nombre_empresa_holding,
    $servicio,
    $tipo_servicio,
    $comunidad,
    $id_comunidad,
    $vigencia_descripcion,
    $nombre_jefatura,
    $cargo_jefatura,
    $telefono_jefatura,
    $email_jefatura,
    $id_perfil_competencia,
    $perfil_competencia,
    $anexo,
    $id_gerencia,
    $id_subgerencia,
    $codigo_sap,
    $regional,
    $avatar,
    $zonal,
    $vicepresidencia,
    $gerenciaR2,
    $gerenciaR3,
    $userid_moodle,
    $operador,
    $organica,
    $nivel_inicio,
    $pais,
    $familia_cargo,
    $tipo_cargo,
    $codigo_negociacion,
    $fecha_reconocimiento,
    $fecha_ingreso_vacaciones,
    $dias_derecho,
    $dias_pendientes,
    $dias_pendientes_real,
    $cod_cargo_ant,
    $gls_cargo_ant,
    $ant_agno_reconoci,
    $tipo_renta,
    $edad,
    $fec_nacim,
    $silla_id_cargo,
    $silla_cargo,
    $silla_id_division,
    $silla_division,
    $silla_id_area,
    $silla_area,
    $silla_id_departamento,
    $silla_departamento,
    $silla_id_zona,
    $silla_zona,
    $silla_id_seccion,
    $silla_seccion,
    $silla_id_oficina,
    $silla_oficina,
    $silla_id_unidad,
    $silla_unidad,
    $opc_uniforme,
    $est_civil,
    $est_civil_glosa,
    $isapre_codigo,
    $isapre_glosa,
    $sucur_ciudad,
    $sucur_comuna,
    $sindi_codigo,
    $sindi_glosa,
    $fec_indem,
    $teletrabajo
) {
    $stmt = new DatabasePDO();

    $sql = "INSERT INTO tbl_usuario_temporal (
        rut,
        rut_completo,
        nombre,
        apaterno,
        amaterno,
        nombre_completo,
        cargo,
        rut_duplicado,
        codigo_proceso,
        id_perfil,
        id_rol,
        id_cargo,
        id_empresa,
        jefe,
        dependencia,
        fecha_ingreso,
        email,
        emailBK,
        negocio,
        zona,
        gerencia,
        area,
        departamento,
        local,
        responsable,
        telefono,
        celular,
        unidad_negocio,
        id_area,
        evaluador,
        perfil_evaluacion,
        seccion,
        ubicacion,
        fecha_nacimiento,
        genero,
        nacionalidad,
        direccion_particular,
        codigo_escolaridad,
        codigo_nivel,
        id_centro_costo,
        centro_costo,
        comuna,
        fecha_antiguedad,
        tipo_contrato,
        tramo_sence,
        dv,
        empresa_holding,
        division,
        porvalidar,
        idprivado,
        antiguedad,
        lider,
        tallergrupo,
        mundo,
        subgerencia,
        estadocivil,
        vigencia,
        id_unidad_negocio,
        escolaridad,
        sucursal,
        nombre_empresa_holding,
        servicio,
        tipo_servicio,
        comunidad,
        id_comunidad,
        vigencia_descripcion,
        nombre_jefatura,
        cargo_jefatura,
        telefono_jefatura,
        email_jefatura,
        id_perfil_competencia,
        perfil_competencia,
        anexo,
        id_gerencia,
        id_subgerencia,
        codigo_sap,
        regional,
        avatar,
        zonal,
        vicepresidencia,
        gerenciaR2,
        gerenciaR3,
        userid_moodle,
        operador,
        organica,
        nivel_inicio,
        pais,
        familia_cargo,
        tipo_cargo,
        codigo_negociacion,
        fecha_reconocimiento,
        fecha_ingreso_vacaciones,
        dias_derecho,
        dias_pendientes,
        dias_pendientes_real,
        cod_cargo_ant,
        gls_cargo_ant,
        ant_agno_reconoci,
        tipo_renta,
        edad,
        fec_nacim,
        silla_id_cargo,
        silla_cargo,
        silla_id_division,
        silla_division,
        silla_id_area,
        silla_area,
        silla_id_departamento,
        silla_departamento,
        silla_id_zona,
        silla_zona,
        silla_id_seccion,
        silla_seccion,
        silla_id_oficina,
        silla_oficina,
        silla_id_unidad,
        silla_unidad,
        opc_uniforme,
        est_civil,
        est_civil_glosa,
        isapre_codigo,
        isapre_glosa,
        sucur_ciudad,
        sucur_comuna,
        sindi_codigo,
        sindi_glosa,
        fec_indem,
        teletrabajo
    ) VALUES (
        :rut,
        :rut_completo,
        :nombre,
        :apaterno,
        :amaterno,
        :nombre_completo,
        :cargo,
        :rut_duplicado,
        :codigo_proceso,
        :id_perfil,
        :id_rol,
        :id_cargo,
        :id_empresa,
        :jefe,
        :dependencia,
        :fecha_ingreso,
        :email,
        :emailBK,
        :negocio,
        :zona,
        :gerencia,
        :area,
        :departamento,
        :local,
        :responsable,
        :telefono,
        :celular,
        :unidad_negocio,
        :id_area,
        :evaluador,
        :perfil_evaluacion,
        :seccion,
        :ubicacion,
        :fecha_nacimiento,
        :genero,
        :nacionalidad,
        :direccion_particular,
        :codigo_escolaridad,
        :codigo_nivel,
        :id_centro_costo,
        :centro_costo,
        :comuna,
        :fecha_antiguedad,
        :tipo_contrato,
        :tramo_sence,
        :dv,
        :empresa_holding,
        :division,
        :porvalidar,
        :idprivado,
        :antiguedad,
        :lider,
        :tallergrupo,
        :mundo,
        :subgerencia,
        :estadocivil,
        :vigencia,
        :id_unidad_negocio,
        :escolaridad,
        :sucursal,
        :nombre_empresa_holding,
        :servicio,
        :tipo_servicio,
        :comunidad,
        :id_comunidad,
        :vigencia_descripcion,
        :nombre_jefatura,
        :cargo_jefatura,
        :telefono_jefatura,
        :email_jefatura,
        :id_perfil_competencia,
        :perfil_competencia,
        :anexo,
        :id_gerencia,
        :id_subgerencia,
        :codigo_sap,
        :regional,
        :avatar,
        :zonal,
        :vicepresidencia,
        :gerenciaR2,
        :gerenciaR3,
        :userid_moodle,
        :operador,
        :organica,
        :nivel_inicio,
        :pais,
        :familia_cargo,
        :tipo_cargo,
        :codigo_negociacion,
        :fecha_reconocimiento,
        :fecha_ingreso_vacaciones,
        :dias_derecho,
        :dias_pendientes,
        :dias_pendientes_real,
        :cod_cargo_ant,
        :gls_cargo_ant,
        :ant_agno_reconoci,
        :tipo_renta,
        :edad,
        :fec_nacim,
        :silla_id_cargo,
        :silla_cargo,
        :silla_id_division,
        :silla_division,
        :silla_id_area,
        :silla_area,
        :silla_id_departamento,
        :silla_departamento,
        :silla_id_zona,
        :silla_zona,
        :silla_id_seccion,
        :silla_seccion,
        :silla_id_oficina,
        :silla_oficina,
        :silla_id_unidad,
        :silla_unidad,
        :opc_uniforme,
        :est_civil,
        :est_civil_glosa,
        :isapre_codigo,
        :isapre_glosa,
        :sucur_ciudad,
        :sucur_comuna,
        :sindi_codigo,
        :sindi_glosa,
        :fec_indem,
        :teletrabajo
    )";

    if ($rut <> '') {
        $stmt->query($sql);

        // Bind parameters
        $stmt->bind(':rut', $rut);
        $stmt->bind(':rut_completo', $rut_completo);
        $stmt->bind(':nombre', $nombre);
        $stmt->bind(':apaterno', $apaterno);
        $stmt->bind(':amaterno', $amaterno);
        $stmt->bind(':nombre_completo', $nombre_completo);
        $stmt->bind(':cargo', $cargo);
        $stmt->bind(':rut_duplicado', $rut_duplicado);
        $stmt->bind(':codigo_proceso', $codigo_proceso);
        $stmt->bind(':id_perfil', $id_perfil);
        $stmt->bind(':id_rol', $id_rol);
        $stmt->bind(':id_cargo', $id_cargo);
        $stmt->bind(':id_empresa', $id_empresa);
        $stmt->bind(':jefe', $jefe);
        $stmt->bind(':dependencia', $dependencia);
        $stmt->bind(':fecha_ingreso', $fecha_ingreso);
        $stmt->bind(':email', $email);
        $stmt->bind(':emailBK', $emailBK);
        $stmt->bind(':negocio', $negocio);
        $stmt->bind(':zona', $zona);
        $stmt->bind(':gerencia', $gerencia);
        $stmt->bind(':area', $area);
        $stmt->bind(':departamento', $departamento);
        $stmt->bind(':local', $local);
        $stmt->bind(':responsable', $responsable);
        $stmt->bind(':telefono', $telefono);
        $stmt->bind(':celular', $celular);
        $stmt->bind(':unidad_negocio', $unidad_negocio);
        $stmt->bind(':id_area', $id_area);
        $stmt->bind(':evaluador', $evaluador);
        $stmt->bind(':perfil_evaluacion', $perfil_evaluacion);
        $stmt->bind(':seccion', $seccion);
        $stmt->bind(':ubicacion', $ubicacion);
        $stmt->bind(':fecha_nacimiento', $fecha_nacimiento);
        $stmt->bind(':genero', $genero);
        $stmt->bind(':nacionalidad', $nacionalidad);
        $stmt->bind(':direccion_particular', $direccion_particular);
        $stmt->bind(':codigo_escolaridad', $codigo_escolaridad);
        $stmt->bind(':codigo_nivel', $codigo_nivel);
        $stmt->bind(':id_centro_costo', $id_centro_costo);
        $stmt->bind(':centro_costo', $centro_costo);
        $stmt->bind(':comuna', $comuna);
        $stmt->bind(':fecha_antiguedad', $fecha_antiguedad);
        $stmt->bind(':tipo_contrato', $tipo_contrato);
        $stmt->bind(':tramo_sence', $tramo_sence);
        $stmt->bind(':dv', $dv);
        $stmt->bind(':empresa_holding', $empresa_holding);
        $stmt->bind(':division', $division);
        $stmt->bind(':porvalidar', $porvalidar);
        $stmt->bind(':idprivado', $idprivado);
        $stmt->bind(':antiguedad', $antiguedad);
        $stmt->bind(':lider', $lider);
        $stmt->bind(':tallergrupo', $tallergrupo);
        $stmt->bind(':mundo', $mundo);
        $stmt->bind(':subgerencia', $subgerencia);
        $stmt->bind(':estadocivil', $estadocivil);
        $stmt->bind(':vigencia', $vigencia);
        $stmt->bind(':id_unidad_negocio', $id_unidad_negocio);
        $stmt->bind(':escolaridad', $escolaridad);
        $stmt->bind(':sucursal', $sucursal);
        $stmt->bind(':nombre_empresa_holding', $nombre_empresa_holding);
        $stmt->bind(':servicio', $servicio);
        $stmt->bind(':tipo_servicio', $tipo_servicio);
        $stmt->bind(':comunidad', $comunidad);
        $stmt->bind(':id_comunidad', $id_comunidad);
        $stmt->bind(':vigencia_descripcion', $vigencia_descripcion);
        $stmt->bind(':nombre_jefatura', $nombre_jefatura);
        $stmt->bind(':cargo_jefatura', $cargo_jefatura);
        $stmt->bind(':telefono_jefatura', $telefono_jefatura);
        $stmt->bind(':email_jefatura', $email_jefatura);
        $stmt->bind(':id_perfil_competencia', $id_perfil_competencia);
        $stmt->bind(':perfil_competencia', $perfil_competencia);
        $stmt->bind(':anexo', $anexo);
        $stmt->bind(':id_gerencia', $id_gerencia);
        $stmt->bind(':id_subgerencia', $id_subgerencia);
        $stmt->bind(':codigo_sap', $codigo_sap);
        $stmt->bind(':regional', $regional);
        $stmt->bind(':avatar', $avatar);
        $stmt->bind(':zonal', $zonal);
        $stmt->bind(':vicepresidencia', $vicepresidencia);
        $stmt->bind(':gerenciaR2', $gerenciaR2);
        $stmt->bind(':gerenciaR3', $gerenciaR3);
        $stmt->bind(':userid_moodle', $userid_moodle);
        $stmt->bind(':operador', $operador);
        $stmt->bind(':organica', $organica);
        $stmt->bind(':nivel_inicio', $nivel_inicio);
        $stmt->bind(':pais', $pais);
        $stmt->bind(':familia_cargo', $familia_cargo);
        $stmt->bind(':tipo_cargo', $tipo_cargo);
        $stmt->bind(':codigo_negociacion', $codigo_negociacion);
        $stmt->bind(':fecha_reconocimiento', $fecha_reconocimiento);
        $stmt->bind(':fecha_ingreso_vacaciones', $fecha_ingreso_vacaciones);
        $stmt->bind(':fecha_ingreso_vacaciones', $fecha_ingreso_vacaciones);
        $stmt->bind(':dias_derecho', $dias_derecho);
        $stmt->bind(':dias_pendientes', $dias_pendientes);
        $stmt->bind(':dias_pendientes_real', $dias_pendientes_real);
        $stmt->bind(':cod_cargo_ant', $cod_cargo_ant);
        $stmt->bind(':gls_cargo_ant', $gls_cargo_ant);
        $stmt->bind(':ant_agno_reconoci', $ant_agno_reconoci);
        $stmt->bind(':tipo_renta', $tipo_renta);
        $stmt->bind(':edad', $edad);
        $stmt->bind(':fec_nacim', $fec_nacim);
        $stmt->bind(':silla_id_cargo', $silla_id_cargo);
        $stmt->bind(':silla_cargo', $silla_cargo);
        $stmt->bind(':silla_id_division', $silla_id_division);
        $stmt->bind(':silla_division', $silla_division);
        $stmt->bind(':silla_id_area', $silla_id_area);
        $stmt->bind(':silla_area', $silla_area);
        $stmt->bind(':silla_id_departamento', $silla_id_departamento);
        $stmt->bind(':silla_departamento', $silla_departamento);
        $stmt->bind(':silla_id_zona', $silla_id_zona);
        $stmt->bind(':silla_zona', $silla_zona);
        $stmt->bind(':silla_id_seccion', $silla_id_seccion);
        $stmt->bind(':silla_seccion', $silla_seccion);
        $stmt->bind(':silla_id_oficina', $silla_id_oficina);
        $stmt->bind(':silla_oficina', $silla_oficina);
        $stmt->bind(':silla_id_unidad', $silla_id_unidad);
        $stmt->bind(':silla_unidad', $silla_unidad);
        $stmt->bind(':opc_uniforme', $opc_uniforme);
        $stmt->bind(':est_civil', $est_civil);
        $stmt->bind(':est_civil_glosa', $est_civil_glosa);
        $stmt->bind(':isapre_codigo', $isapre_codigo);
        $stmt->bind(':isapre_glosa', $isapre_glosa);
        $stmt->bind(':sucur_ciudad', $sucur_ciudad);
        $stmt->bind(':sucur_comuna', $sucur_comuna);
        $stmt->bind(':sindi_codigo', $sindi_codigo);
        $stmt->bind(':sindi_glosa', $sindi_glosa);
        $stmt->bind(':fec_indem', $fec_indem);
        $stmt->bind(':teletrabajo', $teletrabajo);

        // Execute the prepared statement
        $stmt->execute();
    }
}

function usuario_insert_usuario_org_chart(
    $rut,
    $rut_completo,
    $nombre,
    $apaterno,
    $amaterno,
    $nombre_completo,
    $cargo,
    $rut_duplicado,
    $codigo_proceso,
    $id_perfil,
    $id_rol,
    $id_cargo,
    $id_empresa,
    $jefe,
    $dependencia,
    $fecha_ingreso,
    $email,
    $emailBK,
    $negocio,
    $zona,
    $gerencia,
    $area,
    $departamento,
    $local,
    $responsable,
    $telefono,
    $celular,
    $unidad_negocio,
    $id_area,
    $evaluador,
    $perfil_evaluacion,
    $seccion,
    $ubicacion,
    $fecha_nacimiento,
    $genero,
    $nacionalidad,
    $direccion_particular,
    $codigo_escolaridad,
    $codigo_nivel,
    $id_centro_costo,
    $centro_costo,
    $comuna,
    $fecha_antiguedad,
    $tipo_contrato,
    $tramo_sence,
    $dv,
    $empresa_holding,
    $division,
    $porvalidar,
    $idprivado,
    $antiguedad,
    $lider,
    $tallergrupo,
    $mundo,
    $subgerencia,
    $estadocivil,
    $vigencia,
    $id_unidad_negocio,
    $escolaridad,
    $sucursal,
    $nombre_empresa_holding,
    $servicio,
    $tipo_servicio,
    $comunidad,
    $id_comunidad,
    $vigencia_descripcion,
    $nombre_jefatura,
    $cargo_jefatura,
    $telefono_jefatura,
    $email_jefatura,
    $id_perfil_competencia,
    $perfil_competencia,
    $anexo,
    $id_gerencia,
    $id_subgerencia,
    $codigo_sap,
    $regional,
    $avatar,
    $zonal,
    $vicepresidencia,
    $gerenciaR2,
    $gerenciaR3,
    $userid_moodle,
    $operador,
    $organica,
    $nivel_inicio,
    $pais,
    $familia_cargo,
    $tipo_cargo,
    $codigo_negociacion,
    $fecha_reconocimiento,
    $fecha_ingreso_vacaciones,
    $dias_derecho,
    $dias_pendientes,
    $dias_pendientes_real,
    $cod_cargo_ant,
    $gls_cargo_ant,
    $ant_agno_reconoci,
    $tipo_renta,
    $edad,
    $fec_nacim,
    $silla_id_cargo,
    $silla_cargo,
    $silla_id_division,
    $silla_division,
    $silla_id_area,
    $silla_area,
    $silla_id_departamento,
    $silla_departamento,
    $silla_id_zona,
    $silla_zona,
    $silla_id_seccion,
    $silla_seccion,
    $silla_id_oficina,
    $silla_oficina,
    $silla_id_unidad,
    $silla_unidad,
    $opc_uniforme,
    $est_civil,
    $est_civil_glosa,
    $isapre_codigo,
    $isapre_glosa,
    $sucur_ciudad,
    $sucur_comuna,
    $sindi_codigo,
    $sindi_glosa,
    $fec_indem,
    $teletrabajo
) {
    $stmt = new DatabasePDO();


    
    $sql = "INSERT INTO tbl_usuarios_orgchart (
        rut,
        rut_completo,
        nombre,
        apaterno,
        amaterno,
        nombre_completo,
        cargo,
        rut_duplicado,
        codigo_proceso,
        id_perfil,
        id_rol,
        id_cargo,
        id_empresa,
        jefe,
        dependencia,
        fecha_ingreso,
        email,
        emailBK,
        negocio,
        zona,
        gerencia,
        area,
        departamento,
        local,
        responsable,
        telefono,
        celular,
        unidad_negocio,
        id_area,
        evaluador,
        perfil_evaluacion,
        seccion,
        ubicacion,
        fecha_nacimiento,
        genero,
        nacionalidad,
        direccion_particular,
        codigo_escolaridad,
        codigo_nivel,
        id_centro_costo,
        centro_costo,
        comuna,
        fecha_antiguedad,
        tipo_contrato,
        tramo_sence,
        dv,
        empresa_holding,
        division,
        porvalidar,
        idprivado,
        antiguedad,
        lider,
        tallergrupo,
        mundo,
        subgerencia,
        estadocivil,
        vigencia,
        id_unidad_negocio,
        escolaridad,
        sucursal,
        nombre_empresa_holding,
        servicio,
        tipo_servicio,
        comunidad,
        id_comunidad,
        vigencia_descripcion,
        nombre_jefatura,
        cargo_jefatura,
        telefono_jefatura,
        email_jefatura,
        id_perfil_competencia,
        perfil_competencia,
        anexo,
        id_gerencia,
        id_subgerencia,
        codigo_sap,
        regional,
        avatar,
        zonal,
        vicepresidencia,
        gerenciaR2,
        gerenciaR3,
        userid_moodle,
        operador,
        organica,
        nivel_inicio,
        pais,
        familia_cargo,
        tipo_cargo,
        codigo_negociacion,
        fecha_reconocimiento,
        fecha_ingreso_vacaciones,
        dias_derecho,
        dias_pendientes,
        dias_pendientes_real,
        cod_cargo_ant,
        gls_cargo_ant,
        ant_agno_reconoci,
        tipo_renta,
        edad,
        fec_nacim,
        silla_id_cargo,
        silla_cargo,
        silla_id_division,
        silla_division,
        silla_id_area,
        silla_area,
        silla_id_departamento,
        silla_departamento,
        silla_id_zona,
        silla_zona,
        silla_id_seccion,
        silla_seccion,
        silla_id_oficina,
        silla_oficina,
        silla_id_unidad,
        silla_unidad,
        opc_uniforme,
        est_civil,
        est_civil_glosa,
        isapre_codigo,
        isapre_glosa,
        sucur_ciudad,
        sucur_comuna,
        sindi_codigo,
        sindi_glosa,
        fec_indem,
        teletrabajo
    ) VALUES (
        :rut,
        :rut_completo,
        :nombre,
        :apaterno,
        :amaterno,
        :nombre_completo,
        :cargo,
        :rut_duplicado,
        :codigo_proceso,
        :id_perfil,
        :id_rol,
        :id_cargo,
        :id_empresa,
        :jefe,
        :dependencia,
        :fecha_ingreso,
        :email,
        :emailBK,
        :negocio,
        :zona,
        :gerencia,
        :area,
        :departamento,
        :local,
        :responsable,
        :telefono,
        :celular,
        :unidad_negocio,
        :id_area,
        :evaluador,
        :perfil_evaluacion,
        :seccion,
        :ubicacion,
        :fecha_nacimiento,
        :genero,
        :nacionalidad,
        :direccion_particular,
        :codigo_escolaridad,
        :codigo_nivel,
        :id_centro_costo,
        :centro_costo,
        :comuna,
        :fecha_antiguedad,
        :tipo_contrato,
        :tramo_sence,
        :dv,
        :empresa_holding,
        :division,
        :porvalidar,
        :idprivado,
        :antiguedad,
        :lider,
        :tallergrupo,
        :mundo,
        :subgerencia,
        :estadocivil,
        :vigencia,
        :id_unidad_negocio,
        :escolaridad,
        :sucursal,
        :nombre_empresa_holding,
        :servicio,
        :tipo_servicio,
        :comunidad,
        :id_comunidad,
        :vigencia_descripcion,
        :nombre_jefatura,
        :cargo_jefatura,
        :telefono_jefatura,
        :email_jefatura,
        :id_perfil_competencia,
        :perfil_competencia,
        :anexo,
        :id_gerencia,
        :id_subgerencia,
        :codigo_sap,
        :regional,
        :avatar,
        :zonal,
        :vicepresidencia,
        :gerenciaR2,
        :gerenciaR3,
        :userid_moodle,
        :operador,
        :organica,
        :nivel_inicio,
        :pais,
        :familia_cargo,
        :tipo_cargo,
        :codigo_negociacion,
        :fecha_reconocimiento,
        :fecha_ingreso_vacaciones,
        :dias_derecho,
        :dias_pendientes,
        :dias_pendientes_real,
        :cod_cargo_ant,
        :gls_cargo_ant,
        :ant_agno_reconoci,
        :tipo_renta,
        :edad,
        :fec_nacim,
        :silla_id_cargo,
        :silla_cargo,
        :silla_id_division,
        :silla_division,
        :silla_id_area,
        :silla_area,
        :silla_id_departamento,
        :silla_departamento,
        :silla_id_zona,
        :silla_zona,
        :silla_id_seccion,
        :silla_seccion,
        :silla_id_oficina,
        :silla_oficina,
        :silla_id_unidad,
        :silla_unidad,
        :opc_uniforme,
        :est_civil,
        :est_civil_glosa,
        :isapre_codigo,
        :isapre_glosa,
        :sucur_ciudad,
        :sucur_comuna,
        :sindi_codigo,
        :sindi_glosa,
        :fec_indem,
        :teletrabajo
    )";

    if ($rut <> '') {
        $stmt->query($sql);

        // Bind parameters
        $stmt->bind(':rut', $rut);
        $stmt->bind(':rut_completo', $rut_completo);
        $stmt->bind(':nombre', $nombre);
        $stmt->bind(':apaterno', $apaterno);
        $stmt->bind(':amaterno', $amaterno);
        $stmt->bind(':nombre_completo', $nombre_completo);
        $stmt->bind(':cargo', $cargo);
        $stmt->bind(':rut_duplicado', $rut_duplicado);
        $stmt->bind(':codigo_proceso', $codigo_proceso);
        $stmt->bind(':id_perfil', $id_perfil);
        $stmt->bind(':id_rol', $id_rol);
        $stmt->bind(':id_cargo', $id_cargo);
        $stmt->bind(':id_empresa', $id_empresa);
        $stmt->bind(':jefe', $jefe);
        $stmt->bind(':dependencia', $dependencia);
        $stmt->bind(':fecha_ingreso', $fecha_ingreso);
        $stmt->bind(':email', $email);
        $stmt->bind(':emailBK', $emailBK);
        $stmt->bind(':negocio', $negocio);
        $stmt->bind(':zona', $zona);
        $stmt->bind(':gerencia', $gerencia);
        $stmt->bind(':area', $area);
        $stmt->bind(':departamento', $departamento);
        $stmt->bind(':local', $local);
        $stmt->bind(':responsable', $responsable);
        $stmt->bind(':telefono', $telefono);
        $stmt->bind(':celular', $celular);
        $stmt->bind(':unidad_negocio', $unidad_negocio);
        $stmt->bind(':id_area', $id_area);
        $stmt->bind(':evaluador', $evaluador);
        $stmt->bind(':perfil_evaluacion', $perfil_evaluacion);
        $stmt->bind(':seccion', $seccion);
        $stmt->bind(':ubicacion', $ubicacion);
        $stmt->bind(':fecha_nacimiento', $fecha_nacimiento);
        $stmt->bind(':genero', $genero);
        $stmt->bind(':nacionalidad', $nacionalidad);
        $stmt->bind(':direccion_particular', $direccion_particular);
        $stmt->bind(':codigo_escolaridad', $codigo_escolaridad);
        $stmt->bind(':codigo_nivel', $codigo_nivel);
        $stmt->bind(':id_centro_costo', $id_centro_costo);
        $stmt->bind(':centro_costo', $centro_costo);
        $stmt->bind(':comuna', $comuna);
        $stmt->bind(':fecha_antiguedad', $fecha_antiguedad);
        $stmt->bind(':tipo_contrato', $tipo_contrato);
        $stmt->bind(':tramo_sence', $tramo_sence);
        $stmt->bind(':dv', $dv);
        $stmt->bind(':empresa_holding', $empresa_holding);
        $stmt->bind(':division', $division);
        $stmt->bind(':porvalidar', $porvalidar);
        $stmt->bind(':idprivado', $idprivado);
        $stmt->bind(':antiguedad', $antiguedad);
        $stmt->bind(':lider', $lider);
        $stmt->bind(':tallergrupo', $tallergrupo);
        $stmt->bind(':mundo', $mundo);
        $stmt->bind(':subgerencia', $subgerencia);
        $stmt->bind(':estadocivil', $estadocivil);
        $stmt->bind(':vigencia', $vigencia);
        $stmt->bind(':id_unidad_negocio', $id_unidad_negocio);
        $stmt->bind(':escolaridad', $escolaridad);
        $stmt->bind(':sucursal', $sucursal);
        $stmt->bind(':nombre_empresa_holding', $nombre_empresa_holding);
        $stmt->bind(':servicio', $servicio);
        $stmt->bind(':tipo_servicio', $tipo_servicio);
        $stmt->bind(':comunidad', $comunidad);
        $stmt->bind(':id_comunidad', $id_comunidad);
        $stmt->bind(':vigencia_descripcion', $vigencia_descripcion);
        $stmt->bind(':nombre_jefatura', $nombre_jefatura);
        $stmt->bind(':cargo_jefatura', $cargo_jefatura);
        $stmt->bind(':telefono_jefatura', $telefono_jefatura);
        $stmt->bind(':email_jefatura', $email_jefatura);
        $stmt->bind(':id_perfil_competencia', $id_perfil_competencia);
        $stmt->bind(':perfil_competencia', $perfil_competencia);
        $stmt->bind(':anexo', $anexo);
        $stmt->bind(':id_gerencia', $id_gerencia);
        $stmt->bind(':id_subgerencia', $id_subgerencia);
        $stmt->bind(':codigo_sap', $codigo_sap);
        $stmt->bind(':regional', $regional);
        $stmt->bind(':avatar', $avatar);
        $stmt->bind(':zonal', $zonal);
        $stmt->bind(':vicepresidencia', $vicepresidencia);
        $stmt->bind(':gerenciaR2', $gerenciaR2);
        $stmt->bind(':gerenciaR3', $gerenciaR3);
        $stmt->bind(':userid_moodle', $userid_moodle);
        $stmt->bind(':operador', $operador);
        $stmt->bind(':organica', $organica);
        $stmt->bind(':nivel_inicio', $nivel_inicio);
        $stmt->bind(':pais', $pais);
        $stmt->bind(':familia_cargo', $familia_cargo);
        $stmt->bind(':tipo_cargo', $tipo_cargo);
        $stmt->bind(':codigo_negociacion', $codigo_negociacion);
        $stmt->bind(':fecha_reconocimiento', $fecha_reconocimiento);
        $stmt->bind(':fecha_ingreso_vacaciones', $fecha_ingreso_vacaciones);
        $stmt->bind(':fecha_ingreso_vacaciones', $fecha_ingreso_vacaciones);
        $stmt->bind(':dias_derecho', $dias_derecho);
        $stmt->bind(':dias_pendientes', $dias_pendientes);
        $stmt->bind(':dias_pendientes_real', $dias_pendientes_real);
        $stmt->bind(':cod_cargo_ant', $cod_cargo_ant);
        $stmt->bind(':gls_cargo_ant', $gls_cargo_ant);
        $stmt->bind(':ant_agno_reconoci', $ant_agno_reconoci);
        $stmt->bind(':tipo_renta', $tipo_renta);
        $stmt->bind(':edad', $edad);
        $stmt->bind(':fec_nacim', $fec_nacim);
        $stmt->bind(':silla_id_cargo', $silla_id_cargo);
        $stmt->bind(':silla_cargo', $silla_cargo);
        $stmt->bind(':silla_id_division', $silla_id_division);
        $stmt->bind(':silla_division', $silla_division);
        $stmt->bind(':silla_id_area', $silla_id_area);
        $stmt->bind(':silla_area', $silla_area);
        $stmt->bind(':silla_id_departamento', $silla_id_departamento);
        $stmt->bind(':silla_departamento', $silla_departamento);
        $stmt->bind(':silla_id_zona', $silla_id_zona);
        $stmt->bind(':silla_zona', $silla_zona);
        $stmt->bind(':silla_id_seccion', $silla_id_seccion);
        $stmt->bind(':silla_seccion', $silla_seccion);
        $stmt->bind(':silla_id_oficina', $silla_id_oficina);
        $stmt->bind(':silla_oficina', $silla_oficina);
        $stmt->bind(':silla_id_unidad', $silla_id_unidad);
        $stmt->bind(':silla_unidad', $silla_unidad);
        $stmt->bind(':opc_uniforme', $opc_uniforme);
        $stmt->bind(':est_civil', $est_civil);
        $stmt->bind(':est_civil_glosa', $est_civil_glosa);
        $stmt->bind(':isapre_codigo', $isapre_codigo);
        $stmt->bind(':isapre_glosa', $isapre_glosa);
        $stmt->bind(':sucur_ciudad', $sucur_ciudad);
        $stmt->bind(':sucur_comuna', $sucur_comuna);
        $stmt->bind(':sindi_codigo', $sindi_codigo);
        $stmt->bind(':sindi_glosa', $sindi_glosa);
        $stmt->bind(':fec_indem', $fec_indem);
        $stmt->bind(':teletrabajo', $teletrabajo);

        // Execute the prepared statement
        $stmt->execute();
    }
}



function DeleteFullTbltbl_usuario_ausentismo()
{
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_usuario_ausentismo";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_ausentismo_data($row)
{
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_usuario_ausentismo (rut, dv, tipo_ausentismo, nro_dias, fecha_desde, fecha_hasta, description)
    VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function ControlDotacionInasistencia_data()
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_usuario_ausentismo h";
    $connexion->query($sql);
    $cod = $connexion->resultset();

    foreach ($cod as $unico) {
        if ($unico->tipo_ausentismo == "VAC") {
            $regimen = "Ausente";
            $motivo = "Vacaciones";
        } elseif ($unico->tipo_ausentismo == "PER") {
            $regimen = "Ausente";
            $motivo = "Permiso";
        } elseif ($unico->tipo_ausentismo == "LCM") {
            $regimen = "Ausente";
            $motivo = "Licencia Medica";
        }

        $fecha = explode("/", $unico->fecha_hasta);
        $fecha_termino_2 = $fecha[2] . "-" . $fecha[1] . "-" . $fecha[0];

        $fecha1 = explode("/", $unico->fecha_desde);
        $fecha_inicio_2 = $fecha1[2] . "-" . $fecha1[1] . "-" . $fecha1[0];

        $sql_update = "
        UPDATE tbl_contingencia_2021 
        SET regimen='$regimen', motivo='$motivo', 
        fecha_termino='$fecha_termino_2',
        fecha_inicio='$fecha_inicio_2'
        WHERE num_rut='$unico->rut'
        ";

        if ($unico->rut <> "") {
            $connexion->query($sql_update);
        }
    }
    echo "<script> alert('control dotacion 2021 actualizado segun ausentismo');</script>";
}

function Lista_hhee_data($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_escritorio_horas_extras";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFullTbltbl_escritorio_horas_extras()
{
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_escritorio_horas_extras";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_hhee_data($row)
{
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_escritorio_horas_extras (rut, fecha, minutos_extras, minutos_retro, minutos_informada)
    VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_cargas_data($id_empresa)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_beneficios_cargas";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFullTbltbl_cargas()
{
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_beneficios_cargas";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_cargas_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
    INSERT INTO tbl_beneficios_cargas (
    rut,
    dv,
    nombre_completo,
    tipo_contrato,
    cod_beneficio,
    nivel_fun,
    cod_cargo,
    glosa_cargo,
    sexo,
    fecha_nacimiento,
    edad_anos,
    edad_meses,
    estado_civil,
    fecha_ingreso,
    antiguedad_anos,
    antiguedad_meses,
    cod_unidad,
    glosa_unidad,
    oficina,
    glosa_oficina,
    region,
    empresa,
    origen,
    cod_division,
    glosa_division,
    carga_rut,
    carga_dig,
    carga_nombre,
    carga_sexo,
    carga_fecha_nacimiento,
    edad_carga_anos,
    edad_carga_meses,
    carga_fecha_der,
    carga_fecha_venc,
    carga_fecha_mod,
    carga_parentesco,
    carga_reconocimiento,
    carga_tipo,
    codigo_sindi
)
    VALUES ($row)";

    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_usuario_vacaciones_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select * from tbl_usuario_vacaciones";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFullTbltbl_usuario_vacaciones() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_usuario_vacaciones";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_vacaciones_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
    INSERT INTO tbl_usuario_vacaciones (
        num_rut,
        fec_ini,
        fec_term,
        unida_cuipr,
        rut_dig,
        fec_mvto,
        nro_dias,
        tipo_mov,
        vac_folio,
        vac_rec_rrhh,
        rut_rrhh
    )
    VALUES ($row)";

    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_usuario_permisos_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "select * from tbl_usuario_permisos";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFullTbltbl_usuario_permisos() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_usuario_permisos";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_permisos_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
    INSERT INTO tbl_usuario_permisos (
        num_rut,
        fec_desde,
        fec_hasta,
        unida_cuipr,
        nro_dias,
        tipo_permiso,
        rut_digitador,
        fec_digit,
        permi_estad,
        permi_numpe,
        permi_descr
    )
    VALUES ($row)";

    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_usuario_licencias_medicas_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_usuario_licencias_medicas";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_usuario_licencias_medicas() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_usuario_licencias_medicas";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_licencias_medicas_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
    INSERT INTO tbl_usuario_licencias_medicas (
        num_rut,
        nro_lic,
        fec_inicio,
        fec_termino,
        nro_dias,
        cod_grupo,
        cod_diag,
        cod_tipo_lic,
        cod_recup,
        tipo_reposo,
        horario_reposo_parcial,
        cod_lugar_recup,
        direcc_reposo,
        rut_med,
        fec_emision,
        fec_digit,
        rut_digit,
        isapr_codig,
        unida_cuipr,
        region,
        cod_sucursal,
        fec_rec_rrhh,
        FTE_LLMM,
        Licencia_Maternal_parental
    )
    VALUES ($row)";
	
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_metaspivote_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_mc_metas_pivote";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_mc_metas_pivote() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_mc_metas_pivote";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_metas_pivote_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
    INSERT INTO tbl_mc_metas_pivote (
        rut_completo,
        rut,
        dv,
        nombres,
        tipo_metas,
        descripcion_objetivo,
        criterio_medida,
        ponderacion,
        ponderacion_ajustada,
        grado_cumplimiento,
        bloqueada,
        clasificacion,
        ponderacion_matriz_individual,
        creacion_metas_100,
        lineamiento_estrategico,
        cumplimiento_90,
        cumplimiento_130
    )
    VALUES ($row)";
	
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_tbl_mc_carrera_interna_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_mc_carrera_interna";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_mc_carrera_interna() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_mc_carrera_interna";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_mc_carrera_interna_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
    INSERT INTO tbl_mc_carrera_interna (
        rut,
        cod_empresa,
        cargo_codigo,
        fec_ini,
        fec_ter,
        cargo_glosa
    )
    VALUES ($row)";
	
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_tbl_mc_tramo_desempeno_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_mc_tramo_desempeno";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_mc_tramo_desempeno() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_mc_tramo_desempeno";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_mc_tramo_desempeno_data($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_mc_tramo_desempeno (num_rut, zona_salarial, tramo_gestion_desempeno) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_tbl_mc_bac_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_mc_bac";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_mc_bac() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_mc_bac";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_bac_data($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_mc_bac (rut) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_tbl_mc_potencial_relacionados_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_mc_potencial_relacionados";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_mc_potencial_relacionados() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_mc_potencial_relacionados";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_mc_potencial_relacionados($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_mc_potencial_relacionados (rut, rut_dve, apell_paterno, apell_materno, nombres, estado, fecha_declaracion, cod_empresa) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function TblUsuarioJefatuasExcepciones($tipo, $rut)
{
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $sql = "SELECT * FROM tbl_usuario_excepciones_jefaturas WHERE rut = :rut AND tipo = :tipo";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':tipo', $tipo);
    $cod = $connexion->resultset();
    return $cod[0]->rut_nuevo;
}


function ControlDotacion2021_data() {
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(id) AS cuenta FROM tbl_contingencia_2021 WHERE fecha_inicio <> '0000-00-00'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function ControlDotacion2021_cero_data() {
    $connexion = new DatabasePDO();
    $sql = "SELECT COUNT(id) AS cuenta FROM tbl_contingencia_2021 WHERE fecha_inicio = '0000-00-00'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod[0]->cuenta;
}

function Lista_usuario_gestores_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_gestores";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_gestores_data($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_gestores (cui, rut_gestor, rut_gestor_backup) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function DeleteFullTbltbl_gestores() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_gestores";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_cd_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_2021";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_cd_Fecha_Limite_data($fecha, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_2021 WHERE fecha_termino < '$fecha'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_cd_Fecha_Limite_Vigentes_data($fecha, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_2021 WHERE fecha_termino >= '$fecha'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_cd_reporte_por_dia_data($id_empresa, $mes_desde) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_2021_dia WHERE fecha >= '$mes_desde'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_cd_futuro_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_2021 WHERE regimen_futuro <> ''";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_contingencia_2021() {
    $connexion = new DatabasePDO();
    
    $sql = "DELETE FROM tbl_contingencia_2021";
    $connexion->query($sql);
    
    $sql = "DELETE FROM tbl_contingencia_2021_original";
    $connexion->query($sql);
    
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_cd_data($row) {
    $connexion = new DatabasePDO();

    $sql = "INSERT INTO tbl_contingencia_2021 (
                num_rut,
                regimen,
                motivo,
                fecha_inicio,
                fecha_termino,
                rut_actualizador,
                fecha_actualizacion,
                hora_actualizacion
            )
            VALUES ($row)";

    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Insert_Lista_cd_original_data($row) {
    $connexion = new DatabasePDO();

    $sql = "INSERT INTO tbl_contingencia_2021_original (
                num_rut,
                regimen,
                motivo,
                fecha_inicio,
                fecha_termino,
                rut_actualizador,
                fecha_actualizacion,
                hora_actualizacion
            )
            VALUES ($row)";

    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Update_Lista_cd_data($row) {
    $connexion = new DatabasePDO();

    $porciones = explode(",", $row);

    $sql = "UPDATE tbl_contingencia_2021
            SET 
                regimen='".$porciones[1]."',
                motivo='".$porciones[2]."',
                fecha_inicio='".$porciones[3]."',
                fecha_termino='".$porciones[4]."'
            WHERE num_rut='".$porciones[0]."'";

    if ($porciones[0] <> "") {
        $connexion->query($sql);
        $cod = $connexion->resultset();
    }

    // echo "<br>".$sql;
    // exit();
}

function Lista_usuario_tbl_contingencia_2021_option_data($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "SELECT * FROM tbl_contingencia_2021_option";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
} 

function DeleteFull_tbl_contingencia_2021_option() {
    $connexion = new DatabasePDO();

    $sql = "DELETE FROM tbl_contingencia_2021_option";
    $connexion->query($sql);

    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_contingencia_2021_option($row) {
    $connexion = new DatabasePDO();
    $sql = "
        INSERT INTO tbl_contingencia_2021_option (
            regimen_actual,
            motivo_actual,
            regimen_nuevo,
            motivo_nuevo,
            fecha_inicio,
            fecha_fin,
            muestra_modificar_regimen
        )
        VALUES 
        ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_ubicacion_colaboradores_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_ubicacion_colaboradores";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFull_tbl_contingencia_ubicacion_colaboradores() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_contingencia_ubicacion_colaboradores";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_ubicacion_colaboradores_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
        INSERT INTO tbl_contingencia_ubicacion_colaboradores (
            rut,
            direccion,
            piso,
            referencia,
            temporalidad,
            fecha,
            hora,
            rut_actualizador,
            id_empresa,
            comuna,
            ciudad
        )
        VALUES 
        ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_tbl_contingencia_2021_dia_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_2021_dia";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function ControlDotacion2021_Options_Select_Regimen_Motivo_data() {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.regimen_actual, h.motivo_actual FROM tbl_contingencia_2021_option h GROUP BY h.regimen_actual, h.motivo_actual";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function ControlDotacionUpdateDia_RangoFecha_data($rut, $fecha, $fecha_hasta, $regimen, $motivo) {
    $regimen = utf8_decode($regimen);
    $motivo = utf8_decode($motivo);
    $connexion = new DatabasePDO();
    $begin = new DateTime($fecha);
    $end = new DateTime($fecha_hasta);
    $interval = DateInterval::createFromDateString('1 day');
    $period = new DatePeriod($begin, $interval, $end);
    foreach ($period as $dt) {
        $fecha_update = $dt->format("Y-m-d");
        $sql = "UPDATE tbl_contingencia_2021_dia SET regimen = '$regimen', motivo = '$motivo' WHERE rut = '$rut' AND fecha = '$fecha_update'";
        $connexion->query($sql);
    }
    $sql = "UPDATE tbl_contingencia_2021_dia SET regimen = '$regimen', motivo = '$motivo' WHERE rut = '$rut' AND fecha = '$fecha_hasta'";
    $connexion->query($sql);
}

function Lista_usuario_permiso_unico_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_permiso_temporal";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFull_tbl_permiso_temporal() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_permiso_temporal";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_permiso_unico_data($row) {
    $connexion = new DatabasePDO();
    $sql = "
        INSERT INTO tbl_permiso_temporal (
            rut,
            fec_ingreso_indem,
            Fecha_semana
        )
        VALUES 
        ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_tbl_codigo_poliza_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_codigo_poliza";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_mc_poliza() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_codigo_poliza";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_codigo_poliza_data($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_codigo_poliza (rut,codigo_poliza) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_tbl_contingencia_colaborador_retornado_2021_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_colaborador_retornado_2021";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_contingencia_colaborador_retornado_2021($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_contingencia_colaborador_retornado_2021 (rut) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function DeleteFulltbl_contingencia_colaborador_retornado_2021() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_contingencia_colaborador_retornado_2021";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFull_tbl_trabajo_remoto() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_contingencia_2022_trabajo_remoto";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Lista_usuario_trabajo_remoto_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_2022_trabajo_remoto";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_trabajo_remoto_data($row) {
    $connexion = new DatabasePDO();
    $row = str_replace(" ", "", $row);
    $sql = "INSERT INTO tbl_contingencia_2022_trabajo_remoto (rut,dias_remotos) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function Lista_tbl_contingencia_oficina_ubicacion_2021_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_contingencia_oficina_ubicacion";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_contingencia_oficina_ubicacion($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_contingencia_oficina_ubicacion (oficina,sucur_glosa,direccion,piso,referencia,comuna,ciudad) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function DeleteFulltbl_contingencia_oficina_ubicacion_2022() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_contingencia_oficina_ubicacion";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_actualizacion_carreras_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_da_carreras";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_da_carreras() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_da_carreras";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_da_carreras($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_da_carreras (carreras) VALUES ($row)";
    $connexion->query($sql);
    $cod = $connexion->resultset();
}

function lista_actualizacion_instituciones_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_da_instituciones";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_da_instituciones() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_da_instituciones";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_da_instituciones($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_da_instituciones (institucion) VALUES (:row)";
    $connexion->query($sql);
    $connexion->bind(':row', $row);
    $connexion->execute();
}

function lista_actualizacion_sucursales_data($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_da_sucursales";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function DeleteFulltbl_da_sucursales() {
    $connexion = new DatabasePDO();
    $sql = "DELETE FROM tbl_da_sucursales";
    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function Insert_Lista_tbl_da_sucursales($row) {
    $connexion = new DatabasePDO();
    $sql = "INSERT INTO tbl_da_sucursales (sucursal) VALUES (:row)";
    $connexion->query($sql);
    $connexion->bind(':row', $row);
    $connexion->execute();
    $cod = $connexion->resultset();
}

function DatosAcademicosCampos($id_form) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_da_formularios h WHERE h.id = :id_form";
    $connexion->query($sql);
    $connexion->bind(':id_form', $id_form);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function DatosAcademicosNombreCampos($idc) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_da_formularios_campos h WHERE h.id = :idc";
    $connexion->query($sql);
    $connexion->bind(':idc', $idc);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod[0]->nombre;
}

function DatosAcademicosRespuestas($id_form) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_da_formularios_respuestas WHERE id_form = :id_form AND id_empresa = '78'";
    $connexion->query($sql);
    $connexion->bind(':id_form', $id_form);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function egresados_2023(){

    $connexion = new DatabasePDO();
    $sql = "

        select h.*, (select id from tbl_usuario_temporal where rut=h.rut), j.rut as rut_egreso from tbl_usuario h 
        left join tbl_usuario_historicos_fecha_egreso j on j.rut=h.rut
        where (select id from tbl_usuario_temporal where rut=h.rut) is null and h.vigencia_descripcion='' and j.rut  is null

        ";
    //echo "sql $sql";
   
	$connexion->query($sql);
    $fecha_egreso=date("Y-m-d");
    $cod = $connexion->resultset();
    foreach($cod as $unico) {
        $rut=$unico->rut;
        $rut_completo=$unico->rut_completo;
        $nombre=$unico->nombre;
        $apaterno=$unico->apaterno;
        $amaterno=$unico->amaterno;
        $nombre_completo=$unico->nombre_completo;
        $cargo=$unico->cargo;
        $rut_duplicado=$unico->rut_duplicado;
        $codigo_proceso=$unico->codigo_proceso;
        $id_perfil=$unico->id_perfil;
        $id_rol=$unico->id_rol;
        $id_cargo=$unico->id_cargo;
        $id_empresa=$unico->id_empresa;
        $jefe=$unico->jefe;
        $dependencia=$unico->dependencia;
        $fecha_ingreso=$unico->fecha_ingreso;
        $email=$unico->email;
        $emailBK=$unico->emailBK;
        $negocio=$unico->negocio;
        $zona=$unico->zona;
        $gerencia=$unico->gerencia;
        $area=$unico->area;
        $departamento=$unico->departamento;
        $local=$unico->local;
        $responsable=$unico->responsable;
        $telefono=$unico->telefono;
        $celular=$unico->celular;
        $unidad_negocio=$unico->unidad_negocio;
        $id_area=$unico->id_area;
        $evaluador=$unico->evaluador;
        $perfil_evaluacion=$unico->perfil_evaluacion;
        $seccion=$unico->seccion;
        $ubicacion=$unico->ubicacion;
        $fecha_nacimiento=$unico->fecha_nacimiento;
        $genero=$unico->genero;
        $nacionalidad=$unico->nacionalidad;
        $direccion_particular=$unico->direccion_particular;
        $codigo_escolaridad=$unico->codigo_escolaridad;
        $codigo_nivel=$unico->codigo_nivel;
        $id_centro_costo=$unico->id_centro_costo;
        $centro_costo=$unico->centro_costo;
        $comuna=$unico->comuna;
        $fecha_antiguedad=$unico->fecha_antiguedad;
        $tipo_contrato=$unico->tipo_contrato;
        $tramo_sence=$unico->tramo_sence;
        $dv=$unico->dv;
        $empresa_holding=$unico->empresa_holding;
        $division=$unico->division;
        $porvalidar=$unico->porvalidar;
        $idprivado=$unico->idprivado;
        $antiguedad=$unico->antiguedad;
        $lider=$unico->lider;
        $tallergrupo=$unico->tallergrupo;
        $mundo=$unico->mundo;
        $subgerencia=$unico->subgerencia;
        $estadocivil=$unico->estadocivil;
        $vigencia=$unico->vigencia;
        $id_unidad_negocio=$unico->id_unidad_negocio;
        $escolaridad=$unico->escolaridad;
        $sucursal=$unico->sucursal;
        $nombre_empresa_holding=$unico->nombre_empresa_holding;
        $servicio=$unico->servicio;
        $tipo_servicio=$unico->tipo_servicio;
        $comunidad=$unico->comunidad;
        $id_comunidad=$unico->id_comunidad;
        $vigencia_descripcion=$unico->vigencia_descripcion;
        $nombre_jefatura=$unico->nombre_jefatura;
        $cargo_jefatura=$unico->cargo_jefatura;
        $telefono_jefatura=$unico->telefono_jefatura;
        $email_jefatura=$unico->email_jefatura;
        $id_perfil_competencia=$unico->id_perfil_competencia;
        $perfil_competencia=$unico->perfil_competencia;
        $anexo=$unico->anexo;
        $id_gerencia=$unico->id_gerencia;
        $id_subgerencia=$unico->id_subgerencia;
        $codigo_sap=$unico->codigo_sap;
        $regional=$unico->regional;
        $avatar=$unico->avatar;
        $zonal=$unico->zonal;
        $vicepresidencia=$unico->vicepresidencia;
        $gerenciaR2=$unico->gerenciaR2;
        $gerenciaR3=$unico->gerenciaR3;
        $userid_moodle=$unico->userid_moodle;
        $operador=$unico->operador;
        $organica=$unico->organica;
        $nivel_inicio=$unico->nivel_inicio;
        $pais=$unico->pais;
        $familia_cargo=$unico->familia_cargo;
        $tipo_cargo=$unico->tipo_cargo;



        $sql2 = "INSERT INTO tbl_usuario_historicos_fecha_egreso (rut,
rut_completo,
nombre,
apaterno,
amaterno,
nombre_completo,
cargo,
rut_duplicado,
codigo_proceso,
id_perfil,
id_rol,
id_cargo,
id_empresa,
jefe,
dependencia,
fecha_ingreso,
email,
emailBK,
negocio,
zona,
gerencia,
area,
departamento,
local,
responsable,
telefono,
celular,
unidad_negocio,
id_area,
evaluador,
perfil_evaluacion,
seccion,
ubicacion,
fecha_nacimiento,
genero,
nacionalidad,
direccion_particular,
codigo_escolaridad,
codigo_nivel,
id_centro_costo,
centro_costo,
comuna,
fecha_antiguedad,
tipo_contrato,
tramo_sence,
dv,
empresa_holding,
division,
porvalidar,
idprivado,
antiguedad,
lider,
tallergrupo,
mundo,
subgerencia,
estadocivil,
vigencia,
id_unidad_negocio,
escolaridad,
sucursal,
nombre_empresa_holding,
servicio,
tipo_servicio,
comunidad,
id_comunidad,
vigencia_descripcion,
nombre_jefatura,
cargo_jefatura,
telefono_jefatura,
email_jefatura,
id_perfil_competencia,
perfil_competencia,
anexo,
id_gerencia,
id_subgerencia,
codigo_sap,
regional,
avatar,
zonal,
vicepresidencia,
gerenciaR2,
gerenciaR3,
userid_moodle,
operador,
organica,
nivel_inicio,
pais,
familia_cargo,
tipo_cargo, 
fecha_egreso)
                                        VALUES (
  '$rut', 
'$rut_completo', 
'$nombre', 
'$apaterno', 
'$amaterno', 
'$nombre_completo', 
'$cargo', 
'$rut_duplicado', 
'$codigo_proceso', 
'$id_perfil', 
'$id_rol', 
'$id_cargo', 
'$id_empresa', 
'$jefe', 
'$dependencia', 
'$fecha_ingreso', 
'$email', 
'$emailBK', 
'$negocio', 
'$zona', 
'$gerencia', 
'$area', 
'$departamento', 
'$local', 
'$responsable', 
'$telefono', 
'$celular', 
'$unidad_negocio', 
'$id_area', 
'$evaluador', 
'$perfil_evaluacion', 
'$seccion', 
'$ubicacion', 
'$fecha_nacimiento', 
'$genero', 
'$nacionalidad', 
'$direccion_particular', 
'$codigo_escolaridad', 
'$codigo_nivel', 
'$id_centro_costo', 
'$centro_costo', 
'$comuna', 
'$fecha_antiguedad', 
'$tipo_contrato', 
'$tramo_sence', 
'$dv', 
'$empresa_holding', 
'$division', 
'$porvalidar', 
'$idprivado', 
'$antiguedad', 
'$lider', 
'$tallergrupo', 
'$mundo', 
'$subgerencia', 
'$estadocivil', 
'$vigencia', 
'$id_unidad_negocio', 
'$escolaridad', 
'$sucursal', 
'$nombre_empresa_holding', 
'$servicio', 
'$tipo_servicio', 
'$comunidad', 
'$id_comunidad', 
'$vigencia_descripcion', 
'$nombre_jefatura', 
'$cargo_jefatura', 
'$telefono_jefatura', 
'$email_jefatura', 
'$id_perfil_competencia', 
'$perfil_competencia', 
'$anexo', 
'$id_gerencia', 
'$id_subgerencia', 
'$codigo_sap', 
'$regional', 
'$avatar', 
'$zonal', 
'$vicepresidencia', 
'$gerenciaR2', 
'$gerenciaR3', 
'$userid_moodle', 
'$operador', 
'$organica', 
'$nivel_inicio', 
'$pais', 
'$familia_cargo', 
'$tipo_cargo',
'$fecha_egreso'                                     
                                        
                                        
                                        )";
        //  and fechaI='2017-12-01'
        echo "<br />".$sql2;

        if($nombre_completo<>""){
    $connexion->query($sql2);
    $connexion->execute();
        }

    }
}
function Beneficios_UploadNewFile($idl, $tipo_archivo, $destino_enc) {
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_beneficios_formularios_respuestas SET $tipo_archivo = :destino_enc WHERE id = :idl";
    $connexion->query($sql);
    $connexion->bind(':destino_enc', $destino_enc);
    $connexion->bind(':idl', $idl);
    $connexion->execute();
}

function lista_beneficios_data_form($id_empresa, $id_form) {
    $connexion = new DatabasePDO();
    $sql = "
        SELECT h.*,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_empresa = h.id_empresa AND id_beneficio = h.id_beneficios AND id_form = h.$id_form) AS solicitudes,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_empresa = h.id_empresa AND id_beneficio = h.id_beneficios AND validacion1 <> '' AND id_form = h.$id_form) AS validacion1,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_empresa = h.id_empresa AND id_beneficio = h.id_beneficios AND visto = 1 AND id_form = h.$id_form) AS visto,
        (SELECT nombre FROM tbl_beneficios_workflow WHERE id = h.tipo_workflow) AS nombre_tipo_workflow,
        (SELECT nombre FROM tbl_beneficios_formularios WHERE id = h.$id_form) AS nombre_formulario,
        (SELECT id FROM tbl_beneficios_formularios WHERE id = h.$id_form) AS id_formulario
        FROM tbl_beneficios h
        WHERE h.id_empresa = :id_empresa
        AND h.tipo_workflow <> ''
        AND h.$id_form <> ''
        ORDER BY h.nombre";
    
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    
    return $cod;
}

function Beneficios_BarridoSolicitudes($id_beneficio, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
            SUM(CASE WHEN validacion1 IS NULL THEN 1 ELSE 0 END) AS pendiente,
            SUM(CASE WHEN validacion1 = 'Rechazado_edicion' OR validacion1 = 'Rechazado' THEN 1 ELSE 0 END) AS enproceso,
            SUM(CASE WHEN validacion1 = 'Validado' THEN 1 ELSE 0 END) AS validado
            FROM tbl_beneficios_formularios_respuestas h
            WHERE id_empresa = :id_empresa
            AND id_beneficio = :id_beneficio";
    
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':id_beneficio', $id_beneficio);
    $connexion->execute();
    $cod = $connexion->resultset();
    
    return $cod;
}

function Beneficios_Busca_Estado_Solo_Data($id, $tipo_workflow) {
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_beneficios_formularios_respuestas WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
    $cod = $connexion->resultset();

    $estado = "Pendiente";
    
    if ($tipo_workflow == "1003") {
        if ($cod[0]->validacion1 == "Rechazado_edicion" || $cod[0]->validacion1 == "Rechazado") {
            $estado = "En Proceso";
        }
        if ($cod[0]->validacion1 == "Validado") {
            $estado = "Cerrado";
        }
    }
    
    if ($tipo_workflow == "1008") {
        if ($cod[0]->validacion1 == "Rechazado_edicion" || $cod[0]->validacion1 == "Rechazado" || $cod[0]->validacion1 == "NoGanador") {
            $estado = "En Proceso";
        }
        if ($cod[0]->validacion1 == "Ganador") {
            $estado = "Cerrado";
        }
    }
    
    return $estado;
}

function Beneficios_DeleteIdEmpresa99($id_novigente)
{
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_beneficios_formularios_respuestas SET id_empresa = '99' WHERE id = :id_novigente";
    $connexion->query($sql);
    $connexion->bind(':id_novigente', $id_novigente);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function Beneficios_Update_idFormRespuestas_Admin($id_update, $idc01, $idc02, $idc03, $idc04, $idc05, $idc06, $idc07, $idc08, $idc09, $idc10, $idc11, $idc12, $idc13, $idc14, $idc15, $idc16, $idc17, $idc18, $idc19, $idc20, $idc21)
{
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_beneficios_formularios_respuestas SET idc01 = :idc01, idc02 = :idc02, idc03 = :idc03, idc04 = :idc04, idc05 = :idc05, idc06 = :idc06, idc07 = :idc07, idc08 = :idc08, idc09 = :idc09, idc10 = :idc10, idc11 = :idc11, idc12 = :idc12, idc13 = :idc13, idc14 = :idc14, idc15 = :idc15, idc16 = :idc16, idc17 = :idc17, idc18 = :idc18, idc19 = :idc19, idc20 = :idc20, idc21 = :idc21 WHERE id = :id_update";
    
    $connexion->query($sql);
    $connexion->bind(':idc01', $idc01);
    $connexion->bind(':idc02', $idc02);
    $connexion->bind(':idc03', $idc03);
    $connexion->bind(':idc04', $idc04);
    $connexion->bind(':idc05', $idc05);
    $connexion->bind(':idc06', $idc06);
    $connexion->bind(':idc07', $idc07);
    $connexion->bind(':idc08', $idc08);
    $connexion->bind(':idc09', $idc09);
    $connexion->bind(':idc10', $idc10);
    $connexion->bind(':idc11', $idc11);
    $connexion->bind(':idc12', $idc12);
    $connexion->bind(':idc13', $idc13);
    $connexion->bind(':idc14', $idc14);
    $connexion->bind(':idc15', $idc15);
    $connexion->bind(':idc16', $idc16);
    $connexion->bind(':idc17', $idc17);
    $connexion->bind(':idc18', $idc18);
    $connexion->bind(':idc19', $idc19);
    $connexion->bind(':idc20', $idc20);
    $connexion->bind(':idc21', $idc21);
    $connexion->bind(':id_update', $id_update);
    
    $connexion->execute();
}

function Beneficios_BuscaId($id_beneficio)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, (SELECT nombre FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS beneficio FROM tbl_beneficios_formularios_respuestas h WHERE h.id = :id_beneficio";
    
    $connexion->query($sql);
    $connexion->bind(':id_beneficio', $id_beneficio);
    $connexion->execute();
    $cod = $connexion->resultset();
    
    return $cod;
}

function Beneficios_SaveValidacion($id, $validacion, $comentarios, $val)
{
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    $comentarios = utf8_decode($comentarios);
    if ($val == "validacion1") {
        $sql = "UPDATE tbl_beneficios_formularios_respuestas SET validacion1 = :validacion, fechavalidacion1 = :hoy, comentarios_validacion = :comentarios WHERE id = :id";
        $connexion->query($sql);
        $connexion->bind(':validacion', $validacion);
        $connexion->bind(':hoy', $hoy);
        $connexion->bind(':comentarios', $comentarios);
        $connexion->bind(':id', $id);
        $connexion->execute();
    } elseif ($val == "validacion2") {
        $sql = "UPDATE tbl_beneficios_formularios_respuestas SET validacion2 = :validacion, fechavalidacion2 = :hoy, comentarios_validacion = :comentarios WHERE id = :id";
        $connexion->query($sql);
        $connexion->bind(':validacion', $validacion);
        $connexion->bind(':hoy', $hoy);
        $connexion->bind(':comentarios', $comentarios);
        $connexion->bind(':id', $id);
        $connexion->execute();
    } elseif ($val == "validacion3") {
        $sql = "UPDATE tbl_beneficios_formularios_respuestas SET validacion3 = :validacion, fechavalidacion3 = :hoy, comentarios_validacion = :comentarios WHERE id = :id";
        $connexion->query($sql);
        $connexion->bind(':validacion', $validacion);
        $connexion->bind(':hoy', $hoy);
        $connexion->bind(':comentarios', $comentarios);
        $connexion->bind(':id', $id);
        $connexion->execute();
    } elseif ($val == "validacion4") {
        $sql = "UPDATE tbl_beneficios_formularios_respuestas SET validacion4 = :validacion, fechavalidacion4 = :hoy, comentarios_validacion = :comentarios WHERE id = :id";
        $connexion->query($sql);
        $connexion->bind(':validacion', $validacion);
        $connexion->bind(':hoy', $hoy);
        $connexion->bind(':comentarios', $comentarios);
        $connexion->bind(':id', $id);
        $connexion->execute();
    }
}

function Beneficios_CheckDatosPersonas_Admin($rut)
{
    $connexion = new DatabasePDO();
    $sql = "SELECT email_particular FROM tbl_usuario_cel_email WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod[0]->email_particular;
}

function lista_beneficios_validacion_data($idcategoria, $id_empresa, $id_form, $fecha_inicio, $fecha_termino, $estado)
{
    $connexion = new DatabasePDO();
    $fecha_inicio = $_POST["fecha_inicio_bene"];
    $fecha_termino = $_POST["fecha_termino_bene"];
    $rut = $_POST["rut_bene"];

    if ($fecha_inicio <> "" && $fecha_termino <> "") {

    } else {
        $sietediasatras = date('Y-m-d', strtotime('-60 day'));
        $fecha_inicio = $sietediasatras;
        $fecha_termino = date("Y-m-d");
    }

    if ($idcategoria == "{ID_BENEFICIO}") {
        $QueryCat = " ";
    } else {
        $QueryCat = " AND h.id_beneficio = '$idcategoria' ";
    }

    if ($idcategoria == "") {
        $QueryCat = " ";
    }

    if ($id_form <> "") {
        $QueryIdForm = " AND h.id_form = '$id_form' ";
    } else {
        $QueryIdForm = " ";
    }

    if ($fecha_inicio <> "") {
        $QueryFI = " AND h.fecha >= '$fecha_inicio' ";
    } else {
        $QueryFI = " ";
    }

    if ($fecha_termino <> "") {
        $QueryFT = " AND h.fecha <= '$fecha_termino' ";
    } else {
        $QueryFT = " ";
    }

    if ($estado <> "") {
        $QueryEST = " AND h.validacion1 = '$estado' ";
    } else {
        $QueryEST = " ";
    }

    if ($rut <> "") {
        $QueryRUT = " AND h.rut = '$rut' ";
    } else {
        $QueryRUT = " ";
    }

    if ($estado == "Todos") {
        $QueryEST = " ";
        $sql = "SELECT h.*,
            (SELECT nombre FROM tbl_beneficios_formularios WHERE id = h.id_form) AS nombre_formulario,
            (SELECT nombre FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS beneficio,
            (SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS tipo_workflow,
            (SELECT nombre FROM tbl_beneficios_workflow WHERE id = (SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio)) AS nombre_tipo_workflow,
            (SELECT id_form1 FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS id_form1,
            (SELECT id_form2 FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS id_form2
            FROM tbl_beneficios_formularios_respuestas h
            WHERE h.id > 0
            $QueryCat
            $QueryIdForm
            $QueryFI
            $QueryFT
            $QueryEST
            $QueryRUT
            ORDER BY id DESC";
    } else {
        $sql = "SELECT h.*,
            (SELECT nombre FROM tbl_beneficios_formularios WHERE id = h.id_form) AS nombre_formulario,
            (SELECT nombre FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS beneficio,
            (SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS tipo_workflow,
            (SELECT nombre FROM tbl_beneficios_workflow WHERE id = (SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio)) AS nombre_tipo_workflow,
            (SELECT id_form1 FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS id_form1,
            (SELECT id_form2 FROM tbl_beneficios WHERE id_beneficios = h.id_beneficio) AS id_form2
            FROM tbl_beneficios_formularios_respuestas h
            WHERE h.id_empresa = '$id_empresa'
            $QueryCat
            $QueryIdForm
            $QueryFI
            $QueryFT
            $QueryEST
            $QueryRUT
            ORDER BY id DESC";
    }

    $connexion->query($sql);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function RFBeneficiosBecasVisto($id){
    $connexion = new DatabasePDO();
    $sql = "UPDATE tbl_beneficios_formularios_respuestas SET visto = '1' WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

function BuscaDatosUsuarioCelEmailAdmin($rut){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_usuario_cel_email WHERE rut = :rut";
    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $datos = $connexion->resultset();
    return $datos;
}

function BeneficiosBuscaNombreCampoIdCampo($campo, $id_form1){
    $connexion = new DatabasePDO();
    $sql = "SELECT $campo AS id_campo FROM tbl_beneficios_formularios WHERE id = :id_form1";
    $connexion->query($sql);
    $connexion->bind(':id_form1', $id_form1);
    $cod = $connexion->resultset();

    $sql2 = "SELECT nombre FROM tbl_beneficios_formularios_campos WHERE id = :id_campo";
    $connexion->query($sql2);
    $connexion->bind(':id_campo', $cod[0]->id_campo);
    $cod2 = $connexion->resultset();

    return $cod2[0]->nombre;
}

function Beneficios_Busca_Estado($id, $tipo_workflow){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_beneficios_formularios_respuestas WHERE id = :id";
    $connexion->query($sql);
    $connexion->bind(':id', $id);
    $cod = $connexion->resultset();

    $estado = "<span class='badge badge-gray'>Pendiente</span>";

    if ($tipo_workflow == "1003") {
        if ($cod[0]->validacion1 == "Validado") {
            $estado = "<span class='badge badge-success'>Validado</span>";
        } elseif ($cod[0]->validacion1 == "Rechazado_edicion") {
            $estado = "<span class='badge badge-warning'>Rechazado_edicion</span>";
        } elseif ($cod[0]->validacion1 == "Rechazado") {
            $estado = "<span class='badge badge-danger'>Rechazado</span>";
        }
    }

    $estado = "<br>" . $estado;

    return $estado;
}

function dataFullForm_nombre($id_form){
    $connexion = new DatabasePDO();
    $sql = "SELECT nombre FROM tbl_beneficios_formularios WHERE id = :id_form";
    $connexion->query($sql);
    $connexion->bind(':id_form', $id_form);
    $cod = $connexion->resultset();
    return $cod[0]->nombre;
}

function lista_chileactivo_v2_validacion_data($idcategoria, $id_empresa, $id_form, $fecha_inicio, $fecha_termino, $estado) {
    $connexion = new DatabasePDO();

    if ($idcategoria == "{ID_BENEFICIO}") {
        $QueryCat = " ";
    } else {
        $QueryCat = " and h.id_beneficio='$idcategoria' ";
    }

    if ($idcategoria == "") {
        $QueryCat = " ";
    }

    if ($id_form <> "") {
        $QueryIdForm = " and h.id_form='$id_form' ";
    } else {
        $QueryIdForm = " ";
    }

    if ($fecha_inicio <> "") {
        $QueryFI = " and h.fecha>='$fecha_inicio' ";
    } else {
        $QueryFI = " ";
    }

    if ($fecha_termino <> "") {
        $QueryFT = " and h.fecha<='$fecha_termino' ";
    } else {
        $QueryFT = " ";
    }

    if ($estado <> "") {
        $QueryEST = " and h.validacion1='$estado' ";
    } else {
        $QueryEST = " ";
    }

    if ($estado == "Todos") {
        $QueryEST = " ";
        $sql = "select h.*, 
            (select nombre from tbl_beneficios_formularios where id=h.id_form) as nombre_formulario,
            (select nombre from tbl_chileactivo where id_beneficios=h.id_beneficio) as beneficio,
            (select tipo_workflow from tbl_chileactivo where id_beneficios=h.id_beneficio) as tipo_workflow,
            (select nombre from tbl_beneficios_workflow where id=(select tipo_workflow from tbl_beneficios where id_beneficios=h.id_beneficio)) as nombre_tipo_workflow,
            (select id_form1 from tbl_chileactivo where id_beneficios=h.id_beneficio) as id_form1,
            (select id_form2 from tbl_chileactivo where id_beneficios=h.id_beneficio) as id_form2
            from tbl_beneficios_formularios_respuestas h
            where h.id > 0
            $QueryCat 
            $QueryIdForm
            $QueryFI
            $QueryFT
            $QueryEST
            order by id DESC";
    } else {
        $sql = "select h.*, 
            (select nombre from tbl_beneficios_formularios where id=h.id_form) as nombre_formulario,
            (select nombre from tbl_beneficios where id_beneficios=h.id_beneficio) as beneficio,
            (select tipo_workflow from tbl_beneficios where id_beneficios=h.id_beneficio) as tipo_workflow,
            (select nombre from tbl_beneficios_workflow where id=(select tipo_workflow from tbl_beneficios where id_beneficios=h.id_beneficio)) as nombre_tipo_workflow,
            (select id_form1 from tbl_beneficios where id_beneficios=h.id_beneficio) as id_form1,
            (select id_form2 from tbl_beneficios where id_beneficios=h.id_beneficio) as id_form2
            from tbl_beneficios_formularios_respuestas h
            where h.id_empresa='$id_empresa'
            $QueryCat 
            $QueryIdForm
            $QueryFI
            $QueryFT
            $QueryEST
            order by id DESC";
    }

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function BuscaCamposSegunForm($id_form, $campo)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT $campo AS id_campo FROM tbl_beneficios_formularios WHERE id = :id_form";
    //echo $sql;
    $connexion->query($sql);
    $connexion->bind(':id_form', $id_form);
    $cod = $connexion->resultset();
    $id_campo = $cod[0]->id_campo;

    $sql = "SELECT nombre AS campo FROM tbl_beneficios_formularios_campos WHERE id = :id_campo";
    $connexion->query($sql);
    $connexion->bind(':id_campo', $id_campo);
    $cod = $connexion->resultset();

    return ($cod[0]->campo);
}

function lista_beneficios_historicos_data_form($id_empresa, $id_form)
{
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*, (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas_historicos WHERE id_empresa = h.id_empresa AND id_beneficio = h.id_beneficios AND id_form = h.$id_form) AS solicitudes, (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas_historicos WHERE id_empresa = h.id_empresa AND id_beneficio = h.id_beneficios AND validacion1 <> '' AND id_form = h.$id_form) AS validacion1, (SELECT nombre FROM tbl_beneficios_workflow WHERE id = h.tipo_workflow) AS nombre_tipo_workflow, (SELECT nombre FROM tbl_beneficios_formularios WHERE id = h.$id_form) AS nombre_formulario, (SELECT id FROM tbl_beneficios_formularios WHERE id = h.$id_form) AS id_formulario FROM tbl_beneficios h WHERE h.id_empresa = :id_empresa AND h.tipo_workflow <> '' AND h.$id_form <> '' ORDER BY h.nombre";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();

    return $cod;
}

function lista_beneficios_validacion_historicos_data($idcategoria, $id_empresa, $id_form, $fecha_inicio, $fecha_termino, $estado) {

    $connexion = new DatabasePDO();
    $sql = "";

    if($idcategoria=="{ID_BENEFICIO}"){
        $QueryCat =" ";
    } else {
        $QueryCat =" and h.id_beneficio=:idcategoria ";
    }

    if($idcategoria==""){
        $QueryCat =" ";
    }

    if($id_form<>""){
        $QueryIdForm =" and h.id_form=:id_form ";
    } else {
        $QueryIdForm =" ";
    }

    if($fecha_inicio<>""){
        $QueryFI =" and h.fecha>=:fecha_inicio ";
    } else {
        $QueryFI =" ";
    }

    if($fecha_termino<>""){
        $QueryFT =" and h.fecha<=:fecha_termino ";
    } else {
        $QueryFT =" ";
    }

    if($estado <>""){
        $QueryEST =" and h.validacion1=:estado ";
    } else {
        $QueryEST =" ";
    }

    if($estado=="Todos"){
        $QueryEST =" ";
        $sql = "select h.*, 
        (select nombre from tbl_beneficios_formularios where id=h.id_form) as nombre_formulario,
        (select nombre from tbl_beneficios where id_beneficios=h.id_beneficio) as beneficio,
        (select tipo_workflow from tbl_beneficios where id_beneficios=h.id_beneficio) as tipo_workflow,
        (select nombre from tbl_beneficios_workflow where id=(select tipo_workflow from tbl_beneficios where id_beneficios=h.id_beneficio)) as nombre_tipo_workflow,
        (select id_form1 from tbl_beneficios where id_beneficios=h.id_beneficio) as id_form1,
        (select id_form2 from tbl_beneficios where id_beneficios=h.id_beneficio) as id_form2

        from tbl_beneficios_formularios_respuestas_historicos h

        where 
        h.id > 0
                     
        $QueryCat 
        $QueryIdForm
        
        $QueryFI
        $QueryFT
        
        $QueryEST
                     
        order by id DESC";
    } else {
        $sql = "select h.*, 
        (select nombre from tbl_beneficios_formularios where id=h.id_form) as nombre_formulario,
        (select nombre from tbl_beneficios where id_beneficios=h.id_beneficio) as beneficio,
        (select tipo_workflow from tbl_beneficios where id_beneficios=h.id_beneficio) as tipo_workflow,
        (select nombre from tbl_beneficios_workflow where id=(select tipo_workflow from tbl_beneficios where id_beneficios=h.id_beneficio)) as nombre_tipo_workflow,
        (select id_form1 from tbl_beneficios where id_beneficios=h.id_beneficio) as id_form1,
        (select id_form2 from tbl_beneficios where id_beneficios=h.id_beneficio) as id_form2

        from tbl_beneficios_formularios_respuestas_historicos h

        where h.id_empresa=:id_empresa 
                     
        $QueryCat 
        $QueryIdForm
        
        $QueryFI
        $QueryFT
        
        $QueryEST
                     
        order by id DESC";
    }

    $connexion->query($sql);
    $connexion->bind(':idcategoria', $idcategoria);
    $connexion->bind(':id_form', $id_form);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->bind(':estado', $estado);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_beneficios_agendamiento_data($idcategoria, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_beneficios_eventos h WHERE h.ocupada<>'' ORDER BY h.fecha_inicio DESC, h.hora_inicio DESC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Beneficios_Agenda_2020_VistaEvento($idr){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
        (SELECT nombre FROM tbl_beneficios_agenda WHERE id=h.id_agenda) AS agenda,
        (SELECT nombre FROM tbl_beneficios_especialistas WHERE rut=h.id_especialista) AS especialista,
        (SELECT email FROM tbl_beneficios_especialistas WHERE rut=h.id_especialista) AS email_especialista
        FROM tbl_beneficios_eventos h WHERE h.id=:idr";
    $connexion->query($sql);
    $connexion->bind(':idr', $idr);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_beneficios_agendamiento_SinShowdata($idcategoria, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_beneficios_eventos h WHERE h.ocupada<>'' AND h.id_agenda<>'2000' ORDER BY h.fecha_inicio DESC, h.hora_inicio DESC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_beneficios_agendamiento_ConShowdata($idcategoria, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.* FROM tbl_beneficios_eventos h WHERE h.ocupada<>'' AND h.id_agenda='2000' ORDER BY h.fecha_inicio DESC, h.hora_inicio DESC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_beneficios_data_fichas_sociales_form($id_empresa, $id_form) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas_ficha WHERE id_empresa=h.id_empresa AND id_form=h.id) AS solicitudes,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas_ficha WHERE id_empresa=h.id_empresa AND id_form=h.id AND validacion1<>'') AS validacion1,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas_ficha WHERE id_empresa=h.id_empresa AND id_form=h.id AND visto=1) AS visto
        FROM tbl_beneficios_formularios h
        WHERE h.id_empresa=:id_empresa AND h.descripcion='Ficha_Beneficios'
        ORDER BY h.nombre";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_beneficios_validacion_ficha_social_data($idcategoria, $id_empresa, $id_form, $fecha_inicio, $fecha_termino, $estado) {
    $connexion = new DatabasePDO();
    $database = $connexion->getDb();

    if ($idcategoria == "{ID_BENEFICIO}") {
        $QueryCat = " ";
    } else {
        $QueryCat = " and h.id_beneficio=:idcategoria ";
    }

    if ($idcategoria == "") {
        $QueryCat = " ";
    }

    if ($id_form <> "") {
        $QueryIdForm = " and h.id_form=:id_form ";
    } else {
        $QueryIdForm = " ";
    }

    if ($fecha_inicio <> "") {
        $QueryFI = " and h.fecha>=:fecha_inicio ";
    } else {
        $QueryFI = " ";
    }

    if ($fecha_termino <> "") {
        $QueryFT = " and h.fecha<=:fecha_termino ";
    } else {
        $QueryFT = " ";
    }

    if ($estado <> "") {
        $QueryEST = " and h.validacion1=:estado ";
    } else {
        $QueryEST = " ";
    }

    if ($estado == "Todos") {
        $QueryEST = " ";
        $sql = "SELECT h.*, 
        (SELECT nombre FROM tbl_beneficios_formularios WHERE id=h.id_form) AS nombre_formulario,
        (SELECT nombre FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS beneficio,
        (SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS tipo_workflow,
        (SELECT nombre FROM tbl_beneficios_workflow WHERE id=(SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio)) AS nombre_tipo_workflow,
        (SELECT id_form1 FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS id_form1,
        (SELECT id_form2 FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS id_form2
        FROM tbl_beneficios_formularios_respuestas_ficha h
        WHERE h.id > 0
        $QueryCat 
        $QueryIdForm
        $QueryFI
        $QueryFT
        $QueryEST
        ORDER BY id DESC";
    } else {
        $sql = "SELECT h.*, 
        (SELECT nombre FROM tbl_beneficios_formularios WHERE id=h.id_form) AS nombre_formulario,
        (SELECT nombre FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS beneficio,
        (SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS tipo_workflow,
        (SELECT nombre FROM tbl_beneficios_workflow WHERE id=(SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio)) AS nombre_tipo_workflow,
        (SELECT id_form1 FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS id_form1,
        (SELECT id_form2 FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS id_form2
        FROM tbl_beneficios_formularios_respuestas_ficha h
        WHERE h.id_empresa=:id_empresa
        $QueryCat 
        $QueryIdForm
        $QueryFI
        $QueryFT
        $QueryEST
        ORDER BY id DESC";
    }

    $connexion->query($sql);
    $connexion->bind(':idcategoria', $idcategoria);
    $connexion->bind(':id_form', $id_form);
    $connexion->bind(':fecha_inicio', $fecha_inicio);
    $connexion->bind(':fecha_termino', $fecha_termino);
    $connexion->bind(':estado', $estado);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_tbl_usuario_cel_email($id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_usuario_cel_email";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function downloadexamenmedicodata(){
    $connexion = new DatabasePDO();
    $sql = "SELECT h.rut, (SELECT nombre_completo FROM tbl_usuario WHERE rut = h.rut) as nombre, (SELECT email FROM tbl_usuario WHERE rut = h.rut) as email, h.punto, h.fecha, h.bloque FROM tbl_calendario_examen_mujer_respuestas h";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_beneficios_agendamiento_v2_data($idcategoria, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_beneficios_eventos WHERE ocupada <> '' ORDER BY fecha_inicio DESC, hora_inicio DESC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_solicitudes_uniformes_data($id_empresa, $segmento, $post) {
    $connexion = new DatabasePDO();
    if ($post["fecha_desde"] != "") {
        $Jquery_FechaDesde = "AND h.fecha >= '" . $post["fecha_desde"] . "'";
    } else {
        $Jquery_FechaDesde = "";
    }
    if ($post["fecha_hasta"] != "") {
        $Jquery_FechaHasta = "AND h.fecha <= '" . $post["fecha_hasta"] . "'";
    } else {
        $Jquery_FechaHasta = "";
    }
    $sql = "SELECT h.*, (SELECT segmento FROM tbl_vestuario_prenda WHERE id = h.id_prenda) as segmento_prenda, (SELECT temporada FROM tbl_vestuario_prenda WHERE id = h.id_prenda) as temporada_prenda FROM tbl_vestuario_usuario_talla h WHERE h.validacion = '1' AND (SELECT segmento FROM tbl_vestuario_prenda WHERE id = h.id_prenda) LIKE '%" . $segmento . "%' " . $Jquery_FechaDesde . " " . $Jquery_FechaHasta . " GROUP BY h.rut";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Uniformes_BarridoSolicitudes($rut, $id_empresa){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_vestuario_usuario_talla WHERE rut = '$rut'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function uniformes_optionstemporadaslimit1(){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_vestuario_temporada_options ORDER BY id DESC LIMIT 1";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Uniformes_OptionsTemporadas(){
    $connexion = new DatabasePDO();
    $sql = "SELECT * FROM tbl_vestuario_temporada_options ORDER BY id DESC";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function Uniformes_OptionsTemporadasId($id){
    $connexion = new DatabasePDO();
    $sql = "SELECT temporada FROM tbl_vestuario_temporada_options WHERE id_temporada = '$id'";
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod[0]->temporada;
}

function lista_uniformes_v3_validacion_GroupbyRutdata($FechaDesde, $FechaHasta, $segmento, $id_empresa)
{
    $connexion = new DatabasePDO();
    
    if ($segmento != "") {
        $QueryFI = " and (
            SELECT
                segmento
            FROM
                tbl_vestuario_prenda
            WHERE
                id = h.id_prenda
        ) like '%$segmento%' ";
    } else {
        $QueryFI = " ";
    }
    
    if ($FechaDesde != "") {
        $QFD = "  and fecha>='$FechaDesde' ";
    }
    
    if ($FechaHasta != "") {
        $QFH = "  and fecha<='$FechaHasta' ";
    }
    
    $sql = "
        select h.*,
            (
                SELECT
                    prenda
                FROM
                    tbl_vestuario_prenda
                WHERE
                    id = h.id_prenda
            ) AS prenda,
            (
                SELECT
                    segmento
                FROM
                    tbl_vestuario_prenda
                WHERE
                    id = h.id_prenda
            ) AS segmento_prenda,
            (
                SELECT
                    temporada
                FROM
                    tbl_vestuario_prenda
                WHERE
                    id = h.id_prenda
            ) AS temporada_prenda,
            (
                SELECT
                    maternal
                FROM
                    tbl_vestuario_prenda
                WHERE
                    id = h.id_prenda
            ) AS maternal_prenda
        from tbl_vestuario_usuario_talla h
        WHERE h.id > 0
            and h.validacion = '1'
            $QFD
            $QFH
            $QueryFI
        group by h.rut
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_uniformes_v4_PorRutvalidacion_porlinea_data($FechaDesde, $FechaHasta, $segmento, $id_empresa, $rut, $like, $limit) {

    $connexion = new DatabasePDO();
    
    if($segmento !== ""){
        $QueryFI = " and (
            SELECT segmento
            FROM tbl_vestuario_prenda
            WHERE id = h.id_prenda
        ) like '%$segmento%' ";
    } else {
        $QueryFI = " ";
    }
    
    if($FechaDesde !== ""){
        $QFD = " and fecha >= '$FechaDesde' ";
    }
    if($FechaHasta !== ""){
        $QFH = " and fecha <= '$FechaHasta' ";
    }   
    
    $sql = "
        select h.*,
            (
                SELECT prenda
                FROM tbl_vestuario_prenda
                WHERE id = h.id_prenda
            ) AS prenda,
            (
                SELECT segmento
                FROM tbl_vestuario_prenda
                WHERE id = h.id_prenda
            ) AS segmento_prenda,
            (
                SELECT temporada
                FROM tbl_vestuario_prenda
                WHERE id = h.id_prenda
            ) AS temporada_prenda,
            (
                SELECT maternal
                FROM tbl_vestuario_prenda
                WHERE id = h.id_prenda
            ) AS maternal_prenda
        from tbl_vestuario_usuario_talla h
        WHERE h.id > 0
            AND h.rut = :rut
            $QFD
            $QFH
            $QueryFI
            AND (
                SELECT prenda
                FROM tbl_vestuario_prenda
                WHERE id = h.id_prenda
            ) LIKE :like
        LIMIT :limit";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->bind(':like', $like . '%');
    $connexion->bind(':limit', $limit);
    $cod = $connexion->resultset();
    return $cod;
}

function ActualizaEstadoPrendaRut($id, $estado){
    $connexion = new DatabasePDO();
    
    $hoy = date("Y-m-d");
    
    $jquer1 = "";
    $jquer2 = "";
    
    if($estado == "En Confeccion"){
        $jquer1 = ", enconfeccion='1', fechaenconfeccion='".$hoy."'";
    }

    if($estado == "Despachado"){
        $jquer2 = ", despachado='1', fecha_despachado='".$hoy."'";
    }

    $sql = "UPDATE tbl_vestuario_usuario_talla
        SET estado = :estado
        $jquer1
        $jquer2
        WHERE id = :id";

    $connexion->query($sql);
    $connexion->bind(':estado', $estado);
    $connexion->bind(':id', $id);
    $connexion->execute();
}

function Chileactivo_dd_BuscaId($id_beneficio){
    $connexion = new DatabasePDO();
    
    $sql = "
        SELECT h.*,
            (SELECT nombre FROM tbl_chileactivo WHERE id_beneficios = h.id_beneficio) AS beneficio
        FROM tbl_beneficios_formularios_respuestas h
        WHERE h.id = :id_beneficio";

    $connexion->query($sql);
    $connexion->bind(':id_beneficio', $id_beneficio);
    $cod = $connexion->resultset();
    return $cod;
}

function UpdateVestuarioEstadosMasivos($rut_col, $estado_masivo)
{
    $connexion = new DatabasePDO();
    $hoy = date("Y-m-d");
    if ($estado_masivo == "Despachado") {
        $set = " set estado='Despachado', despachado='1', fecha_despachado='$hoy'";
    }
    if ($estado_masivo == "En Confeccion") {
        $set = " set estado='En Confeccion', enconfeccion='1', fechaenconfeccion='$hoy'";
    }

    $sql = "update tbl_vestuario_usuario_talla $set  where rut=:rut_col and (estado is null or estado='En Confeccion' or estado='' or estado='Despachado') ";

    $connexion->query($sql);
    $connexion->bind(':rut_col', $rut_col);
    $connexion->execute();
}

function lista_uniformes_validacion_data($rut, $id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "
        SELECT
            h.*,
            (
                SELECT
                    prenda
                FROM
                    tbl_vestuario_prenda
                WHERE
                    id = h.id_prenda
            ) AS prenda,
            (
                SELECT
                    segmento
                FROM
                    tbl_vestuario_prenda
                WHERE
                    id = h.id_prenda
            ) AS segmento_prenda,
            (
                SELECT
                    temporada
                FROM
                    tbl_vestuario_prenda
                WHERE
                    id = h.id_prenda
            ) AS temporada_prenda
        FROM
            tbl_vestuario_usuario_talla h
        WHERE
            h.validacion = '1'
            AND h.rut = :rut
    ";

    $connexion->query($sql);
    $connexion->bind(':rut', $rut);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function lista_solicitudes_chileactivo_data($id_empresa)
{
    $connexion = new DatabasePDO();

    $sql = "
        SELECT
            h.*,
            (
                SELECT
                    COUNT(id)
                FROM
                    tbl_beneficios_formularios_respuestas
                WHERE
                    id_empresa = h.id_empresa
                    AND id_beneficio = h.id_beneficios
            ) AS solicitudes,
            (
                SELECT
                    COUNT(id)
                FROM
                    tbl_beneficios_formularios_respuestas
                WHERE
                    id_empresa = h.id_empresa
                    AND id_beneficio = h.id_beneficios
                    AND validacion1 <> ''
            ) AS validacion1,
            (
                SELECT
                    nombre
                FROM
                    tbl_beneficios_workflow
                WHERE
                    id = h.tipo_workflow
            ) AS nombre_tipo_workflow
        FROM
            tbl_chileactivo h
        WHERE
            h.id_empresa = :id_empresa
            AND h.tipo_workflow <> ''
            AND h.id_categoria <> 'bch_ton'
            AND h.id_categoria <> 'bch_ch_13'
        ORDER BY
            h.nombre
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function lista_chileactivo_validacion_data($idcategoria, $id_empresa)
{
    $connexion = new DatabasePDO();


    $sql = "
        SELECT
            h.*,
            ca.nombre AS beneficio,
            ca.tipo_workflow,
            ca.id_form1,
            ca.id_form2
        FROM
            tbl_beneficios_formularios_respuestas h
        INNER JOIN
            tbl_chileactivo ca
            ON ca.id_beneficios = h.id_beneficio
        WHERE
            h.id_empresa = :id_empresa
            AND h.id_beneficio = :idcategoria
        ORDER BY
            h.id DESC
    ";

    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $connexion->bind(':idcategoria', $idcategoria);
    $connexion->execute();
    $cod = $connexion->resultset();
    return $cod;
}

function lista_chileactivo_validacion_full_data($idcategoria, $id_empresa, $id_form, $fecha_inicio, $fecha_termino, $estado) {

    $connexion = new DatabasePDO();

    if ($idcategoria == "{ID_BENEFICIO}") {
        $QueryCat = " ";
    } else {
        $QueryCat = " AND h.id_beneficio='$idcategoria' ";
    }

    if ($idcategoria == "") {
        $QueryCat = " ";
    }

    if ($id_form <> "") {
        $QueryIdForm = " AND h.id_form='$id_form' ";
    } else {
        $QueryIdForm = " ";
    }

    if ($fecha_inicio <> "") {
        $QueryFI = " AND h.fecha>='$fecha_inicio' ";
    } else {
        $QueryFI = " ";
    }

    if ($fecha_termino <> "") {
        $QueryFT = " AND h.fecha<='$fecha_termino' ";
    } else {
        $QueryFT = " ";
    }

    if ($estado <> "") {
        $QueryEST = " AND h.validacion1='$estado' ";
    } else {
        $QueryEST = " ";
    }

    $estado == "Todos";

    $QueryEST = " ";
    $sql = "SELECT h.*,
            (SELECT nombre FROM tbl_beneficios_formularios WHERE id=h.id_form) AS nombre_formulario,
            (SELECT nombre FROM tbl_chileactivo WHERE id_beneficios=h.id_beneficio) AS beneficio,
            (SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS tipo_workflow,
            (SELECT nombre FROM tbl_beneficios_workflow WHERE id=(SELECT tipo_workflow FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio)) AS nombre_tipo_workflow,
            (SELECT id_form1 FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS id_form1,
            (SELECT id_form2 FROM tbl_beneficios WHERE id_beneficios=h.id_beneficio) AS id_form2
            FROM tbl_beneficios_formularios_respuestas h
            WHERE
            h.id > 0
            AND (SELECT nombre FROM tbl_chileactivo WHERE id_beneficios=h.id_beneficio) IS NOT NULL
            $QueryCat
            $QueryIdForm
            $QueryFI
            $QueryFT
            $QueryEST
            ORDER BY id DESC ";
    
    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_solicitudes_chileactivo_data_v2($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_empresa=h.id_empresa AND id_beneficio=h.id_beneficios) AS solicitudes,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_empresa=h.id_empresa AND id_beneficio=h.id_beneficios AND validacion1<>'') AS validacion1,
        (SELECT nombre FROM tbl_beneficios_workflow WHERE id=h.tipo_workflow) AS nombre_tipo_workflow
        FROM tbl_chileactivo h WHERE h.id_empresa='$id_empresa'
        AND h.tipo_workflow<>''
        AND h.id_categoria='bch_ton'
        ORDER BY h.nombre
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_chileactivo_inscripcion_validacion_data($idcategoria, $id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*, 'Inscripción' AS tipo FROM tbl_chileactivo_inscripcion h
        WHERE h.fecha IS NOT NULL
        AND h.id_empresa='78'
        UNION
        SELECT j.*, 'Desinscripción' AS tipo FROM tbl_chileactivo_deinscripcion j
        WHERE j.fecha IS NOT NULL
        AND j.id_empresa='78'
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_chileactivo_inscripcion_full_data($idcategoria, $id_empresa, $id_form, $fecha_inicio, $fecha_termino, $estado) {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*
            FROM tbl_chileactivo_inscripcion h
            WHERE h.id_empresa='78'";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_chileactivo_desinscripcion_full_data($idcategoria, $id_empresa, $id_form, $fecha_inicio, $fecha_termino, $estado) {
    $connexion = new DatabasePDO();

    $sql = "SELECT h.*
            FROM tbl_chileactivo_deinscripcion h
            WHERE h.id_empresa='78'";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_solicitudes_chileactivo_data_v3($id_empresa) {
    $connexion = new DatabasePDO();

    $sql = "
        SELECT h.*,
        (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_beneficio=h.id_beneficios AND validacion1='Desinscripcion') AS desinscripciones
        FROM tbl_chileactivo h WHERE h.id_empresa='$id_empresa'
        AND h.tipo_workflow<>''
        AND h.id_categoria = 'bch_ton' OR h.id_categoria <>'bch_ton'
        ORDER BY h.nombre
    ";

    $connexion->query($sql);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_chileactivo_desinscripcion_data($idcategoria, $id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*, 
            (SELECT nombre FROM tbl_chileactivo WHERE id_beneficios = :idcategoria) AS beneficio,
            (SELECT tipo_workflow FROM tbl_chileactivo WHERE id_beneficios = :idcategoria) AS tipo_workflow,
            (SELECT id_form1 FROM tbl_chileactivo WHERE id_beneficios = :idcategoria) AS id_form1,
            (SELECT id_form2 FROM tbl_chileactivo WHERE id_beneficios = :idcategoria) AS id_form2
            FROM tbl_beneficios_formularios_respuestas h
            WHERE validacion1 = 'Desinscripcion' AND h.id_beneficio = :idcategoria ORDER BY id DESC";
    $connexion->query($sql);
    $connexion->bind(':idcategoria', $idcategoria);
    $connexion->bind(':idcategoria', $idcategoria);
    $connexion->bind(':idcategoria', $idcategoria);
    $connexion->bind(':idcategoria', $idcategoria);
    $cod = $connexion->resultset();
    return $cod;
}

function lista_solicitudes_chileactivo_data_v4($id_empresa) {
    $connexion = new DatabasePDO();
    $sql = "SELECT h.*,
            (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_empresa = h.id_empresa AND id_beneficio = h.id_beneficios) AS solicitudes,
            (SELECT COUNT(id) FROM tbl_beneficios_formularios_respuestas WHERE id_empresa = h.id_empresa AND id_beneficio = h.id_beneficios AND validacion1 <> '') AS validacion1,
            (SELECT nombre FROM tbl_beneficios_workflow WHERE id = h.tipo_workflow) AS nombre_tipo_workflow
            FROM tbl_chileactivo h
            WHERE h.id_empresa = :id_empresa AND h.id_categoria = 'bch_ch_13'
            ORDER BY h.nombre";
    $connexion->query($sql);
    $connexion->bind(':id_empresa', $id_empresa);
    $cod = $connexion->resultset();
    return $cod;
}
?>